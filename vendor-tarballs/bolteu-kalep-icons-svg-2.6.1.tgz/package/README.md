<div align="center">

# Kalep Icons SVG

SVG icons for Kalep Design System.
<br />

[Browse](https://kalep.uip.boltint.net/@bolteu/kalep-icons-svg/index.html) •
[Source](https://www.figma.com/file/Qbht5Bzpz6aLVJh1EXpaDp/UI-Foundation---Icons?node-id=9131%3A1&t=tcVkDu1F71VpnEcp-1) •
[Support](https://taxify.slack.com/archives/C034P1EFKDF)

<img width="150" src="../../assets/kalep-logo.png">
</div>

## Getting started

### Installation

**npm**

```
npm install @bolteu/kalep-icons-svg
```

**yarn**

```
yarn add @bolteu/kalep-icons-svg
```

### Choosing icons

See our [icons demo page](https://kalep.uip.boltint.net/@bolteu/kalep-icons-svg/index.html) and [Figma source file](https://www.figma.com/file/Qbht5Bzpz6aLVJh1EXpaDp/UI-Foundation---Icons?node-id=9131%3A1&t=tcVkDu1F71VpnEcp-1) to browse and choose proper icons. Note that icons on the "Payment icons" Figma artboard are prefixed with `Payment` when imported, e.g. `PaymentMasterCard`.

## Contributing

Thank you for your desire to contribute to Kalep! Read our [Kalep Contribution Guide](https://github.com/bolteu/kalep/blob/main/CONTRIBUTING.md) for a better overview of the repository contribution process.

### Guides

#### Updating icons

Fetching new icons and updates from Figma is currently done locally, using the script in `./scripts/fetch-from-figma`.

To update icons you need a Figma API token. Go to Figma, click on your _Profile Avatar_ top-right corner, then _Settings_. In the _Account_ tab, scroll down to the _Personal access tokens_ section, enter a token description, and generate the token. Copy the token and use it in the command below.

Run the following in a terminal:

```sh
$ FIGMA_ACCESS_TOKEN=<your-token-here> pnpm run fetch-from-figma
```

It will export and download icon SVGs and place them in `kalep-icons` folder. Commit and make a PR with the added/updated icons.
In addition to icons the `docs/icons.json` file is updated to match the newest icons. Commit this file too. It is used in generating the documentation site for icons.

Note that the script is considered a hack. The Icons page in Figma is not guaranteed to keep the same structure and thus the script may break on any changes.
It's expected that this situation will improve in the not too distant future.
