<div align="center">

# Kalep Tailwind

TailwindCSS configuration for Kalep Design System.
<br />

[Justification](https://taxify.atlassian.net/wiki/spaces/DS/pages/3718416232/RFC+Component+library+for+web#Tailwind-setup) •
[Tailwind docs](https://tailwindcss.com/docs/installation) •
[Support](https://taxify.slack.com/archives/C034P1EFKDF)

<img width="150" src="../../assets/kalep-logo.png">
</div>

## Getting started

### Peer dependencies

* [`tailwindcss`](https://www.npmjs.com/package/tailwindcss)

### Installation

#### Tailwind config

**npm**
```
npm install -D @bolteu/kalep-tailwind
```

**yarn**

```
yarn add -D @bolteu/kalep-tailwind
```

In your project `tailwind.config.js` add:

```javascript
presets: [require("@bolteu/kalep-tailwind/tailwind.config")];
```

So your resulting `tailwind.config.js` file would look something like:

```javascript
module.exports = {
    // ...
    presets: [require("@bolteu/kalep-tailwind/tailwind.config")],

    // Project-specific customizations
    theme: {
        //...
    },
};
```

You will need to have one entrypoint CSS file that includes the `@tailwind` directives (https://tailwindcss.com/docs/installation).

If your setup contains other styling approaches besides Tailwind (e.g Material-UI, regular CSS or SASS), it is highly recommended to use CSS Cascade Layers. This will help avoid unexpected clashes between styles. Read about the preferred setup [here](https://taxify.atlassian.net/wiki/spaces/DS/pages/4090790662/CSS+Cascade+Layers+in+Kalep).

Example `tailwind.entrypoint.css` file:

```css
/* Defines order of specificity. Lowest -> highest. */
@layer reset, default, component, utility;

@layer reset {
    @tailwind base;
}
@layer component {
    @tailwind components;
}

@layer utility {
    @tailwind utilities;
}
```

#### Fonts

We don't bundle font files with Kalep packages yet. For now, you should make sure that you have Bolt fonts installed in your app separately.

You can download font files from [`design-tokens/fonts`](https://github.com/bolteu/kalep/tree/main/design-tokens/fonts).

Kalep packages rely on font family [Euclid Circular B](https://www.swisstypefaces.com/fonts/euclid/#Circular%20B). Tailwind config and the resulting CSS refer to name `euclidCircularB`. We use regular (400) and semibold (600) font weights in Kalep. For web, we suggest using `.woff2` font files, but depending on your browser compatibility targets you may want to bundle also other formats.

After storing font files in your app bundle you should also add something like this to the top of your main CSS file (fix URLs based on where you store your font files):

```css
@font-face {
  font-family: "euclidCircularB";
  src: url("../fonts/EuclidCircularB-Regular.woff2") format("woff2");
  font-weight: 400;
}

@font-face {
  font-family: "euclidCircularB";
  src: url("../fonts/EuclidCircularB-SemiBold.woff2") format("woff2");
  font-weight: 600;
}
```

## Contributing

Thank you for your desire to contribute to Kalep! Read our [Kalep Contribution Guide](https://github.com/bolteu/kalep/blob/main/CONTRIBUTING.md) for a better overview of the repository contribution process.

### Guides

#### Updating colors

The [`design-tokens/colors`](https://github.com/bolteu/kalep/tree/main/design-tokens/colors) directory contains design tokens generated from Figma.

Links to source files in Figma:
* [Light theme](https://www.figma.com/file/j6A6YkFNhwkxzzzEsyeJT2/Kalep-Colors%3A-Light?node-id=376%3A3804)
* [Light theme active](https://www.figma.com/file/IhG24fPf2buBcySxlHjYWg/Kalep-Colors%3A-Light-%2F-Active?node-id=0%3A1)
* [Dark theme](https://www.figma.com/file/wfMFfhhLkMq7FXQgAJjCMq/Kalep-Colors%3A-Dark?node-id=0%3A1)
* [Dark theme active](https://www.figma.com/file/gk8RlJwoWRolU98lexKKAS/Kalep-Colors%3A-Dark-%2F-Active?node-id=0%3A1)
* [Static colors](https://www.figma.com/file/EPqGZ0ExiZthoGtPKKIEEs/Kalep-Colors%3A-Static?node-id=0%3A1)

Every time these source files are updated, run the following command to parse its contents.

```
pnpm transform-tokens
```

As a result, it will generate `plugin/colors.json` in `kalep-tailwind` package. Multi-theme plugin in `tailwind.config.js` uses `colors.json` to generate `:root` and theme-specific color variables and color names to be used by Tailwind.
