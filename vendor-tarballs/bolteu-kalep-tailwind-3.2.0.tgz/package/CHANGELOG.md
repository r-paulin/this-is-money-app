# @bolteu/kalep-tailwind

## 3.2.0

### Minor Changes

- [#2119](https://github.com/bolteu/kalep/pull/2119) [`ef6842c`](https://github.com/bolteu/kalep/commit/ef6842caeed0c6ddf4bb40748accf963569f41e2) Thanks [@edvardsr](https://github.com/edvardsr)! - Added map tokens and classes

## 3.1.1

### Patch Changes

- [#2097](https://github.com/bolteu/kalep/pull/2097) [`de47a54`](https://github.com/bolteu/kalep/commit/de47a542eb3ec3fc12c3aec1012e1e5cbecddfd3) Thanks [@libahipi](https://github.com/libahipi)! - Add new heading/display font styles (update design-tokens 2.1.0->2.1.1) - WAVE-280

## 3.1.0

### Minor Changes

- [#1997](https://github.com/bolteu/kalep/pull/1997) [`ad95b64`](https://github.com/bolteu/kalep/commit/ad95b64dba4eb5b0c22a528bf3b1af58e5fd0f45) Thanks [@arturluik](https://github.com/arturluik)! - WAVE-143: Add bolt-driver theme for web css

### Patch Changes

- [#2013](https://github.com/bolteu/kalep/pull/2013) [`8cb1e3f`](https://github.com/bolteu/kalep/commit/8cb1e3f4d3ee1eecd6d287004c95e486b0ed640c) Thanks [@libahipi](https://github.com/libahipi)! - chore: update design-tokens package to 2.1.0 - adds driver theme specific CSS output

## 3.0.0

### Major Changes

- [#1985](https://github.com/bolteu/kalep/pull/1985) [`c3c5c7d`](https://github.com/bolteu/kalep/commit/c3c5c7da4559970ca26aba181a022ece63cfbe7a) Thanks [@libahipi](https://github.com/libahipi)! - Updates design-tokens to v2 - setting accessible color theme as the default
  - There is no more "Accessible colors" / "a11y" theme - these are now defaults.
  - The old colorscheme (named Default2024) can be used if needed, but please reach out to #dev-design-system-web-support for help. It is not included by default to save on file size.
  - Bolt Plus no longer exists as a separate theme - Bolt Plus specific tokens are included in the base set.
  - Only semantic colors are available. The new accessible primitive colors palette is not directly available via Tailwind.

  For any web specific questions please reach out to #dev-design-system-web-support
  If you have questions about specific color values and/or design-tokens please reach out to #design-system-general

## 2.2.5

### Patch Changes

- [#1971](https://github.com/bolteu/kalep/pull/1971) [`6b1f6c2`](https://github.com/bolteu/kalep/commit/6b1f6c2bf1459dc0275d3a4b62b6d0933cde9b13) Thanks [@arturluik](https://github.com/arturluik)! - WAVE-72: Update bolt-plus colours to match latest Design System

## 2.2.4

### Patch Changes

- [#1825](https://github.com/bolteu/kalep/pull/1825) [`eec444d`](https://github.com/bolteu/kalep/commit/eec444d1023c18c7af2c49e756350e516e5febdb) Thanks [@lelumees](https://github.com/lelumees)! - chore: update design-tokens to 1.5.6
  - Adds accessible color theme named "a11y"
  - Adds "semantic" static colors special.brand and special.brand-alt
  - Adjusts line-heights on "xs" versions of font styles

## 2.2.3

### Patch Changes

- [#1874](https://github.com/bolteu/kalep/pull/1874) [`b68f287`](https://github.com/bolteu/kalep/commit/b68f287ddba683bc458aee9ca5ac93aa8ef736ce) Thanks [@lelumees](https://github.com/lelumees)! - Add semantic z-indexes to kalep-tailwind

## 2.2.2

### Patch Changes

- [#1659](https://github.com/bolteu/kalep/pull/1659) [`099e015`](https://github.com/bolteu/kalep/commit/099e015df14557f956619944b6dcbe33c72a291e) Thanks [@libahipi](https://github.com/libahipi)! - feature: add a few semantic size & space options from design-tokens to default config

## 2.2.1

### Patch Changes

- [#1631](https://github.com/bolteu/kalep/pull/1631) [`7b747e8`](https://github.com/bolteu/kalep/commit/7b747e8e7d6421ac0cd394379477d7033b51605e) Thanks [@libahipi](https://github.com/libahipi)! - fix: enable `transparent` color for text utilities and as a general color

## 2.2.0

### Minor Changes

- [#1596](https://github.com/bolteu/kalep/pull/1596) [`a21526e8b2d27e095b560d1dcc7a68076d525ab7`](https://github.com/bolteu/kalep/commit/a21526e8b2d27e095b560d1dcc7a68076d525ab7) Thanks [@libahipi](https://github.com/libahipi)! - Update design-tokens to v1.3.0 - changes some font style names!

## 2.1.0

### Minor Changes

- [#1491](https://github.com/bolteu/kalep/pull/1491) [`96a8798e8ea4acfdab06dd6322882f53c3f5efac`](https://github.com/bolteu/kalep/commit/96a8798e8ea4acfdab06dd6322882f53c3f5efac) Thanks [@libahipi](https://github.com/libahipi)! - Change to use InterVariable as the new font by default.
  Implements all styles coming from Design System (https://www.figma.com/design/gM8bsTnkACiIWiuAsFTdyI/UI-Foundation---Fonts?node-id=9183-0&t=isUbiobaVKaUby5t-0) as Tailwind classes in the @component layer. (i.e can be overriden by utilities).

  In the base styles we configure the default font to be body-m-regular.

## 2.0.2

### Patch Changes

- [#1352](https://github.com/bolteu/kalep/pull/1352) [`3c528e3a`](https://github.com/bolteu/kalep/commit/3c528e3a6fae95f1d3ce0aec408086e5dae4e593) Thanks [@libahipi](https://github.com/libahipi)! - fix: Include token-css in kalep-tailwind npm package

## 2.0.1

### Patch Changes

- [#1350](https://github.com/bolteu/kalep/pull/1350) [`1e558b6a`](https://github.com/bolteu/kalep/commit/1e558b6aa6ff44f4bd522e2b78d80827239ccaa5) Thanks [@libahipi](https://github.com/libahipi)! - fix: remove optionalDependency

## 2.0.0

### Major Changes

- [#1340](https://github.com/bolteu/kalep/pull/1340) [`e651bb3b`](https://github.com/bolteu/kalep/commit/e651bb3bac137f69e875dae2d526b7b8ecc9417f) Thanks [@libahipi](https://github.com/libahipi)! - feature: take kalep-tailwind color configuration values from @bolteu/design-tokens repository

## 1.1.0

### Minor Changes

- [#1280](https://github.com/bolteu/kalep/pull/1280) [`582e2b26`](https://github.com/bolteu/kalep/commit/582e2b266a1e5f3d462aca18811b582e29741e80) Thanks [@lelumees](https://github.com/lelumees)! - Update Tailwind

## 1.0.3

### Patch Changes

- [#1043](https://github.com/bolteu/kalep/pull/1043) [`353e7d84`](https://github.com/bolteu/kalep/commit/353e7d849aa51b221a589e450e533ee0ea79d496) Thanks [@libahipi](https://github.com/libahipi)! - refactor: optimise how CSS Custom Properties are added to final CSS file.

## 1.0.2

### Patch Changes

- [#828](https://github.com/bolteu/kalep/pull/828) [`2aa98d55`](https://github.com/bolteu/kalep/commit/2aa98d557eea4cf2f24f69706af758a042494e13) Thanks [@grasscut](https://github.com/grasscut)! - # Added new spacing value
  - Added a new spacing value `1.5` with the corresponding size of `0.375rem` to the Tailwind CSS configuration file.

  # Added new variant for Badge
  - Added a new variant `s-dot` for the Badge component, intended to be used with small icons (24x24px). This variant can be applied to the Badge component to style it specifically for small icons.

  # Fixed paddings in Badge
  - Fixed the paddings in the Badge component to ensure consistent and appropriate spacing. Adjustments were made to align the padding values with the desired design and visual requirements.

  # Added font feature settings
  - Added `font-feature-settings: 'tnum' on;` to the global CSS rules or specific stylesheets to enable tabular numbers (tnum) font feature settings. This allows for consistent alignment of numbers in tables and tabular data.

## 1.0.1

### Patch Changes

- [#728](https://github.com/bolteu/kalep/pull/728) [`1fec6d68`](https://github.com/bolteu/kalep/commit/1fec6d687228ad0bcc7e23fc0e3911d270c83f82) Thanks [@usetheplatform](https://github.com/usetheplatform)! - Add snackbar animation

## 1.0.0

### Major Changes

- [#595](https://github.com/bolteu/kalep/pull/595) [`e07a94d`](https://github.com/bolteu/kalep/commit/e07a94d433edc1416eb90d2643fb104ecf02a666) Thanks [@libahipi](https://github.com/libahipi)! - 1.0.0 release of Tailwind configuration for Kalep

  This version does not include any features, just bumping version to 1.

## 0.0.25

### Patch Changes

- [#543](https://github.com/bolteu/kalep/pull/543) [`523d4aa`](https://github.com/bolteu/kalep/commit/523d4aa5e5de539de75abbcfd591447c222b7ad2) Thanks [@aleksandrashulman](https://github.com/aleksandrashulman)! - Adjusted shadows

* [#548](https://github.com/bolteu/kalep/pull/548) [`eb49e0b`](https://github.com/bolteu/kalep/commit/eb49e0b26864c91cfa0475f47bbb46cdf392d69e) Thanks [@libahipi](https://github.com/libahipi)! - Fix: font-family classes not being generated. Add font-mono

## 0.0.24

### Patch Changes

- [#492](https://github.com/bolteu/kalep/pull/492) [`6674bd5`](https://github.com/bolteu/kalep/commit/6674bd5bdac162a52b4955aaddc43dd363073aa2) Thanks [@aleksandrashulman](https://github.com/aleksandrashulman)! - bolt-plus background changed from gradient to solid color

## 0.0.23

### Patch Changes

- [#440](https://github.com/bolteu/kalep/pull/440) [`fb0a763`](https://github.com/bolteu/kalep/commit/fb0a763fdef4bd8c6ca327a9fd18d526e38785d0) Thanks [@aleksandrashulman](https://github.com/aleksandrashulman)! - added overrides for some colors in bolt plus theme, renamed dark/light theme -> mode

## 0.0.22

### Patch Changes

- [#419](https://github.com/bolteu/kalep/pull/419) [`2e3e3fd`](https://github.com/bolteu/kalep/commit/2e3e3fd9429be279543e7070682dc4c7cc140d0a) Thanks [@lelumees](https://github.com/lelumees)! - Added main font fallbacks

## 0.0.21

### Patch Changes

- [#394](https://github.com/bolteu/kalep/pull/394) [`103a073`](https://github.com/bolteu/kalep/commit/103a0733cea22973878bfbc42481fcc0be15c613) Thanks [@aleksandrashulman](https://github.com/aleksandrashulman)! - text + graphic colors => content; update color classes in kalep-react

* [#396](https://github.com/bolteu/kalep/pull/396) [`92eec02`](https://github.com/bolteu/kalep/commit/92eec024e5503768267384fd584e6156d90a64f1) Thanks [@grasscut](https://github.com/grasscut)! - fix: remove unnecessary commas

- [#401](https://github.com/bolteu/kalep/pull/401) [`96ef2fb`](https://github.com/bolteu/kalep/commit/96ef2fbe68f905d66697d791842bc7d40cce5168) Thanks [@aleksandrashulman](https://github.com/aleksandrashulman)! - Colors for Rider and Driver added; Kalep colors -> Default and split into different files.

* [#390](https://github.com/bolteu/kalep/pull/390) [`9701551`](https://github.com/bolteu/kalep/commit/97015511b3077866ad38406239dcbfee83b31b92) Thanks [@grasscut](https://github.com/grasscut)! - add color variables used by backdrop, before and after pseudo elements

## 0.0.20

### Patch Changes

- [#361](https://github.com/bolteu/kalep/pull/361) [`07c1084`](https://github.com/bolteu/kalep/commit/07c1084f4abadb703186bd75ddb82e0f31277fd9) Thanks [@aleksandrashulman](https://github.com/aleksandrashulman)! - special.scrim color added both for light and dark modes

* [#364](https://github.com/bolteu/kalep/pull/364) [`2cf2e4e`](https://github.com/bolteu/kalep/commit/2cf2e4e1e25a707c5802f81da176e101187ab8fe) Thanks [@aleksandrashulman](https://github.com/aleksandrashulman)! - link-active colors (light, dark) added

## 0.0.19

### Patch Changes

- [#355](https://github.com/bolteu/kalep/pull/355) [`d0d6348`](https://github.com/bolteu/kalep/commit/d0d63486c3398ba090330f19f7e54356fc5ce2f7) Thanks [@aleksandrashulman](https://github.com/aleksandrashulman)! - bg-neutral-secondary and bg-active-neutral-secondary -> the contrast fixed (4% -> 8%, 8% -> 12% of white)

* [#347](https://github.com/bolteu/kalep/pull/347) [`bf008ae`](https://github.com/bolteu/kalep/commit/bf008ae0a3d2effdbcdb0e087459ed2ffe48299e) Thanks [@aleksandrashulman](https://github.com/aleksandrashulman)! - light/layer/floor-0-grouped: neutral-200 -> neutral-100

## 0.0.18

### Patch Changes

- [#335](https://github.com/bolteu/kalep/pull/335) [`88938e3`](https://github.com/bolteu/kalep/commit/88938e3a60b5bf15229974b7498a1ec559f4482d) Thanks [@grasscut](https://github.com/grasscut)! - extend background, border and text colors with functional colors, avoid duplicates in class names, replace color class names in switch, checkbox and radio

## 0.0.17

### Patch Changes

- [#334](https://github.com/bolteu/kalep/pull/334) [`6265f8d`](https://github.com/bolteu/kalep/commit/6265f8db19bdf31364f61772a70e24cf55ac7f92) Thanks [@aleksandrashulman](https://github.com/aleksandrashulman)! - fix: floor-0-default -> floor-0

## 0.0.16

### Patch Changes

- [#313](https://github.com/bolteu/kalep/pull/313) [`0822e1a`](https://github.com/bolteu/kalep/commit/0822e1abe7b8aaffe94d1e9d16d78643b2f563eb) Thanks [@libahipi](https://github.com/libahipi)! - Applied uniform CSS Cascade Layers structure across packages

## 0.0.15

### Patch Changes

- [#310](https://github.com/bolteu/kalep/pull/310) [`e5cb86f`](https://github.com/bolteu/kalep/commit/e5cb86fe31bb316ab5b78e9f2bee92afcf0c2719) Thanks [@arturluik](https://github.com/arturluik)! - Fix: Tailwind typings errors

## 0.0.14

### Patch Changes

- [#306](https://github.com/bolteu/kalep/pull/306) [`f843f0f`](https://github.com/bolteu/kalep/commit/f843f0f7d0915bbaafc2ab98ab64b3f519273a13) Thanks [@arturluik](https://github.com/arturluik)! - Add tailwind.config.d.ts to package.json to be included into the published package

## 0.0.13

### Patch Changes

- [#304](https://github.com/bolteu/kalep/pull/304) [`17282fa`](https://github.com/bolteu/kalep/commit/17282faed4af3fd87ced271597af43a6b1d6478e) Thanks [@arturluik](https://github.com/arturluik)! - Add typings for `tailwind.config.js`

* [#305](https://github.com/bolteu/kalep/pull/305) [`37b46d1`](https://github.com/bolteu/kalep/commit/37b46d12da06d353526ad269b8de86c560f53f46) Thanks [@lelumees](https://github.com/lelumees)! - Fix missing plugin in distributed package

## 0.0.12

### Patch Changes

- [#282](https://github.com/bolteu/kalep/pull/282) [`2933c3b`](https://github.com/bolteu/kalep/commit/2933c3bcb573132af474f9b87cec8facf280d494) Thanks [@grasscut](https://github.com/grasscut)! - add functional colors to tailwind config

## 0.0.11

### Patch Changes

- [#272](https://github.com/bolteu/kalep/pull/272) [`c7ce7e4`](https://github.com/bolteu/kalep/commit/c7ce7e4bec4807efc8270366f767e50f629def8b) Thanks [@libahipi](https://github.com/libahipi)! - Add fade-in & fade-out animations to default config

## 0.0.10

### Patch Changes

- [#247](https://github.com/bolteu/kalep/pull/247) [`ad6a2d3`](https://github.com/bolteu/kalep/commit/ad6a2d3c33758d43c3aab71bb0efa8e2a7b9b618) Thanks [@libahipi](https://github.com/libahipi)! - Upgrade tailwindcss to ^3.1.8

  Tailwind 3.1 Release notes: https://tailwindcss.com/blog/tailwindcss-v3-1

## 0.0.9

### Patch Changes

- [#214](https://github.com/bolteu/kalep/pull/214) [`c507e11`](https://github.com/bolteu/kalep/commit/c507e111c201df0813dc1727ca1baa96c1bddfdf) Thanks [@libahipi](https://github.com/libahipi)! - - Remove custom CSS from kalep-react tailwind config, prefer keeping all styles in classnames
  - Add new special selectors to kalep-tailwind config

  Affects: Tooltip, TextField (search variant) & Slider

## 0.0.8

### Patch Changes

- [#196](https://github.com/bolteu/kalep/pull/196) [`2e757ca`](https://github.com/bolteu/kalep/commit/2e757ca12039264ae97354e2d0e1ea122198b3b5) Thanks [@grasscut](https://github.com/grasscut)! - transparent base color changed

* [#195](https://github.com/bolteu/kalep/pull/195) [`b10f1b6`](https://github.com/bolteu/kalep/commit/b10f1b67ff3a06d9551f4fda6361be9346dfb66a) Thanks [@grasscut](https://github.com/grasscut)! - line heights updated

## 0.0.7

### Patch Changes

- [#185](https://github.com/bolteu/kalep/pull/185) [`49fff2b`](https://github.com/bolteu/kalep/commit/49fff2b94b76a52771f79d9fb898b0de98e4b752) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Add more values for min height and min width.

## 0.0.6

### Patch Changes

- [#138](https://github.com/bolteu/kalep/pull/138) [`8ade428`](https://github.com/bolteu/kalep/commit/8ade428f63cfdbc579047b3e002bd8875b7ac0f6) Thanks [@grasscut](https://github.com/grasscut)! - ProgressBar component & Stepper component, variant 'progress'

* [#145](https://github.com/bolteu/kalep/pull/145) [`ea1de2d`](https://github.com/bolteu/kalep/commit/ea1de2d26c41d2c42380bfbb604609177aa22227) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Update green color values in tailwind config.

## 0.0.5

### Patch Changes

- [#126](https://github.com/bolteu/kalep/pull/126) [`18dee6a`](https://github.com/bolteu/kalep/commit/18dee6a04f5ac0fe2eeb3bf062c54866a6503ce9) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Add values for minWidth and minHeight.

## 0.0.4

### Patch Changes

- [#64](https://github.com/bolteu/kalep/pull/64) [`ed36e52`](https://github.com/bolteu/kalep/commit/ed36e52f300148b9f5a923808379272c5145a016) Thanks [@libahipi](https://github.com/libahipi)! - Add scale and minWidth required by components

## 0.0.3

### Patch Changes

- [#24](https://github.com/bolteu/kalep/pull/24) [`6e0d4fa`](https://github.com/bolteu/kalep/commit/6e0d4fa18f81911cf70723a22075a1f1edd9f0a6) Thanks [@silviuaavram](https://github.com/silviuaavram)! - limit the values for fontWeght to normal and semibold

## 0.0.2

### Patch Changes

- [#17](https://github.com/bolteu/kalep/pull/17) [`f7f5933`](https://github.com/bolteu/kalep/commit/f7f5933717c3a5e6fa5f40c988ee6c6522765915) Thanks [@libahipi](https://github.com/libahipi)! - Fixes typos in tailwind.config.js which caused incorrect CSS to be generated

## 0.0.1

### Patch Changes

- [#11](https://github.com/bolteu/kalep/pull/11) [`56eca97`](https://github.com/bolteu/kalep/commit/56eca972c3a534aafdfc23a4d307546ba173ea72) Thanks [@libahipi](https://github.com/libahipi)! - Update colors and shadows.

  Replaces shadow value keys with a typical Tailwind set
  Removes Green 600 color

* [#14](https://github.com/bolteu/kalep/pull/14) [`38dff80`](https://github.com/bolteu/kalep/commit/38dff808142e5905b5435be4c25cb4e716ed324b) Thanks [@libahipi](https://github.com/libahipi)! - Update typography scale

- [#15](https://github.com/bolteu/kalep/pull/15) [`22c490c`](https://github.com/bolteu/kalep/commit/22c490cc7529cffb090460915efa0ed9c23ff0a5) Thanks [@libahipi](https://github.com/libahipi)! - Increase spacing scale, redefine border-radius
