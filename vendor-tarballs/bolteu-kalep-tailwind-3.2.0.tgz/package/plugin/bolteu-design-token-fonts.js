const plugin = require("tailwindcss/plugin");
const fs = require("fs");
const postcss = require("postcss");
const path = require("node:path");

const cssFontRulesPath = path.join(__dirname, "../token-css/fonts.css");
const fontRules = postcss.parse(fs.readFileSync(cssFontRulesPath, "utf8"));

fontRules.walkRules((decl) => {
    const [, name] = decl.selector.match(/^\.(font-[a-zA-Z-]+)$/);
    decl.selector = `.bolt-${name}`;
});

module.exports = plugin(({addBase, addComponents, theme}) => {
    const defaultFontConfig = theme("fontFamily").sans;
    let defaultFontStack;
    let defaultFontFeatures = {};

    if (Array.isArray(defaultFontConfig)) {
        [defaultFontStack, defaultFontFeatures] = defaultFontConfig;
    } else {
        defaultFontStack = defaultFontConfig;
    }

    addBase({
        html: {
            fontFamily: defaultFontStack,
            ...defaultFontFeatures,
            fontWeight: theme("fontWeight.normal"),
            letterSpacing: theme("letterSpacing.body-m"),
            "-webkit-font-smoothing": "antialiased",
        },
    });
    addComponents(fontRules.nodes);
});
