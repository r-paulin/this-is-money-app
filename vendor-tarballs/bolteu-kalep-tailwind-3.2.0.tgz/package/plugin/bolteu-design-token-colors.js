const plugin = require("tailwindcss/plugin");
const fs = require("fs");
const postcss = require("postcss");
const path = require("node:path");
const glob = require("fast-glob");

const cssColorsLightPath = path.join(__dirname, "../token-css/colors-light.css");
const cssColorsDarkPath = path.join(__dirname, "../token-css/colors-dark.css");
const cssColorsMapLightPath = path.join(__dirname, "../token-css/colors-map-light.css");
const cssColorsMapDarkPath = path.join(__dirname, "../token-css/colors-map-dark.css");

// For these we need to parse values to do the mapping to utility classes
const lightVariables = postcss.parse(fs.readFileSync(cssColorsLightPath, "utf8"));
const darkVariables = postcss.parse(fs.readFileSync(cssColorsDarkPath, "utf8"));
const mapLightVariables = postcss.parse(fs.readFileSync(cssColorsMapLightPath, "utf8"));
const mapDarkVariables = postcss.parse(fs.readFileSync(cssColorsMapDarkPath, "utf8"));

// We expect these only override css vars and don't need to be mapped to utility classes, for now at least
const themeFiles = glob.sync("../token-css/colors-*-theme-*.css", {cwd: __dirname});
const themeVariableNodes = themeFiles
    .filter((file) => !file.includes("default2024")) // Ignore the Default2024 theme, if needed add the CSS manually to product.
    .map((file) => postcss.parse(fs.readFileSync(path.join(__dirname, file), "utf8")).nodes);

// Create semantic color config. I.e which colors to use in TW bg- text- border- utilities.
// lightVariables has all the semantic tokens.

const semanticColors = {
    backgroundColor: {},
    borderColor: {},
    textColor: {},
};

const walkSemanticDecls = (decl) => {
    // Cut the name to pieces to understand what it is for and categorise accordingly.
    // --color-content-primary => [, undefined, "content", "primary"]
    // --color-map-zone-positive-bg-primary => [, "map-zone-positive", "bg", "primary"]
    let [, prefix, group, name] = decl.prop.match(
        /^--color(?:-(special|static|boltplus|map-.+?))?(?:-(bg|border|content|layer))?-(.+)$/,
    );

    name = prefix ? `${prefix}-${name}` : name;

    switch (group) {
        case "bg":
            semanticColors.backgroundColor[name] = `var(${decl.prop})`;
            break;
        case "layer":
            semanticColors.backgroundColor[`layer-${name}`] = `var(${decl.prop})`; // to ensure backwards compatibility.
            break;
        case "border":
            semanticColors.borderColor[name] = `var(${decl.prop})`;
            break;
        case "content":
            semanticColors.textColor[name] = `var(${decl.prop})`;
            break;
    }
};

lightVariables.walkDecls(walkSemanticDecls);
mapLightVariables.walkDecls(walkSemanticDecls);

// Add special-scrim and special-nulled to the semantic colors
semanticColors.backgroundColor["special-scrim"] = `var(--color-special-scrim)`;
semanticColors.backgroundColor["special-nulled"] = `var(--color-special-nulled)`;
semanticColors.borderColor["special-nulled"] = `var(--color-special-nulled)`;

semanticColors.backgroundColor["special-brand"] =
    semanticColors.borderColor["special-brand"] =
    semanticColors.textColor["special-brand"] =
        `var(--color-special-brand)`;

semanticColors.backgroundColor["special-brand-alt"] =
    semanticColors.borderColor["special-brand-alt"] =
    semanticColors.textColor["special-brand-alt"] =
        `var(--color-special-brand-alt)`;

module.exports = plugin(
    ({addBase}) => {
        // Will be added to the output stylesheet along with "@tailwind base;" stuff.
        addBase([
            ...lightVariables.nodes,
            ...darkVariables.nodes,
            ...mapLightVariables.nodes,
            ...mapDarkVariables.nodes,
            ...themeVariableNodes.flat(),
        ]);
    },
    {
        // Will be merged with the config object in tailwind.config.js
        theme: {
            extend: {
                backgroundColor: () => ({
                    inherit: "inherit",
                    transparent: "transparent",
                    ...semanticColors.backgroundColor,
                }),
                borderColor: () => ({
                    inherit: "inherit",
                    transparent: "transparent",
                    ...semanticColors.borderColor,
                }),
                textColor: () => ({
                    inherit: "inherit",
                    transparent: "transparent",
                    ...semanticColors.textColor,
                }),
                placeholderColor: ({theme}) => theme("textColor"),
                caretColor: ({theme}) => theme("textColor"),
            },
        },
    },
);
