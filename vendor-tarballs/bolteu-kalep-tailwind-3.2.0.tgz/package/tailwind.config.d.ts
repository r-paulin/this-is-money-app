declare const KalepTailwindConfig: Record<string, any>;

export = KalepTailwindConfig;
