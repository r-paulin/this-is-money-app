const plugin = require("tailwindcss/plugin");
const defaultConfig = require("tailwindcss/defaultConfig");
const bolteuDesignTokenColorsPlugin = require("./plugin/bolteu-design-token-colors");
const bolteuDesignTokenFontsPlugin = require("./plugin/bolteu-design-token-fonts");

const defaultTheme = defaultConfig.theme;

const config = {
    ...defaultConfig,
    content: ["./src/**/*.{js,jsx,ts,tsx}"],
    theme: {
        ...defaultTheme,
        borderRadius: {
            none: "0px",
            sm: "0.25rem",
            DEFAULT: "0.5rem",
            md: "0.5rem",
            lg: "1rem",
            xl: "1.5rem",
            full: "9999px",
        },
        boxShadow: {
            DEFAULT:
                "0px 0px 1px 1px rgba(26, 27, 35, 0.04), 0px 2px 2px rgba(26, 27, 35, 0.06), 0px 2px 2px -2px rgba(26, 27, 35, 0.24)",
            md: "0px 0px 1px 1px rgba(26, 27, 35, 0.04), 0px 8px 8px rgba(26, 27, 35, 0.06), 0px 8px 8px -8px rgba(26, 27, 35, 0.24)",
            lg: "0px 0px 1px 1px rgba(26, 27, 35, 0.04), 0px 16px 16px rgba(26, 27, 35, 0.06), 0px 16px 16px -16px rgba(26, 27, 35, 0.24)",
            xl: "0px 0px 1px 1px rgba(26, 27, 35, 0.04), 0px 32px 32px rgba(26, 27, 35, 0.12), 0px 32px 32px -32px rgba(26, 27, 35, 0.4)",
            inner: "inset 0px 0px 1px 1px rgba(26, 27, 35, 0.04), inset 0px 4px 4px -2px rgba(26, 27, 35, 0.06)",
            none: "none",
        },
        // Set in bolteuDesignTokenColors plugin that gets them from the bolteu/design-tokens repository.
        // Here intentionally kept empty, so we wouldn't get the default colors from tailwind.
        colors: {},

        // These utility colors are set in bolteuDesignTokenColors plugin.
        backgroundColor: {},
        borderColor: {},
        placeholderColor: {},
        textColor: {},
        // -- end color overrides

        fontFamily: {
            sans: [
                'InterVariable, ui-sans-serif, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"',
                {
                    fontFeatureSettings: '"cv03", "cv04"',
                },
            ],
            mono: "ui-monospace, SFMono-Regular, Menlo, Monaco, monospace",
        },
        fontSize: {
            "size-inherit": ["100%", {lineHeight: "inherit"}],
            xs: ["0.75rem", {lineHeight: "1rem"}], // from tokens
            "xs-compact": ["0.75rem", {lineHeight: "0.875rem"}], // from tokens
            sm: ["0.875rem", {lineHeight: "1.25rem"}], // from tokens
            "sm-compact": ["0.875rem", {lineHeight: "1.125rem"}], // from tokens
            base: ["1rem", {lineHeight: "1.5rem"}],
            m: ["1rem", {lineHeight: "1.5rem"}], // from tokens
            "m-compact": ["1rem", {lineHeight: "1.25rem"}], // from tokens
            lg: ["1.125rem", {lineHeight: "1.625rem"}], // from tokens
            "lg-compact": ["1.125rem", {lineHeight: "1.375rem"}], // from tokens

            xl: ["1.25rem", {lineHeight: "1.5rem"}],
            "2xl": ["1.5rem", {lineHeight: "2rem"}],
            "3xl": ["1.875rem", {lineHeight: "2.25rem"}],
            "4xl": ["2.25rem", {lineHeight: "2.5rem"}],
            "5xl": ["2.5rem", {lineHeight: "1"}],
            "6xl": ["3rem", {lineHeight: "1"}],
        },
        fontWeight: {
            normal: "450",
            semibold: "650",
        },
        letterSpacing: {
            "body-xs": "0",
            "body-xs-tabular": "-0.015em",
            "body-s": "-0.006em",
            "body-s-tabular": "-0.021em",
            "body-m": "-0.011em",
            "body-m-tabular": "-0.026em",
            "body-l": "-0.014em",
            "body-l-tabular": "-0.029em",
        },
        spacing: {
            px: "1px",
            0: "0px",
            0.5: "0.125rem",
            1: "0.25rem",
            1.5: "0.375rem",
            2: "0.5rem",
            3: "0.75rem",
            4: "1rem",
            5: "1.25rem",
            6: "1.5rem",
            7: "1.75rem",
            8: "2rem",
            9: "2.25rem",
            10: "2.5rem",
            11: "2.75rem",
            12: "3rem",
            14: "3.5rem",
            16: "4rem",
            20: "5rem",
            24: "6rem",
            28: "7rem",
            32: "8rem",
            36: "9rem",
            40: "10rem",
            44: "11rem",
            48: "12rem",
            52: "13rem",
            56: "14rem",
            60: "15rem",
            64: "16rem",
            72: "18rem",
            80: "20rem",
            96: "24rem",
        },
        extend: {
            size: {
                "icon-xs": "1rem",
                "icon-s": "1.25rem",
                "icon-m": "1.5rem",
            },
            spacing: {
                "comp-vr-padding-s": "0.5rem",
                "comp-vr-padding-m": "0.5rem",
                "comp-vr-padding-l": "0.75rem",
            },
            scale: {
                975: ".975",
            },
            minHeight: {
                "comp-s": "2.25rem",
                "comp-m": "3rem",
                "comp-l": "3.5rem",
                0.5: "0.125rem",
                1: "0.25rem",
                2: "0.5rem",
                3: "0.75rem",
                4: "1rem",
                5: "1.25rem",
                6: "1.5rem",
                7: "1.75rem",
                8: "2rem",
                9: "2.25rem",
                10: "2.5rem",
                11: "2.75rem",
                12: "3rem",
                14: "3.5rem",
                16: "4rem",
                20: "5rem",
            },
            minWidth: {
                0.5: "0.125rem",
                1: "0.25rem",
                2: "0.5rem",
                3: "0.75rem",
                4: "1rem",
                5: "1.25rem",
                6: "1.5rem",
                7: "1.75rem",
                8: "2rem",
                9: "2.25rem",
                10: "2.5rem",
                11: "2.75rem",
                12: "3rem",
                14: "3.5rem",
                16: "4rem",
                20: "5rem",
                24: "6rem",
                28: "7rem",
                32: "8rem",
                36: "9rem",
                40: "10rem",
            },
            zIndex: {
                base: 1,
                dropdown: 1010,
                modalOverlay: 1019,
                modal: 1020,
                tooltip: 1030,
                snackbar: 1040,
            },
            keyframes: {
                indeterminateProgress: {
                    "0%": {
                        left: "-60%",
                    },
                    "60%": {
                        left: "100%",
                    },
                    "100%": {
                        left: "-60%",
                    },
                },
                "fade-in": {
                    "0%": {
                        opacity: 0,
                    },
                    "100%": {
                        opacity: 1,
                    },
                },
                "fade-out": {
                    "0%": {
                        opacity: 1,
                    },
                    "100%": {
                        opacity: 0,
                    },
                },
                "slide-in": {
                    from: {
                        transform: "translateY(200%)",
                    },
                },
            },
            animation: {
                indeterminateProgress: "indeterminateProgress 2s linear infinite",
                "fade-in": "fade-in 0.3s ease-in",
                "fade-out": "fade-out 0.3s ease-in",
                snackbar: "slide-in 0.3s ease-in-out, fade-in 0.3s ease-in-out",
            },
        },
    },

    plugins: [
        plugin(function ({addVariant}) {
            addVariant("input-clear-button", "&::-webkit-search-cancel-button");
            addVariant("slider-thumb", ["&::-webkit-slider-thumb", "&::-moz-range-thumb", "&::-ms-thumb"]);
            addVariant("slider-track", ["&::-webkit-slider-runnable-track", "&::-moz-range-track", "&::-ms-track"]);
        }),
        bolteuDesignTokenColorsPlugin,
        bolteuDesignTokenFontsPlugin,
    ],
};

module.exports = config;
