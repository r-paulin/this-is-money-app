import * as React from "react";

import type {Meta, StoryObj} from "@storybook/react-webpack5";

import {Typography} from "@/index";

import {Chip} from "../Chip";
import {Skeleton} from "../Skeleton";
import {Accordion, AccordionItem} from "./Accordion";

export default {
    title: "Data Display/Accordion",
    component: Accordion,
    tags: ["autodocs"],
    argTypes: {},
} as Meta<typeof Accordion>;

type AccordionStory = StoryObj<typeof Accordion>;

const items = [
    {
        id: 1,
        title: "Accordion 1",
        subtitle: "Last updated 2 days ago",
        status: "Approved",
    },
    {
        id: 2,
        title: "Accordion 2",
        subtitle: "Last updated today",
        status: "In review",
    },
    {
        id: 3,
        title: "Accordion 3",
        subtitle: "Expires in 3 hours",
    },
];

function logArguments(...args: any) {
    console.log("Received arguments:", args);
}

export const Default: AccordionStory = {
    args: {},
    render: (_args) => (
        <div className="max-w-[410px]">
            <Accordion onExpandedChange={logArguments}>
                {items.map((item) => (
                    <AccordionItem
                        key={item.id}
                        id={item.id}
                        title={{
                            primary: item.title,
                        }}
                    >
                        <Typography align="start" paddingBottom={8}>
                            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Neque, atque! Qui exercitationem,
                            numquam doloremque provident nobis soluta eligendi dolorum, magni aperiam aut laborum
                            architecto quibusdam odit molestiae, culpa illum ea.
                        </Typography>
                    </AccordionItem>
                ))}
            </Accordion>
        </div>
    ),
};

export const Borderless: AccordionStory = {
    args: {},
    render: (_args) => (
        <div className="max-w-[410px]">
            <Accordion onExpandedChange={logArguments} showSeparator={false}>
                {items.map((item) => (
                    <AccordionItem
                        key={item.id}
                        id={item.id}
                        title={{
                            primary: item.title,
                        }}
                    >
                        <Typography align="start" paddingBottom={8}>
                            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Neque, atque! Qui exercitationem,
                            numquam doloremque provident nobis soluta eligendi dolorum, magni aperiam aut laborum
                            architecto quibusdam odit molestiae, culpa illum ea.
                        </Typography>
                    </AccordionItem>
                ))}
            </Accordion>
        </div>
    ),
};

export const ExpandedItems: AccordionStory = {
    args: {},
    render: (_args) => (
        <div className="max-w-[410px]">
            <Accordion onExpandedChange={logArguments} expandedKeys={[2]}>
                {items.map((item) => (
                    <AccordionItem
                        key={item.id}
                        id={item.id}
                        title={{
                            primary: item.title,
                        }}
                    >
                        <Typography align="start" paddingBottom={8}>
                            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Neque, atque! Qui exercitationem,
                            numquam doloremque provident nobis soluta eligendi dolorum, magni aperiam aut laborum
                            architecto quibusdam odit molestiae, culpa illum ea.
                        </Typography>
                    </AccordionItem>
                ))}
            </Accordion>
        </div>
    ),
};

export const DisabledItems: AccordionStory = {
    args: {},
    render: (_args) => (
        <div className="max-w-[410px]">
            <Accordion onExpandedChange={logArguments} disabledKeys={[2]}>
                {items.map((item) => (
                    <AccordionItem
                        key={item.id}
                        id={item.id}
                        title={{
                            primary: item.title,
                        }}
                    >
                        <Typography align="start" paddingBottom={8}>
                            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Neque, atque! Qui exercitationem,
                            numquam doloremque provident nobis soluta eligendi dolorum, magni aperiam aut laborum
                            architecto quibusdam odit molestiae, culpa illum ea.
                        </Typography>
                    </AccordionItem>
                ))}
            </Accordion>
        </div>
    ),
};

export const ComplexItems: AccordionStory = {
    args: {},
    render: (_args) => (
        <div className="max-w-[410px]">
            <Accordion expandedKeys={[2]} disabledKeys={[3]} onExpandedChange={logArguments}>
                {items.map((item) => (
                    <AccordionItem
                        key={item.id}
                        id={item.id}
                        title={{
                            primary: item.title,
                            secondary: item.subtitle,
                            secondaryTypographyProps: {
                                color: item.status === "In review" ? "danger-secondary" : "primary",
                            },
                            renderEndSlot: (props) => (item.status ? <Chip label={item.status} {...props} /> : null),
                        }}
                    >
                        <div className="flex flex-col">
                            <Skeleton variant="text" />
                            <Skeleton variant="text" />
                            <Skeleton variant="text" width="50%" />
                        </div>
                    </AccordionItem>
                ))}
            </Accordion>
        </div>
    ),
};

export const Exclusive: AccordionStory = {
    args: {},
    render: (_args) => (
        <div className="max-w-[410px]">
            <Accordion onExpandedChange={logArguments} exclusive>
                {items.map((item) => (
                    <AccordionItem
                        key={item.id}
                        id={item.id}
                        title={{
                            primary: item.title,
                        }}
                    >
                        <Typography align="start" paddingBottom={8}>
                            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Neque, atque! Qui exercitationem,
                            numquam doloremque provident nobis soluta eligendi dolorum, magni aperiam aut laborum
                            architecto quibusdam odit molestiae, culpa illum ea.
                        </Typography>
                    </AccordionItem>
                ))}
            </Accordion>
        </div>
    ),
};

Exclusive.parameters = {
    docs: {
        description: {
            story: "Exclusive Accordion allows only one item to be expanded at a time.",
        },
    },
};
