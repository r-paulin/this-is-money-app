import * as React from "react";

import ChevronDown from "@bolteu/kalep-react-icons/dist/ChevronDown";

import {ListItemLayout} from "@/components/ListItemLayout";
import {useId} from "@/helpers";
import {cx} from "@/helpers/utils/cx";

import type {SpacingValue} from "../Typography";
import type {
    AccordionAction,
    AccordionArrowProps,
    AccordionContextType,
    AccordionItemProps,
    AccordionProps,
    AccordionState,
} from "./Accordion.types";
import {AccordionActionType} from "./Accordion.types";

function reducer(state: AccordionState, action: AccordionAction): AccordionState {
    switch (action.type) {
        case AccordionActionType.OPEN:
            return {
                ...state,
                expandedKeys: state.exclusive
                    ? new Map().set(action.id, true)
                    : new Map(state.expandedKeys).set(action.id, true),
            };

        case AccordionActionType.CLOSE:
            return {
                ...state,
                expandedKeys: new Map(state.expandedKeys).set(action.id, false),
            };
        case AccordionActionType.CHANGE_EXCLUSIVE:
            return {
                ...state,
                exclusive: action.exclusive,
            };

        default:
            throw new Error("Accordion reducer received an unknown action");
    }
}

const initialState: AccordionState = {
    expandedKeys: new Map<React.Key, boolean>(),
    disabledKeys: new Map<React.Key, boolean>(),
    showSeparator: true,
    exclusive: false,
};

const AccordionContext = React.createContext<AccordionContextType>({
    state: initialState,
    dispatch: () => {},
});

export function Accordion({
    children,
    expandedKeys,
    disabledKeys,
    onExpandedChange,
    paddingStart = 6,
    paddingEnd = 6,
    showSeparator = true,
    exclusive,
}: AccordionProps) {
    const [state, dispatch] = React.useReducer(reducer, {
        expandedKeys: expandedKeys ? new Map(expandedKeys.map((key) => [key, true])) : new Map<React.Key, boolean>(),
        disabledKeys: disabledKeys ? new Map(disabledKeys.map((key) => [key, true])) : new Map<React.Key, boolean>(),
        showSeparator,
        exclusive: Boolean(exclusive),
    });

    React.useEffect(() => {
        const newExpandedKeys = [...state.expandedKeys].filter(([_k, v]) => v).map(([k, _v]) => k);

        onExpandedChange?.(new Set(newExpandedKeys));
    }, [state.expandedKeys, onExpandedChange]);

    React.useEffect(() => {
        dispatch({
            type: AccordionActionType.CHANGE_EXCLUSIVE,
            exclusive: Boolean(exclusive),
        });
    }, [exclusive]);

    const outerContainerStyle = React.useMemo(() => {
        return {
            paddingLeft: getRemFromSpacingSize(paddingStart),
            paddingRight: getRemFromSpacingSize(paddingEnd),
        };
    }, [paddingStart, paddingEnd]);

    const contextValue = React.useMemo(
        () => ({
            state,
            dispatch,
        }),
        [state, dispatch],
    );

    return (
        <AccordionContext.Provider value={contextValue}>
            <ul className={cx("m-0 flex list-none flex-col p-0")} style={outerContainerStyle}>
                {children}
            </ul>
        </AccordionContext.Provider>
    );
}

export function AccordionItem({id, title, children}: AccordionItemProps) {
    const {state, dispatch} = React.useContext(AccordionContext);
    const ref = React.useRef<HTMLButtonElement>(null);
    const isOpen = state.expandedKeys.get(id);
    const isDisabled = state.disabledKeys.get(id);

    const generatedId = useId();
    const sectionId = `kalep-accordion-section-${generatedId}`;
    const buttonId = `kalep-accordion-button-${generatedId}`;

    const clickHandler = React.useCallback(() => {
        dispatch({
            id,
            type: isOpen ? AccordionActionType.CLOSE : AccordionActionType.OPEN,
        });
    }, [isOpen, dispatch, id]);

    return (
        <li>
            <div
                className={`
                  flex flex-col
                  ${state.showSeparator && "border-0 border-b border-solid border-separator"}
                `}
            >
                <button
                    type="button"
                    id={buttonId}
                    ref={ref}
                    data-testid="kalep-accordion-expand-row-button"
                    disabled={isDisabled}
                    aria-expanded={isOpen ? "true" : "false"}
                    aria-controls={sectionId}
                    onClick={clickHandler}
                    className={cx(
                        /* resets */ "select-none border-none bg-special-nulled outline-offset-2",
                        "relative flex items-center justify-between text-left",
                        "w-full flex-1 gap-x-3 p-0",
                        "duration-150 ease-linear",
                        isDisabled ? "cursor-not-allowed" : "cursor-pointer",
                    )}
                >
                    <ListItemLayout paddingStart={0} paddingEnd={0} disabled={isDisabled} {...title} />
                    <div className={cx("h-6 w-6 shrink-0")}>
                        <AccordionArrow isOpen={isOpen} />
                    </div>
                </button>
                <div
                    role="region"
                    id={sectionId}
                    aria-labelledby={buttonId}
                    className={cx(
                        "grid transition-all duration-300 ease-in-out",
                        isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0",
                    )}
                >
                    <div className={cx("overflow-hidden")}>
                        <div className={cx("mb-5 mt-2 ps-3")}>{children}</div>
                    </div>
                </div>
            </div>
        </li>
    );
}

export function AccordionArrow({isOpen}: AccordionArrowProps) {
    return (
        <ChevronDown
            size="lg"
            aria-hidden="true"
            className={cx(
                "absolute right-0 shrink-0 origin-center text-tertiary transition-transform",
                isOpen ? "rotate-180" : "rotate-0",
            )}
        />
    );
}

function getRemFromSpacingSize(spacingValue: SpacingValue): string {
    return `${spacingValue / 4}rem`;
}
