import * as React from "react";

import {BaseTextField} from "./BaseTextField";
import {PasswordTextField} from "./PasswordTextField";
import {SearchTextField} from "./SearchTextField";
import type {TextFieldProps} from "./TextField.types";

export const TextField = React.forwardRef<HTMLInputElement, Omit<TextFieldProps, "inputWrapperRef">>(
    (props, ref): JSX.Element => {
        let Component;

        switch (props.type) {
            case "password":
                Component = PasswordTextField;
                break;
            case "search":
                Component = SearchTextField;
                break;
            default:
                Component = BaseTextField;
                break;
        }

        return <Component {...props} ref={ref} />;
    },
);
TextField.displayName = "TextField";
