import * as React from "react";

import type {RenderResult} from "@testing-library/react";
import {render, screen} from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import {DEFAULT_SHOW_PASSWORD_ARIA_LABEL} from "../PasswordTextField";
import {DEFAULT_CLEAR_TEXT_ARIA_LABEL} from "../SearchTextField";
import {TextField} from "../TextField";
import type {TextFieldProps} from "../TextField.types";

export * from "@testing-library/react";
export {userEvent};

interface RenderTextFieldResult extends Omit<RenderResult, "rerender"> {
    rerender: (props: Partial<TextFieldProps>) => void;
}

export const defaultProps = {
    label: "Default:",
};

export function renderTextField(props?: Partial<TextFieldProps>): RenderTextFieldResult {
    const utils = render(<TextField {...defaultProps} {...props} />);

    function rerender(rerenderProps: Partial<TextFieldProps>): void {
        utils.rerender(<TextField {...defaultProps} {...rerenderProps} />);
    }

    return {...utils, rerender};
}

export function getInput(label = defaultProps.label): HTMLInputElement {
    return screen.getByRole("textbox", {name: label});
}

export async function changeInput(value: string, shouldClear = true): Promise<void> {
    const user = userEvent.setup();
    const input = getInput();

    if (shouldClear) {
        await user.clear(input);
    }

    await user.type(input, value);
}

export function getClearTextButton(clearTextLabel = DEFAULT_CLEAR_TEXT_ARIA_LABEL): HTMLButtonElement | null {
    return screen.queryByRole("button", {name: clearTextLabel});
}

export function getShowPasswordSwitch(showPasswordLabel = DEFAULT_SHOW_PASSWORD_ARIA_LABEL): HTMLButtonElement {
    return screen.getByRole("switch", {name: showPasswordLabel});
}

export async function clickOnClearTextButton(clearTextLabel?: string): Promise<void> {
    const button = getClearTextButton(clearTextLabel);

    if (button) {
        const user = userEvent.setup({delay: null});

        await user.click(button);
    }
}

export async function clickOnShowPasswordSwitch(showPasswordLabel?: string): Promise<void> {
    const button = getShowPasswordSwitch(showPasswordLabel);

    if (button) {
        const user = userEvent.setup({delay: null});

        await user.click(button);
    }
}

export function getErrorIcon(): HTMLElement | null {
    return screen.queryByTestId("textfield-error-icon");
}

export async function clickOnWrapper(): Promise<void> {
    const user = userEvent.setup();

    await user.click(screen.getByTestId("text-field-wrapper"));
}

export async function clickOnInput(): Promise<void> {
    const user = userEvent.setup();

    await user.click(getInput());
}
