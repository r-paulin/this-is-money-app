import * as React from "react";

import {vi} from "vitest";

import Search from "@bolteu/kalep-react-icons/dist/Search";
import Settings from "@bolteu/kalep-react-icons/dist/Settings";

import {DEFAULT_CLEAR_TEXT_ARIA_LABEL} from "../SearchTextField";
import {
    act,
    clickOnClearTextButton,
    getClearTextButton,
    renderTextField,
    screen,
    userEvent,
} from "./TextField.testUtils";

test("can render an input of type 'search'", async function searchInput() {
    const user = userEvent.setup();
    const clearTextLabel = "clear text";
    const label = "Search";
    const value = "meaning of life";

    renderTextField({type: "search", label, clearTextLabel});

    const input = screen.getByLabelText(label, {selector: "[type='search']"});

    expect(input).toHaveAttribute("type", "search");
    expect(getClearTextButton(clearTextLabel)).not.toBeInTheDocument();

    await user.type(input, value);
    const clearTextButton = getClearTextButton(clearTextLabel);

    expect(input).toHaveValue(value);
    expect(clearTextButton?.childNodes[0]).toHaveAttribute("aria-hidden", "true");
});

test("search input is clearable via Clear button", async function clearButton() {
    const user = userEvent.setup({delay: null});
    const label = "Search";
    const defaultValue = "meaning of life";

    renderTextField({type: "search", label, defaultValue});

    const input = screen.getByLabelText(label, {selector: "[type='search']"});
    const clearTextButton = getClearTextButton() as HTMLButtonElement;

    await user.unhover(clearTextButton); // make sure it's not hovered
    await user.hover(clearTextButton);

    await screen.findByRole("tooltip", {name: DEFAULT_CLEAR_TEXT_ARIA_LABEL});

    await act(async () => {
        await clickOnClearTextButton();
    });

    expect(input).not.toHaveValue();
    expect(getClearTextButton()).not.toBeInTheDocument();
    expect(input).toHaveFocus();
});

test("clear text label can be customized", async function customClearTextLabel() {
    const user = userEvent.setup({delay: null});
    const clearTextLabel = "clear everything";
    const defaultValue = "meaning of life";

    renderTextField({type: "search", clearTextLabel, defaultValue});

    const clearTextButton = getClearTextButton(clearTextLabel) as HTMLElement;

    await user.hover(clearTextButton);

    await screen.findByRole("tooltip", {name: clearTextLabel});
});

test("controlled search input is cleared via Clear button", async function clearButton() {
    const label = "Search";
    const value = "meaning of life";
    const onChange = vi.fn();

    renderTextField({type: "search", label, value, onChange});

    const input = screen.getByLabelText(label, {selector: "[type='search']"});

    await act(async () => {
        await clickOnClearTextButton();
    });

    expect(input).toHaveFocus();
    expect(onChange).toHaveBeenCalledTimes(1);
});

test("uncontrolled search input is cleared via Clear button", async function clearButton() {
    const label = "Search";
    const defaultValue = "meaning of life";
    const onChange = vi.fn();

    renderTextField({type: "search", label, defaultValue, onChange});

    const input = screen.getByLabelText(label, {selector: "[type='search']"});

    await act(async () => {
        await clickOnClearTextButton();
    });

    expect(input).toHaveFocus();
    expect(onChange).toHaveBeenCalledTimes(1);
});

test("start, end and input slots custom render", function helperTextRender() {
    const startSlotAriaLabel = "Sherlock Search";
    const endSlotAriaLabel = "More options";
    const inputAriaLabel = "My input";
    const renderInput = vi.fn().mockReturnValue(<input aria-label={inputAriaLabel} />);
    const renderStartSlot = vi.fn().mockReturnValue(<Search aria-label={startSlotAriaLabel} />);
    const renderEndSlot = vi.fn().mockReturnValue(<Settings aria-label={endSlotAriaLabel} />);
    renderTextField({renderStartSlot, renderEndSlot, renderInput, type: "search"});

    expect(screen.getByLabelText(startSlotAriaLabel)).toBeInTheDocument();
    expect(screen.getByLabelText(endSlotAriaLabel)).toBeInTheDocument();
    expect(screen.getByLabelText(inputAriaLabel)).toBeInTheDocument();
    expect(renderStartSlot).toHaveBeenCalledWith(
        expect.objectContaining({
            renderStartSlot: expect.any(Function),
            renderEndSlot: expect.any(Function),
            renderInput: expect.any(Function),
        }),
        expect.any(Function),
    );
    expect(renderStartSlot).toHaveBeenCalledTimes(1);
    expect(renderEndSlot).toHaveBeenCalledWith(
        expect.objectContaining({
            renderStartSlot: expect.any(Function),
            renderEndSlot: expect.any(Function),
            renderInput: expect.any(Function),
        }),
        expect.any(Function),
    );
    expect(renderEndSlot).toHaveBeenCalledTimes(1);
    expect(renderInput).toHaveBeenCalledWith(
        expect.objectContaining({
            renderStartSlot: expect.any(Function),
            renderEndSlot: expect.any(Function),
            renderInput: expect.any(Function),
        }),
        expect.any(Function),
    );
    expect(renderInput).toHaveBeenCalledTimes(1);
});
