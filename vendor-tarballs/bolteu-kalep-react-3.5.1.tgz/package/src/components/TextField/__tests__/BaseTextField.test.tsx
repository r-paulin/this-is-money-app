import * as React from "react";

import {vi} from "vitest";

import Search from "@bolteu/kalep-react-icons/dist/Search";
import Settings from "@bolteu/kalep-react-icons/dist/Settings";

import {
    changeInput,
    clickOnInput,
    clickOnWrapper,
    getErrorIcon,
    getInput,
    renderTextField,
    screen,
} from "./TextField.testUtils";

test("renders an input of type 'text'", () => {
    renderTextField();

    const input = getInput();

    expect(input).toHaveAttribute("type", "text");
    expect(input).toHaveAttribute("aria-invalid", "false");
    expect(input).toHaveAttribute("id", expect.stringMatching(/kalep-text-field-[\w-]+/));
    expect(input).toHaveAttribute("aria-labelledby", expect.stringMatching(/kalep-text-field-[\w:-]+-label/));
    expect(input).not.toHaveAccessibleDescription();
    expect(input).toBeEnabled();
    expect(input).not.toHaveValue();
    expect(getErrorIcon()).not.toBeInTheDocument();
});

test("input should allow text typed into", async () => {
    const value = "Hello TextField!";
    renderTextField();

    await changeInput(value);

    expect(getInput()).toHaveValue(value);
});

test("input should be labelled", () => {
    const label = "First name:";

    renderTextField({label});

    expect(screen.getByText(label, {selector: "label"})).toBeInTheDocument();
    expect(screen.getByRole("textbox", {name: label})).toBeInTheDocument();
});

test("input should be aria-describedby a text element if helperText prop is passed", () => {
    const helperTextString = "Name must not be empty.";
    const helperTextElement = <span>{helperTextString}</span>;

    const {rerender} = renderTextField({helperText: helperTextString});

    expect(getInput()).toHaveAccessibleDescription(helperTextString);
    expect(screen.getByText(helperTextString)).toBeInTheDocument();

    rerender({helperText: helperTextElement});

    expect(screen.getByText(helperTextString)).toBeInTheDocument();
});

test("input cand be readonly", () => {
    const isReadonly = true;

    renderTextField({readOnly: isReadonly});

    expect(getInput()).toHaveAttribute("readonly");
});

test("input cand have a name", () => {
    const name = "mime";

    renderTextField({name});

    expect(getInput()).toHaveAttribute("name", name);
});

test("input cand have an aria-label", () => {
    const ariaLabel = "alias";

    renderTextField({"aria-label": ariaLabel});

    expect(getInput()).toHaveAttribute("aria-label", ariaLabel);
});

test("input should have an id based on the id prop", () => {
    const id = "my-fancy-input";

    renderTextField({id});

    expect(getInput()).toHaveAttribute("id", id);
});

test("input should have placeholder text based on the placeholder prop", () => {
    const placeholder = "my-fancy-input";

    renderTextField({placeholder});

    expect(screen.getByPlaceholderText(placeholder)).toBeInTheDocument();
});

test("input should be disabled based on the disabled prop", () => {
    const {rerender} = renderTextField({disabled: true});

    expect(getInput()).toBeDisabled();

    rerender({disabled: false});

    expect(getInput()).toBeEnabled();
});

test("input should have aria-invalid set to true based on the error prop", () => {
    renderTextField({error: true});

    expect(getInput()).toHaveAttribute("aria-invalid", "true");
    expect(getErrorIcon() as HTMLElement).toHaveAttribute("aria-hidden", "true");
});

test("input should have a full width class based on the fullWidth prop", () => {
    renderTextField({fullWidth: true});

    expect(getInput().parentElement).toHaveClass("w-full");
});

test("input should have a default value based on the defaultValue prop", async () => {
    const defaultValue = "Dorian Gray";
    const newValue = "Basil Hallward";

    renderTextField({defaultValue});

    expect(getInput()).toHaveValue(defaultValue);

    await changeInput(newValue);

    expect(getInput()).toHaveValue(newValue);
});

test("input should have its value controlled by the value prop", async () => {
    const value = "Dorian Gray";
    const newValue = "Basil Hallward";
    const typedValue = "Henry Wotton";

    // pass onChange to avoid warning, we don't actually want it to change anything
    const {rerender} = renderTextField({value, onChange: vi.fn()});

    expect(getInput()).toHaveValue(value);

    await changeInput(typedValue);

    // expect that typed value is not set, the field is controlled
    expect(getInput()).toHaveValue(value);

    // passing a new value in prop does work however
    rerender({value: newValue});

    expect(getInput()).toHaveValue(newValue);
});

test("onChange should be called every time the uncontrolled input value is changed", async () => {
    const onChange = vi.fn();
    const value = ["B", "o", "b", " ", "J", "o", "e"];

    renderTextField({onChange});

    for (let index = 0; index < value.length; index++) {
        const character = value[index];

        await changeInput(character, false);

        expect(onChange).toHaveBeenNthCalledWith(
            index + 1,
            expect.objectContaining({target: expect.objectContaining({value: value.slice(0, index + 1).join("")})}),
        );
    }

    expect(onChange).toHaveBeenCalledTimes(value.length);
});

test("onChange should be called every time the controlled input value is changed", async () => {
    const onChange = vi.fn();
    const value = ["B", "o", "b", " ", "J", "o", "e"];

    renderTextField({onChange, value: "foo"});

    for (let index = 0; index < value.length; index++) {
        const character = value[index];

        await changeInput(character, false);
    }

    expect(onChange).toHaveBeenCalledTimes(value.length);
});

test("suffix text could be added after the input", () => {
    const suffix = "EUR";
    const label = "Top Up:";

    renderTextField({suffix, label});

    expect(screen.getByText(suffix)).toBeInTheDocument();
    expect(screen.getByLabelText(new RegExp(`${label} ${suffix}`), {selector: "input"})).toBeInTheDocument();
});

test("prefix text could be added before the input", () => {
    const prefix = "USD";
    const label = "Top Up:";

    renderTextField({prefix, label});

    expect(screen.getByText(prefix)).toBeInTheDocument();
    expect(screen.getByLabelText(new RegExp(`${label} ${prefix}`), {selector: "input"})).toBeInTheDocument();
});

test("prefix and suffix text could be added before and after the input", () => {
    const label = "Website:";
    const prefix = "www.";
    const suffix = ".com";

    renderTextField({prefix, suffix, label});

    expect(screen.getByLabelText(new RegExp(`${label} ${prefix} ${suffix}`), {selector: "input"})).toBeInTheDocument();
});

test("input can be marked as required", () => {
    const label = "Required";
    renderTextField({required: true, label});

    expect(screen.getByText(new RegExp(label), {selector: "label"})).toHaveClass(
        "after:text-danger-primary after:content-['_*']",
    );
    expect(getInput(label)).toHaveAttribute("required");
});

test("helperText custom render", function helperTextRender() {
    const customHelperText = "I am so custom right now.";
    const renderHelperText = vi.fn().mockReturnValue(<div>{customHelperText}</div>);
    renderTextField({renderHelperText});

    expect(screen.getByText(customHelperText)).toBeInTheDocument();
    expect(renderHelperText).toHaveBeenCalledWith(
        expect.objectContaining({renderHelperText, helperTextId: expect.any(String)}),
        expect.any(Function),
    );
    expect(renderHelperText).toHaveBeenCalledTimes(1);
});

test("start and end slots custom render", function helperTextRender() {
    const startSlotAriaLabel = "Sherlock Search";
    const endSlotAriaLabel = "More options";
    const renderStartSlot = vi.fn().mockReturnValue(<Search aria-label={startSlotAriaLabel} />);
    const renderEndSlot = vi.fn().mockReturnValue(<Settings aria-label={endSlotAriaLabel} />);
    renderTextField({renderStartSlot, renderEndSlot});

    expect(screen.getByLabelText(startSlotAriaLabel)).toBeInTheDocument();
    expect(screen.getByLabelText(endSlotAriaLabel)).toBeInTheDocument();
    expect(renderStartSlot).toHaveBeenCalledWith(
        expect.objectContaining({renderStartSlot, renderEndSlot}),
        expect.any(Function),
    );
    expect(renderStartSlot).toHaveBeenCalledTimes(1);
    expect(renderEndSlot).toHaveBeenCalledWith(
        expect.objectContaining({renderStartSlot, renderEndSlot}),
        expect.any(Function),
    );
    expect(renderEndSlot).toHaveBeenCalledTimes(1);
});

test("label custom render", function helperTextRender() {
    const customLabel = "I am so custom right now.";
    const renderLabel = vi.fn().mockReturnValue(<div>{customLabel}</div>);
    renderTextField({renderLabel});

    expect(screen.getByText(customLabel)).toBeInTheDocument();
    expect(renderLabel).toHaveBeenCalledWith(
        expect.objectContaining({renderLabel, labelId: expect.any(String), inputId: expect.any(String)}),
        expect.any(Function),
    );
    expect(renderLabel).toHaveBeenCalledTimes(1);
});

test("input custom render", function helperTextRender() {
    const customText = "I am so custom right now.";
    const renderInput = vi.fn().mockReturnValue(<div>{customText}</div>);
    renderTextField({renderInput});

    expect(screen.getByText(customText)).toBeInTheDocument();
    expect(renderInput).toHaveBeenCalledWith(
        expect.objectContaining({
            renderInput,
            labelId: expect.any(String),
            inputId: expect.any(String),
            prefixId: expect.any(String),
            suffixId: expect.any(String),
            helperTextId: expect.any(String),
        }),
        expect.any(Function),
    );
    expect(renderInput).toHaveBeenCalledTimes(1);
});

test("wrapper click moves focus to the input", async function wrapperClick() {
    const onClick = vi.fn();

    renderTextField({onClick});

    await clickOnWrapper();

    expect(getInput()).toHaveFocus();
});

test("click on wrapper or input gets propagated", async function wrapperOrInputClick() {
    const onClick = vi.fn();

    renderTextField({onClick});

    await clickOnWrapper();
    expect(onClick).toHaveBeenCalledTimes(1);

    await clickOnInput();
    expect(onClick).toHaveBeenCalledTimes(2);
});
