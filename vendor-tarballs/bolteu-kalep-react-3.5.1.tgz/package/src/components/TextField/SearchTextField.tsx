import * as React from "react";

import Search from "@bolteu/kalep-react-icons/dist/Search";

import {cx} from "@/helpers/utils/cx";
import {mergeRefs} from "@/helpers/utils/mergeRefs";

import {ClearInputButton} from "../_internal/ClearInputButton";
import {BaseTextField} from "./BaseTextField";
import type {TextFieldProps} from "./index";
import type {TextFieldRenderProps} from "./TextField.types";

export const DEFAULT_CLEAR_TEXT_ARIA_LABEL = "Clear";

export const SearchTextField = React.forwardRef<HTMLInputElement, TextFieldProps>((props, forwardedRef) => {
    const {
        defaultValue,
        onChange,
        renderEndSlot: renderEndSlotProp,
        renderInput: renderInputProp,
        renderStartSlot: renderStartSlotProp,
        value,
        clearTextLabel = DEFAULT_CLEAR_TEXT_ARIA_LABEL,
        ...textFieldBaseProps
    } = props;

    const internalRef = React.useRef<HTMLInputElement>();
    const [internalValue, setInternalValue] = React.useState<string>(defaultValue || value || ""); // So that we can keep track of the value for uncontrolled cases

    const isControlled = value !== undefined;
    const isClearButtonVisible = isControlled ? Boolean(value) : Boolean(internalValue);

    /**
     * Needed for showing/hiding clear button based on current value.
     * Then just pass through to the provided onChange prop.
     */
    const handleChange = React.useCallback(
        (event: React.ChangeEvent<HTMLInputElement>) => {
            setInternalValue(event.target.value);
            onChange?.(event);
        },
        [onChange],
    );

    /**
     * Fancy way to clear the value so that the fact of clearing registers as a change event.
     */
    const handleClearButtonClick = React.useCallback(() => {
        const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")?.set;

        nativeInputValueSetter?.call(internalRef.current, "");
        internalRef?.current?.dispatchEvent(new Event("input", {bubbles: true}));
        internalRef?.current?.focus();
    }, [internalRef]);

    const renderEndSlot = React.useCallback(
        function endSlotRenderer(renderProps: TextFieldRenderProps) {
            function renderEndSlotDefault(propsForRender: TextFieldRenderProps) {
                if (!isClearButtonVisible || propsForRender.disabled) {
                    return null;
                }

                return (
                    <ClearInputButton
                        clearTextLabel={propsForRender.clearTextLabel}
                        onClick={handleClearButtonClick}
                        size={propsForRender.size === "sm" ? "sm" : "lg"}
                    />
                );
            }

            return renderEndSlotProp
                ? renderEndSlotProp(renderProps, renderEndSlotDefault)
                : renderEndSlotDefault(renderProps);
        },
        [handleClearButtonClick, isClearButtonVisible, renderEndSlotProp],
    );
    const renderStartSlot = React.useCallback(
        function startSlotRenderer(renderProps: TextFieldRenderProps) {
            return renderStartSlotProp
                ? renderStartSlotProp(renderProps, renderStartSlotDefault)
                : renderStartSlotDefault(renderProps);
        },
        [renderStartSlotProp],
    );
    const renderInput = React.useCallback(
        function inputRenderer(
            renderProps: TextFieldRenderProps,
            renderInputBaseDefault: (props: TextFieldRenderProps) => JSX.Element | null,
        ) {
            function renderInputDefault(localProps: TextFieldRenderProps): JSX.Element {
                const DefaultInput = renderInputBaseDefault(localProps) as JSX.Element;

                return React.cloneElement(DefaultInput, {
                    className: `${DefaultInput.props.className} ${cx("kalep-search-textfield")}`,
                });
            }

            return renderInputProp
                ? renderInputProp(renderProps, renderInputBaseDefault)
                : renderInputDefault(renderProps);
        },
        [renderInputProp],
    );

    return (
        <BaseTextField
            defaultValue={defaultValue}
            onChange={handleChange}
            renderEndSlot={renderEndSlot}
            renderInput={renderInput}
            renderStartSlot={renderStartSlot}
            value={value}
            ref={mergeRefs([internalRef, forwardedRef])}
            clearTextLabel={clearTextLabel}
            {...textFieldBaseProps}
        />
    );
});
SearchTextField.displayName = "SearchTextField";

function renderStartSlotDefault({size}: TextFieldRenderProps): JSX.Element {
    return <Search aria-hidden="true" className={cx("flex-none")} size={size === "sm" ? "sm" : "lg"} />;
}
