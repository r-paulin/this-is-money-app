import React from "react";

import Check from "@bolteu/kalep-react-icons/dist/Check";

import {Checkbox} from "@/components/Checkbox";
import {Radio} from "@/components/RadioGroup";
import {Switch} from "@/components/Switch";
import type {SpacingValue} from "@/components/Typography/Typography.types";
import type {TypographyStackProps} from "@/components/Typography/TypographyStack";
import {TypographyStack} from "@/components/Typography/TypographyStack";
import {cx} from "@/helpers/utils/cx";
import {noopNull} from "@/helpers/utils/noop";

import type {ListItemLayoutProps, ListItemLayoutSelectionSlotProps} from "./ListItemLayout.types";

const variants = {
    base: "py-3 gap-3 min-h-12",
    sm: "py-[6px] gap-3 min-h-9",
} as const;

export const ListItemLayout = React.forwardRef<HTMLDivElement, ListItemLayoutProps>(function ListItemLayoutComponent(
    {onClick, ...props}: ListItemLayoutProps,
    ref: React.Ref<HTMLDivElement>,
): JSX.Element {
    const {
        renderEndSlot = noopNull,
        renderStartSlot = noopNull,
        paddingStart = 4,
        paddingEnd = 4,
        paddingTop,
        paddingBottom,
        separator = false,
        variant = "base",
        highlighted = false,
        disabled = false,
        selected,
        selectionMode = "solo-checkmark",
        ...rest
    } = props;

    const isClickable = typeof onClick === "function";
    const isHighlighted = highlighted && !disabled;

    const hasSelectionSlot = selected !== undefined;
    const selectionSlotPosition = selectionMode === "solo-radio" || selectionMode === "multiple" ? "start" : "end";

    const handleKeyDown = React.useCallback(
        (event: React.KeyboardEvent<HTMLDivElement>) => {
            if (isClickable && !disabled && (event.key === "Enter" || event.key === " ")) {
                onClick();
            }
        },
        [isClickable, disabled, onClick],
    );

    const handleOnClick = React.useCallback(
        (_event: React.MouseEvent<HTMLDivElement>) => {
            if (isClickable && !disabled) {
                onClick();
            }
        },
        [isClickable, disabled, onClick],
    );

    const containerProps = React.useMemo(() => {
        if (isClickable) {
            return {
                onClick: handleOnClick,
                onKeyDown: handleKeyDown,
                role: "button",
                tabIndex: 0,
                "aria-disabled": disabled,
            };
        }

        return {};
    }, [isClickable, disabled, handleOnClick, handleKeyDown]);

    const typographyStackProps: TypographyStackProps = React.useMemo(() => {
        return disabled
            ? {
                  ...rest,
                  primaryTypographyProps: {
                      color: "tertiary",
                  },
                  secondaryTypographyProps: {
                      color: "tertiary",
                  },
              }
            : rest;
    }, [disabled, rest]);

    const leftSlot = React.useMemo(() => {
        return renderStartSlot({disabled, size: mapVariantToSize(variant)}, noopNull);
    }, [disabled, variant, renderStartSlot]);
    const rightSlot = React.useMemo(() => {
        return renderEndSlot({disabled, size: mapVariantToSize(variant)}, noopNull);
    }, [disabled, variant, renderEndSlot]);

    const outerContainerStyle = React.useMemo(() => {
        return {
            paddingInlineStart: getRemFromSpacingSize(paddingStart),
            paddingInlineEnd: getRemFromSpacingSize(paddingEnd),
        };
    }, [paddingStart, paddingEnd]);

    const innerContainerStyle = React.useMemo(() => {
        return {
            paddingTop: typeof paddingTop === "number" ? getRemFromSpacingSize(paddingTop) : undefined,
            paddingBottom: typeof paddingBottom === "number" ? getRemFromSpacingSize(paddingBottom) : undefined,
        };
    }, [paddingTop, paddingBottom]);

    return (
        <div
            style={outerContainerStyle}
            ref={ref}
            className={cx(
                "w-full",
                isClickable && `
                  hover:bg-neutral-secondary
                  focus:hover:bg-neutral-secondary
                `,
                isHighlighted && "bg-neutral-secondary",
                isClickable && "cursor-pointer",
                isClickable && disabled && "cursor-not-allowed",
            )}
        >
            <div
                className={cx(
                    "flex items-center",
                    variants[variant],
                    separator && "border-0 border-b border-solid border-separator",
                )}
                style={innerContainerStyle}
                {...containerProps}
            >
                {hasSelectionSlot && selectionSlotPosition === "start" ? (
                    <SelectionSlot
                        selected={selected}
                        disabled={disabled}
                        selectionMode={selectionMode}
                        aria-label={rest["aria-label"]}
                    />
                ) : null}
                {leftSlot ? <div className={cx("flex h-full shrink-0 items-center")}>{leftSlot}</div> : null}
                <div className={cx("flex-1")}>
                    <TypographyStack variant={variant} {...typographyStackProps} />
                </div>
                {rightSlot ? <div className={cx("ml-auto flex h-full shrink-0 items-center")}>{rightSlot}</div> : null}
                {hasSelectionSlot && selectionSlotPosition === "end" ? (
                    <SelectionSlot
                        selected={selected}
                        disabled={disabled}
                        selectionMode={selectionMode}
                        aria-label={rest["aria-label"]}
                    />
                ) : null}
            </div>
        </div>
    );
});

function mapVariantToSize(variant: keyof typeof variants = "base") {
    return variant === "base" ? "md" : "sm";
}

function getRemFromSpacingSize(spacingValue: SpacingValue): string {
    return `${spacingValue / 4}rem`;
}

function SelectionSlot({
    selected,
    disabled,
    selectionMode = "solo-checkmark",
    "aria-label": ariaLabel,
}: ListItemLayoutSelectionSlotProps) {
    switch (selectionMode) {
        case "solo-radio": {
            return (
                <div className={cx("flex h-full shrink-0 items-center")}>
                    <Radio checked={selected} disabled={disabled} readOnly aria-label={ariaLabel} tabIndex={-1} />
                </div>
            );
        }

        case "solo-checkmark": {
            return selected ? (
                <div className={cx("ml-auto flex h-full shrink-0 items-center")}>
                    <Check
                        size="md"
                        className={cx(disabled ? "text-tertiary" : "text-action-secondary")}
                        aria-label={ariaLabel}
                    />
                </div>
            ) : null;
        }

        case "multiple": {
            return (
                <div className={cx("flex h-full shrink-0 items-center")}>
                    <Checkbox checked={selected} disabled={disabled} readOnly aria-label={ariaLabel} tabIndex={-1} />
                </div>
            );
        }

        case "switch": {
            return (
                <div className={cx("ml-auto flex h-full shrink-0 items-center")}>
                    <Switch checked={selected} disabled={disabled} readOnly aria-label={ariaLabel} tabIndex={-1} />
                </div>
            );
        }

        default: {
            return null;
        }
    }
}
