import type * as React from "react";

export interface SliderProps {
    /**
     * The value of the slider. Providing `value` makes the Slider controlled,
     * so `onChange` callback is expected to make the Slider work properly.
     */
    value?: number;

    /**
     * Initial value, defaults to average of max and min if not provided. Ignored if `value` is provided.
     */
    defaultValue?: number;

    /**
     * The lowest value in the range of permitted values, defaults to 0.
     */
    min?: number;

    /**
     * The greatest value in the range of permitted values, defaults to 100.
     */
    max?: number;

    /**
     * A number that specifies the granularity that the value must adhere to, defaults to 1.
     */
    step?: number;

    /**
     * Change event that is called on every value change during drag and click events.
     * Proxies the whole `React.ChangeEvent` of HTML range input, so use
     * `event.target.value` to receive the value as string representation of the numeric value or
     * `event.target.valueAsNumber` to get the value as number.
     */
    onChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;

    /**
     * A boolean indicating whether the Slider is disabled or not.
     */
    disabled?: boolean;

    /**
     * Optional label that is displayed on top of Slider.
     */
    label?: string;

    /**
     * If Slider does not have an associated label provide
     * an accessible label in aria-label.
     */
    "aria-label"?: string;

    /**
     * Label that is displayed on the left side of Slider that indicates the minimum allowed value.
     * Can be a `number`, `string` or any `ReactNode` for fully custom labels.
     */
    minLabel?: number | string | React.ReactNode;

    /**
     * Label that is displayed on the right side of Slider that indicates the maximum allowed value.
     * Can be a `number`, `string` or any `ReactNode` for fully custom labels.
     */
    maxLabel?: number | string | React.ReactNode;
}
