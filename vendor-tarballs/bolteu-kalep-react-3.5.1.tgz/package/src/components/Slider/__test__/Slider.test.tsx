import * as React from "react";

import {vi} from "vitest";
import {fireEvent, render as testingLibraryRender, screen} from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import type {SliderProps} from "../index";
import {Slider} from "../index";

function render(props: SliderProps = {}) {
    const {rerender} = testingLibraryRender(<Slider {...props} />);
    return (propsOverride: Partial<SliderProps>) => rerender(<Slider {...props} {...propsOverride} />);
}

describe("Slider test suite", () => {
    test("renders to document with correct default values", () => {
        const ariaLabel = "foo";
        const value = 30;
        render({"aria-label": ariaLabel, value});

        expect(screen.getByLabelText(ariaLabel)).toBeInTheDocument();
        expect(screen.getByLabelText(ariaLabel)).toHaveAttribute("min", "0");
        expect(screen.getByLabelText(ariaLabel)).toHaveAttribute("max", "100");
        expect(screen.getByLabelText(ariaLabel)).toHaveValue(value.toString());
        expect(screen.getByLabelText(ariaLabel)).toHaveAttribute("type", "range");
        expect(screen.getByLabelText(ariaLabel)).toHaveAttribute("step", "1");
    });

    test("renders label if provided", () => {
        const label = "foo";
        render({label});
        expect(screen.getByText(label)).toBeInTheDocument();
    });

    test("disabled prop passed on properly", () => {
        const ariaLabel = "foo";
        render({"aria-label": ariaLabel, disabled: true});
        expect(screen.getByLabelText(ariaLabel)).toBeDisabled();
    });

    test("focuses with tab", async () => {
        const ariaLabel = "foo";
        render({"aria-label": ariaLabel});

        const user = userEvent.setup();
        await user.tab();
        expect(screen.getByLabelText(ariaLabel)).toHaveFocus();
    });

    test("does not focus with tab when disabled", async () => {
        const ariaLabel = "foo";
        render({"aria-label": ariaLabel, disabled: true});

        const user = userEvent.setup();
        await user.tab();
        expect(screen.getByLabelText(ariaLabel)).not.toHaveFocus();
    });

    test("onChange prop called properly when uncontrolled", async () => {
        const ariaLabel = "foo";
        const onChange = vi.fn();
        const defaultValue = 20;
        const targetValue = 33;
        const changeEvent = {target: {value: targetValue}};

        render({"aria-label": ariaLabel, onChange, defaultValue});

        const slider = screen.getByLabelText(ariaLabel);
        expect(slider).toHaveValue(defaultValue.toString());

        // We cannot test keyboard and other fancy events properly until this one is fixed:
        // https://github.com/testing-library/user-event/issues/871
        fireEvent.change(slider, changeEvent);

        expect(slider).toHaveValue(targetValue.toString());
        expect(slider).toHaveStyle({"background-size": `${targetValue}% 100%`});
        expect(onChange).toHaveBeenCalledTimes(1);
    });

    test("onChange prop called properly when controlled", async () => {
        const ariaLabel = "foo";
        const onChange = vi.fn();
        const value = 20;
        const targetValue = 33;
        const changeEvent = {target: {value: targetValue}};

        render({"aria-label": ariaLabel, onChange, value});

        const slider = screen.getByLabelText(ariaLabel);
        expect(slider).toHaveValue(value.toString());

        // We cannot test keyboard and other fancy events properly until this one is fixed:
        // https://github.com/testing-library/user-event/issues/871
        fireEvent.change(slider, changeEvent);

        expect(onChange).toHaveBeenCalledTimes(1);
    });

    test("respects default value if in range", () => {
        const ariaLabel = "foo";
        render({"aria-label": ariaLabel, defaultValue: 1});
        expect(screen.getByLabelText(ariaLabel)).toHaveValue("1");
    });

    test("sets default value to min if out of range", () => {
        const ariaLabel = "foo";
        render({"aria-label": ariaLabel, defaultValue: -10});
        expect(screen.getByLabelText(ariaLabel)).toHaveValue("0");
    });

    test("sets default value to max if out of range", () => {
        const ariaLabel = "foo";
        render({"aria-label": ariaLabel, defaultValue: 999});
        expect(screen.getByLabelText(ariaLabel)).toHaveValue("100");
    });

    test("sets default value to min if not provided", () => {
        const ariaLabel = "foo";
        render({"aria-label": ariaLabel, min: 0, max: 10});
        expect(screen.getByLabelText(ariaLabel)).toHaveValue("0");
    });

    test("handles non-integer values", () => {
        const ariaLabel = "foo";
        render({"aria-label": ariaLabel, min: 0, max: 1, step: 0.1, defaultValue: 0.2});
        expect(screen.getByLabelText(ariaLabel)).toHaveAttribute("min", "0");
        expect(screen.getByLabelText(ariaLabel)).toHaveAttribute("max", "1");
        expect(screen.getByLabelText(ariaLabel)).toHaveValue("0.2");
    });

    test("renders custom min and max labels", () => {
        const minLabel = "foo";
        const maxLabel = "bar";
        render({minLabel, maxLabel});

        expect(screen.getByText(minLabel)).toBeInTheDocument();
        expect(screen.getByText(maxLabel)).toBeInTheDocument();
    });

    test("has proper aria attributes", () => {
        const ariaLabel = "foo";
        const min = 1;
        const max = 10;
        const defaultValue = 5;

        render({"aria-label": ariaLabel, min, max, defaultValue});

        expect(screen.getByLabelText(ariaLabel)).toHaveAttribute("aria-valuemin", min.toString());
        expect(screen.getByLabelText(ariaLabel)).toHaveAttribute("aria-valuemax", max.toString());
        expect(screen.getByLabelText(ariaLabel)).toHaveAttribute("aria-valuenow", defaultValue.toString());
    });
});
