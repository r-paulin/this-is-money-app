export function addConsumerClasses<State extends object>(
    state: State,
    classes: string | ((state: State) => string | undefined) | undefined,
) {
    if (typeof classes === "function") {
        return classes(state);
    }
    return classes;
}
