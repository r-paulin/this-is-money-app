import * as React from "react";

import type {Meta, StoryContext, StoryObj} from "@storybook/react-webpack5";

import {Heart} from "@bolteu/kalep-react-icons";

import {Button} from "@/components/baseui-components/Button";
import {cx} from "@/helpers/utils/cx";

import DocumentationTemplate from "../docs/DocumentationTemplate.mdx";

const meta = {
    component: Button,
    title: "BaseUI Playground/Button",
    tags: ["experimental", "BaseUI", "autodocs"],
    subcomponents: {"Button.Icon": Button.Icon, "Button.Label": Button.Label},
    parameters: {
        docs: {
            subtitle: "A primitive Button component",
            page: DocumentationTemplate,
        },
    },
} satisfies Meta<typeof Button>;

export default meta;

type Story = StoryObj<typeof meta>;

export const Default: Story = {
    args: {
        children: "Click me",
    },
};

export const Sizes: Story = {
    render: (_args) => (
        <div className="flex items-center gap-2">
            <Button size="sm">Small</Button>
            <Button size="md">Medium</Button>
            <Button size="lg">Large</Button>
        </div>
    ),
};

export const Variants: Story = {
    render: (_args) => (
        <div className="flex flex-col gap-8">
            <div className="flex items-center gap-2">
                <Button variant="primary">Primary</Button>
                <Button variant="secondary">Secondary</Button>
                <Button variant="tertiary">Tertiary</Button>
                <Button variant="floating">Floating</Button>
                <Button variant="danger">Danger</Button>
            </div>
            <div className="flex items-center gap-4 bg-promo-primary p-8">
                <Button variant="static-light">Static Light</Button>
                <p className="text-static-primary-light">
                    Designed for cases like promo banners which may require light buttons that remain light even in dark
                    mode
                </p>
            </div>
        </div>
    ),
};

export const Disabled: Story = {
    render: (_args) => (
        <div className="flex flex-col gap-8">
            <div className="flex items-center gap-2">
                <Button variant="primary" disabled>
                    Primary
                </Button>
                <Button variant="secondary" disabled>
                    Secondary
                </Button>
                <Button variant="tertiary" disabled>
                    Tertiary
                </Button>
                <Button variant="floating" disabled>
                    Floating
                </Button>
                <Button variant="danger" disabled>
                    Danger
                </Button>
            </div>
            <div className={cx("flex items-center gap-4 bg-promo-primary p-8")}>
                <Button variant="static-light" disabled>
                    Static Light
                </Button>
                <p className="text-static-primary-light">
                    Designed for cases like promo banners which may require light buttons that remain light even in dark
                    mode
                </p>
            </div>
        </div>
    ),
};

export const Loading: Story = {
    args: {
        loading: true,
        children: "I'm loading...",
    },
};

/**
 * In case of rendering anything other than a `<button />`, please include the `nativeButton={false}` prop
 */
export const RenderAsLink: Story = {
    args: {
        nativeButton: false,
        render: <a href="https://bolt.eu/" />,
        children: "I'm a link!",
    },
    parameters: {
        docs: {
            source: {
                transform: (codeBlock: string, {args}: StoryContext) => {
                    return codeBlock.replace("<Button", `<Button nativeButton={${args.nativeButton}}`);
                },
            },
        },
    },
};

export const WithIcons: Story = {
    render: (_args) => {
        const sizes = ["sm", "md", "lg"] as const;
        return (
            <div className="flex flex-col gap-8">
                {sizes.map((size) => (
                    <div key={size} className="flex items-center gap-2">
                        <Button size={size}>
                            <Button.Icon icon={<Heart />} />
                            <Button.Label>Leading Icon</Button.Label>
                        </Button>
                        <Button size={size}>
                            <Button.Icon icon={<Heart />} />
                            <Button.Label>Both Icons</Button.Label>
                            <Button.Icon icon={<Heart />} />
                        </Button>
                        <Button size={size}>
                            <Button.Label>Trailing Icon</Button.Label>
                            <Button.Icon icon={<Heart />} />
                        </Button>
                    </div>
                ))}
            </div>
        );
    },
};
