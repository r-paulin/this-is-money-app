import {ButtonIcon} from "./ButtonIcon";
import {ButtonLabel} from "./ButtonLabel";

import {Button as ButtonPrimitive} from "./Button";
export type {ButtonProps} from "./Button";
export type {ButtonIconProps} from "./ButtonIcon";
export type {ButtonLabelProps} from "./ButtonLabel";

/**
 * ### Composition guide
 * Regular usage:
 *
 * ```tsx
 * <Button />
 * ```
 *
 * Composed with subcomponents:
 * ```tsx
 *  <Button>
 *      <Button.Icon icon={<Heart />} />
 *      <Button.Label>Both Icons</Button.Label>
 *      <Button.Icon icon={<Heart />} />
 *  </Button>
 * ```
 * A `render` prop is provided for the `Button`, `Button.Icon` and `Button.Label` components to
 * allow custom rendering of the components respectively.
 *
 */
export const Button = Object.assign(ButtonPrimitive, {
    Icon: ButtonIcon,
    Label: ButtonLabel,
});
