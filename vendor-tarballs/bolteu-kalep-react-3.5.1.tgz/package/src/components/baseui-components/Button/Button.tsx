import * as React from "react";

import {Button as BaseUIButton, useRender} from "@base-ui/react";
import type {BaseUIEvent, HTMLProps} from "@base-ui/react/utils/types";

import {SpinnerIcon} from "@/components/_internal/SpinnerIcon";
import {ButtonProvider} from "@/components/baseui-components/Button/context/ButtonProvider";
import type {Indexable} from "@/components/baseui-components/types/common-types";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

type Size = "sm" | "md" | "lg";
type Variant = "primary" | "secondary" | "danger" | "tertiary" | "floating" | "static-light";

type WithDefault<T> = {default: string} & T;
interface ButtonStyles {
    sizes: WithDefault<Record<Size, string>>;
    variants: WithDefault<Record<Variant, string>>;
    disabled: WithDefault<Partial<Record<Variant, string>>>; // Not all variants have variant specific styles
    loading: WithDefault<Partial<Record<Variant, string>>>; // Not all variants have variant specific styles
    loadingSpinner: WithDefault<Record<Variant, string>>;
}

const btnStyles: ButtonStyles = {
    sizes: {
        default: "",
        sm: "px-4 py-0 h-9 gap-1 bolt-font-body-s-accent",
        md: "px-6 py-0 h-12 gap-2 bolt-font-body-m-accent",
        lg: "px-6 py-0 h-14 gap-2 bolt-font-body-l-accent",
    },
    variants: {
        default: "",
        primary:
            "bg-action-primary hover:bg-active-action-primary active:bg-active-action-primary text-static-key-light",
        secondary:
            "bg-neutral-secondary hover:bg-active-neutral-secondary active:bg-active-neutral-secondary text-primary",
        danger: "bg-danger-primary hover:bg-active-danger-primary active:bg-active-danger-primary text-static-key-light",
        tertiary: "bg-special-nulled hover:bg-action-secondary active:bg-action-secondary text-action-primary",
        floating: "bg-layer-floor-2 shadow-md hover:shadow active:shadow disabled:shadow-md text-primary",
        "static-light":
            "bg-static-key-light hover:bg-static-active-key-light active:bg-static-active-key-light text-static-key-dark",
    },
    disabled: {
        default:
            "bg-neutral-secondary hover:bg-neutral-secondary active:bg-neutral-secondary text-tertiary cursor-not-allowed",
        "static-light":
            "bg-static-key-light hover:bg-static-key-light active:bg-static-key-light text-static-tertiary-dark cursor-not-allowed",
    },
    loading: {
        default: "cursor-progress text-transparent",
    },
    loadingSpinner: {
        default: "",
        primary: "text-static-key-light",
        secondary: "text-primary",
        danger: "text-static-key-light",
        tertiary: "text-action-primary",
        floating: "text-primary",
        "static-light": "text-static-key-dark",
    },
};

type ButtonClassesType = keyof typeof btnStyles;
function getButtonStyleClasses(type: ButtonClassesType, key: string): string {
    const typeObj = btnStyles[type];
    return typeObj[key as keyof typeof typeObj] || typeObj["default"];
}

// @todo: Replace with new component, when https://taxify.atlassian.net/browse/WAVE-187 gets done
function LoadingSpinner(props: Pick<ButtonProps, "size" | "variant">) {
    const {size = "md", variant = "primary"} = props;
    return (
        <div className={cx("absolute", getButtonStyleClasses("loadingSpinner", variant))}>
            <SpinnerIcon className={cx("block animate-spin")} size={size} />
        </div>
    );
}

interface ButtonInnerProps extends HTMLProps {
    size: Size;
    render: BaseUIButton.Props["render"];
    state: BaseUIButton.State;
    consumerRef?: React.Ref<HTMLButtonElement>;
}

function ButtonInner(props: ButtonInnerProps) {
    const {render, state, size, consumerRef, ...otherProps} = props;
    const element = useRender<Indexable<BaseUIButton.State>, HTMLButtonElement>({
        defaultTagName: "button",
        render,
        state,
        ref: consumerRef,
        props: otherProps,
    });

    return (
        <ButtonProvider state={state} props={{size}}>
            {element}
        </ButtonProvider>
    );
}

export type ButtonProps = BaseUIButton.Props & {
    /**
     * Button size
     *
     * @default md
     */
    size?: Size;
    /**
     * Button variant
     *
     * @default primary
     */
    variant?: Variant;
    /**
     * Whether the button is in a loading state
     *
     * @default false
     */
    loading?: boolean;
};

export const Button = React.forwardRef(function Button(props: ButtonProps, ref: React.ForwardedRef<HTMLButtonElement>) {
    const {size = "md", render, variant = "primary", className, children, onClick, loading, ...rest} = props;
    const isLoading = !rest.disabled && loading;
    const buttonClassName = React.useCallback(
        function buttonClassName(state: BaseUIButton.State) {
            const isLoading = !state.disabled && loading;
            return cx(
                "[&>.icon:first-child]:-ms-1 [&>.icon:last-child]:-me-1",
                "cursor-pointer border-none",
                "relative flex flex-none items-center justify-center",
                "rounded-full duration-150 ease-linear",
                "no-underline", // in case of rendering as anchor
                "active:scale-975 active:duration-100 active:ease-in-out",
                "w-fit",
                getButtonStyleClasses("sizes", size),
                getButtonStyleClasses("variants", variant),
                {
                    [getButtonStyleClasses("loading", variant)]: isLoading,
                    [getButtonStyleClasses("disabled", variant)]: state.disabled,
                },
                addConsumerClasses(state, className),
            );
        },
        [className, loading, size, variant],
    );

    const defaultRender = React.useCallback(
        function buttonDefaultRender({ref, ...buttonProps}: HTMLProps, state: BaseUIButton.State) {
            return <ButtonInner consumerRef={ref} size={size} render={render} state={state} {...buttonProps} />;
        },
        [size, render],
    );

    const clickHandler = React.useCallback(
        function clickHandler(ev: BaseUIEvent<React.MouseEvent<HTMLButtonElement, MouseEvent>>) {
            if (isLoading) {
                ev.preventDefault();
                ev.stopPropagation();
            } else {
                onClick?.(ev);
            }
        },
        [isLoading, onClick],
    );
    return (
        <BaseUIButton render={defaultRender} ref={ref} onClick={clickHandler} className={buttonClassName} {...rest}>
            {children}
            {isLoading ? <LoadingSpinner variant={variant} size={size} /> : null}
        </BaseUIButton>
    );
});
