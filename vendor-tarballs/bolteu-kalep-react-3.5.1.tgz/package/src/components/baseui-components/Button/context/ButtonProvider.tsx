import type {ReactNode} from "react";
import * as React from "react";

import type {Button as BaseUIButton} from "@base-ui/react";

import type {ButtonProps} from "@/components/baseui-components/Button";

export type ButtonContextType = {state: BaseUIButton.State; props: Pick<ButtonProps, "size">};

export const ButtonContext = React.createContext<ButtonContextType | null>(null);

export function ButtonProvider(props: ButtonContextType & {children: ReactNode | ReactNode[]}) {
    const {children, ...rest} = props;
    const contextValue: ButtonContextType = React.useMemo(() => rest, [rest]);
    return <ButtonContext.Provider value={contextValue}>{children}</ButtonContext.Provider>;
}
