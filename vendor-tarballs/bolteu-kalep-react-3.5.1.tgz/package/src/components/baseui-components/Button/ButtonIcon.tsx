import * as React from "react";

import type {Button as BaseUIButton} from "@base-ui/react";
import {mergeProps, useRender} from "@base-ui/react";

import type {KalepIconElement} from "@bolteu/kalep-react-icons/dist/types";

import {useButtonContext} from "@/components/baseui-components/Button/context/useButtonContext";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

export interface ButtonIconProps extends Omit<useRender.ComponentProps<"span">, "className"> {
    className?: string | ((state: BaseUIButton.State) => string);
    /**
     * Example: `<Heart />`
     */
    icon: KalepIconElement;
}

/**
 * ### Button.Icon
 * Use this for the `Button` content in case you need to include icons
 * ```tsx
 *  <Button>
 *      <Button.Icon icon={<Heart />} />
 *      <Button.Label>Both Icons</Button.Label>
 *      <Button.Icon icon={<Heart />} />
 *  </Button>
 * ```
 */
export const ButtonIcon = React.forwardRef(function ButtonIcon(
    props: ButtonIconProps,
    ref: React.ForwardedRef<HTMLSpanElement>,
) {
    const {render, className, icon, ...rest} = props;
    const {
        state,
        props: {size},
    } = useButtonContext();
    const defaultProps: useRender.ElementProps<"span"> = {
        className: cx("icon flex", addConsumerClasses(state, className)),
        children: React.cloneElement(icon, {size}), // Cloning, because we need to pass the size to the actual icon
        "aria-hidden": true,
    };
    return useRender({
        defaultTagName: "span",
        render,
        ref,
        state,
        props: mergeProps<"span">(defaultProps, rest),
    });
});
