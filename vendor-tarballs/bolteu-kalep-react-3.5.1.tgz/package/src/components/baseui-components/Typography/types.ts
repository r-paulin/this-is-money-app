import type * as React from "react";

import type {useRender} from "@base-ui/react";

// copied from @/components/Typography/Typography.types
export type BoltFontStyles =
    | "heading-l-accent"
    | "heading-m-accent"
    | "heading-s-accent"
    | "heading-xs-accent"
    | "heading-xs-regular"
    | "body-l-regular"
    | "body-l-accent"
    | "body-l-compact-regular"
    | "body-l-compact-accent"
    | "body-m-regular"
    | "body-m-accent"
    | "body-m-compact-regular"
    | "body-m-compact-accent"
    | "body-s-regular"
    | "body-s-accent"
    | "body-s-compact-regular"
    | "body-s-compact-accent"
    | "body-xs-regular"
    | "body-xs-accent"
    | "body-xs-compact-regular"
    | "body-xs-compact-accent"
    | "body-tabular-l-regular"
    | "body-tabular-l-accent"
    | "body-tabular-l-compact-regular"
    | "body-tabular-l-compact-accent"
    | "body-tabular-m-regular"
    | "body-tabular-m-accent"
    | "body-tabular-m-compact-regular"
    | "body-tabular-m-compact-accent"
    | "body-tabular-s-regular"
    | "body-tabular-s-accent"
    | "body-tabular-s-compact-regular"
    | "body-tabular-s-compact-accent"
    | "body-tabular-xs-regular"
    | "body-tabular-xs-accent"
    | "body-tabular-xs-compact-regular"
    | "body-tabular-xs-compact-accent"
    | "caps-l-accent"
    | "caps-m-accent"
    | "caps-s-accent"
    | "display-m-regular";
export type TypographyLineClampValues = 1 | 2 | 3 | 4 | "none";
export type TypographySize =
    | "text-xs"
    | "text-sm"
    | "text-base"
    | "text-md"
    | "text-lg"
    | "text-xl"
    | "text-2xl"
    | "text-3xl"
    | "text-4xl"
    | "text-5xl"
    | "text-6xl";

export type TypographyStackVariant = "base" | "sm" | "sm-expressive";

export interface TypographyState {
    lines?: TypographyLineClampValues;
}

export interface TypographyStackState {
    variant: TypographyStackVariant;
}

type UseRenderProps = Omit<useRender.ComponentProps<"span", TypographyState>, "className">;

export interface TypographyProps extends UseRenderProps {
    className?: string | ((state: TypographyState) => string);
    defaultTag?: keyof React.JSX.IntrinsicElements;
    lines?: TypographyLineClampValues;
}

export interface TypographyStackProps extends Omit<useRender.ComponentProps<"div", TypographyStackState>, "className"> {
    className?: string | ((state: TypographyStackState) => string);
    variant?: TypographyStackVariant;
}

export interface TypographyStackContextValue extends TypographyStackState {}

export interface TypographyStackItemProps extends TypographyProps {}
