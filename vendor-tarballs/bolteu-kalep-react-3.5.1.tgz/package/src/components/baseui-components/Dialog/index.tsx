import {Dialog as BaseUIDialog} from "@base-ui/react";

import {DialogBackdropComponent} from "@/components/baseui-components/Dialog/Backdrop/Backdrop";
import {DialogCloseComponent} from "@/components/baseui-components/Dialog/Close/Close";
import {DialogDescriptionComponent} from "@/components/baseui-components/Dialog/Description/Description";
import {DialogFooterComponent} from "@/components/baseui-components/Dialog/Footer/Footer";
import {DialogHandleComponent} from "@/components/baseui-components/Dialog/Handle/Handle";
import {DialogHeaderComponent} from "@/components/baseui-components/Dialog/Header/Header";
import {DialogPopupComponent} from "@/components/baseui-components/Dialog/Popup/Popup";
import {DialogPortalComponent} from "@/components/baseui-components/Dialog/Portal/Portal";
import {DialogRootComponent} from "@/components/baseui-components/Dialog/Root/Root";
import {DialogTitleComponent} from "@/components/baseui-components/Dialog/Title/Title";
import {DialogTriggerComponent} from "@/components/baseui-components/Dialog/Trigger/Trigger";
import {DialogViewportComponent} from "@/components/baseui-components/Dialog/Viewport/Viewport";

export const Dialog = {
    Root: DialogRootComponent,
    Header: DialogHeaderComponent,
    Footer: DialogFooterComponent,
    Trigger: DialogTriggerComponent,
    Portal: DialogPortalComponent,
    Backdrop: DialogBackdropComponent,
    Popup: DialogPopupComponent,
    Viewport: DialogViewportComponent,
    Title: DialogTitleComponent,
    Description: DialogDescriptionComponent,
    Close: DialogCloseComponent,
    Handle: DialogHandleComponent,
    createHandle: BaseUIDialog.createHandle,
};

Object.assign(Dialog.Root, {
    displayName: "Dialog.Root",
});
Dialog.Header.displayName = "Dialog.Header";
Dialog.Footer.displayName = "Dialog.Footer";
Dialog.Trigger.displayName = "Dialog.Trigger";
Dialog.Portal.displayName = "Dialog.Portal";
Dialog.Backdrop.displayName = "Dialog.Backdrop";
Dialog.Viewport.displayName = "Dialog.Viewport";
Dialog.Popup.displayName = "Dialog.Popup";
Dialog.Title.displayName = "Dialog.Title";
Dialog.Description.displayName = "Dialog.Description";
Dialog.Close.displayName = "Dialog.Close";
Object.assign(Dialog.Handle, {displayName: "Dialog.Handle"});

export {useDialogPopup} from "@/components/baseui-components/Dialog/context/useDialogPopup";
