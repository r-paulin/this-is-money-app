import * as React from "react";

import type {Dialog as BaseUIDialog} from "@base-ui/react";
import {mergeProps, useRender} from "@base-ui/react";

import {useDialogPopup} from "@/components/baseui-components/Dialog/context/useDialogPopup";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

export interface DialogHeaderState extends BaseUIDialog.Popup.State {}
export interface DialogHeaderProps extends Omit<useRender.ComponentProps<"header">, "className"> {
    className?: string | ((state: DialogHeaderState) => string);
}
export const DialogHeaderComponent = React.forwardRef(function DialogHeaderComponent(
    props: DialogHeaderProps,
    ref: React.ForwardedRef<HTMLElement>,
) {
        const {render, className, ...otherComponentProps} = props;
        const {dialogPopupState} = useDialogPopup();

        const defaultProps: useRender.ElementProps<"header"> = {
            className: cx(
                "flex items-baseline justify-between gap-6 px-6 pb-4 pt-5",
                addConsumerClasses(dialogPopupState, className),
            ),
        };

        return useRender({
            defaultTagName: "header",
            render,
            ref,
            state: {...dialogPopupState},
            props: mergeProps<"header">(defaultProps, otherComponentProps),
        });
});
