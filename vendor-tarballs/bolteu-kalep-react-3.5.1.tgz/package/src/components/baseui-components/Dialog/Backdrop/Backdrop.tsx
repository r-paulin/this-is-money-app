import * as React from "react";

import {Dialog as BaseUIDialog} from "@base-ui/react";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

export const DialogBackdropComponent = React.forwardRef(function DialogBackdropComponent(
    props: BaseUIDialog.Backdrop.Props,
    ref: React.ForwardedRef<HTMLDivElement>,
) {
        const {className, ...rest} = props;
        const backdropClassname = React.useCallback(
            (state: BaseUIDialog.Backdrop.State) => {
                return cx(
                    "fixed inset-0 z-modalOverlay bg-special-scrim",
                    {"animate-overlayShow": state.open},
                    addConsumerClasses(state, className),
                );
            },
            [className],
        );
        return <BaseUIDialog.Backdrop {...rest} ref={ref} className={backdropClassname} />;
});
