import * as React from "react";

import type {Dialog as BaseUIDialog} from "@base-ui/react";
import {mergeProps, useRender} from "@base-ui/react";

import {useDialogPopup} from "@/components/baseui-components/Dialog/context/useDialogPopup";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

export interface DialogFooterState extends BaseUIDialog.Popup.State {}
export interface DialogFooterProps extends Omit<useRender.ComponentProps<"footer">, "className"> {
    className?: string | ((state: DialogFooterState) => string);
}

export const DialogFooterComponent = React.forwardRef(function DialogFooterComponent(
    props: DialogFooterProps,
    ref: React.ForwardedRef<HTMLElement>,
) {
        const {render, className, ...otherComponentProps} = props;
        const {dialogPopupState} = useDialogPopup();

        const defaultProps: useRender.ElementProps<"footer"> = {
            className: cx("px-6 pb-6 pt-4", "flex justify-end gap-4", addConsumerClasses(dialogPopupState, className)),
        };

        return useRender({
            defaultTagName: "footer",
            render,
            ref,
            state: {...dialogPopupState},
            props: mergeProps<"footer">(defaultProps, otherComponentProps),
        });
});
