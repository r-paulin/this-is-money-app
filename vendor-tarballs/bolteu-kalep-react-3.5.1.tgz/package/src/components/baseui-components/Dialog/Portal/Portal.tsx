import {Dialog as BaseUIDialog} from "@base-ui/react";

/**
 * Dialog.Portal
 *
 * Portals dialog content to a top-level layer for correct overlay rendering.
 */
export const DialogPortalComponent = BaseUIDialog.Portal;
