import * as React from "react";

import {Checkbox as BaseUICheckbox} from "@base-ui/react/checkbox";
import type {HTMLProps} from "@base-ui/react/utils/types";

import Check from "@bolteu/kalep-react-icons/dist/Check";

function Dash({className}: {className?: string}) {
    return (
        <svg
            width="12"
            height="2"
            viewBox="0 0 12 2"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className={className}
        >
            <path
                d="M11.25 2H0.75C0.3 2 0 1.6 0 1C0 0.4 0.3 0 0.75 0H11.25C11.7 0 12 0.4 12 1C12 1.6 11.625 2 11.25 2Z"
                fill="currentColor"
            />
        </svg>
    );
}

export const CheckboxIndicator = React.forwardRef(
    (props: BaseUICheckbox.Indicator.Props, ref: React.ForwardedRef<HTMLSpanElement>) => {
        const {render, ...rest} = props;
        const renderIndicator = React.useCallback(
            (_props: HTMLProps<HTMLSpanElement>, state: BaseUICheckbox.Indicator.State) => {
                return state.indeterminate ? <Dash /> : <Check height="22" width="22" />;
            },
            [],
        );
        return <BaseUICheckbox.Indicator render={render ?? renderIndicator} {...rest} ref={ref} />;
    },
);

CheckboxIndicator.displayName = "Checkbox.Indicator";
