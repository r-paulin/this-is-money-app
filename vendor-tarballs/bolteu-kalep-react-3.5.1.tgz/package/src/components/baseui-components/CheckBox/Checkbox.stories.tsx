import * as React from "react";

import type {Meta, StoryObj} from "@storybook/react-webpack5";

import {Checkbox} from "@/components/baseui-components/CheckBox";

import DocumentationTemplate from "../docs/DocumentationTemplate.mdx";

const meta = {
    component: Checkbox,
    title: "BaseUI Playground/Checkbox",
    tags: ["experimental", "BaseUI", "autodocs"],
    subcomponents: {"Checkbox.Indicator": Checkbox.Indicator},
    parameters: {
        docs: {
            subtitle: "A primitive Checkbox component",
            page: DocumentationTemplate,
        },
    },
} satisfies Meta<typeof Checkbox>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
    args: {},
};
export const Disabled: Story = {
    args: {
        disabled: true,
    },
};
export const Checked: Story = {
    args: {
        checked: true,
    },
};
export const CheckedDisabled: Story = {
    args: {
        checked: true,
        disabled: true,
    },
};

export const Indeterminate: Story = {
    args: {
        indeterminate: true,
    },
};
export const IndeterminateDisabled: Story = {
    args: {
        indeterminate: true,
        disabled: true,
    },
};

export const FullComposition: Story = {
    args: {
        children: <Checkbox.Indicator />,
    },
};

export const RenderProps: Story = {
    args: {
        render: <span />,
        children: <Checkbox.Indicator render={<span />} />,
    },
};
