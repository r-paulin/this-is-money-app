import * as React from "react";

import {Autocomplete as BaseUIAutocomplete} from "@base-ui/react/autocomplete";

/**
 * ### Autocomplete.Value
 * Renders the current string value of the autocomplete.
 * Doesn't render its own HTML element.
 *
 * ```tsx
 * <Autocomplete.Value>
 *   {(value) => <span>{value}</span>}
 * </Autocomplete.Value>
 * ```
 */
// WHY wrapper: Base UI shares the same JS object between Autocomplete.Value and
// Combobox.Value (they are `===`). A direct re-export would mean that setting
// `displayName` on our export also mutates Combobox.Value.displayName. Wrapping in
// a dedicated function component creates a unique identity so displayNames stay isolated.
// Note: Value renders no DOM element, so forwardRef is not needed — a plain function suffices.
export function AutocompleteValue(props: BaseUIAutocomplete.Value.Props): React.ReactElement {
    return <BaseUIAutocomplete.Value {...props} />;
}
