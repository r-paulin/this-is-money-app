export type AutocompleteSize = "sm" | "md" | "lg";
