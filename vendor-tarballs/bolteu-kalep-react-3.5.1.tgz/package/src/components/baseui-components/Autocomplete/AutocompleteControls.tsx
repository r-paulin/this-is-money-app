import * as React from "react";

import {mergeProps, useRender} from "@base-ui/react";
import type {Autocomplete as BaseUIAutocomplete} from "@base-ui/react/autocomplete";

import {useAutocompleteInputContextSelector} from "@/components/baseui-components/Autocomplete/context";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

export interface AutocompleteControlsState extends BaseUIAutocomplete.Input.State {}
export interface AutocompleteControlsProps extends Omit<useRender.ComponentProps<"div">, "className"> {
    className?: string | ((state: AutocompleteControlsState) => string);
}

/**
 * ### Autocomplete.Controls
 * Flex container for clear buttons, triggers, or custom actions.
 * Place it directly inside `Autocomplete.Input`.
 *
 * ```tsx
 * <Autocomplete.Input>
 *   <Autocomplete.Control />
 *   <Autocomplete.Controls>
 *     <Autocomplete.Clear />
 *     <Autocomplete.Trigger>
 *       <Autocomplete.Icon />
 *     </Autocomplete.Trigger>
 *   </Autocomplete.Controls>
 * </Autocomplete.Input>
 * ```
 */
export const AutocompleteControls = React.forwardRef(function AutocompleteControls(
    props: AutocompleteControlsProps,
    forwardRef: React.ForwardedRef<HTMLDivElement>,
) {
    const {render, className, ...otherComponentProps} = props;
    const autocompleteInputState = useAutocompleteInputContextSelector((context) => context.autocompleteInputState);

    const defaultProps: useRender.ElementProps<"div"> = {
        className: cx("flex items-center gap-2", addConsumerClasses(autocompleteInputState, className)),
    };

    return useRender({
        defaultTagName: "div",
        render,
        ref: forwardRef,
        state: {...autocompleteInputState},
        props: mergeProps<"div">(defaultProps, otherComponentProps),
    });
});
