import * as React from "react";

import type {Autocomplete as BaseUIAutocomplete} from "@base-ui/react/autocomplete";

export interface AutocompleteInputContextType {
    autocompleteInputState: BaseUIAutocomplete.Input.State;
    autocompleteInputProps: Omit<BaseUIAutocomplete.Input.Props, "children"> | null;
    inputRef: React.RefCallback<HTMLInputElement | null>;
}

const AutocompleteInputContext = React.createContext<AutocompleteInputContextType | null>(null);

interface AutocompleteInputContextProviderProps extends Omit<AutocompleteInputContextType, "controlRef"> {
    children: React.ReactNode;
}

export function AutocompleteInputContextProvider({
    children,
    autocompleteInputProps,
    autocompleteInputState,
    inputRef,
}: AutocompleteInputContextProviderProps) {
    const contextValue = React.useMemo(
        () => ({
            autocompleteInputProps,
            autocompleteInputState,
            inputRef,
        }),
        [autocompleteInputProps, autocompleteInputState, inputRef],
    );

    return <AutocompleteInputContext.Provider value={contextValue}>{children}</AutocompleteInputContext.Provider>;
}

export function useAutocompleteInputContext() {
    const context = React.useContext(AutocompleteInputContext);

    if (!context) {
        throw new Error("Autocomplete parts must be rendered within Autocomplete.Input");
    }

    return context;
}

type AutocompleteInputContextReadonly = AutocompleteInputContextType & {
    readonly autocompleteInputProps: Readonly<AutocompleteInputContextType["autocompleteInputProps"]>;
    readonly autocompleteInputState: Readonly<AutocompleteInputContextType["autocompleteInputState"]>;
};

export function useAutocompleteInputContextSelector<T>(selector: (context: AutocompleteInputContextReadonly) => T): T {
    const context = useAutocompleteInputContext();

    return selector(context);
}
