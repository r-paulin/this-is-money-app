import * as React from "react";

import {Autocomplete as BaseUIAutocomplete} from "@base-ui/react/autocomplete";
import type {BaseUIEvent, HTMLProps} from "@base-ui/react/utils/types";

import Clear from "@bolteu/kalep-react-icons/dist/Clear";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

import {useAutocompleteContextSelector, useAutocompleteInputContextSelector} from "./context";

/**
 * ### Autocomplete.Clear
 * Optional affordance for clearing the current input value.
 *
 * ```tsx
 * <Autocomplete.Controls>
 *   <Autocomplete.Clear aria-label="Clear input" />
 *   <Autocomplete.Trigger>…</Autocomplete.Trigger>
 * </Autocomplete.Controls>
 * ```
 */
export const AutocompleteClear = React.forwardRef(function AutocompleteClear(
    props: BaseUIAutocomplete.Clear.Props,
    forwardedRef: React.ForwardedRef<HTMLButtonElement>,
) {
    const {"aria-label": ariaLabel, className, render, ...rest} = props;

    const size = useAutocompleteContextSelector((context) => context.size);
    const readonly = useAutocompleteInputContextSelector(
        (context) => context.autocompleteInputProps?.readOnly ?? false,
    );

    const getAutocompleteClearClassNames = React.useCallback(
        (state: BaseUIAutocomplete.Clear.State) =>
            cx(
                "block text-tertiary",
                state.disabled
                    ? "cursor-not-allowed"
                    : `
                      cursor-pointer
                      hover:text-primary
                    `,
                addConsumerClasses(state, className),
            ),
        [className],
    );

    const renderDefault = React.useCallback(
        (renderProps: HTMLProps<HTMLButtonElement>, state: BaseUIAutocomplete.Clear.State) => {
            const {onMouseDown, onClick, className: clearClassName, ...remainingRenderProps} = renderProps;

            // Prevent the default onMouseDown behavior to avoid focus jumps
            const handleMouseDown = (event: BaseUIEvent<React.MouseEvent<HTMLButtonElement>>) => {
                event.preventDefault();
                event.stopPropagation();
                onMouseDown?.(event);
            };

            // Stop click from bubbling to the Input wrapper's onClick handler
            const handleClick = (event: BaseUIEvent<React.MouseEvent<HTMLButtonElement>>) => {
                event.stopPropagation();
                onClick?.(event);
            };

            if (state.disabled || readonly) {
                return <></>;
            }

            return (
                <button
                    {...remainingRenderProps}
                    aria-hidden="true"
                    type="button"
                    className={cx("border-0 bg-transparent p-0")}
                    onMouseDown={handleMouseDown}
                    onClick={handleClick}
                >
                    <Clear aria-hidden="true" className={clearClassName} size={size === "sm" ? "md" : "lg"} />
                </button>
            );
        },
        [size, readonly],
    );

    return (
        <BaseUIAutocomplete.Clear
            {...rest}
            aria-label={ariaLabel ?? "Clear input"}
            ref={forwardedRef}
            className={getAutocompleteClearClassNames}
            render={render ?? renderDefault}
        />
    );
});
