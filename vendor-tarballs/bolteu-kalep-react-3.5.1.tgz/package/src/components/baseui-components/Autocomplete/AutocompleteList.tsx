import * as React from "react";

import {Autocomplete as BaseUIAutocomplete} from "@base-ui/react/autocomplete";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Autocomplete.List
 * Scrollable container for option rows inside `Autocomplete.Popup`. Provide a function child to render
 * each item from the underlying collection.
 *
 * ```tsx
 * <Autocomplete.Portal>
 *   <Autocomplete.Positioner>
 *     <Autocomplete.Popup>
 *       <Autocomplete.List>
 *         {(item) => (
 *           <Autocomplete.Item key={item.value} value={item}>
 *             <span>{item.label}</span>
 *           </Autocomplete.Item>
 *         )}
 *       </Autocomplete.List>
 *     </Autocomplete.Popup>
 *   </Autocomplete.Positioner>
 * </Autocomplete.Portal>
 * ```
 */
export const AutocompleteList = React.forwardRef(function AutocompleteList(
    props: BaseUIAutocomplete.List.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, ...rest} = props;

    const getAutocompleteListClassNames = React.useCallback(
        (state: BaseUIAutocomplete.List.State) =>
            cx(
                `m-0 max-h-80 cursor-pointer list-none overflow-y-auto overscroll-none px-0 py-1`,
                addConsumerClasses(state, className),
            ),
        [className],
    );

    return <BaseUIAutocomplete.List {...rest} ref={forwardedRef} className={getAutocompleteListClassNames} />;
});
