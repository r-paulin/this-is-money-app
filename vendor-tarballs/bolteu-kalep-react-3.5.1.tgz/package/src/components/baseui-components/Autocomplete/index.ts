import {Autocomplete as BaseUIAutocomplete} from "@base-ui/react/autocomplete";

import {AutocompleteClear} from "./AutocompleteClear";
import {AutocompleteControl} from "./AutocompleteControl";
import {AutocompleteControls} from "./AutocompleteControls";
import {AutocompleteEmpty} from "./AutocompleteEmpty";
import {AutocompleteGroup} from "./AutocompleteGroup";
import {AutocompleteGroupLabel} from "./AutocompleteGroupLabel";
import {AutocompleteIcon} from "./AutocompleteIcon";
import {AutocompleteInput} from "./AutocompleteInput";
import {AutocompleteItem} from "./AutocompleteItem";
import {AutocompleteList} from "./AutocompleteList";
import {AutocompletePopup} from "./AutocompletePopup";
import {AutocompletePortal} from "./AutocompletePortal";
import {AutocompletePositioner} from "./AutocompletePositioner";
import {AutocompleteRoot} from "./AutocompleteRoot";
import {AutocompleteStatus} from "./AutocompleteStatus";
import {AutocompleteTrigger} from "./AutocompleteTrigger";
import {AutocompleteValue} from "./AutocompleteValue";

export const Autocomplete = {
    Root: AutocompleteRoot,
    Trigger: AutocompleteTrigger,
    Control: AutocompleteControl,
    Controls: AutocompleteControls,
    Input: AutocompleteInput,
    Icon: AutocompleteIcon,
    Clear: AutocompleteClear,
    List: AutocompleteList,
    Item: AutocompleteItem,
    Portal: AutocompletePortal,
    Positioner: AutocompletePositioner,
    Popup: AutocompletePopup,
    Value: AutocompleteValue,
    Group: AutocompleteGroup,
    GroupLabel: AutocompleteGroupLabel,
    Empty: AutocompleteEmpty,
    Status: AutocompleteStatus,
    useFilter: BaseUIAutocomplete.useFilter,
    useFilteredItems: BaseUIAutocomplete.useFilteredItems,
};

// Components without render implementation — typings don't allow displayName assignment
Object.assign(Autocomplete.Root, {displayName: "Autocomplete.Root"});
Object.assign(Autocomplete.Value, {displayName: "Autocomplete.Value"});

Autocomplete.Trigger.displayName = "Autocomplete.Trigger";
Autocomplete.Control.displayName = "Autocomplete.Control";
Autocomplete.Controls.displayName = "Autocomplete.Controls";
Autocomplete.Input.displayName = "Autocomplete.Input";
Autocomplete.Icon.displayName = "Autocomplete.Icon";
Autocomplete.Clear.displayName = "Autocomplete.Clear";
Autocomplete.List.displayName = "Autocomplete.List";
Autocomplete.Item.displayName = "Autocomplete.Item";
Autocomplete.Portal.displayName = "Autocomplete.Portal";
Autocomplete.Positioner.displayName = "Autocomplete.Positioner";
Autocomplete.Popup.displayName = "Autocomplete.Popup";
Autocomplete.Group.displayName = "Autocomplete.Group";
Autocomplete.GroupLabel.displayName = "Autocomplete.GroupLabel";
Autocomplete.Empty.displayName = "Autocomplete.Empty";
Autocomplete.Status.displayName = "Autocomplete.Status";

export {useAutocompleteContextSelector} from "./context";
