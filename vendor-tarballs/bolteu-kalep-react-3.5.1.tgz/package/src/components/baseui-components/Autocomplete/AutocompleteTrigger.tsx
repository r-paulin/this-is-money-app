import * as React from "react";

import {Autocomplete as BaseUIAutocomplete} from "@base-ui/react/autocomplete";
import type {HTMLProps} from "@base-ui/react/utils/types";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

import {useAutocompleteInputContextSelector} from "./context";

/**
 * ### Autocomplete.Trigger
 * Button used to toggle the popup, typically wrapping `Autocomplete.Icon`.
 *
 * ```tsx
 * <Autocomplete.Controls>
 *   <Autocomplete.Trigger>
 *     <Autocomplete.Icon />
 *   </Autocomplete.Trigger>
 * </Autocomplete.Controls>
 * ```
 */
export const AutocompleteTrigger = React.forwardRef(function AutocompleteTrigger(
    props: BaseUIAutocomplete.Trigger.Props,
    forwardedRef: React.ForwardedRef<HTMLButtonElement>,
) {
    const {className, children, render, ...rest} = props;

    const readOnly = useAutocompleteInputContextSelector(
        (context) => context.autocompleteInputProps?.readOnly ?? false,
    );

    const defaultRender = React.useCallback(
        (triggerProps: HTMLProps<HTMLButtonElement>, state: BaseUIAutocomplete.Trigger.State) => {
            const autocompleteTriggerClassNames = cx(
                "flex items-center border-0 bg-transparent p-0",
                state.disabled
                    ? "pointer-events-none cursor-not-allowed"
                    : readOnly
                      ? "cursor-default"
                      : "cursor-pointer",
                addConsumerClasses(state, className),
            );
            return (
                <button
                    {...triggerProps}
                    aria-hidden={readOnly}
                    className={autocompleteTriggerClassNames}
                    ref={triggerProps.ref}
                    type="button"
                >
                    {children}
                </button>
            );
        },
        [children, className, readOnly],
    );

    return (
        <BaseUIAutocomplete.Trigger {...rest} render={render ?? defaultRender} ref={forwardedRef}>
            {children}
        </BaseUIAutocomplete.Trigger>
    );
});
