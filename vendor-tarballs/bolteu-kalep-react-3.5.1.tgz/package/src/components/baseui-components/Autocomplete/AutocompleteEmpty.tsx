import * as React from "react";

import {Autocomplete as BaseUIAutocomplete} from "@base-ui/react/autocomplete";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Autocomplete.Empty
 * Placeholder content shown when the list has zero items.
 *
 * ```tsx
 * <Autocomplete.Popup>
 *   <Autocomplete.Empty>No results found</Autocomplete.Empty>
 *   <Autocomplete.List>…</Autocomplete.List>
 * </Autocomplete.Popup>
 * ```
 *
 * Combine with actions or hints to guide the user toward the next step.
 */
export const AutocompleteEmpty = React.forwardRef(function AutocompleteEmpty(
    props: BaseUIAutocomplete.Empty.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, children, ...rest} = props;

    const getAutocompleteEmptyClassNames = React.useCallback(
        (state: BaseUIAutocomplete.Empty.State) =>
            cx(
                `
                  flex items-center px-6 text-primary
                  [&:not(:empty)]:pt-2
                `,
                addConsumerClasses(state, className),
            ),
        [className],
    );

    return (
        <BaseUIAutocomplete.Empty {...rest} ref={forwardedRef} className={getAutocompleteEmptyClassNames}>
            {children}
        </BaseUIAutocomplete.Empty>
    );
});
