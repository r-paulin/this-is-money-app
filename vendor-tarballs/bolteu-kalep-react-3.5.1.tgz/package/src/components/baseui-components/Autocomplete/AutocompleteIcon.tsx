import * as React from "react";

import {Autocomplete as BaseUIAutocomplete} from "@base-ui/react/autocomplete";
import type {HTMLProps} from "@base-ui/react/utils/types";

import ChevronDown from "@bolteu/kalep-react-icons/dist/ChevronDown";

import {
    useAutocompleteContextSelector,
    useAutocompleteInputContextSelector,
} from "@/components/baseui-components/Autocomplete/context";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Autocomplete.Icon
 * Chevron/indicator rendered inside `Autocomplete.Trigger`.
 *
 * ```tsx
 * <Autocomplete.Trigger>
 *   <Autocomplete.Icon />
 * </Autocomplete.Trigger>
 * ```
 */
export const AutocompleteIcon = React.forwardRef(function AutocompleteIcon(
    props: BaseUIAutocomplete.Icon.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    const size = useAutocompleteContextSelector((context) => context.size);
    const disabled = useAutocompleteInputContextSelector((context) => context.autocompleteInputState?.disabled);
    const open = useAutocompleteInputContextSelector((context) => context.autocompleteInputState?.open);

    const {className, render, ...rest} = props;

    const getAutocompleteIconClassNames = React.useCallback(
        (state: BaseUIAutocomplete.Icon.State) =>
            cx(
                `transition-transform duration-100 ease-linear`,
                open && "rotate-180",
                disabled ? "text-tertiary" : "text-primary",
                addConsumerClasses(state, className),
            ),
        [className, disabled, open],
    );

    const renderDefault = React.useCallback(
        (iconProps: HTMLProps<HTMLDivElement>) => {
            return <ChevronDown {...iconProps} size={size === "sm" ? "md" : "lg"} aria-hidden="true" />;
        },
        [size],
    );

    return (
        <BaseUIAutocomplete.Icon
            {...rest}
            ref={forwardedRef}
            className={getAutocompleteIconClassNames}
            render={render ?? renderDefault}
        />
    );
});
