import * as React from "react";

import {Autocomplete as BaseUIAutocomplete} from "@base-ui/react/autocomplete";

/**
 * ### Autocomplete.Status
 * Displays a live-region status message announced politely to assistive technologies.
 * Useful for conveying the status of an asynchronously loaded list (e.g. loading,
 * error, or result count). Renders a `<div>` element.
 *
 * The component must stay **always mounted** so the ARIA live region is present in
 * the DOM when content changes — conditionally mounting/unmounting the container
 * causes screen readers to miss announcements. Update the *children* instead.
 *
 * ```tsx
 * <Autocomplete.Popup>
 *   <Autocomplete.Status>
 *     {statusMessage && (
 *       <div className="text-sm text-secondary">{statusMessage}</div>
 *     )}
 *   </Autocomplete.Status>
 *   <Autocomplete.List>{(item) => …}</Autocomplete.List>
 * </Autocomplete.Popup>
 * ```
 */
// WHY wrapper: Base UI shares the same JS object between Autocomplete.Status and
// Combobox.Status (they are `===`). A direct re-export would mean that setting
// `displayName` on our export also mutates Combobox.Status.displayName. Wrapping in
// a dedicated forwardRef creates a unique function identity so displayNames stay isolated.
export const AutocompleteStatus = React.forwardRef(function AutocompleteStatus(
    props: BaseUIAutocomplete.Status.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    return <BaseUIAutocomplete.Status {...props} ref={forwardedRef} />;
});
