import * as React from "react";

import {Autocomplete as BaseUIAutocomplete} from "@base-ui/react/autocomplete";

/**
 * ### Autocomplete.Portal
 *
 * Renders autocomplete popup content in a portal outside the trigger's layout context.
 * By default, the portal element is appended to `<body>`.
 * Renders a `<div>` element.
 */
// WHY wrapper: Base UI shares the same JS object between Autocomplete.Portal and
// Combobox.Portal (they are `===`). A direct re-export would mean that setting
// `displayName` on our export also mutates Combobox.Portal.displayName. Wrapping in
// a dedicated forwardRef creates a unique function identity so displayNames stay isolated.
export const AutocompletePortal = React.forwardRef(function AutocompletePortal(
    props: BaseUIAutocomplete.Portal.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    return <BaseUIAutocomplete.Portal {...props} ref={forwardedRef} />;
});
