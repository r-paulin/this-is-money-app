import * as React from "react";

import {Input as BaseUIInput} from "@base-ui/react";
import type {BaseUIComponentProps, HTMLProps} from "@base-ui/react/utils/types";

import type {FieldSize, PropsWithFieldSize} from "@/components/baseui-components/types/common-types";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {useId} from "@/helpers";
import {cx} from "@/helpers/utils/cx";
import {mergeRefs} from "@/helpers/utils/mergeRefs";

const textAreaStyles: Record<FieldSize, string> = {
    sm: "p-2 bolt-font-body-s-regular",
    md: "p-2 bolt-font-body-m-regular",
    lg: "p-3 bolt-font-body-m-regular",
};

const textAreaHeights: Record<FieldSize, string> = {
    sm: "h-20 min-h-comp-s",
    md: "h-28 min-h-comp-m",
    lg: "h-36 min-h-comp-l",
};

const states: Record<"idle" | "disabled" | "error", string> = {
    idle: "border-special-nulled focus:border-action-primary text-primary",
    disabled: "border-neutral-secondary cursor-not-allowed text-tertiary bg-special-nulled placeholder-tertiary",
    error: "border-danger-primary focus:border-danger-primary focus:shadow-inner text-primary caret-danger-primary",
};
export type TextAreaState = BaseUIInput.State;

export type TextAreaProps = BaseUIComponentProps<"textarea", TextAreaState> &
    Omit<BaseUIInput.Props, keyof BaseUIComponentProps<"textarea", TextAreaState>>;

/**
 * ### Composition guide
 *
 * ```tsx
 *  <TextArea />
 * ```
 *
 * A `render` prop is provided for the `TextArea` component to allow custom rendering of the component.
 *
 * See `Field` and `Form` component documentation for better understanding of the field composition in a form.
 */
export const TextArea = React.forwardRef(function TextArea(
    props: PropsWithFieldSize<TextAreaProps>,
    forwardedRef: React.ForwardedRef<HTMLTextAreaElement>,
) {
    const {fieldSize = "md", className, id: idProp, render, ...otherProps} = props;

    const generatedId = useId();
    const textAreaId = idProp ?? `kalep-text-area-${generatedId}`;
    const textAreaClassName = React.useCallback(
        function cn(state: TextAreaState) {
            const invalid = state.valid === false;
            return cx(
                "w-full resize-y",
                "rounded-md border-2 outline-none",
                "bg-neutral-secondary placeholder-secondary caret-action-primary",
                "duration-100 ease-linear",
                "focus:bg-special-nulled",
                {
                    [states.error]: invalid,
                    [states.disabled]: state.disabled,
                    [states.idle]: !invalid && !state.disabled,
                },
                typeof props.rows === "undefined" && textAreaHeights[fieldSize],
                textAreaStyles[fieldSize],
                addConsumerClasses(state, className),
            );
        },
        [className, fieldSize, props.rows],
    );

    const defaultRender = React.useCallback(
        function renderTextArea(
            {ref: baseUIRef, ...renderProps}: HTMLProps<HTMLTextAreaElement>,
            state: TextAreaState,
        ) {
            const ref = mergeRefs([baseUIRef, forwardedRef]);
            return <textarea ref={ref} {...renderProps} className={cx(textAreaClassName(state))} />;
        },
        [forwardedRef, textAreaClassName],
    );
    return (
        <BaseUIInput
            // NOTE: BaseUIInput is typed as an <input>, but we want a <textarea>.
            // We adapt via render() and cast the remaining props once here.
            // TODO: Replace this when BaseUI exposes a textarea primitive or
            //       low-level hooks/context for custom components, that would work inside `Field.*`
            id={textAreaId}
            render={render ?? defaultRender}
            {...(otherProps as Partial<BaseUIInput.Props>)}
        />
    );
});
