import type {Meta, StoryObj} from "@storybook/react-webpack5";

import {TextArea} from "@/components/baseui-components/TextArea/TextArea";

import DocumentationTemplate from "../docs/DocumentationTemplate.mdx";

const meta = {
    component: TextArea,
    title: "BaseUI Playground/TextArea",
    tags: ["experimental", "BaseUI", "autodocs"],
    parameters: {
        docs: {
            subtitle: "A primitive TextArea component",
            page: DocumentationTemplate,
        },
    },
} satisfies Meta<typeof TextArea>;

export default meta;

type Story = StoryObj<typeof meta>;

export const Default: Story = {
    args: {
        placeholder: "placeholder",
        className: "max-w-md",
        onValueChange: console.log,
    },
};

export const Disabled: Story = {
    args: {
        placeholder: "I'm disabled",
        className: "max-w-md",
        disabled: true,
    },
};

export const WithStringBasedClassnames: Story = {
    args: {
        placeholder: "placeholder",
        className: "max-w-md shadow-lg",
    },
};
