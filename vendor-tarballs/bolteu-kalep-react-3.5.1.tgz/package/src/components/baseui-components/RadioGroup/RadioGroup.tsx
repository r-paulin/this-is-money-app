import * as React from "react";

import {RadioGroup as BaseUIRadioGroup} from "@base-ui/react";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Composition guide
 * Radio buttons should be included inside a `RadioGroup` component:
 * ```tsx
 * <RadioGroup name="field-name" defaultValue="option-1">
 *   <Radio value="option-1" />
 *   <Radio value="option-2" />
 * </RadioGroup>
 * ```
 *
 * A `render` prop is provided for the `Radio` and `RadioGroup` components to
 * allow custom rendering of the components respectively.
 *
 * See `Field` and `Form` component documentation for better understanding of the field composition in a form.
 */
export const RadioGroup = React.forwardRef(function RadioGroup(
    props: BaseUIRadioGroup.Props,
    ref: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, ...otherProps} = props;

    const radioGroupClassName = React.useCallback(
        (state: BaseUIRadioGroup.State) => {
            return cx("flex flex-col items-start gap-3", addConsumerClasses(state, className));
        },
        [className],
    );
    return <BaseUIRadioGroup ref={ref} className={radioGroupClassName} {...otherProps} />;
});
