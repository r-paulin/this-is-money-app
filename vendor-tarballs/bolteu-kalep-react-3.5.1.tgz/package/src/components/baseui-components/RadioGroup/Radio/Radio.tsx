import * as React from "react";

import {Radio as BaseUIRadio} from "@base-ui/react";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

export const Radio = React.forwardRef(function Radio(
    props: BaseUIRadio.Root.Props,
    ref: React.ForwardedRef<HTMLSpanElement>,
) {
    const {className, ...rest} = props;

    const radioRootClassname = React.useCallback(
        (state: BaseUIRadio.Root.State) => {
            const {disabled, valid, checked} = state;
            const invalid = valid === false;
            return cx(
                "m-0 flex h-6 w-6 shrink-0 rounded-full",
                "border-2 border-solid bg-special-nulled",
                "duration-150 ease-linear",
                disabled ? "cursor-not-allowed border-0 bg-special-disabled" : "cursor-pointer",
                invalid ? "border-danger-primary" : "border-neutral-primary",
                {
                    "border-[7px]": checked,
                    "border-action-primary": checked && !invalid,
                    "border-separator bg-special-nulled": disabled && checked,
                    "bg-static-key-light": !disabled && checked,
                    "hover:border-active-danger-primary": disabled && invalid,
                    "hover:border-active-neutral-primary": !disabled && !invalid,
                    "hover:border-active-action-primary": !disabled && !invalid && checked,
                },
                addConsumerClasses(state, className),
            );
        },
        [className],
    );
    return <BaseUIRadio.Root className={radioRootClassname} {...rest} ref={ref} />;
});
