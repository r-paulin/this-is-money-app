import * as React from "react";

import type {Meta, StoryObj} from "@storybook/react-webpack5";

import DocumentationTemplate from "@/components/baseui-components/docs/DocumentationTemplate.mdx";
import {Radio} from "@/components/baseui-components/RadioGroup/Radio/Radio";
import {RadioGroup} from "@/components/baseui-components/RadioGroup/RadioGroup";

const meta = {
    component: RadioGroup,
    title: "BaseUI Playground/Radio",
    tags: ["experimental", "BaseUI", "autodocs"],
    subcomponents: {Radio},
    parameters: {
        docs: {
            subtitle: "RadioGroup and Radio button component for selecting a single option from a set.",
            page: DocumentationTemplate,
        },
    },
} satisfies Meta<typeof RadioGroup>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
    args: {
        defaultValue: "test-value-1",
        children: [
            <Radio value="test-value-1" />,
            <Radio value="test-value-2" />,
            <Radio value="test-value-3" disabled />,
        ],
    },
};
