import * as React from "react";

import {mergeProps, useRender} from "@base-ui/react";

import {SpinnerIcon} from "@/components/_internal/SpinnerIcon";
import type {Indexable} from "@/components/baseui-components/types/common-types";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

import {CLASSNAME_TW_SPINNER_SIZE_MAP, type SpinnerSize} from "./spinner.types";

type SpinnerState = Indexable<{
    size: SpinnerSize;
}>;

export interface SpinnerProps extends Omit<useRender.ComponentProps<"span", SpinnerState>, "className"> {
    /**
     * Supported sizes:
     * xs=16px, sm=20px, md=20px, lg=24px, xl=36px,
     * 400=16px, 500=24px, 600=36px, 700=48px, inherit=100%.
     */
    size?: SpinnerSize;
    className?: string | ((state: SpinnerState) => string | undefined);
}

/**
 * ### Spinner
 * Basic indeterminate loader.
 *
 * ```tsx
 * <Spinner />
 * ```
 */
export const Spinner = React.forwardRef(function Spinner(
    props: SpinnerProps,
    ref: React.ForwardedRef<HTMLSpanElement>,
) {
    const {size = 500, className, render, ...restProps} = props;
    const state = React.useMemo<SpinnerState>(
        () => ({
            size,
        }),
        [size],
    );
    const sizeClassName = CLASSNAME_TW_SPINNER_SIZE_MAP[size];
    const icon = <SpinnerIcon aria-hidden="true" size="inherit" className={cx("inline-block animate-spin")} />;

    const defaultProps: useRender.ElementProps<"span"> = {
        role: "status",
        "aria-live": "polite",
        className: cx(
            "inline-flex items-center justify-center text-action-primary",
            sizeClassName,
            addConsumerClasses(state, className),
        ),
        children: icon,
    };

    return useRender({
        defaultTagName: "span",
        render,
        ref,
        state,
        props: mergeProps(defaultProps, restProps),
    });
});
