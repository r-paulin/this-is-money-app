import * as React from "react";

import {expect, within} from "storybook/test";
import type {Meta, StoryObj} from "@storybook/react-webpack5";

import {Spinner} from "@/components/baseui-components/Spinner";

import DocumentationTemplate from "../docs/DocumentationTemplate.mdx";

const meta = {
    component: Spinner,
    title: "BaseUI Playground/Spinner",
    tags: ["experimental", "BaseUI", "autodocs"],
    parameters: {
        docs: {
            subtitle: "A Base UI powered indeterminate progress indicator.",
            page: DocumentationTemplate,
        },
    },
} satisfies Meta<typeof Spinner>;

export default meta;

type Story = StoryObj<typeof meta>;

const withSource = (code: string) => ({
    parameters: {
        docs: {
            source: {
                code,
            },
        },
    },
});

export const Default: Story = {
    args: {},
    ...withSource("<Spinner />"),
    play: async ({canvasElement}) => {
        const spinner = within(canvasElement).getByRole("status");
        await expect(spinner).toBeInTheDocument();
        await expect(spinner).toHaveClass("text-action-primary");
    },
};

const sizesStorySource = `
<div className="flex flex-wrap items-center gap-6">
  <Spinner size="xs" />
  <Spinner size="sm" />
  <Spinner size="md" />
  <Spinner size="lg" />
  <Spinner size="xl" />
  <Spinner size={400} />
  <Spinner size={500} />
  <Spinner size={600} />
  <Spinner size={700} />
  <div className="h-20 w-20">
    <Spinner size="inherit" />
  <div>
</div>
`.trim();

export const Sizes: Story = {
    ...withSource(sizesStorySource),
    render: () => (
        <div className="flex flex-wrap items-center gap-6">
            <Spinner size="xs" />
            <Spinner size="sm" />
            <Spinner size="md" />
            <Spinner size="lg" />
            <Spinner size="xl" />
            <Spinner size={400} />
            <Spinner size={500} />
            <Spinner size={600} />
            <Spinner size={700} />
            <div className="h-20 w-20">
                <Spinner size="inherit" />
            </div>
        </div>
    ),
};

const paletteStorySource = `
const colors = [
  "text-primary",
  "text-primary-inverted",
  "text-secondary",
  "text-tertiary",
  "text-action-primary",
  "text-action-secondary",
  "text-danger-primary",
  "text-danger-secondary",
  "text-warning-primary",
  "text-warning-secondary",
  "text-positive-primary",
  "text-positive-secondary",
  "text-promo-primary",
  "text-promo-secondary",
  "text-link-primary",
  "text-link-secondary",
];

<div className="grid grid-cols-4 gap-4">
  {colors.map((className) => (
    <Spinner className={className} key={className} />
  ))}
</div>
`.trim();

export const Palette: Story = {
    ...withSource(paletteStorySource),
    render: () => {
        const colorClasses = [
            "text-primary",
            "text-primary-inverted",
            "text-secondary",
            "text-tertiary",
            "text-action-primary",
            "text-action-secondary",
            "text-danger-primary",
            "text-danger-secondary",
            "text-warning-primary",
            "text-warning-secondary",
            "text-positive-primary",
            "text-positive-secondary",
            "text-promo-primary",
            "text-promo-secondary",
            "text-link-primary",
            "text-link-secondary",
        ];

        return (
            <div className="grid grid-cols-4 gap-4">
                {colorClasses.map((className) => (
                    <Spinner className={className} key={className} />
                ))}
            </div>
        );
    },
};

export const CustomClasses: Story = {
    args: {
        className: "border border-action-secondary rounded-full",
        size: 600,
    },
    ...withSource('<Spinner className="border border-action-secondary rounded-full" size={600} />'),
};
