import {Control} from "./Control/Control";
import {Description} from "./Description/Description";
import {Error} from "./Error/Error";
import {Item} from "./Item/Item";
import {Label} from "./Label/Label";
import {Root} from "./Root/Root";
import {Validity} from "./Validity/Validity";

/**
 * Field compound component.
 *
 * Provides a set of subcomponents for building form fields:
 * - `Field.Root`: the main container
 * - `Field.Label`: label for the field
 * - `Field.Item`: wrapper for option type fields: `Radio`, `Checkbox`
 * - `Field.Description`: description text for the field
 * - `Field.Control`: the form control element. Can be `Input`, `Select`, `Switch`, etc.
 * - `Field.Error`: error message. Displayed, when the field is marked invalid in the `Form` level
 * - `Field.Validity`: validity state management. Can be used, if you don't need to display the field description and the error message at the same time.
 *
 * ### Composition guide
 * ```tsx
 * <Field.Root>
 *     <Field.Label>Label</Field.Label>
 *     <Field.Control />
 *     <Field.Description>Description text</Field.Description>
 *     <Field.Error>Error text</Field.Error>
 *     <Field.Validity>
 *         {(state: Field.Validity.State) => {
 *             return <div>...</div>
 *         }}
 *     </Field.Validity>
 * </Field.Root>
 * ```
 */
export const Field = {
    Root,
    Label,
    Description,
    Control,
    Item,
    Error,
    Validity,
};

Field.Root.displayName = "Field.Root";
Field.Label.displayName = "Field.Label";
Field.Item.displayName = "Field.Item";
Field.Description.displayName = "Field.Description";
Field.Control.displayName = "Field.Control";
Field.Error.displayName = "Field.Error";
Field.Validity.displayName = "Field.Validity";
