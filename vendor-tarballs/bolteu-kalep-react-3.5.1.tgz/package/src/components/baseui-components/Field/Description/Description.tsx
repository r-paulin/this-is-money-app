import * as React from "react";

import {Field as BaseUIField} from "@base-ui/react/field";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

export const Description = React.forwardRef(function Description(
    props: BaseUIField.Description.Props,
    ref: React.ForwardedRef<HTMLParagraphElement>,
) {
    const {className, render = <span />, ...rest} = props;
    const descriptionClassName = React.useCallback(
        (state: BaseUIField.Description.State) => {
            return cx(
                "bolt-font-body-s-regular text-secondary",
                state.disabled && "text-tertiary",
                addConsumerClasses(state, className),
            );
        },
        [className],
    );

    return <BaseUIField.Description render={render} className={descriptionClassName} {...rest} ref={ref} />;
});
