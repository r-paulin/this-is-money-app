import * as React from "react";

import {Field as BaseUIField} from "@base-ui/react/field";

import {Input} from "@/components/baseui-components/Input";

export const Control = React.forwardRef(function Control(
    props: BaseUIField.Control.Props,
    ref: React.ForwardedRef<HTMLInputElement>,
) {
    const {render, ...rest} = props;

    return <BaseUIField.Control render={render ?? <Input />} {...rest} ref={ref} />;
});
