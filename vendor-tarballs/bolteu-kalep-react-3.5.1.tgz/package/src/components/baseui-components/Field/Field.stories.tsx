import * as React from "react";

import type {Meta, StoryObj} from "@storybook/react-webpack5";

import {Checkbox} from "@/components/baseui-components/CheckBox";
import {CheckboxGroup} from "@/components/baseui-components/CheckboxGroup";
import {Fieldset} from "@/components/baseui-components/Fieldset/Fieldset";
import {Form} from "@/components/baseui-components/Form";
import {Input} from "@/components/baseui-components/Input";
import {PasswordInput} from "@/components/baseui-components/PasswordInput";
import {RadioGroup} from "@/components/baseui-components/RadioGroup";
import {Radio} from "@/components/baseui-components/RadioGroup/Radio/Radio";
import {Switch} from "@/components/baseui-components/Switch";
import {TextArea} from "@/components/baseui-components/TextArea/TextArea";

import DocumentationTemplate from "../docs/DocumentationTemplate.mdx";
import {Field} from "./index";

const meta = {
    // @ts-expect-error -- Not entirely sure, how to fix this in order to have proper JSDoc displayed
    component: Field,
    subcomponents: {
        "Field.Root": Field.Root,
        "Field.Label": Field.Label,
        "Field.Description": Field.Description,
        "Field.Error": Field.Error,
        "Field.Control": Field.Control,
        "Field.Validity": Field.Validity,
    },
    title: "BaseUI Playground/Field",
    tags: ["experimental", "BaseUI", "autodocs"],
    parameters: {
        docs: {
            subtitle: "Components to provide labelling and validation for form controls.",
            page: DocumentationTemplate,
        },
    },
} satisfies Meta<typeof Field>;

export default meta;

type Story = StoryObj<typeof meta>;

/**
 * Basic Field composition example
 */
export const FieldStory: Story = {
    render: (args) => (
        <Field.Root {...args}>
            <Field.Label>Label</Field.Label>
            <Field.Control />
            <Field.Description>Description text</Field.Description>
            <Field.Error>Error text</Field.Error>
        </Field.Root>
    ),
};

/**
 * Disabled field example
 */
export const DisabledField: Story = {
    args: {
        disabled: true,
    },
    render: (args) => (
        <Field.Root {...args}>
            <Field.Label>Label</Field.Label>
            <Field.Control />
            <Field.Description>Description text</Field.Description>
            <Field.Error>Error text</Field.Error>
        </Field.Root>
    ),
};

/**
 * Invalid field example, where error message is provided from Form level
 */
export const InvalidFieldMessageFromForm: Story = {
    args: {
        name: "invalid-field",
        validationMode: "onChange",
    },
    render: (args) => {
        return (
            <Form
                errors={{
                    ["invalid-field"]:
                        "To render the Error message in Form level, do not add `children` to the `Field.Error` component.",
                }}
            >
                <Field.Root {...args}>
                    <Field.Label>Label</Field.Label>
                    <Field.Control required />
                    <Field.Description>Description text</Field.Description>
                    <Field.Error />
                </Field.Root>
            </Form>
        );
    },
};
/**
 * Invalid field example, where error message is provided from Field.Error component
 */
export const InvalidFieldMessageFromErrorComponent: Story = {
    args: {
        name: "invalid-field",
        validationMode: "onChange",
    },
    render: (args) => {
        return (
            <Form errors={{["invalid-field"]: "This will be overridden by Field.Error component"}}>
                <Field.Root {...args}>
                    <Field.Label>Label</Field.Label>
                    <Field.Control required />
                    <Field.Description>Description text</Field.Description>
                    <Field.Error>Error message configured in `Field.Error` component</Field.Error>
                </Field.Root>
            </Form>
        );
    },
};

const InvalidFieldHidesDescriptionStoryCode = `
<Form>
    <Field.Root
        name="invalid-field"
        validationMode="onChange"
        validate={(value) => {
            if (value === "invalid") {
                return "Error message";
            }
            // Return null when valid
            return null;
        }}
    >
        <Field.Label>Label</Field.Label>
        <Field.Control placeholder="Type 'invalid' to see the error" />
        <Field.Validity>
            {(validity) => {
                if (validity.validity.valid === false) {
                    return <Field.Error>Error message</Field.Error>;
                }
                return <Field.Description>Description text</Field.Description>;
            }}
        </Field.Validity>
    </Field.Root>
</Form>
`.trim();

/**
 * Invalid field example, where `Field.Description` is hidden when field is invalid
 */
export const InvalidFieldHidesDescription: Story = {
    parameters: {
        docs: {
            source: {
                code: InvalidFieldHidesDescriptionStoryCode,
            },
        },
    },

    render: (_args) => {
        return (
            <Form>
                <Field.Root
                    name="invalid-field"
                    validationMode="onChange"
                    validate={(value) => {
                        if (value === "invalid") {
                            return "Error message";
                        }
                        // Return `null` when valid
                        return null;
                    }}
                >
                    <Field.Label>Label</Field.Label>
                    <Field.Control placeholder="Type 'invalid' to see the error" />
                    <Field.Validity>
                        {(validity) => {
                            if (validity.validity.valid === false) {
                                return <Field.Error>Error message</Field.Error>;
                            }
                            return <Field.Description>Description text</Field.Description>;
                        }}
                    </Field.Validity>
                </Field.Root>
            </Form>
        );
    },
};

/**
 * PasswordInput usage with Field and Form composition
 */
export const PasswordInputInForm: Story = {
    render: () => {
        return (
            <Form className="max-w-96">
                <Field.Root
                    name="password"
                    validationMode="onChange"
                    validate={(value) => {
                        const stringValue = String(value ?? "");
                        if (stringValue.length < 8) {
                            return "Password must contain at least 8 characters.";
                        }
                        return null;
                    }}
                >
                    <Field.Label>Password</Field.Label>
                    <PasswordInput
                        autoComplete="new-password"
                        placeholder="Create a password"
                    />
                    <Field.Validity>
                        {(validity) => {
                            if (validity.validity.valid === false) {
                                return <Field.Error />;
                            }
                            return <Field.Description>Use at least 8 characters.</Field.Description>;
                        }}
                    </Field.Validity>
                </Field.Root>
            </Form>
        );
    },
};

/**
 * Multiple, different types of fields example
 */
export const MultipleFields: Story = {
    render: (_args) => (
        <Form
            className="flex max-w-96 flex-col gap-4"
            validationMode="onChange"
            errors={{
                ["text-field"]: "invalid",
                checkbox: "invalid",
                switch: "invalid",
            }}
        >
            <Field.Root name="checkbox-group" render={<Fieldset />}>
                <Fieldset.Legend>Select one or many</Fieldset.Legend>
                <CheckboxGroup>
                    <Field.Item>
                        <Field.Label inline>
                            <Checkbox value="option-1" />
                            Option 1
                        </Field.Label>
                    </Field.Item>
                    <Field.Item>
                        <Field.Label inline>
                            <Checkbox value="option-2" />
                            Option 2
                        </Field.Label>
                    </Field.Item>
                    <Field.Item>
                        <Field.Label inline>
                            <Checkbox value="option-3" />
                            Option 3
                        </Field.Label>
                    </Field.Item>
                </CheckboxGroup>
            </Field.Root>
            <Field.Root name="text-field">
                <Field.Label>Label</Field.Label>
                <Field.Control required />
                <Field.Description>Field description</Field.Description>
                <Field.Error>Error text</Field.Error>
            </Field.Root>
            <Field.Root name="text-field-input">
                <Field.Label>Website</Field.Label>
                <Input>
                    <Input.Slot>www.</Input.Slot>
                    <Input.Control placeholder="example" />
                    <Input.Slot>.eu</Input.Slot>
                </Input>
                <Field.Description>Field description</Field.Description>
                <Field.Error>Error text</Field.Error>
            </Field.Root>
            <Field.Root name="password-field">
                <Field.Label>Password</Field.Label>
                <PasswordInput placeholder="Create a password" />
                <Field.Description>Use at least 8 characters.</Field.Description>
                <Field.Error>Error text</Field.Error>
            </Field.Root>
            <Field.Root name="text-area-input">
                <Field.Label>Area</Field.Label>
                <TextArea />
                <Field.Description>Field description</Field.Description>
                <Field.Error>Error text</Field.Error>
            </Field.Root>
            <Field.Root name="checkbox">
                <Field.Label inline>
                    <Field.Control required render={<Checkbox />} />
                    Do you agree?
                </Field.Label>
                <Field.Error>Error text</Field.Error>
            </Field.Root>
            <Field.Root>
                <Field.Label>Choose an option</Field.Label>
                <Field.Control render={<RadioGroup name="invalid-test" defaultValue="2" />}>
                    <Field.Item>
                        <Field.Label inline>
                            <Radio value="1" />
                            Option 1
                        </Field.Label>
                    </Field.Item>
                    <Field.Item disabled>
                        <Field.Label inline>
                            <Radio value="2" />
                            Option 2
                        </Field.Label>
                    </Field.Item>
                    <Field.Item>
                        <Field.Label inline>
                            <Radio value="3" />
                            Option 3
                        </Field.Label>
                    </Field.Item>
                </Field.Control>
                <Field.Description>Helper Text</Field.Description>
            </Field.Root>
            <Field.Root>
                <Field.Label>Choose an option</Field.Label>
                <Field.Control render={<RadioGroup name="valid-test" />}>
                    <Field.Item>
                        <Field.Label inline>
                            <Radio value="1" />
                            Option 1
                        </Field.Label>
                    </Field.Item>
                    <Field.Item>
                        <Field.Label inline>
                            <Radio value="2" />
                            Option 2
                        </Field.Label>
                    </Field.Item>
                    <Field.Item disabled>
                        <Field.Label inline>
                            <Radio value="3" />
                            Option 3
                        </Field.Label>
                    </Field.Item>
                </Field.Control>
                <Field.Description>Helper Text</Field.Description>
            </Field.Root>
            <Field.Root name="switch" disabled>
                <Field.Label inline>
                    <Field.Control render={<Switch />} />
                    Are you sure?
                </Field.Label>
                <Field.Error>Error text</Field.Error>
            </Field.Root>
        </Form>
    ),
};
