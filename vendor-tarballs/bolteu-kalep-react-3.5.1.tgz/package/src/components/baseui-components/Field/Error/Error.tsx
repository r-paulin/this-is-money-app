import * as React from "react";

import {Field as BaseUIField} from "@base-ui/react/field";

import {cx} from "@/helpers/utils/cx";

export const Error = React.forwardRef(function Error(
    props: BaseUIField.Error.Props,
    ref: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, ...rest} = props;

    return (
        <BaseUIField.Error
            className={cx("bolt-font-body-s-regular text-danger-primary", className)}
            {...rest}
            ref={ref}
        />
    );
});
