import * as React from "react";

import {mergeProps, useRender} from "@base-ui/react";
import type {Combobox as BaseUICombobox} from "@base-ui/react/combobox";

import {useComboboxInputContextSelector} from "@/components/baseui-components/Combobox/context";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

export interface ComboboxValueAreaState extends BaseUICombobox.Input.State {}
export interface ComboboxValueAreaProps extends Omit<useRender.ComponentProps<"div">, "className"> {
    className?: string | ((state: ComboboxValueAreaState) => string);
}

/**
 * ### Combobox.ValueArea
 * Handles layout for `Combobox.Control` and chips.
 *
 * ```tsx
 * <Combobox.ValueArea>
 *   <Combobox.Control />
 * </Combobox.ValueArea>
 * ```
 *
 * For `multiple`, place `Combobox.Value` (rendering chips) inside the same value area before the control.
 */
export const ComboboxValueArea = React.forwardRef(function ComboboxValueArea(
    props: ComboboxValueAreaProps,
    forwardRef: React.ForwardedRef<HTMLDivElement>,
) {
    const {render, className, children, ...otherComponentProps} = props;
    const comboboxInputState = useComboboxInputContextSelector((context) => context.comboboxInputState);

    const defaultProps: useRender.ElementProps<"div"> = {
        className: cx(
            `flex min-w-0 flex-1 flex-wrap items-center gap-2 overflow-hidden`,
            addConsumerClasses(comboboxInputState, className),
        ),
        children,
    };

    return useRender({
        defaultTagName: "div",
        render,
        ref: forwardRef,
        state: {...comboboxInputState},
        props: mergeProps<"div">(defaultProps, otherComponentProps),
    });
});
