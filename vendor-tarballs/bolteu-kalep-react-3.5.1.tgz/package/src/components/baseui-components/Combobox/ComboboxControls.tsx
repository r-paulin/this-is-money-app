import * as React from "react";

import {mergeProps, useRender} from "@base-ui/react";
import type {Combobox as BaseUICombobox} from "@base-ui/react/combobox";

import {useComboboxInputContextSelector} from "@/components/baseui-components/Combobox/context";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

export interface ComboboxControlsState extends BaseUICombobox.Input.State {}
export interface ComboboxControlsProps extends Omit<useRender.ComponentProps<"div">, "className"> {
    className?: string | ((state: ComboboxControlsState) => string);
}

/**
 * ### Combobox.Controls
 * Flex container for clear buttons, triggers, or custom actions. Place it directly inside `Combobox.Input`.
 *
 * ```tsx
 * <Combobox.Input>
 *   <Combobox.ValueArea>…</Combobox.ValueArea>
 *   <Combobox.Controls>
 *     <Combobox.Clear />
 *     <Combobox.Trigger>
 *       <Combobox.Icon />
 *     </Combobox.Trigger>
 *   </Combobox.Controls>
 * </Combobox.Input>
 * ```
 */
export const ComboboxControls = React.forwardRef(function ComboboxControls(
    props: ComboboxControlsProps,
    forwardRef: React.ForwardedRef<HTMLDivElement>,
) {
    const {render, className, ...otherComponentProps} = props;
    const comboboxInputState = useComboboxInputContextSelector((context) => context.comboboxInputState);

    const defaultProps: useRender.ElementProps<"div"> = {
        className: cx("flex items-center gap-2", addConsumerClasses(comboboxInputState, className)),
    };

    return useRender({
        defaultTagName: "div",
        render,
        ref: forwardRef,
        state: {...comboboxInputState},
        props: mergeProps<"div">(defaultProps, otherComponentProps),
    });
});
