import * as React from "react";

import {Combobox as BaseUICombobox} from "@base-ui/react/combobox";
import type {HTMLProps} from "@base-ui/react/utils/types";

import ChevronDown from "@bolteu/kalep-react-icons/dist/ChevronDown";

import {
    useComboboxContextSelector,
    useComboboxInputContextSelector,
} from "@/components/baseui-components/Combobox/context";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Combobox.Icon
 * Chevron/indicator rendered inside `Combobox.Trigger`.
 *
 * ```tsx
 * <Combobox.Trigger>
 *   <Combobox.Icon />
 * </Combobox.Trigger>
 * ```
 */
export const ComboboxIcon = React.forwardRef(function ComboboxIcon(
    props: BaseUICombobox.Icon.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    const size = useComboboxContextSelector((context) => context.customComboboxProps.size);
    const disabled = useComboboxInputContextSelector((context) => context.comboboxInputState?.disabled);
    const open = useComboboxInputContextSelector((context) => context.comboboxInputState?.open);

    const {className, render, ...rest} = props;

    const getComboboxIconClassNames = React.useCallback(
        (state: BaseUICombobox.Icon.State) =>
            cx(
                `transition-transform duration-100 ease-linear`,
                open && "rotate-180",
                disabled ? "text-tertiary" : "text-primary",
                addConsumerClasses(state, className),
            ),
        [className, disabled, open],
    );

    const renderDefault = React.useCallback(
        (iconProps: HTMLProps<HTMLDivElement>) => {
            return <ChevronDown {...iconProps} size={size === "sm" ? "md" : "lg"} aria-hidden="true" />;
        },
        [size],
    );

    return (
        <BaseUICombobox.Icon
            {...rest}
            ref={forwardedRef}
            className={getComboboxIconClassNames}
            render={render ?? renderDefault}
        />
    );
});
