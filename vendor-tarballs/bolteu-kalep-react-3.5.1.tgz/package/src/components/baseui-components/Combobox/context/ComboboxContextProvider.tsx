import * as React from "react";

import type {ComboboxSize} from "@/components/baseui-components/Combobox/combobox.types";

export interface ComboboxContextType {
    customComboboxProps: {
        size: ComboboxSize;
        multiline: boolean;
        multiple: boolean;
        placeholder?: string;
    };
    inputWrapperRef: React.MutableRefObject<HTMLDivElement | null>;
}

const ComboboxContext = React.createContext<ComboboxContextType | null>(null);

interface ComboboxContextProviderProps extends Omit<ComboboxContextType, "inputWrapperRef"> {
    children: React.ReactNode;
}

export function ComboboxContextProvider({children, customComboboxProps}: ComboboxContextProviderProps) {
    const inputWrapperRef = React.useRef<HTMLDivElement | null>(null);

    const contextValue: ComboboxContextType = React.useMemo(
        () => ({
            customComboboxProps,
            inputWrapperRef,
        }),
        [customComboboxProps],
    );

    return <ComboboxContext.Provider value={contextValue}>{children}</ComboboxContext.Provider>;
}

export function useComboboxContext() {
    const context = React.useContext(ComboboxContext);

    if (!context) {
        throw new Error("Combobox parts must be rendered within Combobox.Root");
    }

    return context;
}

type ComboboxContextReadonly = ComboboxContextType & {
    readonly customComboboxProps: Readonly<ComboboxContextType["customComboboxProps"]>;
    readonly inputWrapperRef: Readonly<ComboboxContextType["inputWrapperRef"]>;
};

export function useComboboxContextSelector<T>(selector: (context: ComboboxContextReadonly) => T): T {
    const context = useComboboxContext();

    return selector(context);
}
