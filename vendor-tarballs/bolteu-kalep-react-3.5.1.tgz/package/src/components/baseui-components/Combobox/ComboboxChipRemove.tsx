import * as React from "react";

import {Combobox as BaseUICombobox} from "@base-ui/react/combobox";
import type {HTMLProps} from "@base-ui/react/utils/types";

import Clear from "@bolteu/kalep-react-icons/dist/Clear";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Combobox.ChipRemove
 * Button rendered inside each chip to remove a selected option.
 *
 * ```tsx
 * <Combobox.Chip>
 *   {option.label}
 *   <Combobox.ChipRemove aria-label={`Remove ${option.label}`} />
 * </Combobox.Chip>
 * ```
 */
export const ComboboxChipRemove = React.forwardRef(function ComboboxChipRemove(
    props: BaseUICombobox.ChipRemove.Props,
    forwardedRef: React.ForwardedRef<HTMLButtonElement>,
) {
    const {className, render, ...rest} = props;

    const getComboboxChipRemoveClassNames = React.useCallback(
        (state: BaseUICombobox.ChipRemove.State) => {
            return cx(
                `
                  flex cursor-pointer items-center justify-center rounded-full border-0 bg-transparent p-0
                  text-secondary transition-colors duration-100 ease-linear
                  focus-visible:border-action-primary focus-visible:outline focus-visible:outline-2
                `,
                state.disabled
                    ? "cursor-not-allowed text-tertiary"
                    : `
                      text-secondary
                      hover:text-primary
                    `,
                addConsumerClasses(state, className),
            );
        },
        [className],
    );

    const renderDefault = React.useCallback((renderProps: HTMLProps<HTMLButtonElement>) => {
        const {className: clearClassName, ...restRenderProps} = renderProps;

        return (
            <button {...restRenderProps} className={cx("border-0 bg-transparent p-0")} type="button">
                <Clear className={clearClassName} aria-hidden="true" size="xs" />
            </button>
        );
    }, []);

    return (
        <BaseUICombobox.ChipRemove
            {...rest}
            ref={forwardedRef}
            className={getComboboxChipRemoveClassNames}
            render={render ?? renderDefault}
        />
    );
});
