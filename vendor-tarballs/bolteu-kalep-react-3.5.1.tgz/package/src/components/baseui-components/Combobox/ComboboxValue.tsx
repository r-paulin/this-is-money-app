import {Combobox as BaseUICombobox} from "@base-ui/react/combobox";

/**
 * Combobox.Value
 *
 * Renders the currently selected value (single or multiple) from combobox state.
 */
export const ComboboxValue = BaseUICombobox.Value;
