import * as React from "react";

import {render, screen} from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import {Combobox} from "@/components/baseui-components/Combobox";
import {Field} from "@/components/baseui-components/Field";

const options = [
    {label: "Placeholder option", value: null},
    {label: "Tallinn", value: "1"},
];

function renderComboboxRoot(
    rootProps?: Partial<React.ComponentProps<typeof Combobox.Root>>,
    inputProps?: Partial<React.ComponentProps<typeof Combobox.Input>>,
    controlProps?: Partial<React.ComponentProps<typeof Combobox.Control>>,
) {
    return render(
        <Field.Root name="test-combobox">
            <Field.Label>Label</Field.Label>
            <Combobox.Root items={options} {...rootProps}>
                <Combobox.Input {...(inputProps ?? {placeholder: "Pick city"})}>
                    <Combobox.ValueArea>
                        <Combobox.Control {...controlProps} />
                    </Combobox.ValueArea>
                </Combobox.Input>
                <Combobox.Portal>
                    <Combobox.Positioner>
                        <Combobox.Popup>
                            <Combobox.List>
                                {options.map((option) => (
                                    <Combobox.Item key={option.value ?? "none"} value={option} />
                                ))}
                            </Combobox.List>
                        </Combobox.Popup>
                    </Combobox.Positioner>
                </Combobox.Portal>
            </Combobox.Root>
            <Field.Error />
        </Field.Root>,
    );
}

function getComboboxWrapper(): HTMLElement {
    const control = screen.getByRole("combobox");
    const wrapper = control.closest<HTMLElement>('[role="presentation"]');

    if (!wrapper) {
        throw new Error("Combobox wrapper element not found");
    }

    return wrapper;
}

describe("ComboboxControl", () => {
    test("applies size specific classes", () => {
        renderComboboxRoot({size: "sm"});

        expect(getComboboxWrapper()).toHaveClass("min-h-9");
    });

    test("shows disabled styles when disabled", () => {
        renderComboboxRoot({disabled: true});

        expect(getComboboxWrapper()).toHaveClass("cursor-not-allowed");
    });

    test("shows error styles when field is invalid", () => {
        render(
            <Field.Root name="test-combobox" invalid>
                <Field.Label>Label</Field.Label>
                <Combobox.Root items={options}>
                    <Combobox.Input placeholder="Pick city">
                        <Combobox.ValueArea>
                            <Combobox.Control />
                        </Combobox.ValueArea>
                    </Combobox.Input>
                    <Combobox.Portal>
                        <Combobox.Positioner>
                            <Combobox.Popup>
                                <Combobox.List>
                                    {options.map((option) => (
                                        <Combobox.Item key={option.value ?? "none"} value={option} />
                                    ))}
                                </Combobox.List>
                            </Combobox.Popup>
                        </Combobox.Positioner>
                    </Combobox.Portal>
                </Combobox.Root>
                <Field.Error />
            </Field.Root>,
        );

        expect(getComboboxWrapper()).toHaveClass("border-danger-primary");
    });

    test("toggles open styles when clicking the control", async () => {
        renderComboboxRoot();

        const wrapper = getComboboxWrapper();
        const input = screen.getByRole("combobox");

        await userEvent.click(input);

        expect(wrapper).toHaveClass("border-action-primary");
    });

    test("uses placeholder provided to Combobox.Root when input has none", () => {
        const placeholder = "Pick a city";

        renderComboboxRoot({placeholder}, {});

        expect(screen.getByPlaceholderText(placeholder)).toBeInTheDocument();
    });

    test("allows Combobox.Input placeholder to override the root placeholder", () => {
        renderComboboxRoot(
            {placeholder: "Root placeholder"},
            {
                placeholder: "Input placeholder",
            },
        );

        expect(screen.getByPlaceholderText("Input placeholder")).toBeInTheDocument();
    });

    test("allows Combobox.Control placeholder to override the root placeholder", () => {
        renderComboboxRoot(
            {placeholder: "Root placeholder"},
            {},
            {
                placeholder: "Control placeholder",
            },
        );

        expect(screen.getByPlaceholderText("Control placeholder")).toBeInTheDocument();
    });
});
