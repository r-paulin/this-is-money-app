import * as React from "react";

import {Combobox as BaseUICombobox} from "@base-ui/react/combobox";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Combobox.Chips
 * Wraps `Combobox.Input` when `multiple` is enabled so selected values render as removable chips.
 *
 * ```tsx
 * <Combobox.Chips>
 *   <Combobox.Input placeholder="Select cities">
 *     <Combobox.ValueArea>
 *       <Combobox.Value>
 *         {(currentValue) => {
 *           const selected = Array.isArray(currentValue) ? currentValue : [];
 *           return (
 *             <>
 *               {selected.map((option) => (
 *                 <Combobox.Chip key={option.value}>
 *                   {option.label}
 *                   <Combobox.ChipRemove aria-label={`Remove ${option.label}`} />
 *                 </Combobox.Chip>
 *               ))}
 *               <Combobox.Control />
 *             </>
 *           );
 *         }}
 *       </Combobox.Value>
 *     </Combobox.ValueArea>
 *   </Combobox.Input>
 * </Combobox.Chips>
 * ```
 */
export const ComboboxChips = React.forwardRef(function ComboboxChips(
    props: BaseUICombobox.Chips.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, ...rest} = props;

    const getComboboxChipsClassNames = React.useCallback(
        (state: BaseUICombobox.Chips.State) => cx("w-full min-w-0", addConsumerClasses(state, className)),
        [className],
    );

    return <BaseUICombobox.Chips {...rest} ref={forwardedRef} className={getComboboxChipsClassNames} />;
});
