import * as React from "react";

import {Combobox as BaseUICombobox} from "@base-ui/react/combobox";

import Check from "@bolteu/kalep-react-icons/dist/Check";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Combobox.ItemIndicator
 * Selection icon displayed inside `Combobox.Item`.
 *
 * ```tsx
 * <Combobox.Item value={option}>
 *   {option.label}
 *   <Combobox.ItemIndicator />
 * </Combobox.Item>
 * ```
 */
export const ComboboxItemIndicator = React.forwardRef(function ComboboxItemIndicator(
    props: BaseUICombobox.ItemIndicator.Props,
    forwardedRef: React.ForwardedRef<HTMLSpanElement>,
) {
    const {className, render, ...rest} = props;

    const getComboboxItemIndicatorClassNames = React.useCallback(
        (state: BaseUICombobox.ItemIndicator.State) =>
            cx(
                "flex flex-none items-center justify-center text-action-secondary",
                addConsumerClasses(state, className),
            ),
        [className],
    );

    const renderDefault = React.useCallback((props: BaseUICombobox.ItemIndicator.Props) => {
        // ref is not forwarded to the Kalep icons
        const {ref: _ref, ...rest} = props;

        return <Check aria-hidden="true" size="md" {...rest} />;
    }, []);

    return (
        <BaseUICombobox.ItemIndicator
            {...rest}
            ref={forwardedRef}
            className={getComboboxItemIndicatorClassNames}
            render={render ?? renderDefault}
        />
    );
});
