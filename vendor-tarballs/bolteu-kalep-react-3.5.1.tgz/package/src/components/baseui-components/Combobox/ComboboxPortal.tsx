import {Combobox as BaseUICombobox} from "@base-ui/react/combobox";

/**
 * Combobox.Portal
 *
 * Renders combobox popup content in a portal outside the trigger's layout context.
 */
export const ComboboxPortal = BaseUICombobox.Portal;
