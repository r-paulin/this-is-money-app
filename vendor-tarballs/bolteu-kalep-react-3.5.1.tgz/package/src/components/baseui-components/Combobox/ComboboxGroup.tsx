import {Combobox as BaseUICombobox} from "@base-ui/react/combobox";

/**
 * Combobox.Group
 *
 * Groups related combobox options under a shared label.
 */
export const ComboboxGroup = BaseUICombobox.Group;
