import * as React from "react";

import type {Input} from "@base-ui/react";
import {mergeProps, useRender} from "@base-ui/react";

import {useInput} from "@/components/baseui-components/Input/context/useInput";
import type {Indexable} from "@/components/baseui-components/types/common-types";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {useId} from "@/helpers";
import {cx} from "@/helpers/utils/cx";

export interface InputSlotProps extends Omit<
    useRender.ComponentProps<"span", Indexable<Input.State>>,
    "className" | "children"
> {
    className?: string | ((state: Input.State) => string);
    children?: string;
}
type InputSlotState = Indexable<Input.State>;
export const InputSlot = React.forwardRef<HTMLSpanElement, InputSlotProps>(
    (props: InputSlotProps, forwardedRef: React.ForwardedRef<HTMLSpanElement>) => {
        const {render, className, ...otherComponentProps} = props;
        const {
            inputState,
            inputProps: {id: inputId},
        } = useInput();

        const generatedId = useId();
        const slotId = props.id ?? `${inputId}-slot-${generatedId}`;
        const inputSlotState: InputSlotState = {...inputState};

        const defaultProps: useRender.ElementProps<"span"> = {
            className: cx(
                "flex flex-shrink-0",
                inputSlotState.disabled && inputSlotState.valid !== false ? "text-tertiary" : "text-secondary",
                addConsumerClasses(inputSlotState, className),
            ),
            id: slotId,
            ...otherComponentProps,
        };
        return useRender({
            defaultTagName: "span",
            render,
            ref: forwardedRef,
            state: inputSlotState,
            props: mergeProps<"span">(defaultProps, otherComponentProps),
        });
    },
);

InputSlot.displayName = "Input.Slot";
