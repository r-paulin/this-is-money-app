import * as React from "react";

import {InputContext} from "@/components/baseui-components/Input/context/InputProvider";

export function useInput() {
    const context = React.useContext(InputContext);
    if (!context) {
        throw new Error("InputControl must be used within an Input component");
    }
    return context;
}
