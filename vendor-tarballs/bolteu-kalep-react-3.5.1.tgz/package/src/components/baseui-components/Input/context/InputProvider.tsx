import * as React from "react";

import type {Input} from "@base-ui/react";

import type {PropsWithFieldSize} from "@/components/baseui-components/types/common-types";

export type InputContextType = {
    inputProps: PropsWithFieldSize<Input.Props> & {ref?: React.Ref<HTMLInputElement> | undefined};
    inputState: Input.State;
};

export const InputContext = React.createContext<InputContextType | null>(null);

interface InputProviderProps extends InputContextType {
    children: React.ReactNode;
}
export function InputProvider({children, inputState, inputProps}: InputProviderProps) {
    const contextValue: InputContextType = React.useMemo(() => ({inputState, inputProps}), [inputState, inputProps]);
    return <InputContext.Provider value={contextValue}>{children}</InputContext.Provider>;
}
