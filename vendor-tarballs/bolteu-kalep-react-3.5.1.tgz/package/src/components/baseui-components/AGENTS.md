# AGENTS.md

This file defines how automated agents (LLMs, copilots, generators) should behave when working in this repository.

This is an **internal React component library** documented with **Storybook (webpack-5)** and used as a **design handoff
tool**. Components are built on top of **Base UI** headless primitives and follow Base UI composition patterns.

The repository is a monorepo consisting of many packages, but this document only applies to the
`packages/kalep-react` package and new, BaseUI based components are added to
`packages/kalep-react/src/components/baseui-components` folder.

Scope rule:

- Agents must only create/modify files under `packages/kalep-react/src/components/baseui-components/**` unless
  explicitly instructed otherwise.
- When reusing components, prefer those under `baseui-components` folder.

> ⚠️ For now, agents are expected to **generate code only**.
> Do not create pull requests, commit messages, changelogs, or release notes unless explicitly instructed.
---

## Supported React Versions

This library must remain compatible with **both React 17 and React 18**.

Implications:

- Do not rely on React 18–only APIs (e.g. useId without a fallback).
- Avoid assumptions about concurrent rendering.
- Effects and refs must behave correctly in both versions.

## Goals

Agents may:

- Generate new components
- Generate Storybook stories
- Generate tests (Vitest + Playwright via Storybook)
- Extend existing components when explicitly instructed

## Non-goals & Hard Restrictions

Agents must NOT:

- Open or describe pull requests
- Generate commit messages or changelog entries
- Add or modify build tooling or configuration
- Introduce new runtime dependencies
- Change existing public APIs unless explicitly instructed (except when refactoring to align with Base UI APIs)
- Replace or bypass Base UI patterns
- Weaken or remove accessibility behavior
- Introduce wrapper components that only exist to preserve legacy APIs

## Tech Stack & Constraints

- React: 17 and 18
- TypeScript: tsconfig.json
- Styling: TailwindCSS
- Storybook: webpack-5
- Headless foundation: Base UI
- Tests:
    - Unit/logic: Vitest
    - Interaction/e2e: Playwright via Storybook

## Base UI Usage (Critical)

Base UI is the headless UI foundation for this component library.

All components must follow Base UI composition patterns.

Base UI documentation can be found here: https://base-ui.com/llms.txt

Rules:

- Prefer Base UI primitives over custom behavior
- Use Base UI utilities/hooks where applicable
- Use `useRender` for DOM output
- Follow Base UI slot/prop patterns instead of ad-hoc abstractions
- When a Base UI primitive covers most of the behavior, wrap/extend it instead of reimplementing the logic.

Do NOT:

- Reimplement behavior already provided by Base UI
- Bypass Base UI’s accessibility or state logic
- Introduce incompatible composition patterns

### Wrapping Base UI parts

- Preserve consumer props and handlers when adding internal behavior; always call consumer callbacks if you add your
  own.
- Use `render` props to compose Base UI parts with custom components; do not hard-swap the underlying element without
  need.
- Keep public props minimal; prefer composition with subcomponents for each rendered element.

## Canonical Component References

Use these components as authoritative references for patterns, structure, and quality:

- [Alert](./Alert) — Reference for:
    - controlled/uncontrolled patterns
    - Component composition patterns
    - usage of `useRender` hook since BaseUI did not provide needed primitives
- [Dialog](./Dialog) — Reference for:
    - A more complex component composition pattern
    - usage of `useRender` hook for custom components - `Dialog.Header` and `Dialog.Footer`

Agents should mirror patterns from these components whenever possible.

## Component Design Principles

### Composition first

- Favor composition over configuration.
- Avoid large numbers of boolean props.
- Prefer explicit slots/children patterns already used in this repo or Base UI.
- Prefer `baseui-components/TypographyStack` for Base UI examples and compound content blocks; avoid overriding its
  defaults unless parity requires it.
- When refactoring legacy components built with prop configuration, translate them into Base UI composition patterns.
  Prefer Base UI’s public API and prioritize visual parity over legacy prop compatibility unless explicitly requested.
  Do not mirror or preserve legacy prop names unless explicitly requested.
  Styling-only/visual props (padding, spacing, colors, etc.) should be removed in favor of `className`.
  Document any intentional legacy API removals or behavior changes in the refactor plan and stories/tests.
  Example:
    - Before: `backgroundColor="bg-neutral-secondary" color="text-primary"`
    - After: `className="bg-neutral-secondary text-primary"` on the root and rely on composition for content.

### Base UI API alignment

- Prefer Base UI prop names directly (e.g. use `multiple` rather than `exclusive`).
- Do not introduce custom props that only mirror Base UI behavior.
- If Base UI provides a feature, wire to it instead of reimplementing or renaming it.
- Base UI props are the canonical public API for refactors unless explicitly instructed otherwise.
- Wrapper components may add default styles for parity but must not rename or alias Base UI props.

### Controlled vs Uncontrolled

- Support both controlled and uncontrolled usage.
- Follow BaseUI conventions exactly for controlled/uncontrolled patterns.

### Rendering

- Use `useRender` for custom DOM output.
- Avoid direct JSX in component implementations outside of the render mechanism provided by Base UI (`useRender`) unless re-exporting Base UI parts directly.
- Each component/subcomponent must render a single element (no fragments, no multi-root).
- Non-render logic (state/hooks/derived values) may be implemented normally in TypeScript.
- Do not introduce ad-hoc rendering abstractions; follow Base UI rendering patterns strictly.
- Default visual parity (spacing/typography) should live in component part defaults when wrappers are used; otherwise keep it in stories.
- Wrapper components are allowed for styling and visual parity when they preserve Base UI props and behavior.
- Do not introduce wrapper components that only map or translate legacy props; use Base UI props directly.
- Inner wrappers are allowed when needed for animation parity (e.g., animated padding/opacity), and must be documented with a short code comment.

### File structure

- Keep component files flat within their folder; use a `context/` subfolder only when shared context is required.
- Each subcomponent must live in its own file; avoid multiple component definitions in the same file.

### Refs

- Properly forward refs using `React.forwardRef`.
- Ensure refs point to the correct DOM elements as per BaseUI patterns.
- Ensure ref types are accurate in TypeScript.

## Accessibility (Audited - Non-negotiable)

Accessibility is a top priority. All components must be fully accessible. Accessibility must not regress.

Requirements:

- Prefer native semantic elements.
- Full keyboard support for all interactive components.
- Correct labeling and relationships.
- ARIA only when native semantics are insufficient.
- Follow Base UI’s accessibility patterns strictly.

If behavior changes:

- Update or add tests to cover keyboard and focus behavior.

## Styling with Tailwind

- Use Tailwind utility classes.
- Prefer existing tokens and theme values.
- Group utility classes logically (layout → spacing → typography → color → state).
- Include hover, focus-visible, active, and disabled states where relevant.
- Follow existing focus-ring conventions in this repo.
- When using function-based `className`, define the function with `React.useCallback`.
- Store Tailwind class strings in `const` values prefixed with `CLASSNAME_TW_` when it improves clarity or reuse (e.g., complex/long class sets like in `SnackbarRoot.tsx`). This includes string constants and mapping objects/arrays that hold class strings (e.g., variants, sizes).

## Storybook Requirements (Design Handoff)

Storybook is used for **design review and handoff**. Stories must be clear, stable, and comprehensive without creating
excessive noise.

Every new component must include at least:

1. **Default** usage
2. **Variants** (the most important visual/behavioral variants only)
3. **States** (disabled, loading, error, empty, etc. — only those that apply)
4. **Accessibility** (keyboard navigation, focus states, labeling)

Guidelines:

- Use Storybook Controls for public props.
- Follow existing story patterns in this repo.
- Use `args` and `argTypes` for prop documentation.
- Stories must be deterministic and not rely on external data.
- Use `play` functions for interaction testing where applicable.
- Avoid generating a combinatorial “matrix” of every prop combination unless explicitly requested.

## Testing

### Unit & Logic (Vitest)

- Use Vitest for unit tests.
- Test behavior, not implementation details.
- Prefer role/name/label-based queries.
- Cover public API behavior and important edge cases.
- Mock external dependencies when needed.

Good candidates for Vitest:

- rendering semantics (role/element type)
- prop-driven behavior
- event callbacks
- simple state transitions
- async UI state driven by external resources (e.g., image loading) should mock the resource and use `waitFor`

### Interaction & E2E (Playwright via Storybook)

- Use Playwright via Storybook for interaction tests.
- Cover keyboard navigation, focus management, and critical interaction flows.

Good candidates for Playwright:

- focus trapping / focus return
- keyboard navigation patterns
- layered UI (portals, dialogs, tooltips) and interaction timing
- cross-browser interaction behavior

Avoid:

- snapshot-only tests unless explicitly requested
- testing internal implementation details

## File and Export Conventions

Follow existing repo structure. Typical pattern:

```
components/
    baseui-components/
        ComponentName/
            ComponentName.tsx
            ComponentName.stories.tsx
            ComponentName.test.tsx
            SubComponent1.tsx
            SubComponent2.tsx
            index.ts
```

Rules:

- PascalCase for components and folders.
- Export via established barrel files
- Public APIs must be intentional and minimal
- When `index.ts`/`index.tsx` exposes a component as a compound object (for example `export const Dialog = { ... }`),
  do not assign Base UI primitives directly in that object (Storybook docs cannot reliably parse these symbols).
  This rule applies only to object-based compound exports.
  - Bad:
    ```ts
    export const Dialog = {
      Root: BaseUIDialog.Root,
      Header: DialogHeader,
    };
    ```
  - Good:
    ```ts
    // DialogRoot.tsx
    export const DialogRoot = BaseUIDialog.Root;

    // index.ts
    import { DialogRoot } from './DialogRoot';

    export const Dialog = {
      Root: DialogRoot,
      Header: DialogHeader,
    };

    Object.assign(Dialog.Root, {displayName: "Dialog.Root"});
    Dialog.Header.displayName = "Dialog.Header";
    ```

## Dependency Rules

Agents may NOT:

- Add runtime dependencies
- Add build or tooling dependencies

Agents may only use:

- Existing dependencies in this repository

## Agent Output Rules

For now:

- **Agents must output code only** (new files and/or diffs).
- Do NOT generate PRs, commit messages, changelogs, release notes, or review commentary unless explicitly instructed.
- Skill-mandated refactor notes are still required artifacts even when code-only output is expected.

Output format:

- Prefer unified diffs for edits.
- For new files, output full file contents and include the intended file path.
- Do not include explanatory prose outside code/diff blocks unless asked.

If something is ambiguous:

- Ask for clarification before proceeding.

## When to stop and ask

Agents should pause and ask if:

- API design decisions are unclear
- Accessibility behavior is ambiguous
- A change might affect existing consumers
- A required BaseUI pattern is unclear

## BaseUI refactor guidance

When refactoring existing components to Base UI composition patterns:

- **Composition only:** expose subcomponents for each rendered element; avoid configuration helpers or render-function
  children for slots.
- **Event handling:** do not override consumer event props. Let them flow from `useRender.ComponentProps` and forward
  the original event. For keyboard activation, call `event.currentTarget.click()` to reuse the provided handler.
- **Spacing:** avoid bespoke spacing props unless already part of the API; demonstrate spacing variations with Tailwind
  classes in stories.
- **Class merging:** always use `addConsumerClasses` when supporting function className props to align with Base UI
  state.
- **Typography:** prefer `TypographyStack` for composed title/subtitle blocks and avoid overriding defaults unless
  parity requires it.
- **Selection primitives:** use the Base UI composition pattern for control state (e.g. `RadioGroup` for radio state)
  instead of passing unsupported props directly.
- **API alignment:** prefer Base UI props and names. Do not keep legacy visual props (e.g. padding) or rename Base UI
  props into custom aliases (e.g. `exclusive` vs `multiple`) unless explicitly instructed. Base UI props are canonical.
- **Subcomponents:** use real Base UI parts (`Root`, `Item`, `Header`, `Trigger`, `Panel`, etc.) as separate files and
  export them via `Component.*`.
- **Primitive export rule:** when a compound API is assembled as an object in `index.ts`/`index.tsx` and exposes a
  Base UI primitive part (e.g. `Component.Root`), export that part from its own file first, then compose in `index.ts`;
  do not reference `BaseUI*.Root` directly in the compound object.
- **Display names in index:** set `displayName` on compound API members in `index.ts`/`index.tsx` (e.g.
  `Object.assign(Component.Root, {displayName: "Component.Root"})`), not in primitive proxy files.
- **Stories:** build examples only from the compound components (no extra helper wrappers). If slot content needs
  state (size/disabled), read it from context via a dedicated hook.
- **Disabled styling:** avoid hover/focus/active styles on disabled interactive elements to prevent misleading
  affordances.
- For legacy refactors, you MUST follow .codex/skills/00-refactor-router.md and include the final Refactor Skill Report
  in the PR description.

## Event propagation in nested interactive elements

When a compound component nests interactive elements (buttons, links) inside a wrapper that has its own
event handlers (e.g. the Input wrapper's `onClick` that focuses the input), the inner element's custom
handlers **must** call `event.stopPropagation()` to prevent the wrapper's handler from firing
unintentionally.

- Always `stopPropagation()` on `onClick` and `onMouseDown` for nested interactive elements that have
  their own distinct behavior.
- Always forward to the original Base UI handler after stopping propagation
  (e.g. `onMouseDown?.(event)` after `event.stopPropagation()`).
- Do **not** `stopPropagation()` if the nested element's action intentionally relies on the parent
  handler also firing.
