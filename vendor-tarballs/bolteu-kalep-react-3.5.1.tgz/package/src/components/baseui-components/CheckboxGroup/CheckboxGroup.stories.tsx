import * as React from "react";

import type {Meta, StoryObj} from "@storybook/react-webpack5";

import {Checkbox} from "@/components/baseui-components/CheckBox";

import DocumentationTemplate from "../docs/DocumentationTemplate.mdx";
import {CheckboxGroup} from "./CheckboxGroup";

const meta = {
    component: CheckboxGroup,
    title: "BaseUI Playground/CheckboxGroup",
    tags: ["experimental", "BaseUI", "autodocs"],
    parameters: {
        docs: {
            subtitle: "Provides shared state to a series of checkboxes.",
            page: DocumentationTemplate,
        },
    },
} satisfies Meta<typeof CheckboxGroup>;

export default meta;

type Story = StoryObj<typeof meta>;

export const Default: Story = {
    args: {
        defaultValue: ["option-2"],
        children: [
            <Checkbox name="field-name" value="option-1" />,
            <Checkbox name="field-name" value="option-2" />,
            <Checkbox name="field-name" value="option-3" />,
        ],
    },
};
