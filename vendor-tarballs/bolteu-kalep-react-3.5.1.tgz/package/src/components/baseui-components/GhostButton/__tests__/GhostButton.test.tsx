import * as React from "react";

import {vi} from "vitest";
import {render, screen} from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import {GhostButton} from "../GhostButton";

describe("GhostButton", () => {
    test("has role='button'", () => {
        const handler = vi.fn();
        render(<GhostButton onClick={handler}>lolo</GhostButton>);
        expect(screen.getByRole("button", {name: "lolo"})).toBeInTheDocument();
    });

    test("'id' attribute is properly reflected", () => {
        const handler = vi.fn();
        const {rerender} = render(<GhostButton onClick={handler}>lolo</GhostButton>);

        expect(screen.getByRole("button", {name: "lolo"})).not.toHaveAttribute("id");

        const testId = "button-test-id";
        rerender(
            <GhostButton onClick={handler} id={testId}>
                lolo
            </GhostButton>,
        );
        expect(screen.getByRole("button", {name: "lolo"})).toHaveAttribute("id", testId);
    });

    test("click event triggers onClick handler", async () => {
        const user = userEvent.setup();
        const handler = vi.fn();
        render(<GhostButton onClick={handler}>lolo</GhostButton>);
        await user.click(screen.getByRole("button", {name: "lolo"}));
        expect(handler).toHaveBeenCalledTimes(1);
    });

    test("disabled prop blocks onClick handler", async () => {
        const user = userEvent.setup();
        const handler = vi.fn();
        const {rerender} = render(<GhostButton onClick={handler}>lolo</GhostButton>);
        await user.click(screen.getByRole("button", {name: "lolo"}));
        expect(handler).toHaveBeenCalledTimes(1);
        rerender(
            <GhostButton onClick={handler} disabled>
                lolo
            </GhostButton>,
        );
        await user.click(screen.getByRole("button", {name: "lolo"}));
        expect(handler).toHaveBeenCalledTimes(1);
        expect(screen.getByRole("button", {name: "lolo"})).toHaveAttribute("aria-disabled", "true");
    });

    test("tab onto button and trigger onClick handler with Space", async () => {
        const user = userEvent.setup();
        const handler = vi.fn();
        render(<GhostButton onClick={handler}>lolo</GhostButton>);

        await user.tab();
        expect(screen.getByRole("button", {name: "lolo"})).toHaveFocus();

        await user.keyboard("[Space]");

        expect(handler).toHaveBeenCalledTimes(1);
    });

    test("tab onto button and trigger onClick handler with Enter", async () => {
        const user = userEvent.setup();
        const handler = vi.fn();
        render(<GhostButton onClick={handler}>lolo</GhostButton>);

        await user.tab();
        expect(screen.getByRole("button", {name: "lolo"})).toHaveFocus();

        await user.keyboard("[Enter]");

        expect(handler).toHaveBeenCalledTimes(1);
    });
});
