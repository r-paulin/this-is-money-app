import * as React from "react";

import {expect, fn, userEvent, within} from "storybook/test";
import type {Meta, StoryObj} from "@storybook/react-webpack5";

import {Show} from "@bolteu/kalep-react-icons";

import DocumentationTemplate from "../docs/DocumentationTemplate.mdx";
import {GhostButton} from "./index";

const meta = {
    component: GhostButton,
    title: "BaseUI Playground/GhostButton",
    tags: ["experimental", "BaseUI", "autodocs"],
    parameters: {
        docs: {
            subtitle: "A primitive GhostButton component",
            page: DocumentationTemplate,
        },
    },
} satisfies Meta<typeof GhostButton>;

export default meta;

type Story = StoryObj<typeof meta>;

export const Default: Story = {
    args: {
        children: "Ghost Button",
        onClick: () => alert("clicked"),
    },
};

export const InTextField: Story = {
    render: (_args) => {
        const [inputType, setInputType] = React.useState<"password" | "text">("password");
        const toggleInputType = React.useCallback(() => {
            setInputType((prevType) => (prevType === "password" ? "text" : "password"));
        }, []);
        return (
            <div className="flex flex-col gap-6 font-sans">
                <div className={`
                  flex h-11 w-64 items-center gap-2 rounded-lg border border-solid border-neutral-secondary px-4
                `}>
                    <input
                        type={inputType}
                        placeholder="Password"
                        className="h-8 flex-grow border-0 font-sans text-size-inherit"
                    />
                    <GhostButton className="-mr-3 p-2" onClick={toggleInputType} aria-label="Toggle show password">
                        <Show />
                    </GhostButton>
                </div>
                <div className={`
                  flex h-11 w-96 items-center justify-between gap-2 rounded-lg border border-solid
                  border-neutral-secondary px-4
                `}>
                    <input
                        type={inputType}
                        placeholder="Password"
                        className="h-8 border-0 font-sans text-size-inherit"
                    />
                    <GhostButton className="text-sm font-semibold uppercase" onClick={toggleInputType}>
                        Reveal
                    </GhostButton>
                </div>
            </div>
        );
    },
};

export const Accessibility: Story = {
    args: {
        onClick: fn(),
        "aria-label": "Show password",
        children: <Show />,
    },
    play: async ({canvasElement, step, args}) => {
        const canvas = within(canvasElement);
        const button = await canvas.findByRole("button", {name: "Show password"});

        await step("Button is focusable", async () => {
            await userEvent.tab();
            await expect(button).toHaveFocus();
        });

        await step("Space triggers onClick", async () => {
            await userEvent.keyboard("[Space]");
            await expect(args.onClick).toHaveBeenCalledTimes(1);
        });

        await step("Enter triggers onClick", async () => {
            await userEvent.keyboard("[Enter]");
            await expect(args.onClick).toHaveBeenCalledTimes(2);
        });
    },
};
