import * as React from "react";

import {expect, fn, userEvent, within} from "storybook/test";
import type {Meta, StoryObj} from "@storybook/react-webpack5";

import DocumentationTemplate from "../docs/DocumentationTemplate.mdx";
import {PasswordInput} from "./index";

const meta = {
    component: PasswordInput,
    title: "BaseUI Playground/PasswordInput",
    tags: ["experimental", "BaseUI", "autodocs"],
    parameters: {
        docs: {
            subtitle: "A composed password field built on top of Input.",
            page: DocumentationTemplate,
        },
    },
} satisfies Meta<typeof PasswordInput>;

export default meta;

type Story = StoryObj<typeof meta>;

export const Default: Story = {
    args: {
        defaultValue: "myLongpassword8",
        placeholder: "Create a password",
        "aria-label": "Password",
        onValueChange: fn(),
    },
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement);
        const input = await canvas.findByLabelText("Password");
        const toggle = await canvas.findByRole("button", {name: "Show password"});

        await step("Input and toggle are rendered", async () => {
            await expect(input).toBeInTheDocument();
            await expect(toggle).toBeInTheDocument();
        });

        await step("Clear button appears on focus when value is filled", async () => {
            await userEvent.click(input);
            await expect(await canvas.findByRole("button", {name: "Clear password"})).toBeInTheDocument();
        });
    },
};

export const Sizes: Story = {
    render: (_args) => (
        <div className="flex max-w-[420px] flex-col gap-4">
            <PasswordInput fieldSize="lg" defaultValue="myLongpassword8" />
            <PasswordInput fieldSize="md" defaultValue="myLongpassword8" />
            <PasswordInput fieldSize="sm" defaultValue="myLongpassword8" />
        </div>
    ),
};

export const States: Story = {
    render: (_args) => (
        <div className="flex max-w-[420px] flex-col gap-4">
            <PasswordInput defaultValue="myLongpassword8" />
            <PasswordInput disabled defaultValue="myLongpassword8" />
            <PasswordInput readOnly defaultValue="myLongpassword8" />
        </div>
    ),
};

export const Accessibility: Story = {
    render: (_args) => <PasswordInput aria-label="Accessibility password" defaultValue="myLongpassword8" />,
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement);
        const input = await canvas.findByLabelText("Accessibility password");
        const toggle = await canvas.findByRole("button", {name: "Show password"});

        await step("Clear action is hidden while the input is not focused", async () => {
            await expect(canvas.queryByRole("button", {name: "Clear password"})).not.toBeInTheDocument();
        });

        await step("Focused and filled input shows clear action", async () => {
            await userEvent.click(input);
            await expect(await canvas.findByRole("button", {name: "Clear password"})).toBeInTheDocument();
        });

        await step("Toggle action updates password visibility", async () => {
            await expect(input).toHaveAttribute("type", "password");
            await userEvent.click(toggle);
            await expect(input).toHaveAttribute("type", "text");
            await expect(toggle).toHaveAccessibleName("Hide password");
            await userEvent.click(toggle);
            await expect(input).toHaveAttribute("type", "password");
            await expect(toggle).toHaveAccessibleName("Show password");
        });

        await step("Clear action clears value and keeps focus on input", async () => {
            await userEvent.click(input);
            const clear = await canvas.findByRole("button", {name: "Clear password"});
            await userEvent.click(clear);
            await expect(input).toHaveValue("");
            await expect(input).toHaveFocus();
            await expect(canvas.queryByRole("button", {name: "Clear password"})).not.toBeInTheDocument();
        });

        await step("Keyboard activation toggles visibility", async () => {
            await userEvent.type(input, "new-password");
            await expect(await canvas.findByRole("button", {name: "Clear password"})).toBeInTheDocument();
            toggle.focus();
            await expect(toggle).toHaveFocus();
            await userEvent.keyboard("[Enter]");
            await expect(input).toHaveAttribute("type", "text");
        });
    },
};
