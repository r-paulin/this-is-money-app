import * as React from "react";

import type {Meta, StoryObj} from "@storybook/react-webpack5";

import {Switch} from "@/components/baseui-components/Switch";

import DocumentationTemplate from "../docs/DocumentationTemplate.mdx";

const meta = {
    component: Switch,
    title: "BaseUI Playground/Switch",
    tags: ["experimental", "BaseUI", "autodocs"],
    subcomponents: {"Switch.Thumb": Switch.Thumb},
    parameters: {
        docs: {
            subtitle: "A primitive Switch component",
            page: DocumentationTemplate,
        },
    },
} satisfies Meta<typeof Switch>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
    args: {},
};
export const Disabled: Story = {
    args: {
        disabled: true,
    },
};
export const Checked: Story = {
    args: {
        checked: true,
    },
};

export const CheckedDisabled: Story = {
    args: {
        checked: true,
        disabled: true,
    },
};

export const Composed: Story = {
    args: {
        children: <Switch.Thumb />,
    },
};
