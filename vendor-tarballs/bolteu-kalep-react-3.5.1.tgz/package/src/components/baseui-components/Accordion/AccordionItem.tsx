import * as React from "react";

import {Accordion as BaseUIAccordion} from "@base-ui/react/accordion";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

export const AccordionItem = React.forwardRef(function AccordionItem(
    props: BaseUIAccordion.Item.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, ...rest} = props;

    const getItemClassNames = React.useCallback(
        (state: BaseUIAccordion.Item.State) => {
            return cx("border-0 border-b border-separator", addConsumerClasses(state, className));
        },
        [className],
    );

    return <BaseUIAccordion.Item {...rest} ref={forwardedRef} className={getItemClassNames} />;
});
