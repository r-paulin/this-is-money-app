import {AccordionHeader} from "./AccordionHeader";
import {AccordionItem} from "./AccordionItem";
import {AccordionPanel} from "./AccordionPanel";
import {AccordionRoot} from "./AccordionRoot";
import {AccordionTrigger} from "./AccordionTrigger";

/**
 * Accordion compound component built on Base UI primitives.
 *
 * Provides the Accordion subparts:
 * - `Accordion.Root`: groups items and manages open state
 * - `Accordion.Item`: wraps a single header + panel pair
 * - `Accordion.Header`: heading wrapper for the trigger
 * - `Accordion.Trigger`: interactive element that toggles the panel
 * - `Accordion.Panel`: collapsible region for the item content
 *
 * ### Composition guide
 * ```tsx
 * <Accordion.Root>
 *   <Accordion.Item>
 *     <Accordion.Header>
 *       <Accordion.Trigger>Section title</Accordion.Trigger>
 *     </Accordion.Header>
 *     <Accordion.Panel>Panel content</Accordion.Panel>
 *   </Accordion.Item>
 * </Accordion.Root>
 * ```
 */
export const Accordion = {
    Root: AccordionRoot,
    Item: AccordionItem,
    Header: AccordionHeader,
    Trigger: AccordionTrigger,
    Panel: AccordionPanel,
};

AccordionRoot.displayName = "Accordion.Root";
AccordionItem.displayName = "Accordion.Item";
AccordionHeader.displayName = "Accordion.Header";
AccordionTrigger.displayName = "Accordion.Trigger";
AccordionPanel.displayName = "Accordion.Panel";
