import * as React from "react";

import {vi} from "vitest";
import {render, screen} from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import {Accordion} from "../index";

function renderSimpleAccordion(props: React.ComponentProps<typeof Accordion.Root> = {}) {
    return render(
        <Accordion.Root {...props}>
            <Accordion.Item value="item-1">
                <Accordion.Header>
                    <Accordion.Trigger>Accordion 1</Accordion.Trigger>
                </Accordion.Header>
                <Accordion.Panel>Accordion 1 content</Accordion.Panel>
            </Accordion.Item>
            <Accordion.Item value="item-2">
                <Accordion.Header>
                    <Accordion.Trigger>Accordion 2</Accordion.Trigger>
                </Accordion.Header>
                <Accordion.Panel>Accordion 2 content</Accordion.Panel>
            </Accordion.Item>
        </Accordion.Root>,
    );
}

test("renders a collapsed accordion by default", async () => {
    renderSimpleAccordion();

    expect(await screen.findByRole("button", {name: "Accordion 1"})).toHaveAttribute("aria-expanded", "false");
});

test("toggles an accordion item on click", async () => {
    const user = userEvent.setup();
    renderSimpleAccordion();

    const button = await screen.findByRole("button", {name: /Accordion 1/i});
    await user.click(button);

    expect(button).toHaveAttribute("aria-expanded", "true");
    expect(await screen.findByText("Accordion 1 content")).toBeVisible();
});

test("honors controlled value", async () => {
    renderSimpleAccordion({value: ["item-2"]});

    expect(await screen.findByRole("button", {name: "Accordion 1"})).toHaveAttribute("aria-expanded", "false");
    expect(await screen.findByRole("button", {name: "Accordion 2"})).toHaveAttribute("aria-expanded", "true");
});

test("disabled items are not interactive", async () => {
    render(
        <Accordion.Root>
            <Accordion.Item value="item-1">
                <Accordion.Header>
                    <Accordion.Trigger>Accordion 1</Accordion.Trigger>
                </Accordion.Header>
                <Accordion.Panel>Accordion 1 content</Accordion.Panel>
            </Accordion.Item>
            <Accordion.Item value="item-2" disabled>
                <Accordion.Header>
                    <Accordion.Trigger>Accordion 2</Accordion.Trigger>
                </Accordion.Header>
                <Accordion.Panel>Accordion 2 content</Accordion.Panel>
            </Accordion.Item>
        </Accordion.Root>,
    );

    expect(await screen.findByRole("button", {name: "Accordion 1"})).toBeEnabled();
    expect(await screen.findByRole("button", {name: "Accordion 2"})).toHaveAttribute("aria-disabled", "true");
});

test("calls onValueChange with the next open items", async () => {
    const user = userEvent.setup();
    const listener = vi.fn();

    renderSimpleAccordion({onValueChange: listener});

    const button = await screen.findByRole("button", {name: "Accordion 2"});
    await user.click(button);

    expect(listener).toHaveBeenCalledWith(["item-2"], expect.any(Object));
});
