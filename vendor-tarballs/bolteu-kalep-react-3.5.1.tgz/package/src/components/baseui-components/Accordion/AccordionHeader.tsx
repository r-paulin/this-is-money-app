import * as React from "react";

import {Accordion as BaseUIAccordion} from "@base-ui/react/accordion";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

export const AccordionHeader = React.forwardRef(function AccordionHeader(
    props: BaseUIAccordion.Header.Props,
    forwardedRef: React.ForwardedRef<HTMLHeadingElement>,
) {
    const {className, ...rest} = props;

    const getHeaderClassNames = React.useCallback(
        (state: BaseUIAccordion.Item.State) => {
            return cx("m-0", addConsumerClasses(state, className));
        },
        [className],
    );

    return <BaseUIAccordion.Header {...rest} ref={forwardedRef} className={getHeaderClassNames} />;
});
