import * as React from "react";

import {expect, fn, userEvent, within} from "storybook/test";
import type {Meta, StoryObj} from "@storybook/react-webpack5";

import Lights from "@bolteu/kalep-react-icons/dist/Lights";
import LightsOutlined from "@bolteu/kalep-react-icons/dist/LightsOutlined";

import {Field} from "@/components/baseui-components/Field";
import {Tooltip} from "@/components/Tooltip";

import DocumentationTemplate from "../docs/DocumentationTemplate.mdx";
import {Slider} from "./index";

const meta = {
    component: Slider as unknown as React.ComponentType<any>,
    title: "BaseUI Playground/Slider",
    tags: ["experimental", "BaseUI", "autodocs"],
    subcomponents: {
        "Slider.Root": Slider.Root,
        "Slider.Control": Slider.Control,
        "Slider.Track": Slider.Track,
        "Slider.Indicator": Slider.Indicator,
        "Slider.Thumb": Slider.Thumb,
        "Slider.Value": Slider.Value,
    },
    parameters: {
        docs: {
            toc: true,
            subtitle: "Composition patterns and API for the Base UI Slider",
            page: DocumentationTemplate,
        },
    },
} satisfies Meta<typeof Slider.Root>;

export default meta;

type Story = StoryObj<typeof meta>;

const withSource = (code: string) => ({
    parameters: {
        docs: {
            source: {
                code,
            },
        },
    },
});

type SliderStoryOptions = {
    label?: string;
    helperText?: React.ReactNode;
    startLabel?: React.ReactNode;
    endLabel?: React.ReactNode;
    hideValue?: boolean;
    valueChildren?: React.ComponentProps<typeof Slider.Value>["children"];
    thumbCount?: number;
    controlWrapper?: (thumbs: React.ReactNode) => React.ReactNode;
};

const BASE_SECTION_TEST_ID = "baseui-slider-section";

function getSliderInput(canvasElement: HTMLElement, label: string) {
    const baseSection = within(canvasElement).getByTestId(BASE_SECTION_TEST_ID);
    return within(baseSection).getByLabelText(label, {selector: 'input[type="range"]'});
}

function renderSlider(args: React.ComponentProps<typeof Slider.Root>, options: SliderStoryOptions = {}) {
    const {
        label = "Adjust lights",
        helperText = "Use arrow keys or drag the handle to adjust the value.",
        startLabel,
        endLabel,
        thumbCount,
        controlWrapper,
        valueChildren,
    } = options;

    const fieldName = `slider-${label}`.toLowerCase().replace(/[^a-z0-9-]+/g, "-") || "slider-example";

    const sliderValue = (args.value ?? args.defaultValue) as number | readonly number[] | undefined;
    const derivedThumbCount = Array.isArray(sliderValue) ? sliderValue.length : 1;
    const resolvedThumbCount = thumbCount ?? derivedThumbCount;

    const thumbs = Array.from({length: resolvedThumbCount}).map((_, index) => <Slider.Thumb key={index} />);
    const renderedThumbs = controlWrapper ? controlWrapper(thumbs) : thumbs;
    const renderedControl = (
        <Slider.Control>
            <Slider.Track>
                <Slider.Indicator />
                {renderedThumbs}
            </Slider.Track>
        </Slider.Control>
    );

    return (
        <div className="space-y-8">
            <div className="w-96 space-y-2" data-testid={BASE_SECTION_TEST_ID}>
                <p className="bolt-font-body-xs-accent uppercase text-secondary">BaseUI Slider</p>
                <Field.Root name={fieldName}>
                    <Field.Label>{label}</Field.Label>
                    <div className="flex w-full items-center gap-4 py-2">
                        {startLabel ? (
                            <div className="bolt-font-body-m-regular shrink-0 text-secondary">{startLabel}</div>
                        ) : null}
                        <div className="w-full">
                            <Slider.Root {...args}>
                                {renderedControl}
                                <Slider.Value>{valueChildren}</Slider.Value>
                            </Slider.Root>
                        </div>
                        {endLabel ? (
                            <div className="bolt-font-body-m-regular shrink-0 text-secondary">{endLabel}</div>
                        ) : null}
                    </div>
                    {helperText ? <Field.Description>{helperText}</Field.Description> : null}
                </Field.Root>
            </div>
        </div>
    );
}

const defaultStorySource = `
<Field.Root name="lights">
  <Field.Label>Adjust lights</Field.Label>
  <div className="flex w-full items-center gap-4 py-2">
    <span className="bolt-font-body-m-regular text-secondary">0</span>
    <div className="w-full">
      <Slider.Root defaultValue={35}>
        <Slider.Control>
          <Slider.Track>
            <Slider.Indicator />
            <Slider.Thumb />
          </Slider.Track>
        </Slider.Control>
        <Slider.Value />
      </Slider.Root>
    </div>
    <span className="bolt-font-body-m-regular text-secondary">100</span>
  </div>
  <Field.Description>Use arrow keys or drag the handle to adjust the value.</Field.Description>
</Field.Root>
`.trim();

export const Default: Story = {
    args: {
        defaultValue: 35,
        onValueChange: fn(),
        onValueCommitted: fn(),
    },
    ...withSource(defaultStorySource),
    render: (args) =>
        renderSlider(args, {
            startLabel: "0",
            endLabel: "100",
        }),
    play: async ({canvasElement}) => {
        const slider = getSliderInput(canvasElement, "Adjust lights");

        await expect(slider).toHaveAttribute("aria-valuenow", "35");

        slider.focus();
        await userEvent.keyboard("{ArrowRight}");

        await expect(slider).toHaveAttribute("aria-valuenow", "36");
    },
};

const discreteStorySource = `
<Field.Root name="brightness">
  <Field.Label>Brightness</Field.Label>
  <div className="flex w-full items-center gap-4 py-2">
    <span className="bolt-font-body-m-regular text-secondary">0</span>
    <div className="w-full">
      <Slider.Root defaultValue={30} step={10}>
        <Slider.Control>
          <Slider.Track>
            <Slider.Indicator />
            <Slider.Thumb />
          </Slider.Track>
        </Slider.Control>
        <Slider.Value />
      </Slider.Root>
    </div>
    <span className="bolt-font-body-m-regular text-secondary">100</span>
  </div>
  <Field.Description>Moves in steps of 10.</Field.Description>
</Field.Root>
`.trim();

export const Discrete: Story = {
    args: {
        defaultValue: 30,
        step: 10,
    },
    ...withSource(discreteStorySource),
    render: (args) =>
        renderSlider(args, {
            label: "Brightness",
            helperText: "Moves in steps of 10.",
            startLabel: "0",
            endLabel: "100",
        }),
};

const nonIntegerSource = `
<Field.Root name="opacity">
  <Field.Label>Opacity</Field.Label>
  <div className="flex w-full items-center gap-4 py-2">
    <span className="bolt-font-body-m-regular text-secondary">0</span>
    <div className="w-full">
      <Slider.Root defaultValue={0.3} min={0} max={1} step={0.1} format={{maximumFractionDigits: 1}}>
        <Slider.Control>
          <Slider.Track>
            <Slider.Indicator />
            <Slider.Thumb />
          </Slider.Track>
        </Slider.Control>
        <Slider.Value />
      </Slider.Root>
    </div>
    <span className="bolt-font-body-m-regular text-secondary">1</span>
  </div>
  <Field.Description>Fractional values between 0 and 1.</Field.Description>
</Field.Root>
`.trim();

export const NonIntegerValues: Story = {
    args: {
        defaultValue: 0.3,
        min: 0,
        max: 1,
        step: 0.1,
        format: {maximumFractionDigits: 1},
    },
    ...withSource(nonIntegerSource),
    render: (args) =>
        renderSlider(args, {
            label: "Opacity",
            helperText: "Fractional values between 0 and 1.",
            startLabel: "0",
            endLabel: "1",
        }),
};

const disabledStorySource = `
<Field.Root name="disabled-slider">
  <Field.Label>Adjust lights</Field.Label>
  <div className="flex w-full items-center gap-4 py-2">
    <span className="bolt-font-body-m-regular text-secondary">0</span>
    <div className="w-full">
      <Slider.Root defaultValue={35} disabled>
        <Slider.Control>
          <Slider.Track>
            <Slider.Indicator />
          </Slider.Track>
          <Slider.Thumb />
        </Slider.Control>
        <Slider.Value />
      </Slider.Root>
    </div>
    <span className="bolt-font-body-m-regular text-secondary">100</span>
  </div>
  <Field.Description>Disabled sliders ignore user interaction.</Field.Description>
</Field.Root>
`.trim();

export const Disabled: Story = {
    args: {
        defaultValue: 35,
        disabled: true,
    },
    ...withSource(disabledStorySource),
    render: (args) =>
        renderSlider(args, {
            helperText: "Disabled sliders ignore user interaction.",
            startLabel: "0",
            endLabel: "100",
        }),
    play: async ({canvasElement}) => {
        const slider = getSliderInput(canvasElement, "Adjust lights");
        await expect(slider).toBeDisabled();
    },
};

const customLabelsSource = `
import Lights from '@bolteu/kalep-react-icons/dist/Lights';
import LightsOutlined from '@bolteu/kalep-react-icons/dist/LightsOutlined';

<Field.Root name="lighting">
  <Field.Label>Lighting</Field.Label>
  <div className="flex w-full items-center gap-4 py-2">
    <LightsOutlined className="shrink-0 text-primary" size="lg" />
    <div className="w-full">
      <Slider.Root defaultValue={30}>
        <Slider.Control>
          <Slider.Track>
            <Slider.Indicator />
            <Slider.Thumb />
          </Slider.Track>
        </Slider.Control>
        <Slider.Value />
      </Slider.Root>
    </div>
    <Lights className="shrink-0 text-primary" size="lg" />
  </div>
  <Field.Description>Icons communicate each extreme.</Field.Description>
</Field.Root>
`.trim();

export const CustomLabels: Story = {
    args: {
        defaultValue: 30,
    },
    ...withSource(customLabelsSource),
    render: (args) =>
        renderSlider(args, {
            label: "Lighting",
            helperText: "Icons communicate the low/high extremes.",
            startLabel: <LightsOutlined className="text-primary" size="lg" />,
            endLabel: <Lights className="text-primary" size="lg" />,
        }),
};

const tooltipThumbSource = `
function TooltipExample() {
  const [value, setValue] = React.useState(40);

  return (
    <div className="w-96">
      <Slider.Root value={value} onValueChange={(next) => typeof next === 'number' && setValue(next)}>
        <Slider.Control>
          <Slider.Track>
            <Slider.Indicator />
            <Tooltip content={String(value)} placement="bottom" onOpenChange={() => {}}>
              <Slider.Thumb />
            </Tooltip>
          </Slider.Track>
        </Slider.Control>
        <Slider.Value />
      </Slider.Root>
    </div>
  );
}
`.trim();

export const TooltipOnThumb: Story = {
    args: {
        defaultValue: 40,
    },
    ...withSource(tooltipThumbSource),
    render: (args) => {
        function TooltipExample() {
            const [value, setValue] = React.useState<number>(args.defaultValue as number);

            return renderSlider(
                {
                    ...args,
                    value,
                    onValueChange: (nextValue) => {
                        if (typeof nextValue === "number") {
                            setValue(nextValue);
                        }
                    },
                },
                {
                    label: "Tooltip example",
                    helperText: "Hover the thumb to see contextual info.",
                    startLabel: "0",
                    endLabel: "100",
                    controlWrapper: (thumbs) => {
                        const elements = React.Children.map(thumbs, (child) => (
                            <Tooltip content={`${value}`} placement="top" onOpenChange={() => {}} isOpen={true}>
                                {child as React.ReactElement}
                            </Tooltip>
                        ));

                        return elements ?? null;
                    },
                },
            );
        }

        return <TooltipExample />;
    },
};

const rangeSource = `
<Field.Root name="range">
  <Field.Label>Allowed range</Field.Label>
  <div className="flex w-full items-center gap-4 py-2">
    <span className="bolt-font-body-m-regular text-secondary">0</span>
    <div className="w-full">
      <Slider.Root defaultValue={[20, 70]} minStepsBetweenValues={5}>
        <Slider.Control>
          <Slider.Track>
            <Slider.Indicator />
            <Slider.Thumb />
            <Slider.Thumb />
          </Slider.Track>
        </Slider.Control>
        <Slider.Value>{(_, values) => \`\${values[0]} – \${values[1]}\`}</Slider.Value>
      </Slider.Root>
    </div>
    <span className="bolt-font-body-m-regular text-secondary">100</span>
  </div>
  <Field.Description>Drag each thumb to set the minimum and maximum.</Field.Description>
</Field.Root>
`.trim();

export const Range: Story = {
    args: {
        defaultValue: [20, 70],
        minStepsBetweenValues: 5,
    },
    ...withSource(rangeSource),
    render: (args) =>
        renderSlider(args, {
            label: "Allowed range",
            helperText: "Drag each thumb to set the minimum and maximum.",
            startLabel: "0",
            endLabel: "100",
            valueChildren: (_, values) => `${values[0]} – ${values[1]}`,
        }),
};

const controlledSource = `
function ControlledSlider() {
  const [value, setValue] = React.useState(30);

  return (
    <Field.Root name="controlled">
      <Field.Label>Adjust lights</Field.Label>
      <Slider.Root value={value} onValueChange={(next) => setValue(next as number)}>
        <Slider.Control>
          <Slider.Track>
            <Slider.Indicator />
            <Slider.Thumb />
          </Slider.Track>
        </Slider.Control>
        <Slider.Value />
      </Slider.Root>
      <Field.Description>State-managed slider using the value prop.</Field.Description>
    </Field.Root>
  );
}
`.trim();

export const Controlled: Story = {
    args: {},
    ...withSource(controlledSource),
    render: (args) => {
        function ControlledExample() {
            const [value, setValue] = React.useState<number>(30);
            const handleValueChange = (nextValue: number | readonly number[]) => {
                if (typeof nextValue === "number") {
                    setValue(nextValue);
                }
            };

            return renderSlider(
                {
                    ...args,
                    value,
                    onValueCommitted: fn(),
                    onValueChange: handleValueChange,
                },
                {
                    helperText: "State-managed slider using the value prop.",
                    startLabel: "0",
                    endLabel: "100",
                },
            );
        }

        return <ControlledExample />;
    },
    play: async ({canvasElement}) => {
        const slider = getSliderInput(canvasElement, "Adjust lights");

        await expect(slider).toHaveAttribute("aria-valuenow", "30");

        slider.focus();
        await userEvent.keyboard("{ArrowLeft}");

        await expect(slider).toHaveAttribute("aria-valuenow", "29");
    },
};
