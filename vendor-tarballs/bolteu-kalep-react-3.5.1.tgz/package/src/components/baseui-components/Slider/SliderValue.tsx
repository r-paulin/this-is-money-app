import * as React from "react";

import {Slider as BaseUISlider} from "@base-ui/react/slider";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Slider.Value
 * Renders the current slider value(s) as text or custom JSX.
 *
 * ```tsx
 * <Slider.Value>{(formatted) => formatted.join(" / ")}</Slider.Value>
 * ```
 */
export const SliderValue = React.forwardRef(function SliderValue(
    props: BaseUISlider.Value.Props,
    ref: React.ForwardedRef<HTMLOutputElement>,
) {
    const {className, ...rest} = props;

    const sliderValueClassName = React.useCallback(
        (state: BaseUISlider.Root.State) => {
            return cx(
                "bolt-font-body-s-regular text-secondary",
                "inline-flex items-center",
                addConsumerClasses(state, className),
            );
        },
        [className],
    );

    return <BaseUISlider.Value ref={ref} className={sliderValueClassName} {...rest} />;
});

