import * as React from "react";

import {Slider as BaseUISlider} from "@base-ui/react/slider";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Slider.Indicator
 * Highlights the active portion of the track (filled area).
 *
 * ```tsx
 * <Slider.Track>
 *   <Slider.Indicator />
 * </Slider.Track>
 * ```
 */
export const SliderIndicator = React.forwardRef(function SliderIndicator(
    props: BaseUISlider.Indicator.Props,
    ref: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, ...rest} = props;

    const sliderIndicatorClassName = React.useCallback(
        (state: BaseUISlider.Root.State) => {
            const invalid = state.valid === false;
            return cx(
                "pointer-events-none rounded-full bg-action-primary",
                "h-full",
                "transition-colors duration-150 ease-linear",
                {
                    "bg-neutral-secondary": state.disabled && !invalid,
                    "bg-danger-primary": invalid,
                },
                addConsumerClasses(state, className),
            );
        },
        [className],
    );

    return <BaseUISlider.Indicator ref={ref} className={sliderIndicatorClassName} {...rest} />;
});

