import * as React from "react";

import {Slider as BaseUISlider} from "@base-ui/react/slider";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Slider.Thumb
 * Draggable handle that sets the slider value.
 *
 * ```tsx
 * <Slider.Control>
 *   <Slider.Track>
 *     <Slider.Indicator />
 *     <Slider.Thumb />
 *   </Slider.Track>
 * </Slider.Control>
 * ```
 */
export const SliderThumb = React.forwardRef(function SliderThumb(
    props: BaseUISlider.Thumb.Props,
    ref: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, children, ...rest} = props;

    const sliderThumbClassName = React.useCallback(
        (state: BaseUISlider.Thumb.State) => {
            const invalid = state.valid === false;
            return cx(
                "h-6 w-6 border-4",
                "box-border rounded-full border-solid border-action-primary bg-static-key-light shadow-md",
                `
                  has-[:focus-visible]:outline has-[:focus-visible]:outline-1 has-[:focus-visible]:outline-offset-1
                  has-[:focus-visible]:[outline-color:var(--color-bg-action-primary)]
                `,
                state.disabled
                    ? "cursor-not-allowed"
                    : `
                      cursor-grab
                      active:cursor-grabbing
                    `,
                {
                    "border-neutral-secondary shadow-none": state.disabled && !invalid,
                    "border-danger-primary": invalid,
                    "shadow-lg": state.dragging && !state.disabled,
                },
                addConsumerClasses(state, className),
            );
        },
        [className],
    );

    return (
        <BaseUISlider.Thumb ref={ref} className={sliderThumbClassName} {...rest}>
            {children}
        </BaseUISlider.Thumb>
    );
});

