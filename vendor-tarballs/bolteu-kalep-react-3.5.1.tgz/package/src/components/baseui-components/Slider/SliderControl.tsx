import * as React from "react";

import {Slider as BaseUISlider} from "@base-ui/react/slider";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Slider.Control
 * Click / drag surface that hosts the track + thumbs.
 *
 * ```tsx
 * <Slider.Control>
 *   <Slider.Track>
 *     <Slider.Indicator />
 *     <Slider.Thumb />
 *   </Slider.Track>  
 * </Slider.Control>
 * ```
 */
export const SliderControl = React.forwardRef(function SliderControl(
    props: BaseUISlider.Control.Props,
    ref: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, ...rest} = props;

    const sliderControlClassName = React.useCallback(
        (state: BaseUISlider.Control.State) => {
            return cx(
                "relative flex w-full items-center py-2",
                "touch-none select-none",
                state.disabled ? "cursor-not-allowed" : "cursor-pointer",
                addConsumerClasses(state, className),
            );
        },
        [className],
    );

    return <BaseUISlider.Control ref={ref} className={sliderControlClassName} {...rest} />;
});

