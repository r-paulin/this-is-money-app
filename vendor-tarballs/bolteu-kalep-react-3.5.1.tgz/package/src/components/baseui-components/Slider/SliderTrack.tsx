import * as React from "react";

import {Slider as BaseUISlider} from "@base-ui/react/slider";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Slider.Track
 * Visual baseline of the control, typically wraps `Slider.Indicator`.
 *
 * ```tsx
 * <Slider.Track>
 *   <Slider.Indicator />
 * </Slider.Track>
 * ```
 */
export const SliderTrack = React.forwardRef(function SliderTrack(
    props: BaseUISlider.Track.Props,
    ref: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, ...rest} = props;

    const sliderTrackClassName = React.useCallback(
        (state: BaseUISlider.Root.State) => {
            const invalid = state.valid === false;

            return cx(
                "relative h-1 w-full rounded-full bg-neutral-secondary-hard",
                "transition-colors duration-150 ease-linear",
                {
                    "bg-special-disabled": state.disabled && !invalid,
                    "bg-danger-secondary": invalid,
                },
                addConsumerClasses(state, className),
            );
        },
        [className],
    );

    return <BaseUISlider.Track ref={ref} className={sliderTrackClassName} {...rest} />;
});

