import * as React from "react";

import type {Meta, StoryObj} from "@storybook/react-webpack5";

import {Form} from "@/components/baseui-components/Form";

const meta = {
    component: Form,
    title: "BaseUI Playground/Form",
    tags: ["experimental", "BaseUI", "autodocs"],
    parameters: {
        docs: {
            subtitle: "A primitive component for building forms with data handling.",
        },
    },
} satisfies Meta<typeof Form>;

export default meta;

type Story = StoryObj<typeof meta>;

export const Primitive: Story = {
    args: {},
    render: (args) => <Form {...args} className="rounded-md border border-solid border-neutral-secondary p-4" />,
};
