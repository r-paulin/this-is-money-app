import {Form as BaseUIForm} from "@base-ui/react";

/**
 * This documentation part is under development.
 * In the meanwhile, please refer to the BaseUI documentation for the `Form` component.
 * - [Component description](https://base-ui.com/react/components/form)
 * - [Building forms](https://base-ui.com/react/handbook/forms)
 */
export const Form = BaseUIForm;
