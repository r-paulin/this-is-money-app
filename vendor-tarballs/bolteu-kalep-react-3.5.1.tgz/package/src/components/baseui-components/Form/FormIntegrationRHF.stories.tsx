import * as React from "react";
import {Controller, useForm, type UseFormRegisterReturn} from "react-hook-form";

import {expect, userEvent, waitFor, within} from "storybook/test";
import type {Meta, StoryObj} from "@storybook/react-webpack5";

import {Checkbox} from "@/components/baseui-components/CheckBox";
import {CheckboxGroup} from "@/components/baseui-components/CheckboxGroup";
import {Combobox} from "@/components/baseui-components/Combobox";
import {Field} from "@/components/baseui-components/Field";
import {Form} from "@/components/baseui-components/Form";
import {Input} from "@/components/baseui-components/Input";
import {Radio} from "@/components/baseui-components/RadioGroup/Radio";
import {RadioGroup} from "@/components/baseui-components/RadioGroup/RadioGroup";
import {Select} from "@/components/baseui-components/Select";
import {Slider} from "@/components/baseui-components/Slider";
import {Switch} from "@/components/baseui-components/Switch";
import {TextArea} from "@/components/baseui-components/TextArea";

const meta = {
    component: Form,
    title: "BaseUI Playground/Form Integration of RHF",
    tags: ["experimental", "BaseUI", "autodocs"],
    parameters: {
        docs: {
            subtitle:
                "Separated React Hook Form examples for register and Controller integration, plus extended validation scenarios.",
        },
    },
} satisfies Meta<typeof Form>;

export default meta;

type Story = StoryObj<typeof meta>;
const withSource = (code: string) => ({
    parameters: {
        docs: {
            source: {
                code,
            },
        },
    },
});

type CityOption = {
    label: string;
    value: string;
    secondary: string;
};

type SelectOption = {
    label: string;
    value: string | null;
};

const CITY_OPTIONS: CityOption[] = [
    {label: "Tallinn", value: "1", secondary: "Estonia"},
    {label: "Stockholm", value: "2", secondary: "Sweden"},
    {label: "Berlin", value: "3", secondary: "Germany"},
    {label: "Warsaw", value: "4", secondary: "Poland"},
    {label: "Paris", value: "5", secondary: "France"},
];

const SELECT_OPTIONS: SelectOption[] = [{label: "Choose a city", value: null}, ...CITY_OPTIONS];
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function findCityByValue(value: string | null): CityOption | null {
    if (!value) {
        return null;
    }

    return CITY_OPTIONS.find((option) => option.value === value) ?? null;
}

function findCitiesByValues(values: string[]): CityOption[] {
    return values
        .map((value) => CITY_OPTIONS.find((option) => option.value === value))
        .filter((option): option is CityOption => Boolean(option));
}

function safeStringify(value: unknown): string {
    const visited = new WeakSet<object>();

    return JSON.stringify(
        value,
        (_key, currentValue) => {
            if (typeof currentValue === "function") {
                return `[Function ${currentValue.name || "anonymous"}]`;
            }

            if (typeof Element !== "undefined" && currentValue instanceof Element) {
                return `[${currentValue.tagName}]`;
            }

            if (currentValue && typeof currentValue === "object") {
                if (visited.has(currentValue)) {
                    return "[Circular]";
                }
                visited.add(currentValue);
            }

            return currentValue;
        },
        2,
    );
}

function ValuePanel({title, value, testId}: {title: string; value: unknown; testId: string}) {
    return (
        <div className="rounded-md border border-solid border-neutral-secondary bg-special-nulled p-3">
            <p className="bolt-font-body-s-accent mb-2">{title}</p>
            <pre className="bolt-font-body-s-regular overflow-auto text-secondary" data-testid={testId}>
                {safeStringify(value)}
            </pre>
        </div>
    );
}

function toFormErrors(entries: Array<[string, string | undefined]>): Record<string, string> {
    return Object.fromEntries(entries.filter((entry): entry is [string, string] => Boolean(entry[1])));
}

function SelectField({
    name,
    value,
    onChange,
    inputRef,
    onBlur,
    touched,
    touchedTestId,
    invalid,
    errorMessage,
    testIdPrefix,
}: {
    name: string;
    value: string | null;
    onChange: (value: string | null) => void;
    inputRef?: React.Ref<HTMLInputElement>;
    onBlur?: React.FocusEventHandler<HTMLElement>;
    touched?: boolean;
    touchedTestId?: string;
    invalid: boolean;
    errorMessage?: string;
    testIdPrefix: string;
}) {
    return (
        <Field.Root name={name} invalid={invalid}>
            <Field.Label>Select city</Field.Label>
            <Select.Root items={SELECT_OPTIONS} value={value} onValueChange={onChange} name={name} inputRef={inputRef}>
                <Select.Trigger data-testid={`${testIdPrefix}-select-trigger`} onBlur={onBlur}>
                    <Select.Value />
                    <Select.Icon />
                </Select.Trigger>
                <Select.Portal>
                    <Select.Positioner>
                        <Select.Popup>
                            <Select.List data-testid={`${testIdPrefix}-select-list`}>
                                {SELECT_OPTIONS.map((option) => (
                                    <Select.Item
                                        key={option.value ?? "placeholder"}
                                        value={option.value}
                                        data-testid={`${testIdPrefix}-select-item-${option.value ?? "null"}`}
                                    >
                                        <Select.ItemText>{option.label}</Select.ItemText>
                                        <Select.ItemIndicator />
                                    </Select.Item>
                                ))}
                            </Select.List>
                        </Select.Popup>
                    </Select.Positioner>
                </Select.Portal>
            </Select.Root>
            <Field.Error match={invalid}>{errorMessage}</Field.Error>
            <Field.Description>Controller with primitive value mapping</Field.Description>
            {touchedTestId ? (
                <span className="sr-only" data-testid={touchedTestId}>
                    {String(Boolean(touched))}
                </span>
            ) : null}
        </Field.Root>
    );
}

function SingleComboboxField({
    name,
    value,
    onChange,
    controlRef,
    onBlur,
    registerField,
    touched,
    touchedTestId,
    invalid,
    errorMessage,
    testIdPrefix,
}: {
    name: string;
    value: string | null;
    onChange: (value: string | null) => void;
    controlRef?: React.Ref<HTMLInputElement>;
    onBlur?: (event?: unknown) => void;
    registerField?: UseFormRegisterReturn;
    touched?: boolean;
    touchedTestId?: string;
    invalid: boolean;
    errorMessage?: string;
    testIdPrefix: string;
}) {
    const selectedOption = React.useMemo(() => findCityByValue(value), [value]);

    const handleValueChange = React.useCallback(
        (nextValue: CityOption | CityOption[] | null) => {
            const nextOption = Array.isArray(nextValue) ? nextValue[0] : nextValue;
            const mappedValue = nextOption?.value ?? "";
            registerField?.onChange({
                target: {name: registerField.name, value: mappedValue},
                type: "change",
            });
            onChange(nextOption?.value ?? null);
        },
        [onChange, registerField],
    );

    return (
        <Field.Root name={name} invalid={invalid}>
            <Field.Label>Favorite city</Field.Label>
            <Combobox.Root items={CITY_OPTIONS} value={selectedOption} onValueChange={handleValueChange}>
                <Combobox.Input data-testid={`${testIdPrefix}-combobox-single-trigger`} placeholder="Pick a city">
                    <Combobox.ValueArea>
                        <Combobox.Control
                            data-testid={`${testIdPrefix}-combobox-single-control`}
                            ref={controlRef}
                            onBlur={(event) => {
                                onBlur?.(event);
                                if (!registerField) {
                                    return;
                                }
                                registerField?.onBlur({
                                    target: {name: registerField.name},
                                    type: "blur",
                                });
                            }}
                        />
                    </Combobox.ValueArea>
                    <Combobox.Controls>
                        <Combobox.Clear data-testid={`${testIdPrefix}-combobox-single-clear`} />
                        <Combobox.Trigger>
                            <Combobox.Icon />
                        </Combobox.Trigger>
                    </Combobox.Controls>
                </Combobox.Input>
                <Combobox.Portal>
                    <Combobox.Positioner sideOffset={4}>
                        <Combobox.Popup>
                            <Combobox.Empty>No options</Combobox.Empty>
                            <Combobox.List data-testid={`${testIdPrefix}-combobox-single-list`}>
                                {(item: CityOption) => (
                                    <Combobox.Item
                                        key={item.value}
                                        value={item}
                                        data-testid={`${testIdPrefix}-combobox-single-item-${item.value}`}
                                    >
                                        <div className="flex min-w-0 flex-1 flex-col">
                                            <span>{item.label}</span>
                                            <span className="bolt-font-body-s-regular text-secondary">
                                                {item.secondary}
                                            </span>
                                        </div>
                                        <Combobox.ItemIndicator />
                                    </Combobox.Item>
                                )}
                            </Combobox.List>
                        </Combobox.Popup>
                    </Combobox.Positioner>
                </Combobox.Portal>
            </Combobox.Root>
            <Field.Error match={invalid}>{errorMessage}</Field.Error>
            <Field.Description>Controller with option object to primitive mapping</Field.Description>
            {touchedTestId ? (
                <span className="sr-only" data-testid={touchedTestId}>
                    {String(Boolean(touched))}
                </span>
            ) : null}
        </Field.Root>
    );
}

function MultiComboboxField({
    name,
    value,
    onChange,
    controlRef,
    onBlur,
    invalid,
    errorMessage,
    testIdPrefix,
}: {
    name: string;
    value: string[];
    onChange: (value: string[]) => void;
    controlRef?: React.Ref<HTMLInputElement>;
    onBlur?: (event?: unknown) => void;
    invalid: boolean;
    errorMessage?: string;
    testIdPrefix: string;
}) {
    const chipsRef = React.useRef<HTMLDivElement | null>(null);
    const selectedOptions = React.useMemo(() => findCitiesByValues(value), [value]);

    const handleValueChange = React.useCallback(
        (nextValue: CityOption | CityOption[] | null) => {
            if (!Array.isArray(nextValue)) {
                onChange([]);
                return;
            }

            onChange(nextValue.map((item) => item.value));
        },
        [onChange],
    );

    return (
        <Field.Root name={name} invalid={invalid}>
            <Field.Label>Visited cities</Field.Label>
            <Combobox.Root items={CITY_OPTIONS} value={selectedOptions} onValueChange={handleValueChange} multiple>
                <Combobox.Chips ref={chipsRef}>
                    <Combobox.Input
                        data-testid={`${testIdPrefix}-combobox-multi-trigger`}
                        placeholder="Pick one or many"
                    >
                        <Combobox.ValueArea>
                            <Combobox.Value>
                                {(currentValue) => {
                                    const selected = Array.isArray(currentValue) ? currentValue : [];
                                    return (
                                        <>
                                            {selected.map((option) => (
                                                <Combobox.Chip key={option.value}>
                                                    <span className="max-w-[9rem] truncate">{option.label}</span>
                                                    <Combobox.ChipRemove
                                                        aria-label={`Remove ${option.label}`}
                                                        data-testid={`${testIdPrefix}-combobox-multi-remove-${option.value}`}
                                                    />
                                                </Combobox.Chip>
                                            ))}
                                            <Combobox.Control
                                                placeholder="Pick one or many"
                                                data-testid={`${testIdPrefix}-combobox-multi-input`}
                                                ref={controlRef}
                                                onBlur={onBlur}
                                            />
                                        </>
                                    );
                                }}
                            </Combobox.Value>
                        </Combobox.ValueArea>
                        <Combobox.Controls>
                            <Combobox.Clear data-testid={`${testIdPrefix}-combobox-multi-clear`} />
                            <Combobox.Trigger>
                                <Combobox.Icon />
                            </Combobox.Trigger>
                        </Combobox.Controls>
                    </Combobox.Input>
                </Combobox.Chips>

                <Combobox.Portal>
                    <Combobox.Positioner anchor={chipsRef} sideOffset={4}>
                        <Combobox.Popup>
                            <Combobox.Empty>No options</Combobox.Empty>
                            <Combobox.List data-testid={`${testIdPrefix}-combobox-multi-list`}>
                                {(item: CityOption) => (
                                    <Combobox.Item
                                        key={item.value}
                                        value={item}
                                        data-testid={`${testIdPrefix}-combobox-multi-item-${item.value}`}
                                    >
                                        <span>{item.label}</span>
                                        <Combobox.ItemIndicator />
                                    </Combobox.Item>
                                )}
                            </Combobox.List>
                        </Combobox.Popup>
                    </Combobox.Positioner>
                </Combobox.Portal>
            </Combobox.Root>
            <Field.Error match={invalid}>{errorMessage}</Field.Error>
            <Field.Description>Controller with option array to primitive array mapping</Field.Description>
        </Field.Root>
    );
}

type RegisterValues = {
    fullName: string;
    email: string;
    note: string;
    travelClass: string;
    favoriteCityId: string;
    marketingOptIn: boolean;
};

const REGISTER_DEFAULTS: RegisterValues = {
    fullName: "",
    email: "",
    note: "",
    travelClass: "",
    favoriteCityId: "",
    marketingOptIn: false,
};

function RegisterFieldsExample() {
    const [submitted, setSubmitted] = React.useState<RegisterValues | null>(null);
    const {
        register,
        handleSubmit,
        reset,
        setValue,
        watch,
        formState: {errors, touchedFields},
    } = useForm<RegisterValues>({
        defaultValues: REGISTER_DEFAULTS,
        mode: "onSubmit",
        reValidateMode: "onChange",
        shouldFocusError: true,
    });
    const travelClassRegister = register("travelClass", {
        validate: (value) => Boolean(value) || "Select travel class",
    });
    const favoriteCityRegister = register("favoriteCityId", {
        validate: (value) => Boolean(value) || "Pick a favorite city",
    });
    const marketingOptInRegister = register("marketingOptIn");

    const travelClassValue = watch("travelClass");
    const favoriteCityIdValue = watch("favoriteCityId");
    const marketingOptInValue = watch("marketingOptIn");
    const favoriteCityOption = React.useMemo(() => findCityByValue(favoriteCityIdValue || null), [favoriteCityIdValue]);
    const formErrors = React.useMemo(
        () =>
            toFormErrors([
                ["fullName", errors.fullName?.message],
                ["email", errors.email?.message],
                ["note", errors.note?.message],
                ["travelClass", errors.travelClass?.message],
                ["favoriteCityId", errors.favoriteCityId?.message],
                ["marketingOptIn", errors.marketingOptIn?.message],
            ]),
        [
            errors.email?.message,
            errors.favoriteCityId?.message,
            errors.fullName?.message,
            errors.marketingOptIn?.message,
            errors.note?.message,
            errors.travelClass?.message,
        ],
    );

    return (
        <div className="mx-auto max-w-2xl space-y-5">
            <Form
                errors={formErrors}
                onSubmit={handleSubmit((values) => setSubmitted(values))}
                noValidate
                className="space-y-4"
            >
                <Field.Root name="fullName" invalid={Boolean(errors.fullName)}>
                    <Field.Label>Full name</Field.Label>
                    <Input
                        data-testid="register-full-name"
                        placeholder="Jane Doe"
                        {...register("fullName", {
                            validate: (value) =>
                                value.trim().length >= 2 || "Full name must have at least 2 characters",
                        })}
                    >
                        <Input.Control data-testid="register-full-name-input" />
                    </Input>
                    <div data-testid="register-full-name-error">
                        <Field.Error match={Boolean(errors.fullName)}>{errors.fullName?.message}</Field.Error>
                    </div>
                    <span className="sr-only" data-testid="register-full-name-touched">
                        {String(Boolean(touchedFields.fullName))}
                    </span>
                    <Field.Description>`register` with custom validate (no native required attr)</Field.Description>
                </Field.Root>

                <Field.Root name="email" invalid={Boolean(errors.email)}>
                    <Field.Label>Email</Field.Label>
                    <Input
                        data-testid="register-email"
                        placeholder="jane@company.com"
                        {...register("email", {
                            validate: (value) => {
                                const trimmed = value.trim();
                                if (!trimmed) {
                                    return "Email is required";
                                }
                                return EMAIL_REGEX.test(trimmed) || "Enter a valid email address";
                            },
                        })}
                    >
                        <Input.Control data-testid="register-email-input" />
                    </Input>
                    <div data-testid="register-email-error">
                        <Field.Error match={Boolean(errors.email)}>{errors.email?.message}</Field.Error>
                    </div>
                    <span className="sr-only" data-testid="register-email-touched">
                        {String(Boolean(touchedFields.email))}
                    </span>
                    <Field.Description>Validation includes required + email format</Field.Description>
                </Field.Root>

                <Field.Root name="note" invalid={Boolean(errors.note)}>
                    <Field.Label>Internal note</Field.Label>
                    <TextArea
                        data-testid="register-note"
                        rows={3}
                        placeholder="At least 15 characters if provided"
                        {...register("note", {
                            validate: (value) => {
                                const trimmed = value.trim();

                                if (!trimmed) {
                                    return true;
                                }
                                return trimmed.length >= 15 || "Note must have at least 15 characters";
                            },
                        })}
                    />
                    <div data-testid="register-note-error">
                        <Field.Error match={Boolean(errors.note)}>{errors.note?.message}</Field.Error>
                    </div>
                    <Field.Description>Optional field with conditional min length</Field.Description>
                </Field.Root>

                <Field.Root name="travelClass" invalid={Boolean(errors.travelClass)}>
                    <Field.Label>Travel class</Field.Label>
                    <RadioGroup
                        name={travelClassRegister.name}
                        onBlur={travelClassRegister.onBlur}
                        value={travelClassValue}
                        onValueChange={(nextValue) => {
                            travelClassRegister.onChange({
                                target: {name: travelClassRegister.name, value: String(nextValue ?? "")},
                                type: "change",
                            });
                        }}
                        inputRef={travelClassRegister.ref}
                    >
                        <Field.Item>
                            <Field.Label inline>
                                <Radio value="economy" data-testid="register-travel-class-economy" />
                                Economy
                            </Field.Label>
                        </Field.Item>
                        <Field.Item>
                            <Field.Label inline>
                                <Radio value="business" data-testid="register-travel-class-business" />
                                Business
                            </Field.Label>
                        </Field.Item>
                    </RadioGroup>
                    <div data-testid="register-travel-class-error">
                        <Field.Error match={Boolean(errors.travelClass)}>{errors.travelClass?.message}</Field.Error>
                    </div>
                    <Field.Description>Register + setValue mapping for RadioGroup</Field.Description>
                </Field.Root>

                <SingleComboboxField
                    name="favoriteCityId"
                    value={favoriteCityOption?.value ?? null}
                    onChange={(nextValue) =>
                        setValue("favoriteCityId", nextValue ?? "", {shouldDirty: true, shouldValidate: true})
                    }
                    registerField={favoriteCityRegister}
                    invalid={Boolean(errors.favoriteCityId)}
                    errorMessage={errors.favoriteCityId?.message}
                    testIdPrefix="register"
                />

                <Field.Root name="marketingOptIn" invalid={Boolean(errors.marketingOptIn)}>
                    <Field.Label inline>
                        <Checkbox
                            data-testid="register-marketing-opt-in"
                            checked={Boolean(marketingOptInValue)}
                            name={marketingOptInRegister.name}
                            inputRef={marketingOptInRegister.ref}
                            onBlur={marketingOptInRegister.onBlur}
                            onCheckedChange={(checked) => {
                                marketingOptInRegister.onChange({
                                    target: {
                                        name: marketingOptInRegister.name,
                                        type: "checkbox",
                                        checked: Boolean(checked),
                                    },
                                    type: "change",
                                });
                            }}
                        />
                        Receive product updates
                    </Field.Label>
                    <Field.Description>`register` checkbox via onCheckedChange + inputRef</Field.Description>
                </Field.Root>

                <div className="flex flex-wrap gap-3">
                    <button
                        type="submit"
                        data-testid="register-submit"
                        className={
                            "rounded-md border border-solid border-action-primary px-4 py-2 text-sm text-action-primary"
                        }
                    >
                        Submit register form
                    </button>
                    <button
                        type="button"
                        data-testid="register-reset"
                        onClick={() => {
                            reset(REGISTER_DEFAULTS);
                            setSubmitted(null);
                        }}
                        className="rounded-md border border-solid border-neutral-secondary px-4 py-2 text-sm"
                    >
                        Reset
                    </button>
                    <button
                        type="button"
                        data-testid="register-set-values"
                        onClick={() => {
                            setValue("fullName", "Preset User", {shouldDirty: true, shouldValidate: true});
                            setValue("email", "preset@example.com", {shouldDirty: true, shouldValidate: true});
                            setValue("note", "Preset note with enough text", {shouldDirty: true, shouldValidate: true});
                            setValue("travelClass", "business", {shouldDirty: true, shouldValidate: true});
                            setValue("favoriteCityId", "3", {shouldDirty: true, shouldValidate: true});
                            setValue("marketingOptIn", true, {shouldDirty: true, shouldValidate: true});
                        }}
                        className="rounded-md border border-solid border-neutral-secondary px-4 py-2 text-sm"
                    >
                        Set values
                    </button>
                </div>
            </Form>

            <ValuePanel title="Register payload" value={submitted} testId="register-output" />
        </div>
    );
}

type ControllerValues = {
    acceptTerms: boolean;
    updatesEnabled: boolean;
    travelClass: string;
    interests: string[];
    cityId: string | null;
    favoriteCityId: string | null;
    visitedCityIds: string[];
    brightness: number;
};

const CONTROLLER_DEFAULTS: ControllerValues = {
    acceptTerms: false,
    updatesEnabled: false,
    travelClass: "",
    interests: [],
    cityId: null,
    favoriteCityId: null,
    visitedCityIds: [],
    brightness: 25,
};

function ControllerFieldsExample() {
    const [submitted, setSubmitted] = React.useState<ControllerValues | null>(null);
    const {
        control,
        handleSubmit,
        setValue,
        reset,
        formState: {errors},
    } = useForm<ControllerValues>({
        defaultValues: CONTROLLER_DEFAULTS,
        mode: "onSubmit",
        reValidateMode: "onChange",
        shouldFocusError: true,
    });
    const formErrors = React.useMemo(
        () =>
            toFormErrors([
                ["acceptTerms", errors.acceptTerms?.message],
                ["updatesEnabled", errors.updatesEnabled?.message],
                ["travelClass", errors.travelClass?.message],
                ["interests", errors.interests?.message],
                ["brightness", errors.brightness?.message],
                ["cityId", errors.cityId?.message],
                ["favoriteCityId", errors.favoriteCityId?.message],
                ["visitedCityIds", errors.visitedCityIds?.message],
            ]),
        [
            errors.acceptTerms?.message,
            errors.brightness?.message,
            errors.cityId?.message,
            errors.favoriteCityId?.message,
            errors.interests?.message,
            errors.travelClass?.message,
            errors.updatesEnabled?.message,
            errors.visitedCityIds?.message,
        ],
    );

    return (
        <div className="mx-auto max-w-4xl space-y-6">
            <Form
                errors={formErrors}
                onSubmit={handleSubmit((values) => setSubmitted(values))}
                noValidate
                className="space-y-4"
            >
                <Controller
                    name="acceptTerms"
                    control={control}
                    rules={{validate: (value) => value || "You must accept terms"}}
                    render={({field, fieldState}) => (
                        <Field.Root name="acceptTerms" invalid={Boolean(fieldState.error)}>
                            <Field.Label inline>
                                <Checkbox
                                    name={field.name}
                                    checked={field.value}
                                    inputRef={field.ref}
                                    onBlur={field.onBlur}
                                    onCheckedChange={(checked) => field.onChange(Boolean(checked))}
                                    data-testid="controller-accept-terms"
                                />
                                I accept terms and conditions
                            </Field.Label>
                            <Field.Error match={Boolean(fieldState.error)}>{fieldState.error?.message}</Field.Error>
                            <Field.Description>Controller boolean mapping</Field.Description>
                        </Field.Root>
                    )}
                />

                <Controller
                    name="updatesEnabled"
                    control={control}
                    rules={{validate: (value) => value || "Enable updates"}}
                    render={({field, fieldState}) => (
                        <Field.Root name="updatesEnabled" invalid={Boolean(fieldState.error)}>
                            <Field.Label inline>
                                <Switch
                                    name={field.name}
                                    checked={field.value}
                                    inputRef={field.ref}
                                    onBlur={field.onBlur}
                                    onCheckedChange={(checked) => field.onChange(Boolean(checked))}
                                    data-testid="controller-updates-enabled"
                                />
                                Receive updates
                            </Field.Label>
                            <Field.Error match={Boolean(fieldState.error)}>{fieldState.error?.message}</Field.Error>
                            <Field.Description>Switch with checked/onCheckedChange mapping</Field.Description>
                        </Field.Root>
                    )}
                />

                <Controller
                    name="travelClass"
                    control={control}
                    rules={{validate: (value) => Boolean(value) || "Select travel class"}}
                    render={({field, fieldState}) => (
                        <Field.Root name="travelClass" invalid={Boolean(fieldState.error)}>
                            <Field.Label>Travel class</Field.Label>
                            <RadioGroup
                                name={field.name}
                                value={field.value}
                                onValueChange={field.onChange}
                                onBlur={field.onBlur}
                                inputRef={field.ref}
                            >
                                <Field.Item>
                                    <Field.Label inline>
                                        <Radio value="economy" data-testid="controller-travel-class-economy" />
                                        Economy
                                    </Field.Label>
                                </Field.Item>
                                <Field.Item>
                                    <Field.Label inline>
                                        <Radio value="business" data-testid="controller-travel-class-business" />
                                        Business
                                    </Field.Label>
                                </Field.Item>
                            </RadioGroup>
                            <Field.Error match={Boolean(fieldState.error)}>{fieldState.error?.message}</Field.Error>
                            <Field.Description>RadioGroup value + onValueChange mapping</Field.Description>
                        </Field.Root>
                    )}
                />

                <Controller
                    name="interests"
                    control={control}
                    rules={{validate: (value) => value.length > 0 || "Select at least one interest"}}
                    render={({field, fieldState}) => (
                        <Field.Root name="interests" invalid={Boolean(fieldState.error)}>
                            <Field.Label>Interests</Field.Label>
                            <CheckboxGroup
                                value={field.value}
                                onValueChange={(nextValue) => field.onChange(nextValue ?? [])}
                            >
                                <Field.Item>
                                    <Field.Label inline>
                                        <Checkbox value="design" data-testid="controller-interest-design" />
                                        Design
                                    </Field.Label>
                                </Field.Item>
                                <Field.Item>
                                    <Field.Label inline>
                                        <Checkbox value="engineering" data-testid="controller-interest-engineering" />
                                        Engineering
                                    </Field.Label>
                                </Field.Item>
                            </CheckboxGroup>
                            <Field.Error match={Boolean(fieldState.error)}>{fieldState.error?.message}</Field.Error>
                            <Field.Description>CheckboxGroup string array mapping</Field.Description>
                        </Field.Root>
                    )}
                />

                <Controller
                    name="brightness"
                    control={control}
                    rules={{validate: (value) => value >= 10 || "Brightness must be >= 10"}}
                    render={({field, fieldState}) => (
                        <Field.Root name="brightness" invalid={Boolean(fieldState.error)}>
                            <Field.Label>Brightness</Field.Label>
                            <Slider.Root
                                value={field.value}
                                min={0}
                                max={100}
                                onValueChange={(nextValue) => {
                                    field.onChange(Array.isArray(nextValue) ? nextValue[0] : nextValue);
                                }}
                            >
                                <Slider.Control>
                                    <Slider.Track>
                                        <Slider.Indicator />
                                        <Slider.Thumb />
                                    </Slider.Track>
                                </Slider.Control>
                                <Slider.Value />
                            </Slider.Root>
                            <Field.Error match={Boolean(fieldState.error)}>{fieldState.error?.message}</Field.Error>
                            <Field.Description>Slider numeric mapping</Field.Description>
                        </Field.Root>
                    )}
                />

                <Controller
                    name="cityId"
                    control={control}
                    rules={{validate: (value) => Boolean(value) || "Select city is required"}}
                    render={({field, fieldState}) => (
                        <SelectField
                            name="cityId"
                            value={field.value}
                            onChange={field.onChange}
                            inputRef={field.ref}
                            onBlur={field.onBlur}
                            touched={fieldState.isTouched}
                            touchedTestId="controller-city-touched"
                            invalid={Boolean(fieldState.error)}
                            errorMessage={fieldState.error?.message}
                            testIdPrefix="controller"
                        />
                    )}
                />

                <Controller
                    name="favoriteCityId"
                    control={control}
                    rules={{validate: (value) => Boolean(value) || "Favorite city is required"}}
                    render={({field, fieldState}) => (
                        <SingleComboboxField
                            name="favoriteCityId"
                            value={field.value}
                            onChange={field.onChange}
                            controlRef={field.ref}
                            onBlur={field.onBlur}
                            touched={fieldState.isTouched}
                            touchedTestId="controller-favorite-city-touched"
                            invalid={Boolean(fieldState.error)}
                            errorMessage={fieldState.error?.message}
                            testIdPrefix="controller"
                        />
                    )}
                />

                <Controller
                    name="visitedCityIds"
                    control={control}
                    rules={{validate: (value) => value.length > 0 || "Select at least one visited city"}}
                    render={({field, fieldState}) => (
                        <MultiComboboxField
                            name="visitedCityIds"
                            value={field.value}
                            onChange={field.onChange}
                            controlRef={field.ref}
                            onBlur={field.onBlur}
                            invalid={Boolean(fieldState.error)}
                            errorMessage={fieldState.error?.message}
                            testIdPrefix="controller"
                        />
                    )}
                />

                <div className="flex flex-wrap gap-3">
                    <button
                        type="submit"
                        data-testid="controller-submit"
                        className={
                            "rounded-md border border-solid border-action-primary px-4 py-2 text-sm text-action-primary"
                        }
                    >
                        Submit controller form
                    </button>
                    <button
                        type="button"
                        data-testid="controller-reset"
                        onClick={() => {
                            reset(CONTROLLER_DEFAULTS);
                            setSubmitted(null);
                        }}
                        className="rounded-md border border-solid border-neutral-secondary px-4 py-2 text-sm"
                    >
                        Reset
                    </button>
                    <button
                        type="button"
                        data-testid="controller-set-values"
                        onClick={() => {
                            setValue("acceptTerms", true, {shouldDirty: true, shouldValidate: true});
                            setValue("updatesEnabled", true, {shouldDirty: true, shouldValidate: true});
                            setValue("travelClass", "business", {shouldDirty: true, shouldValidate: true});
                            setValue("interests", ["design", "engineering"], {shouldDirty: true, shouldValidate: true});
                            setValue("cityId", "4", {shouldDirty: true, shouldValidate: true});
                            setValue("favoriteCityId", "3", {shouldDirty: true, shouldValidate: true});
                            setValue("visitedCityIds", ["2", "5"], {shouldDirty: true, shouldValidate: true});
                            setValue("brightness", 72, {shouldDirty: true, shouldValidate: true});
                        }}
                        className="rounded-md border border-solid border-neutral-secondary px-4 py-2 text-sm"
                    >
                        Set values
                    </button>
                </div>
            </Form>

            <ValuePanel title="Controller payload" value={submitted} testId="controller-output" />
        </div>
    );
}

type GeneralValues = {
    fullName: string;
    email: string;
    bio: string;
    updatesEnabled: boolean;
    favoriteCityId: string | null;
    brightness: number;
};

const GENERAL_DEFAULTS: GeneralValues = {
    fullName: "",
    email: "",
    bio: "",
    updatesEnabled: false,
    favoriteCityId: null,
    brightness: 30,
};

function GeneralFormExamples() {
    const [submitted, setSubmitted] = React.useState<GeneralValues | null>(null);
    const {
        register,
        control,
        handleSubmit,
        trigger,
        getValues,
        setValue,
        reset,
        formState: {errors},
    } = useForm<GeneralValues>({
        defaultValues: GENERAL_DEFAULTS,
        mode: "onSubmit",
        reValidateMode: "onChange",
        shouldFocusError: true,
    });
    const formErrors = React.useMemo(
        () =>
            toFormErrors([
                ["fullName", errors.fullName?.message],
                ["email", errors.email?.message],
                ["bio", errors.bio?.message],
                ["favoriteCityId", errors.favoriteCityId?.message],
                ["brightness", errors.brightness?.message],
            ]),
        [
            errors.bio?.message,
            errors.brightness?.message,
            errors.email?.message,
            errors.favoriteCityId?.message,
            errors.fullName?.message,
        ],
    );

    return (
        <div className="mx-auto max-w-3xl space-y-6">
            <Form
                errors={formErrors}
                onSubmit={handleSubmit((values) => setSubmitted(values))}
                noValidate
                className="space-y-4"
            >
                <Field.Root name="fullName" invalid={Boolean(errors.fullName)}>
                    <Field.Label>Full name</Field.Label>
                    <Input
                        data-testid="general-full-name"
                        placeholder="Jane Doe"
                        {...register("fullName", {
                            validate: (value) => value.trim().length >= 2 || "Name is too short",
                        })}
                    />
                    <Field.Error match={Boolean(errors.fullName)} />
                </Field.Root>

                <Field.Root name="email" invalid={Boolean(errors.email)}>
                    <Field.Label>Email</Field.Label>
                    <Input
                        data-testid="general-email"
                        placeholder="jane@company.com"
                        {...register("email", {
                            validate: (value) => {
                                const trimmed = value.trim();
                                if (!trimmed) {
                                    return "Email is required";
                                }
                                return EMAIL_REGEX.test(trimmed) || "Invalid email format";
                            },
                        })}
                    />
                    <Field.Error match={Boolean(errors.email)} />
                </Field.Root>

                <Controller
                    name="updatesEnabled"
                    control={control}
                    render={({field}) => (
                        <Field.Root name="updatesEnabled" invalid={Boolean(errors.updatesEnabled)}>
                            <Field.Label inline>
                                <Switch
                                    checked={field.value}
                                    onCheckedChange={(checked) => field.onChange(Boolean(checked))}
                                    data-testid="general-updates-enabled"
                                />
                                Enable updates (makes bio required)
                            </Field.Label>
                        </Field.Root>
                    )}
                />

                <Field.Root name="bio" invalid={Boolean(errors.bio)}>
                    <Field.Label>Bio</Field.Label>
                    <TextArea
                        data-testid="general-bio"
                        rows={3}
                        placeholder="Required if updates are enabled"
                        {...register("bio", {
                            validate: (value) => {
                                const updatesEnabled = getValues("updatesEnabled");
                                const trimmed = value.trim();
                                if (!updatesEnabled) {
                                    return true;
                                }
                                if (!trimmed) {
                                    return "Bio is required when updates are enabled";
                                }
                                return trimmed.length >= 20 || "Bio must have at least 20 characters";
                            },
                        })}
                    />
                    <div data-testid="general-bio-error">
                        <Field.Error match={Boolean(errors.bio)}>{errors.bio?.message}</Field.Error>
                    </div>
                </Field.Root>

                <Controller
                    name="favoriteCityId"
                    control={control}
                    rules={{validate: (value) => Boolean(value) || "Pick a favorite city"}}
                    render={({field, fieldState}) => (
                        <SingleComboboxField
                            name="favoriteCityId"
                            value={field.value}
                            onChange={field.onChange}
                            controlRef={field.ref}
                            onBlur={field.onBlur}
                            touched={fieldState.isTouched}
                            touchedTestId="general-favorite-city-touched"
                            invalid={Boolean(fieldState.error)}
                            errorMessage={fieldState.error?.message}
                            testIdPrefix="general"
                        />
                    )}
                />

                <Controller
                    name="brightness"
                    control={control}
                    rules={{validate: (value) => value >= 20 || "Brightness must be at least 20"}}
                    render={({field, fieldState}) => (
                        <Field.Root name="brightness" invalid={Boolean(fieldState.error)}>
                            <Field.Label>Brightness</Field.Label>
                            <Slider.Root
                                value={field.value}
                                min={0}
                                max={100}
                                onValueChange={(nextValue) => {
                                    field.onChange(Array.isArray(nextValue) ? nextValue[0] : nextValue);
                                }}
                            >
                                <Slider.Control>
                                    <Slider.Track>
                                        <Slider.Indicator />
                                        <Slider.Thumb inputRef={field.ref} onBlur={field.onBlur} />
                                    </Slider.Track>
                                </Slider.Control>
                                <Slider.Value />
                            </Slider.Root>
                            <Field.Error match={Boolean(fieldState.error)}>{fieldState.error?.message}</Field.Error>
                        </Field.Root>
                    )}
                />

                <div className="flex flex-wrap gap-3">
                    <button
                        type="submit"
                        data-testid="general-submit"
                        className={
                            "rounded-md border border-solid border-action-primary px-4 py-2 text-sm text-action-primary"
                        }
                    >
                        Submit general form
                    </button>
                    <button
                        type="button"
                        data-testid="general-validate"
                        onClick={() => {
                            void trigger();
                        }}
                        className="rounded-md border border-solid border-neutral-secondary px-4 py-2 text-sm"
                    >
                        Validate now
                    </button>
                    <button
                        type="button"
                        data-testid="general-set-values"
                        onClick={() => {
                            setValue("fullName", "Preset General", {shouldDirty: true, shouldValidate: true});
                            setValue("email", "general@example.com", {shouldDirty: true, shouldValidate: true});
                            setValue("updatesEnabled", true, {shouldDirty: true, shouldValidate: true});
                            setValue("bio", "This biography text is long enough to pass.", {
                                shouldDirty: true,
                                shouldValidate: true,
                            });
                            setValue("favoriteCityId", "2", {shouldDirty: true, shouldValidate: true});
                            setValue("brightness", 55, {shouldDirty: true, shouldValidate: true});
                        }}
                        className="rounded-md border border-solid border-neutral-secondary px-4 py-2 text-sm"
                    >
                        Set values
                    </button>
                    <button
                        type="button"
                        data-testid="general-reset"
                        onClick={() => {
                            reset(GENERAL_DEFAULTS);
                            setSubmitted(null);
                        }}
                        className="rounded-md border border-solid border-neutral-secondary px-4 py-2 text-sm"
                    >
                        Reset
                    </button>
                </div>
            </Form>

            <ValuePanel title="General payload" value={submitted} testId="general-output" />
        </div>
    );
}

const registerFieldsSource = `
import {useForm} from 'react-hook-form';
import {Form} from '@/components/baseui-components/Form';

type RegisterValues = {
  fullName: string;
  email: string;
  note: string;
  travelClass: string;
  favoriteCityId: string;
  marketingOptIn: boolean;
};

function RegisterOnlyExample() {
  const {register, watch, setValue, handleSubmit, formState: {errors}} = useForm<RegisterValues>({
    defaultValues: {fullName: '', email: '', note: '', travelClass: '', favoriteCityId: '', marketingOptIn: false},
    mode: 'onSubmit',
  });
  const travelClassRegister = register('travelClass', {
    validate: (value) => Boolean(value) || 'Select travel class',
  });
  const favoriteCityRegister = register('favoriteCityId', {
    validate: (value) => Boolean(value) || 'Pick a favorite city',
  });
  const marketingOptInRegister = register('marketingOptIn');
  const travelClass = watch('travelClass');
  const favoriteCityId = watch('favoriteCityId');
  const marketingOptIn = watch('marketingOptIn');

  return (
    <Form onSubmit={handleSubmit(console.log)} noValidate>
      <Field.Root name="fullName" invalid={Boolean(errors.fullName)}>
        <Field.Label>Full name</Field.Label>
        <Input
          placeholder="Jane Doe"
          {...register('fullName', {
            validate: (value) => value.trim().length >= 2 || 'Full name must have at least 2 characters',
          })}
        />
        <Field.Error match={Boolean(errors.fullName)}>{errors.fullName?.message}</Field.Error>
      </Field.Root>

      <Field.Root name="email" invalid={Boolean(errors.email)}>
        <Field.Label>Email</Field.Label>
        <Input
          placeholder="jane@company.com"
          {...register('email', {
            validate: (value) => {
              const trimmed = value.trim();
              if (!trimmed) return 'Email is required';
              return /^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(trimmed) || 'Enter a valid email address';
            },
          })}
        />
        <Field.Error match={Boolean(errors.email)}>{errors.email?.message}</Field.Error>
      </Field.Root>

      <Field.Root name="travelClass" invalid={Boolean(errors.travelClass)}>
        <Field.Label>Travel class</Field.Label>
        <RadioGroup
          name={travelClassRegister.name}
          onBlur={travelClassRegister.onBlur}
          value={travelClass}
          onValueChange={(nextValue) => {
            travelClassRegister.onChange({
              target: {name: travelClassRegister.name, value: String(nextValue ?? '')},
              type: 'change',
            });
          }}
          inputRef={travelClassRegister.ref}
        >
          <Field.Item>
            <Field.Label inline>
              <Radio value="economy" />
              Economy
            </Field.Label>
          </Field.Item>
          <Field.Item>
            <Field.Label inline>
              <Radio value="business" />
              Business
            </Field.Label>
          </Field.Item>
        </RadioGroup>
        <Field.Error match={Boolean(errors.travelClass)}>{errors.travelClass?.message}</Field.Error>
      </Field.Root>

      <SingleComboboxField
        name="favoriteCityId"
        value={favoriteCityId || null}
        onChange={(nextValue) => setValue('favoriteCityId', nextValue ?? '', {shouldValidate: true})}
        registerField={favoriteCityRegister}
        invalid={Boolean(errors.favoriteCityId)}
        errorMessage={errors.favoriteCityId?.message}
        testIdPrefix="register-example"
      />

      <Field.Root name="marketingOptIn">
        <Field.Label inline>
          <Checkbox
            checked={Boolean(marketingOptIn)}
            name={marketingOptInRegister.name}
            inputRef={marketingOptInRegister.ref}
            onBlur={marketingOptInRegister.onBlur}
            onCheckedChange={(checked) =>
              marketingOptInRegister.onChange({
                target: {name: marketingOptInRegister.name, type: 'checkbox', checked: Boolean(checked)},
                type: 'change',
              })
            }
          />
          Receive product updates
        </Field.Label>
      </Field.Root>
    </Form>
  );
}
`.trim();

const controllerFieldsSource = `
import {Controller, useForm} from 'react-hook-form';
import {Form} from '@/components/baseui-components/Form';

type ControllerValues = {
  acceptTerms: boolean;
  updatesEnabled: boolean;
  travelClass: string;
  interests: string[];
  brightness: number;
  cityId: string | null;
  favoriteCityId: string | null;
  visitedCityIds: string[];
};

function ControllerOnlyExample() {
  const {control, handleSubmit, formState: {errors}} = useForm<ControllerValues>({
    defaultValues: {
      acceptTerms: false,
      updatesEnabled: false,
      travelClass: '',
      interests: [],
      brightness: 25,
      cityId: null,
      favoriteCityId: null,
      visitedCityIds: [],
    },
  });

  return (
    <Form onSubmit={handleSubmit(console.log)} noValidate>
      <Controller
        name="acceptTerms"
        control={control}
        rules={{validate: (value) => value || 'You must accept terms'}}
        render={({field, fieldState}) => (
          <Field.Root name="acceptTerms" invalid={Boolean(fieldState.error)}>
            <Field.Label inline>
              <Checkbox
                name={field.name}
                checked={field.value}
                inputRef={field.ref}
                onBlur={field.onBlur}
                onCheckedChange={(checked) => field.onChange(Boolean(checked))}
              />
              I accept terms and conditions
            </Field.Label>
            <Field.Error>{fieldState.error?.message}</Field.Error>
          </Field.Root>
        )}
      />

      <Controller
        name="updatesEnabled"
        control={control}
        rules={{validate: (value) => value || 'Enable updates'}}
        render={({field, fieldState}) => (
          <Field.Root name="updatesEnabled" invalid={Boolean(fieldState.error)}>
            <Field.Label inline>
              <Switch
                name={field.name}
                checked={field.value}
                inputRef={field.ref}
                onBlur={field.onBlur}
                onCheckedChange={(checked) => field.onChange(Boolean(checked))}
              />
              Receive updates
            </Field.Label>
            <Field.Error match={Boolean(fieldState.error)}>{fieldState.error?.message}</Field.Error>
          </Field.Root>
        )}
      />

      <Controller
        name="travelClass"
        control={control}
        rules={{validate: (value) => Boolean(value) || 'Select travel class'}}
        render={({field, fieldState}) => (
          <Field.Root name="travelClass" invalid={Boolean(fieldState.error)}>
            <Field.Label>Travel class</Field.Label>
            <RadioGroup
              name={field.name}
              value={field.value}
              onValueChange={field.onChange}
              onBlur={field.onBlur}
              inputRef={field.ref}
            >
              <Field.Item>
                <Field.Label inline>
                  <Radio value="economy" />
                  Economy
                </Field.Label>
              </Field.Item>
              <Field.Item>
                <Field.Label inline>
                  <Radio value="business" />
                  Business
                </Field.Label>
              </Field.Item>
            </RadioGroup>
            <Field.Error match={Boolean(fieldState.error)}>{fieldState.error?.message}</Field.Error>
          </Field.Root>
        )}
      />

      <Controller
        name="interests"
        control={control}
        rules={{validate: (value) => value.length > 0 || 'Select at least one interest'}}
        render={({field, fieldState}) => (
          <Field.Root name="interests" invalid={Boolean(fieldState.error)}>
            <Field.Label>Interests</Field.Label>
            <CheckboxGroup value={field.value} onValueChange={(nextValue) => field.onChange(nextValue ?? [])}>
              <Field.Item>
                <Field.Label inline>
                  <Checkbox value="design" />
                  Design
                </Field.Label>
              </Field.Item>
              <Field.Item>
                <Field.Label inline>
                  <Checkbox value="engineering" />
                  Engineering
                </Field.Label>
              </Field.Item>
            </CheckboxGroup>
            <Field.Error match={Boolean(fieldState.error)}>{fieldState.error?.message}</Field.Error>
          </Field.Root>
        )}
      />

      <Controller
        name="brightness"
        control={control}
        rules={{validate: (value) => value >= 10 || 'Brightness must be >= 10'}}
        render={({field, fieldState}) => (
          <Field.Root name="brightness" invalid={Boolean(fieldState.error)}>
            <Field.Label>Brightness</Field.Label>
            <Slider.Root
              value={field.value}
              min={0}
              max={100}
              onValueChange={(nextValue) => field.onChange(Array.isArray(nextValue) ? nextValue[0] : nextValue)}
            >
              <Slider.Control>
                <Slider.Track>
                  <Slider.Indicator />
                  <Slider.Thumb inputRef={field.ref} onBlur={field.onBlur} />
                </Slider.Track>
              </Slider.Control>
              <Slider.Value />
            </Slider.Root>
            <Field.Error match={Boolean(fieldState.error)}>{fieldState.error?.message}</Field.Error>
          </Field.Root>
        )}
      />

      <Controller
        name="cityId"
        control={control}
        rules={{validate: (value) => Boolean(value) || 'Select city is required'}}
        render={({field, fieldState}) => (
          <SelectField
            name="cityId"
            value={field.value}
            onChange={field.onChange}
            inputRef={field.ref}
            onBlur={field.onBlur}
            invalid={Boolean(fieldState.error)}
            errorMessage={fieldState.error?.message}
            testIdPrefix="controller-example"
          />
        )}
      />

      <Controller
        name="favoriteCityId"
        control={control}
        rules={{validate: (value) => Boolean(value) || 'Favorite city is required'}}
        render={({field, fieldState}) => (
          <SingleComboboxField
            name="favoriteCityId"
            value={field.value}
            onChange={field.onChange}
            controlRef={field.ref}
            onBlur={field.onBlur}
            invalid={Boolean(fieldState.error)}
            errorMessage={fieldState.error?.message}
            testIdPrefix="controller-example"
          />
        )}
      />

      <Controller
        name="visitedCityIds"
        control={control}
        rules={{validate: (value) => value.length > 0 || 'Select at least one visited city'}}
        render={({field, fieldState}) => (
          <MultiComboboxField
            name="visitedCityIds"
            value={field.value}
            onChange={field.onChange}
            controlRef={field.ref}
            onBlur={field.onBlur}
            invalid={Boolean(fieldState.error)}
            errorMessage={fieldState.error?.message}
            testIdPrefix="controller-example"
          />
        )}
      />
    </Form>
  );
}
`.trim();

const generalValidationCasesSource = `
import {Controller, useForm} from 'react-hook-form';
import {Form} from '@/components/baseui-components/Form';

type GeneralValues = {
  fullName: string;
  email: string;
  updatesEnabled: boolean;
  bio: string;
  favoriteCityId: string | null;
  brightness: number;
};

function ConditionalValidationExample() {
  const {register, control, handleSubmit, getValues, formState: {errors}} = useForm<GeneralValues>({
    defaultValues: {fullName: '', email: '', updatesEnabled: false, bio: '', favoriteCityId: null, brightness: 30},
  });

  return (
    <Form onSubmit={handleSubmit(console.log)} noValidate>
      <Field.Root name="fullName" invalid={Boolean(errors.fullName)}>
        <Field.Label>Full name</Field.Label>
        <Input
          {...register('fullName', {
            validate: (value) => value.trim().length >= 2 || 'Name is too short',
          })}
        />
        <Field.Error match={Boolean(errors.fullName)} />
      </Field.Root>

      <Field.Root name="email" invalid={Boolean(errors.email)}>
        <Field.Label>Email</Field.Label>
        <Input
          {...register('email', {
            validate: (value) => {
              const trimmed = value.trim();
              if (!trimmed) return 'Email is required';
              return /^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(trimmed) || 'Invalid email format';
            },
          })}
        />
        <Field.Error match={Boolean(errors.email)} />
      </Field.Root>

      <Controller
        name="updatesEnabled"
        control={control}
        render={({field}) => (
          <Field.Root name="updatesEnabled">
            <Field.Label inline>
              <Switch checked={field.value} onCheckedChange={(checked) => field.onChange(Boolean(checked))} />
              Enable updates (bio becomes required)
            </Field.Label>
          </Field.Root>
        )}
      />

      <Field.Root name="bio" invalid={Boolean(errors.bio)}>
        <Field.Label>Bio</Field.Label>
        <TextArea
          {...register('bio', {
            validate: (value) => {
              const trimmed = value.trim();
              if (!getValues('updatesEnabled')) return true;
              if (!trimmed) return 'Bio is required when updates are enabled';
              return trimmed.length >= 20 || 'Bio must have at least 20 characters';
            },
          })}
        />
        <Field.Error>{errors.bio?.message}</Field.Error>
      </Field.Root>

      <Controller
        name="favoriteCityId"
        control={control}
        rules={{validate: (value) => Boolean(value) || 'Pick a favorite city'}}
        render={({field, fieldState}) => (
          <SingleComboboxField
            name="favoriteCityId"
            value={field.value}
            onChange={field.onChange}
            controlRef={field.ref}
            onBlur={field.onBlur}
            touched={fieldState.isTouched}
            touchedTestId="general-source-favorite-city-touched"
            invalid={Boolean(fieldState.error)}
            errorMessage={fieldState.error?.message}
            testIdPrefix="general-source"
          />
        )}
      />

      <Controller
        name="brightness"
        control={control}
        rules={{validate: (value) => value >= 20 || 'Brightness must be at least 20'}}
        render={({field, fieldState}) => (
          <Field.Root name="brightness" invalid={Boolean(fieldState.error)}>
            <Field.Label>Brightness</Field.Label>
            <Slider.Root
              value={field.value}
              min={0}
              max={100}
              onValueChange={(nextValue) => field.onChange(Array.isArray(nextValue) ? nextValue[0] : nextValue)}
            >
              <Slider.Control>
                <Slider.Track>
                  <Slider.Indicator />
                  <Slider.Thumb inputRef={field.ref} onBlur={field.onBlur} />
                </Slider.Track>
              </Slider.Control>
              <Slider.Value />
            </Slider.Root>
            <Field.Error>{fieldState.error?.message}</Field.Error>
          </Field.Root>
        )}
      />
    </Form>
  );
}
`.trim();

export const RegisterFields: Story = {
    render: () => <RegisterFieldsExample />,
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement);

        await step("Tracks touched state for register fields", async () => {
            await expect(await canvas.findByTestId("register-full-name-touched")).toHaveTextContent("false");
            await expect(await canvas.findByTestId("register-email-touched")).toHaveTextContent("false");

            await userEvent.click(await canvas.findByTestId("register-email-input"));
            await userEvent.tab();

            await waitFor(() => {
                expect(canvas.getByTestId("register-email-touched")).toHaveTextContent("true");
            });
        });

        await step("Shows register validation messages", async () => {
            await userEvent.click(await canvas.findByTestId("register-submit"));
            await expect(await canvas.findByTestId("register-full-name-error")).toHaveTextContent(
                "Full name must have at least 2 characters",
            );
            await expect(await canvas.findByTestId("register-email-error")).toHaveTextContent("Email is required");
            await expect(await canvas.findByTestId("register-travel-class-error")).toHaveTextContent(
                "Select travel class",
            );
            await expect(canvas.getByText("Pick a favorite city")).toBeVisible();
        });

        await step("Validates invalid email and then submits", async () => {
            const fullNameInput = await canvas.findByTestId("register-full-name-input");
            const emailInput = await canvas.findByTestId("register-email-input");
            const noteTextarea = await canvas.findByTestId("register-note");

            await userEvent.clear(fullNameInput);
            await userEvent.type(fullNameInput, "Ja");
            await userEvent.clear(emailInput);
            await userEvent.type(emailInput, "invalid-email");
            await expect(emailInput).toHaveValue("invalid-email");
            await userEvent.click(await canvas.findByTestId("register-submit"));

            await waitFor(() => {
                expect(canvas.getByTestId("register-email-error")).toHaveTextContent("Enter a valid email address");
            });

            await userEvent.clear(noteTextarea);
            await userEvent.type(noteTextarea, "short note");
            await userEvent.tab();
            await waitFor(() => {
                expect(canvas.getByTestId("register-note-error")).toHaveTextContent(
                    "Note must have at least 15 characters",
                );
            });
            await userEvent.clear(emailInput);
            await userEvent.type(emailInput, "jane@example.com");
            await userEvent.clear(noteTextarea);
            await userEvent.type(noteTextarea, "This note is definitely long enough.");
            await userEvent.tab();
            await waitFor(() => {
                expect(canvas.getByTestId("register-email-error")).not.toHaveTextContent("Enter a valid email address");
                expect(canvas.getByTestId("register-note-error")).not.toHaveTextContent(
                    "Note must have at least 15 characters",
                );
            });

            await userEvent.click(await canvas.findByTestId("register-set-values"));
            await waitFor(() => {
                expect(canvas.getByTestId("register-combobox-single-control")).toHaveValue("Berlin");
            });
            await userEvent.clear(fullNameInput);
            await userEvent.type(fullNameInput, "Ja");
            await userEvent.clear(emailInput);
            await userEvent.type(emailInput, "jane@example.com");
            await userEvent.click(await canvas.findByTestId("register-submit"));

            const output = await canvas.findByTestId("register-output");
            await waitFor(() => {
                expect(output).not.toHaveTextContent("null");
            });
            await expect(output).toHaveTextContent('"fullName": "Ja"');
            await expect(output).toHaveTextContent('"email": "jane@example.com"');
            await expect(output).toHaveTextContent('"travelClass": "business"');
            await expect(output).toHaveTextContent('"favoriteCityId": "3"');
        });

        await step("Supports set and reset", async () => {
            await userEvent.click(await canvas.findByTestId("register-set-values"));
            await expect(await canvas.findByTestId("register-full-name-input")).toHaveValue("Preset User");
            await expect(await canvas.findByTestId("register-combobox-single-control")).toHaveValue("Berlin");
            await userEvent.click(await canvas.findByTestId("register-submit"));
            await expect(await canvas.findByTestId("register-output")).toHaveTextContent('"marketingOptIn": true');

            await userEvent.click(await canvas.findByTestId("register-reset"));
            await expect(await canvas.findByTestId("register-full-name-input")).toHaveValue("");
            await expect(await canvas.findByTestId("register-email-input")).toHaveValue("");
            await expect(await canvas.findByTestId("register-combobox-single-control")).toHaveValue("");
        });
    },
    ...withSource(registerFieldsSource),
};

export const ControllerFields: Story = {
    render: () => <ControllerFieldsExample />,
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement);

        await step("Shows controller validation messages", async () => {
            await userEvent.click(await canvas.findByTestId("controller-submit"));
            await expect(canvas.getByText("You must accept terms")).toBeVisible();
            await expect(canvas.getByText("Enable updates")).toBeVisible();
            await expect(canvas.getByText("Select travel class")).toBeVisible();
            await expect(canvas.getByText("Select city is required")).toBeVisible();
        });

        await step("Tracks touched state via onBlur wiring", async () => {
            await expect(await canvas.findByTestId("controller-city-touched")).toHaveTextContent("false");
            await expect(await canvas.findByTestId("controller-favorite-city-touched")).toHaveTextContent("false");

            await userEvent.click(await canvas.findByTestId("controller-select-trigger"));
            await userEvent.tab();
            await waitFor(() => {
                expect(canvas.getByTestId("controller-city-touched")).toHaveTextContent("true");
            });

            await userEvent.click(await canvas.findByTestId("controller-combobox-single-trigger"));
            await userEvent.tab();
            await waitFor(() => {
                expect(canvas.getByTestId("controller-favorite-city-touched")).toHaveTextContent("true");
            });
        });

        await step("Fills controller fields and submits", async () => {
            await userEvent.click(await canvas.findByTestId("controller-accept-terms"));
            await userEvent.click(await canvas.findByTestId("controller-updates-enabled"));
            await userEvent.click(await canvas.findByTestId("controller-travel-class-business"));
            await userEvent.click(await canvas.findByTestId("controller-interest-engineering"));
            await userEvent.click(await canvas.findByTestId("controller-set-values"));
            await waitFor(() => {
                expect(canvas.getByTestId("controller-combobox-single-control")).toHaveValue("Berlin");
            });

            await userEvent.click(await canvas.findByTestId("controller-submit"));

            const output = await canvas.findByTestId("controller-output");
            await waitFor(() => {
                expect(output).not.toHaveTextContent("null");
            });
            await expect(output).toHaveTextContent('"travelClass": "business"');
            await expect(output).toHaveTextContent('"cityId": "4"');
            await expect(output).toHaveTextContent('"favoriteCityId": "3"');
            await expect(output).toHaveTextContent('"visitedCityIds": [');
        });

        await step("setValue updates controller-mapped UI", async () => {
            await userEvent.click(await canvas.findByTestId("controller-set-values"));
            await expect(await canvas.findByTestId("controller-combobox-single-control")).toHaveValue("Berlin");
        });
    },
    ...withSource(controllerFieldsSource),
};

export const GeneralValidationCases: Story = {
    render: () => <GeneralFormExamples />,
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement);

        await step("Tracks touched state for controlled combobox", async () => {
            await expect(await canvas.findByTestId("general-favorite-city-touched")).toHaveTextContent("false");
            await userEvent.click(await canvas.findByTestId("general-combobox-single-trigger"));
            await userEvent.tab();
            await waitFor(() => {
                expect(canvas.getByTestId("general-favorite-city-touched")).toHaveTextContent("true");
            });
        });

        await step("Runs conditional validation", async () => {
            await userEvent.click(await canvas.findByTestId("general-updates-enabled"));
            await userEvent.click(await canvas.findByTestId("general-validate"));
            await expect(await canvas.findByTestId("general-bio-error")).toHaveTextContent(
                "Bio is required when updates are enabled",
            );
        });

        await step("Set values and submit successfully", async () => {
            await userEvent.click(await canvas.findByTestId("general-set-values"));
            await userEvent.click(await canvas.findByTestId("general-submit"));

            const output = await canvas.findByTestId("general-output");
            await waitFor(() => {
                expect(output).not.toHaveTextContent("null");
            });
            await expect(output).toHaveTextContent('"fullName": "Preset General"');
            await expect(output).toHaveTextContent('"favoriteCityId": "2"');
            await expect(output).toHaveTextContent('"brightness": 55');
        });

        await step("Reset clears values", async () => {
            await userEvent.click(await canvas.findByTestId("general-reset"));
            await expect(await canvas.findByTestId("general-full-name")).toHaveValue("");
            await expect(await canvas.findByTestId("general-email")).toHaveValue("");
            await expect(await canvas.findByTestId("general-bio")).toHaveValue("");
        });
    },
    ...withSource(generalValidationCasesSource),
};
