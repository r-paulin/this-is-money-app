import * as React from "react";

import {expect, userEvent, waitFor, within} from "storybook/test";
import type {Meta, StoryObj} from "@storybook/react-webpack5";
import {revalidateLogic, useForm} from "@tanstack/react-form";

import {Checkbox} from "@/components/baseui-components/CheckBox";
import {CheckboxGroup} from "@/components/baseui-components/CheckboxGroup";
import {Combobox} from "@/components/baseui-components/Combobox";
import {Field} from "@/components/baseui-components/Field";
import {Form} from "@/components/baseui-components/Form";
import {Input} from "@/components/baseui-components/Input";
import {Radio} from "@/components/baseui-components/RadioGroup/Radio";
import {RadioGroup} from "@/components/baseui-components/RadioGroup/RadioGroup";
import {Select} from "@/components/baseui-components/Select";
import {Slider} from "@/components/baseui-components/Slider";
import {Switch} from "@/components/baseui-components/Switch";
import {TextArea} from "@/components/baseui-components/TextArea";

const meta = {
    component: Form,
    title: "BaseUI Playground/Form Integration of TanStack Form",
    tags: ["experimental", "BaseUI", "autodocs"],
    parameters: {
        docs: {
            subtitle: "TanStack Form examples showing field-level and form-level validation integration.",
        },
    },
} satisfies Meta<typeof Form>;

export default meta;

type Story = StoryObj<typeof meta>;
const withSource = (code: string) => ({
    parameters: {
        docs: {
            source: {
                code,
            },
        },
    },
});

type CityOption = {
    label: string;
    value: string;
    secondary: string;
};

type SelectOption = {
    label: string;
    value: string | null;
};

const CITY_OPTIONS: CityOption[] = [
    {label: "Tallinn", value: "1", secondary: "Estonia"},
    {label: "Stockholm", value: "2", secondary: "Sweden"},
    {label: "Berlin", value: "3", secondary: "Germany"},
    {label: "Warsaw", value: "4", secondary: "Poland"},
    {label: "Paris", value: "5", secondary: "France"},
];

const SELECT_OPTIONS: SelectOption[] = [{label: "Choose a city", value: null}, ...CITY_OPTIONS];
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Type-safe interface for TanStack Form field props we use
// This matches the shape of field passed to form.Field render prop
interface TanStackField<TValue> {
    name: string;
    state: {
        value: TValue;
        meta: {
            errors: Array<string | undefined>;
            isTouched: boolean;
            isDirty: boolean;
            isValid: boolean;
        };
    };
    handleChange: (value: TValue | ((prev: TValue) => TValue)) => void;
    handleBlur: () => void;
}

function findCityByValue(value: string | null): CityOption | null {
    if (!value) {
        return null;
    }

    return CITY_OPTIONS.find((option) => option.value === value) ?? null;
}

function findCitiesByValues(values: string[]): CityOption[] {
    return values
        .map((value) => CITY_OPTIONS.find((option) => option.value === value))
        .filter((option): option is CityOption => Boolean(option));
}

function safeStringify(value: unknown): string {
    const visited = new WeakSet<object>();

    return JSON.stringify(
        value,
        (_key, currentValue) => {
            if (typeof currentValue === "function") {
                return `[Function ${currentValue.name || "anonymous"}]`;
            }

            if (typeof Element !== "undefined" && currentValue instanceof Element) {
                return `[${currentValue.tagName}]`;
            }

            if (currentValue && typeof currentValue === "object") {
                if (visited.has(currentValue)) {
                    return "[Circular]";
                }
                visited.add(currentValue);
            }

            return currentValue;
        },
        2,
    );
}

function ValuePanel({title, value, testId}: {title: string; value: unknown; testId: string}) {
    return (
        <div className="rounded-md border border-solid border-neutral-secondary bg-special-nulled p-3">
            <p className="bolt-font-body-s-accent mb-2">{title}</p>
            <pre className="bolt-font-body-s-regular overflow-auto text-secondary" data-testid={testId}>
                {safeStringify(value)}
            </pre>
        </div>
    );
}

function SelectField({field, testIdPrefix}: {field: TanStackField<string | null>; testIdPrefix: string}) {
    const fieldState = field.state;
    const isInvalid = !fieldState.meta.isValid;

    return (
        <Field.Root
            name={field.name}
            invalid={isInvalid}
            touched={fieldState.meta.isTouched}
            dirty={fieldState.meta.isDirty}
        >
            <Field.Label>Select city</Field.Label>
            <Select.Root
                items={SELECT_OPTIONS}
                value={fieldState.value}
                onValueChange={field.handleChange}
                name={field.name}
            >
                <Select.Trigger data-testid={`${testIdPrefix}-select-trigger`} onBlur={field.handleBlur}>
                    <Select.Value />
                    <Select.Icon />
                </Select.Trigger>
                <Select.Portal>
                    <Select.Positioner>
                        <Select.Popup>
                            <Select.List data-testid={`${testIdPrefix}-select-list`}>
                                {SELECT_OPTIONS.map((option) => (
                                    <Select.Item
                                        key={option.value ?? "placeholder"}
                                        value={option.value}
                                        data-testid={`${testIdPrefix}-select-item-${option.value ?? "null"}`}
                                    >
                                        <Select.ItemText>{option.label}</Select.ItemText>
                                        <Select.ItemIndicator />
                                    </Select.Item>
                                ))}
                            </Select.List>
                        </Select.Popup>
                    </Select.Positioner>
                </Select.Portal>
            </Select.Root>
            <Field.Error match={isInvalid}>{fieldState.meta.errors.join(", ")}</Field.Error>
            <Field.Description>TanStack Form field with primitive value mapping</Field.Description>
        </Field.Root>
    );
}

function SingleComboboxField({field, testIdPrefix}: {field: TanStackField<string | null>; testIdPrefix: string}) {
    const fieldState = field.state;
    const isInvalid = !fieldState.meta.isValid;
    const selectedOption = React.useMemo(() => findCityByValue(fieldState.value), [fieldState.value]);

    const handleValueChange = React.useCallback(
        (nextValue: CityOption | CityOption[] | null) => {
            const nextOption = Array.isArray(nextValue) ? nextValue[0] : nextValue;
            field.handleChange(nextOption?.value ?? null);
        },
        [field],
    );

    return (
        <Field.Root
            name={field.name}
            invalid={isInvalid}
            touched={fieldState.meta.isTouched}
            dirty={fieldState.meta.isDirty}
        >
            <Field.Label>Favorite city</Field.Label>
            <Combobox.Root items={CITY_OPTIONS} value={selectedOption} onValueChange={handleValueChange}>
                <Combobox.Input data-testid={`${testIdPrefix}-combobox-single-trigger`} placeholder="Pick a city">
                    <Combobox.ValueArea>
                        <Combobox.Control
                            data-testid={`${testIdPrefix}-combobox-single-control`}
                            onBlur={field.handleBlur}
                        />
                    </Combobox.ValueArea>
                    <Combobox.Controls>
                        <Combobox.Clear data-testid={`${testIdPrefix}-combobox-single-clear`} />
                        <Combobox.Trigger>
                            <Combobox.Icon />
                        </Combobox.Trigger>
                    </Combobox.Controls>
                </Combobox.Input>
                <Combobox.Portal>
                    <Combobox.Positioner>
                        <Combobox.Popup>
                            <Combobox.Empty>No options</Combobox.Empty>
                            <Combobox.List data-testid={`${testIdPrefix}-combobox-single-list`}>
                                {(item: CityOption) => (
                                    <Combobox.Item
                                        key={item.value}
                                        value={item}
                                        data-testid={`${testIdPrefix}-combobox-single-item-${item.value}`}
                                    >
                                        <div className="flex min-w-0 flex-1 flex-col">
                                            <span>{item.label}</span>
                                            <span className="bolt-font-body-s-regular text-secondary">
                                                {item.secondary}
                                            </span>
                                        </div>
                                        <Combobox.ItemIndicator />
                                    </Combobox.Item>
                                )}
                            </Combobox.List>
                        </Combobox.Popup>
                    </Combobox.Positioner>
                </Combobox.Portal>
            </Combobox.Root>
            <Field.Error match={isInvalid}>{fieldState.meta.errors.join(", ")}</Field.Error>
            <Field.Description>TanStack Form field with option object to primitive mapping</Field.Description>
        </Field.Root>
    );
}

function MultiComboboxField({field, testIdPrefix}: {field: TanStackField<string[]>; testIdPrefix: string}) {
    const chipsRef = React.useRef<HTMLDivElement | null>(null);
    const fieldState = field.state;
    const isInvalid = !fieldState.meta.isValid;
    const selectedOptions = React.useMemo(() => findCitiesByValues(fieldState.value), [fieldState.value]);

    const handleValueChange = React.useCallback(
        (nextValue: CityOption | CityOption[] | null) => {
            if (!Array.isArray(nextValue)) {
                field.handleChange([]);
                return;
            }

            field.handleChange(nextValue.map((item) => item.value));
        },
        [field],
    );

    return (
        <Field.Root
            name={field.name}
            invalid={isInvalid}
            touched={fieldState.meta.isTouched}
            dirty={fieldState.meta.isDirty}
        >
            <Field.Label>Visited cities</Field.Label>
            <Combobox.Root items={CITY_OPTIONS} value={selectedOptions} onValueChange={handleValueChange} multiple>
                <Combobox.Chips ref={chipsRef}>
                    <Combobox.Input
                        data-testid={`${testIdPrefix}-combobox-multi-trigger`}
                        placeholder="Pick one or many"
                    >
                        <Combobox.ValueArea>
                            <Combobox.Value>
                                {(currentValue) => {
                                    const selected = Array.isArray(currentValue) ? currentValue : [];
                                    return (
                                        <>
                                            {selected.map((option) => (
                                                <Combobox.Chip key={option.value}>
                                                    <span className="max-w-[9rem] truncate">{option.label}</span>
                                                    <Combobox.ChipRemove
                                                        aria-label={`Remove ${option.label}`}
                                                        data-testid={`${testIdPrefix}-combobox-multi-remove-${option.value}`}
                                                    />
                                                </Combobox.Chip>
                                            ))}
                                            <Combobox.Control
                                                placeholder="Pick one or many"
                                                data-testid={`${testIdPrefix}-combobox-multi-input`}
                                                onBlur={field.handleBlur}
                                            />
                                        </>
                                    );
                                }}
                            </Combobox.Value>
                        </Combobox.ValueArea>
                        <Combobox.Controls>
                            <Combobox.Clear data-testid={`${testIdPrefix}-combobox-multi-clear`} />
                            <Combobox.Trigger>
                                <Combobox.Icon />
                            </Combobox.Trigger>
                        </Combobox.Controls>
                    </Combobox.Input>
                </Combobox.Chips>

                <Combobox.Portal>
                    <Combobox.Positioner anchor={chipsRef}>
                        <Combobox.Popup>
                            <Combobox.Empty>No options</Combobox.Empty>
                            <Combobox.List data-testid={`${testIdPrefix}-combobox-multi-list`}>
                                {(item: CityOption) => (
                                    <Combobox.Item
                                        key={item.value}
                                        value={item}
                                        data-testid={`${testIdPrefix}-combobox-multi-item-${item.value}`}
                                    >
                                        <span>{item.label}</span>
                                        <Combobox.ItemIndicator />
                                    </Combobox.Item>
                                )}
                            </Combobox.List>
                        </Combobox.Popup>
                    </Combobox.Positioner>
                </Combobox.Portal>
            </Combobox.Root>
            <Field.Error match={isInvalid}>{fieldState.meta.errors.join(", ")}</Field.Error>
            <Field.Description>TanStack Form field with option array to primitive array mapping</Field.Description>
        </Field.Root>
    );
}

type BasicFieldValues = {
    fullName: string;
    email: string;
    note: string;
    travelClass: string;
    favoriteCityId: string | null;
    marketingOptIn: boolean;
};

const BASIC_DEFAULTS: BasicFieldValues = {
    fullName: "",
    email: "",
    note: "",
    travelClass: "",
    favoriteCityId: null,
    marketingOptIn: false,
};

function BasicFieldsExample() {
    const [submitted, setSubmitted] = React.useState<BasicFieldValues | null>(null);
    const form = useForm({
        defaultValues: BASIC_DEFAULTS,
        onSubmit: async ({value}) => {
            setSubmitted(value);
        },
    });

    return (
        <div className="mx-auto max-w-2xl space-y-5">
            <Form
                onSubmit={(event) => {
                    event.preventDefault();
                    form.handleSubmit();
                }}
                noValidate
                className="space-y-4"
            >
                <form.Field
                    name="fullName"
                    validators={{
                        onChange: ({value}) =>
                            value.trim().length >= 2 ? undefined : "Full name must have at least 2 characters",
                    }}
                >
                    {(field) => {
                        const fieldState = field.state;
                        const isInvalid = !fieldState.meta.isValid;
                        return (
                            <Field.Root
                                name={field.name}
                                invalid={isInvalid}
                                touched={fieldState.meta.isTouched}
                                dirty={fieldState.meta.isDirty}
                            >
                                <Field.Label>Full name</Field.Label>
                                <Input
                                    data-testid="tanstack-full-name"
                                    placeholder="Jane Doe"
                                    onValueChange={field.handleChange}
                                    onBlur={field.handleBlur}
                                >
                                    <Input.Control data-testid="tanstack-full-name-input" value={fieldState.value} />
                                </Input>
                                <div data-testid="tanstack-full-name-error">
                                    <Field.Error match={isInvalid}>{fieldState.meta.errors.join(", ")}</Field.Error>
                                </div>
                                <span className="sr-only" data-testid="tanstack-full-name-touched">
                                    {String(fieldState.meta.isTouched)}
                                </span>
                                <Field.Description>TanStack Form field with onChange validation</Field.Description>
                            </Field.Root>
                        );
                    }}
                </form.Field>

                <form.Field
                    name="email"
                    validators={{
                        onChange: ({value}) => {
                            const trimmed = value.trim();
                            if (!trimmed) {
                                return "Email is required";
                            }
                            return EMAIL_REGEX.test(trimmed) ? undefined : "Enter a valid email address";
                        },
                    }}
                >
                    {(field) => {
                        const fieldState = field.state;
                        const isInvalid = !fieldState.meta.isValid;
                        return (
                            <Field.Root
                                name={field.name}
                                invalid={isInvalid}
                                touched={fieldState.meta.isTouched}
                                dirty={fieldState.meta.isDirty}
                            >
                                <Field.Label>Email</Field.Label>
                                <Input
                                    data-testid="tanstack-email"
                                    placeholder="jane@company.com"
                                    onValueChange={field.handleChange}
                                    onBlur={field.handleBlur}
                                >
                                    <Input.Control data-testid="tanstack-email-input" value={fieldState.value} />
                                </Input>
                                <div data-testid="tanstack-email-error">
                                    <Field.Error match={isInvalid}>{fieldState.meta.errors.join(", ")}</Field.Error>
                                </div>
                                <span className="sr-only" data-testid="tanstack-email-touched">
                                    {String(fieldState.meta.isTouched)}
                                </span>
                                <Field.Description>Required field with email format validation</Field.Description>
                            </Field.Root>
                        );
                    }}
                </form.Field>

                <form.Field
                    name="note"
                    validators={{
                        onChange: ({value}) => {
                            const trimmed = value.trim();
                            if (!trimmed) {
                                return undefined;
                            }
                            return trimmed.length >= 15 ? undefined : "Note must have at least 15 characters";
                        },
                    }}
                >
                    {(field) => {
                        const fieldState = field.state;
                        const isInvalid = !fieldState.meta.isValid;
                        return (
                            <Field.Root
                                name={field.name}
                                invalid={isInvalid}
                                touched={fieldState.meta.isTouched}
                                dirty={fieldState.meta.isDirty}
                            >
                                <Field.Label>Internal note</Field.Label>
                                <TextArea
                                    data-testid="tanstack-note"
                                    rows={3}
                                    placeholder="At least 15 characters if provided"
                                    value={fieldState.value}
                                    onBlur={field.handleBlur}
                                    onValueChange={field.handleChange}
                                />
                                <div data-testid="tanstack-note-error">
                                    <Field.Error match={isInvalid}>{fieldState.meta.errors.join(", ")}</Field.Error>
                                </div>
                                <Field.Description>Optional field with conditional min length</Field.Description>
                            </Field.Root>
                        );
                    }}
                </form.Field>

                <form.Field
                    name="travelClass"
                    validators={{
                        onChange: ({value}) => (value ? undefined : "Select travel class"),
                    }}
                >
                    {(field) => {
                        const fieldState = field.state;
                        const isInvalid = !fieldState.meta.isValid;
                        return (
                            <Field.Root
                                name={field.name}
                                invalid={isInvalid}
                                touched={fieldState.meta.isTouched}
                                dirty={fieldState.meta.isDirty}
                            >
                                <Field.Label>Travel class</Field.Label>
                                <RadioGroup
                                    name={field.name}
                                    value={fieldState.value}
                                    onValueChange={(nextValue) => field.handleChange(String(nextValue ?? ""))}
                                    onBlur={field.handleBlur}
                                >
                                    <Field.Item>
                                        <Field.Label inline>
                                            <Radio value="economy" data-testid="tanstack-travel-class-economy" />
                                            Economy
                                        </Field.Label>
                                    </Field.Item>
                                    <Field.Item>
                                        <Field.Label inline>
                                            <Radio value="business" data-testid="tanstack-travel-class-business" />
                                            Business
                                        </Field.Label>
                                    </Field.Item>
                                </RadioGroup>
                                <div data-testid="tanstack-travel-class-error">
                                    <Field.Error match={isInvalid}>{fieldState.meta.errors.join(", ")}</Field.Error>
                                </div>
                                <Field.Description>RadioGroup with TanStack Form field integration</Field.Description>
                            </Field.Root>
                        );
                    }}
                </form.Field>

                <form.Field
                    name="favoriteCityId"
                    validators={{
                        onChange: ({value}) => (value ? undefined : "Pick a favorite city"),
                    }}
                >
                    {(field) => <SingleComboboxField field={field} testIdPrefix="tanstack" />}
                </form.Field>

                <form.Field name="marketingOptIn">
                    {(field) => {
                        const fieldState = field.state;
                        const isInvalid = !fieldState.meta.isValid;
                        return (
                            <Field.Root
                                name={field.name}
                                invalid={isInvalid}
                                touched={fieldState.meta.isTouched}
                                dirty={fieldState.meta.isDirty}
                            >
                                <Field.Label inline>
                                    <Checkbox
                                        data-testid="tanstack-marketing-opt-in"
                                        checked={Boolean(fieldState.value)}
                                        name={field.name}
                                        onBlur={field.handleBlur}
                                        onCheckedChange={field.handleChange}
                                    />
                                    Receive product updates
                                </Field.Label>
                                <Field.Description>Checkbox with TanStack Form field integration</Field.Description>
                            </Field.Root>
                        );
                    }}
                </form.Field>

                <div className="flex flex-wrap gap-3">
                    <button
                        type="submit"
                        data-testid="tanstack-submit"
                        className={
                            "rounded-md border border-solid border-action-primary px-4 py-2 text-sm text-action-primary"
                        }
                    >
                        Submit form
                    </button>
                    <button
                        type="button"
                        data-testid="tanstack-reset"
                        onClick={() => {
                            form.reset();
                            setSubmitted(null);
                        }}
                        className="rounded-md border border-solid border-neutral-secondary px-4 py-2 text-sm"
                    >
                        Reset
                    </button>
                    <button
                        type="button"
                        data-testid="tanstack-set-values"
                        onClick={() => {
                            form.setFieldValue("fullName", "Preset User");
                            form.setFieldValue("email", "preset@example.com");
                            form.setFieldValue("note", "Preset note with enough text");
                            form.setFieldValue("travelClass", "business");
                            form.setFieldValue("favoriteCityId", "3");
                            form.setFieldValue("marketingOptIn", true);
                        }}
                        className="rounded-md border border-solid border-neutral-secondary px-4 py-2 text-sm"
                    >
                        Set values
                    </button>
                </div>
            </Form>

            <ValuePanel title="Form payload" value={submitted} testId="tanstack-output" />
        </div>
    );
}

type AdvancedFieldValues = {
    acceptTerms: boolean;
    updatesEnabled: boolean;
    travelClass: string;
    interests: string[];
    cityId: string | null;
    favoriteCityId: string | null;
    visitedCityIds: string[];
    brightness: number;
};

const ADVANCED_DEFAULTS: AdvancedFieldValues = {
    acceptTerms: false,
    updatesEnabled: false,
    travelClass: "",
    interests: [],
    cityId: null,
    favoriteCityId: null,
    visitedCityIds: [],
    brightness: 25,
};

function AdvancedFieldsExample() {
    const [submitted, setSubmitted] = React.useState<AdvancedFieldValues | null>(null);
    const form = useForm({
        defaultValues: ADVANCED_DEFAULTS,
        onSubmit: async ({value}) => {
            setSubmitted(value);
        },
    });

    return (
        <div className="mx-auto max-w-4xl space-y-6">
            <Form
                onSubmit={(event) => {
                    event.preventDefault();
                    form.handleSubmit();
                }}
                noValidate
                className="space-y-4"
            >
                <form.Field
                    name="acceptTerms"
                    validators={{
                        onChange: ({value}) => (value === true ? undefined : "You must accept terms"),
                    }}
                >
                    {(field) => {
                        const fieldState = field.state;
                        const isInvalid = !fieldState.meta.isValid;
                        return (
                            <Field.Root
                                name={field.name}
                                invalid={isInvalid}
                                touched={fieldState.meta.isTouched}
                                dirty={fieldState.meta.isDirty}
                            >
                                <Field.Label inline>
                                    <Checkbox
                                        name={field.name}
                                        checked={fieldState.value}
                                        onBlur={field.handleBlur}
                                        onCheckedChange={field.handleChange}
                                        data-testid="tanstack-accept-terms"
                                    />
                                    I accept terms and conditions
                                </Field.Label>
                                <Field.Error match={isInvalid}>{fieldState.meta.errors.join(", ")}</Field.Error>
                                <Field.Description>Boolean field with validation</Field.Description>
                            </Field.Root>
                        );
                    }}
                </form.Field>

                <form.Field
                    name="updatesEnabled"
                    validators={{
                        onChange: ({value}) => (value === true ? undefined : "Enable updates"),
                    }}
                >
                    {(field) => {
                        const fieldState = field.state;
                        const isInvalid = !fieldState.meta.isValid;
                        return (
                            <Field.Root
                                name={field.name}
                                invalid={isInvalid}
                                touched={fieldState.meta.isTouched}
                                dirty={fieldState.meta.isDirty}
                            >
                                <Field.Label inline>
                                    <Switch
                                        name={field.name}
                                        checked={fieldState.value}
                                        onBlur={field.handleBlur}
                                        onCheckedChange={field.handleChange}
                                        data-testid="tanstack-updates-enabled"
                                    />
                                    Receive updates
                                </Field.Label>
                                <Field.Error match={isInvalid}>{fieldState.meta.errors.join(", ")}</Field.Error>
                                <Field.Description>Switch with checked/onCheckedChange mapping</Field.Description>
                            </Field.Root>
                        );
                    }}
                </form.Field>

                <form.Field
                    name="travelClass"
                    validators={{
                        onChange: ({value}) => (value ? undefined : "Select travel class"),
                    }}
                >
                    {(field) => {
                        const fieldState = field.state;
                        const isInvalid = !fieldState.meta.isValid;
                        return (
                            <Field.Root
                                name={field.name}
                                invalid={isInvalid}
                                touched={fieldState.meta.isTouched}
                                dirty={fieldState.meta.isDirty}
                            >
                                <Field.Label>Travel class</Field.Label>
                                <RadioGroup
                                    name={field.name}
                                    value={fieldState.value}
                                    onValueChange={(nextValue) => field.handleChange(String(nextValue ?? ""))}
                                    onBlur={field.handleBlur}
                                >
                                    <Field.Item>
                                        <Field.Label inline>
                                            <Radio value="economy" data-testid="tanstack-adv-travel-class-economy" />
                                            Economy
                                        </Field.Label>
                                    </Field.Item>
                                    <Field.Item>
                                        <Field.Label inline>
                                            <Radio value="business" data-testid="tanstack-adv-travel-class-business" />
                                            Business
                                        </Field.Label>
                                    </Field.Item>
                                </RadioGroup>
                                <Field.Error match={isInvalid}>{fieldState.meta.errors.join(", ")}</Field.Error>
                                <Field.Description>RadioGroup value + onValueChange mapping</Field.Description>
                            </Field.Root>
                        );
                    }}
                </form.Field>

                <form.Field
                    name="interests"
                    validators={{
                        onChange: ({value}) => (value.length > 0 ? undefined : "Select at least one interest"),
                    }}
                >
                    {(field) => {
                        const fieldState = field.state;
                        const isInvalid = !fieldState.meta.isValid;
                        return (
                            <Field.Root
                                name={field.name}
                                invalid={isInvalid}
                                touched={fieldState.meta.isTouched}
                                dirty={fieldState.meta.isDirty}
                            >
                                <Field.Label>Interests</Field.Label>
                                <CheckboxGroup
                                    value={fieldState.value}
                                    onValueChange={(nextValue) => field.handleChange(nextValue ?? [])}
                                >
                                    <Field.Item>
                                        <Field.Label inline>
                                            <Checkbox value="design" data-testid="tanstack-adv-interest-design" />
                                            Design
                                        </Field.Label>
                                    </Field.Item>
                                    <Field.Item>
                                        <Field.Label inline>
                                            <Checkbox
                                                value="engineering"
                                                data-testid="tanstack-adv-interest-engineering"
                                            />
                                            Engineering
                                        </Field.Label>
                                    </Field.Item>
                                </CheckboxGroup>
                                <Field.Error match={isInvalid}>{fieldState.meta.errors.join(", ")}</Field.Error>
                                <Field.Description>CheckboxGroup string array mapping</Field.Description>
                            </Field.Root>
                        );
                    }}
                </form.Field>

                <form.Field
                    name="brightness"
                    validators={{
                        onChange: ({value}) => (value >= 10 ? undefined : "Brightness must be >= 10"),
                    }}
                >
                    {(field) => {
                        const fieldState = field.state;
                        const isInvalid = !fieldState.meta.isValid;
                        return (
                            <Field.Root
                                name={field.name}
                                invalid={isInvalid}
                                touched={fieldState.meta.isTouched}
                                dirty={fieldState.meta.isDirty}
                            >
                                <Field.Label>Brightness</Field.Label>
                                <Slider.Root
                                    value={fieldState.value}
                                    min={0}
                                    max={100}
                                    onValueChange={field.handleChange}
                                >
                                    <Slider.Control>
                                        <Slider.Track>
                                            <Slider.Indicator />
                                            <Slider.Thumb />
                                        </Slider.Track>
                                    </Slider.Control>
                                    <Slider.Value />
                                </Slider.Root>
                                <Field.Error match={isInvalid}>{fieldState.meta.errors.join(", ")}</Field.Error>
                                <Field.Description>Slider numeric mapping</Field.Description>
                            </Field.Root>
                        );
                    }}
                </form.Field>

                <form.Field
                    name="cityId"
                    validators={{
                        onChange: ({value}) => (value ? undefined : "Select city is required"),
                    }}
                >
                    {(field) => <SelectField field={field} testIdPrefix="tanstack-adv" />}
                </form.Field>

                <form.Field
                    name="favoriteCityId"
                    validators={{
                        onChange: ({value}) => (value ? undefined : "Favorite city is required"),
                    }}
                >
                    {(field) => <SingleComboboxField field={field} testIdPrefix="tanstack-adv" />}
                </form.Field>

                <form.Field
                    name="visitedCityIds"
                    validators={{
                        onChange: ({value}) => (value.length > 0 ? undefined : "Select at least one visited city"),
                    }}
                >
                    {(field) => <MultiComboboxField field={field} testIdPrefix="tanstack-adv" />}
                </form.Field>

                <div className="flex flex-wrap gap-3">
                    <button
                        type="submit"
                        data-testid="tanstack-adv-submit"
                        className={
                            "rounded-md border border-solid border-action-primary px-4 py-2 text-sm text-action-primary"
                        }
                    >
                        Submit advanced form
                    </button>
                    <button
                        type="button"
                        data-testid="tanstack-adv-reset"
                        onClick={() => {
                            form.reset();
                            setSubmitted(null);
                        }}
                        className="rounded-md border border-solid border-neutral-secondary px-4 py-2 text-sm"
                    >
                        Reset
                    </button>
                    <button
                        type="button"
                        data-testid="tanstack-adv-set-values"
                        onClick={() => {
                            form.setFieldValue("acceptTerms", true);
                            form.setFieldValue("updatesEnabled", true);
                            form.setFieldValue("travelClass", "business");
                            form.setFieldValue("interests", ["design", "engineering"]);
                            form.setFieldValue("cityId", "4");
                            form.setFieldValue("favoriteCityId", "3");
                            form.setFieldValue("visitedCityIds", ["2", "5"]);
                            form.setFieldValue("brightness", 72);
                        }}
                        className="rounded-md border border-solid border-neutral-secondary px-4 py-2 text-sm"
                    >
                        Set values
                    </button>
                </div>
            </Form>

            <ValuePanel title="Advanced payload" value={submitted} testId="tanstack-adv-output" />
        </div>
    );
}

const basicFieldsSource = `
import {useForm} from '@tanstack/react-form';
import {Form} from '@/components/baseui-components/Form';

type BasicFieldValues = {
  fullName: string;
  email: string;
  note: string;
  travelClass: string;
  favoriteCityId: string | null;
  marketingOptIn: boolean;
};

function BasicFieldsExample() {
  const form = useForm<BasicFieldValues>({
    defaultValues: {
      fullName: '',
      email: '',
      note: '',
      travelClass: '',
      favoriteCityId: null,
      marketingOptIn: false,
    },
    onSubmit: async ({value}) => {
      console.log(value);
    },
  });

  return (
    <form onSubmit={(event) => { event.preventDefault(); form.handleSubmit(); }}>
      <form.Field
        name="fullName"
        validators={{
          onChange: ({value}) =>
            value.trim().length >= 2 ? undefined : 'Full name must have at least 2 characters',
        }}
      >
        {(field) => {
          const fieldState = field.state;
          const isInvalid = !fieldState.meta.isValid;
          return (
            <Field.Root name={field.name} invalid={isInvalid}>
              <Field.Label>Full name</Field.Label>
              <Input>
                <Input.Control
                  value={fieldState.value}
                  onBlur={field.handleBlur}
                  onValueChange={field.handleChange}
                />
              </Input>
              <Field.Error match={isInvalid}>{fieldState.meta.errors.join(', ')}</Field.Error>
            </Field.Root>
          );
        }}
      </form.Field>

      <form.Field
        name="travelClass"
        validators={{
          onChange: ({value}) => (value ? undefined : 'Select travel class'),
        }}
      >
        {(field) => {
          const fieldState = field.state;
          return (
            <Field.Root name={field.name} invalid={!fieldState.meta.isValid}>
              <Field.Label>Travel class</Field.Label>
              <RadioGroup
                name={field.name}
                value={fieldState.value}
                onValueChange={(nextValue) => field.handleChange(String(nextValue ?? ''))}
                onBlur={field.handleBlur}
              >
                <Field.Item>
                  <Field.Label inline>
                    <Radio value="economy" />
                    Economy
                  </Field.Label>
                </Field.Item>
                <Field.Item>
                  <Field.Label inline>
                    <Radio value="business" />
                    Business
                  </Field.Label>
                </Field.Item>
              </RadioGroup>
              <Field.Error>{fieldState.meta.errors.join(', ')}</Field.Error>
            </Field.Root>
          );
        }}
      </form.Field>

      <form.Field name="marketingOptIn">
        {(field) => {
          const fieldState = field.state;
          return (
            <Field.Root name={field.name}>
              <Field.Label inline>
                <Checkbox
                  checked={Boolean(fieldState.value)}
                  name={field.name}
                  onBlur={field.handleBlur}
                  onCheckedChange={field.handleChange}
                />
                Receive product updates
              </Field.Label>
            </Field.Root>
          );
        }}
      </form.Field>

      <button type="submit">Submit</button>
    </form>
  );
}
`.trim();

const advancedFieldsSource = `
import {useForm} from '@tanstack/react-form';
import {Form} from '@/components/baseui-components/Form';

type AdvancedFieldValues = {
  acceptTerms: boolean;
  updatesEnabled: boolean;
  travelClass: string;
  interests: string[];
  cityId: string | null;
  favoriteCityId: string | null;
  visitedCityIds: string[];
  brightness: number;
};

function AdvancedFieldsExample() {
  const form = useForm<AdvancedFieldValues>({
    defaultValues: {
      acceptTerms: false,
      updatesEnabled: false,
      travelClass: '',
      interests: [],
      cityId: null,
      favoriteCityId: null,
      visitedCityIds: [],
      brightness: 25,
    },
    onSubmit: async ({value}) => {
      console.log(value);
    },
  });

  return (
    <form onSubmit={(event) => { event.preventDefault(); form.handleSubmit(); }}>
      <form.Field
        name="acceptTerms"
        validators={{
          onChange: ({value}) => (value ? undefined : 'You must accept terms'),
        }}
      >
        {(field) => {
          const fieldState = field.state;
          const isInvalid = !fieldState.meta.isValid;
          return (
            <Field.Root name={field.name} invalid={isInvalid}>
              <Field.Label inline>
                <Checkbox
                  name={field.name}
                  checked={fieldState.value}
                  onBlur={field.handleBlur}
                  onCheckedChange={field.handleChange}
                />
                I accept terms and conditions
              </Field.Label>
              <Field.Error match={isInvalid}>{fieldState.meta.errors.join(', ')}</Field.Error>
            </Field.Root>
          );
        }}
      </form.Field>

      <form.Field
        name="interests"
        validators={{
          onChange: ({value}) =>
            value.length > 0 ? undefined : 'Select at least one interest',
        }}
      >
        {(field) => {
          const fieldState = field.state;
          const isInvalid = !fieldState.meta.isValid;
          return (
            <Field.Root name={field.name} invalid={isInvalid}>
              <Field.Label>Interests</Field.Label>
              <CheckboxGroup
                value={fieldState.value}
                onValueChange={(nextValue) => field.handleChange(nextValue ?? [])}
              >
                <Field.Item>
                  <Field.Label inline>
                    <Checkbox value="design" />
                    Design
                  </Field.Label>
                </Field.Item>
                <Field.Item>
                  <Field.Label inline>
                    <Checkbox value="engineering" />
                    Engineering
                  </Field.Label>
                </Field.Item>
              </CheckboxGroup>
              <Field.Error match={isInvalid}>{fieldState.meta.errors.join(', ')}</Field.Error>
            </Field.Root>
          );
        }}
      </form.Field>

      <form.Field
        name="brightness"
        validators={{
          onChange: ({value}) => (value >= 10 ? undefined : 'Brightness must be >= 10'),
        }}
      >
        {(field) => {
          const fieldState = field.state;
          const isInvalid = !fieldState.meta.isValid;
          return (
            <Field.Root name={field.name} invalid={isInvalid}>
              <Field.Label>Brightness</Field.Label>
              <Slider.Root
                value={fieldState.value}
                min={0}
                max={100}
                onValueChange={field.handleChange}
              >
                <Slider.Control>
                  <Slider.Track>
                    <Slider.Indicator />
                    <Slider.Thumb />
                  </Slider.Track>
                </Slider.Control>
                <Slider.Value />
              </Slider.Root>
              <Field.Error match={isInvalid}>{fieldState.meta.errors.join(', ')}</Field.Error>
            </Field.Root>
          );
        }}
      </form.Field>

      <button type="submit">Submit</button>
    </form>
  );
}
`.trim();

type FormLevelValues = {
    fullName: string;
    email: string;
    age: number;
    acceptTerms: boolean;
};

const FORM_LEVEL_DEFAULTS: FormLevelValues = {
    fullName: "",
    email: "",
    age: 0,
    acceptTerms: false,
};

function FormLevelValidationExample() {
    const [submitted, setSubmitted] = React.useState<FormLevelValues | null>(null);
    const form = useForm({
        defaultValues: FORM_LEVEL_DEFAULTS,
        validationLogic: revalidateLogic({
            mode: "submit",
            modeAfterSubmission: "change",
        }),
        validators: {
            onDynamic: ({value: formValues}) => {
                const errors: Record<string, string> = {};

                if (!formValues.fullName) {
                    errors.fullName = "Full name is required.";
                } else if (formValues.fullName.length < 3) {
                    errors.fullName = "At least 3 characters.";
                }

                if (!formValues.email) {
                    errors.email = "Email is required.";
                } else if (!EMAIL_REGEX.test(formValues.email)) {
                    errors.email = "Invalid email address.";
                }

                if (formValues.age <= 0) {
                    errors.age = "Age must be greater than 0.";
                } else if (formValues.age < 18) {
                    errors.age = "You must be at least 18 years old.";
                }

                if (!formValues.acceptTerms) {
                    errors.acceptTerms = "You must accept the terms.";
                }

                return Object.keys(errors).length > 0 ? {form: errors, fields: errors} : undefined;
            },
        },
        onSubmit: async ({value}) => {
            setSubmitted(value);
        },
    });

    return (
        <div className="mx-auto max-w-2xl space-y-5">
            <Form
                onSubmit={(event) => {
                    event.preventDefault();
                    form.handleSubmit();
                }}
                noValidate
                className="space-y-4"
            >
                <form.Field name="fullName">
                    {(field) => {
                        const fieldState = field.state;
                        const isInvalid = !fieldState.meta.isValid;
                        return (
                            <Field.Root
                                name={field.name}
                                invalid={isInvalid}
                                touched={fieldState.meta.isTouched}
                                dirty={fieldState.meta.isDirty}
                            >
                                <Field.Label>Full name</Field.Label>
                                <Input
                                    data-testid="form-level-full-name"
                                    placeholder="Jane Doe"
                                    onValueChange={field.handleChange}
                                    onBlur={field.handleBlur}
                                >
                                    <Input.Control data-testid="form-level-full-name-input" value={fieldState.value} />
                                </Input>
                                <div data-testid="form-level-full-name-error">
                                    <Field.Error match={isInvalid}>{fieldState.meta.errors.join(", ")}</Field.Error>
                                </div>
                                <Field.Description>Form-level validation with revalidateLogic</Field.Description>
                            </Field.Root>
                        );
                    }}
                </form.Field>

                <form.Field name="email">
                    {(field) => {
                        const fieldState = field.state;
                        const isInvalid = !fieldState.meta.isValid;
                        return (
                            <Field.Root
                                name={field.name}
                                invalid={isInvalid}
                                touched={fieldState.meta.isTouched}
                                dirty={fieldState.meta.isDirty}
                            >
                                <Field.Label>Email</Field.Label>
                                <Input
                                    data-testid="form-level-email"
                                    placeholder="jane@company.com"
                                    onValueChange={field.handleChange}
                                    onBlur={field.handleBlur}
                                >
                                    <Input.Control data-testid="form-level-email-input" value={fieldState.value} />
                                </Input>
                                <div data-testid="form-level-email-error">
                                    <Field.Error match={isInvalid}>{fieldState.meta.errors.join(", ")}</Field.Error>
                                </div>
                                <Field.Description>Validated on submit, then on change</Field.Description>
                            </Field.Root>
                        );
                    }}
                </form.Field>

                <form.Field name="age">
                    {(field) => {
                        const fieldState = field.state;
                        const isInvalid = !fieldState.meta.isValid;
                        return (
                            <Field.Root
                                name={field.name}
                                invalid={isInvalid}
                                touched={fieldState.meta.isTouched}
                                dirty={fieldState.meta.isDirty}
                            >
                                <Field.Label>Age</Field.Label>
                                <Input
                                    data-testid="form-level-age"
                                    placeholder="18"
                                    type="number"
                                    onValueChange={(value) => field.handleChange(Number(value))}
                                    onBlur={field.handleBlur}
                                >
                                    <Input.Control
                                        data-testid="form-level-age-input"
                                        value={String(fieldState.value)}
                                    />
                                </Input>
                                <div data-testid="form-level-age-error">
                                    <Field.Error match={isInvalid}>{fieldState.meta.errors.join(", ")}</Field.Error>
                                </div>
                                <Field.Description>Cross-field validation example</Field.Description>
                            </Field.Root>
                        );
                    }}
                </form.Field>

                <form.Field name="acceptTerms">
                    {(field) => {
                        const fieldState = field.state;
                        const isInvalid = !fieldState.meta.isValid;
                        return (
                            <Field.Root
                                name={field.name}
                                invalid={isInvalid}
                                touched={fieldState.meta.isTouched}
                                dirty={fieldState.meta.isDirty}
                            >
                                <Field.Label inline>
                                    <Checkbox
                                        data-testid="form-level-accept-terms"
                                        checked={Boolean(fieldState.value)}
                                        name={field.name}
                                        onBlur={field.handleBlur}
                                        onCheckedChange={field.handleChange}
                                    />
                                    I accept the terms and conditions
                                </Field.Label>
                                <div data-testid="form-level-accept-terms-error">
                                    <Field.Error match={isInvalid}>{fieldState.meta.errors.join(", ")}</Field.Error>
                                </div>
                                <Field.Description>All errors centralized in validators.onDynamic</Field.Description>
                            </Field.Root>
                        );
                    }}
                </form.Field>

                <div className="flex flex-wrap gap-3">
                    <button
                        type="submit"
                        data-testid="form-level-submit"
                        className={
                            "rounded-md border border-solid border-action-primary px-4 py-2 text-sm text-action-primary"
                        }
                    >
                        Submit form
                    </button>
                    <button
                        type="button"
                        data-testid="form-level-reset"
                        onClick={() => {
                            form.reset();
                            setSubmitted(null);
                        }}
                        className="rounded-md border border-solid border-neutral-secondary px-4 py-2 text-sm"
                    >
                        Reset
                    </button>
                    <button
                        type="button"
                        data-testid="form-level-set-values"
                        onClick={() => {
                            form.setFieldValue("fullName", "John Doe");
                            form.setFieldValue("email", "john@example.com");
                            form.setFieldValue("age", 25);
                            form.setFieldValue("acceptTerms", true);
                        }}
                        className="rounded-md border border-solid border-neutral-secondary px-4 py-2 text-sm"
                    >
                        Set valid values
                    </button>
                </div>
            </Form>

            <ValuePanel title="Form-level validation payload" value={submitted} testId="form-level-output" />
        </div>
    );
}

const formLevelValidationSource = `
import {useForm, revalidateLogic} from '@tanstack/react-form';
import {Form} from '@/components/baseui-components/Form';

type FormLevelValues = {
  fullName: string;
  email: string;
  age: number;
  acceptTerms: boolean;
};

function FormLevelValidationExample() {
  const form = useForm({
    defaultValues: {
      fullName: '',
      email: '',
      age: 0,
      acceptTerms: false,
    },
    validationLogic: revalidateLogic({
      mode: 'submit',
      modeAfterSubmission: 'change',
    }),
    validators: {
      onDynamic: ({value: formValues}) => {
        const errors: Record<string, string> = {};

        if (!formValues.fullName) {
          errors.fullName = 'Full name is required.';
        } else if (formValues.fullName.length < 3) {
          errors.fullName = 'At least 3 characters.';
        }

        if (!formValues.email) {
          errors.email = 'Email is required.';
        } else if (!EMAIL_REGEX.test(formValues.email)) {
          errors.email = 'Invalid email address.';
        }

        if (formValues.age <= 0) {
          errors.age = 'Age must be greater than 0.';
        } else if (formValues.age < 18) {
          errors.age = 'You must be at least 18 years old.';
        }

        if (!formValues.acceptTerms) {
          errors.acceptTerms = 'You must accept the terms.';
        }

        return Object.keys(errors).length > 0 ? {form: errors, fields: errors} : undefined;
      },
    },
    onSubmit: async ({value}) => {
      console.log(value);
    },
  });

  return (
    <Form onSubmit={(e) => { e.preventDefault(); form.handleSubmit(); }}>
      <form.Field name="fullName">
        {(field) => {
          const fieldState = field.state;
          const isInvalid = !fieldState.meta.isValid;
          return (
            <Field.Root name={field.name} invalid={isInvalid}>
              <Field.Label>Full name</Field.Label>
              <Input>
                <Input.Control
                  value={fieldState.value}
                  onBlur={field.handleBlur}
                  onValueChange={field.handleChange}
                />
              </Input>
              <Field.Error match={isInvalid}>{fieldState.meta.errors.join(', ')}</Field.Error>
            </Field.Root>
          );
        }}
      </form.Field>

      <form.Field name="email">
        {(field) => (
          <Field.Root name={field.name} invalid={!field.state.meta.isValid}>
            <Field.Label>Email</Field.Label>
            <Input onValueChange={field.handleChange} onBlur={field.handleBlur}>
              <Input.Control value={field.state.value} />
            </Input>
            <Field.Error>{field.state.meta.errors.join(', ')}</Field.Error>
          </Field.Root>
        )}
      </form.Field>

      <button type="submit">Submit</button>
    </Form>
  );
}
`.trim();

export const BasicFields: Story = {
    render: () => <BasicFieldsExample />,
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement);

        await step("Tracks touched state for fields", async () => {
            await expect(await canvas.findByTestId("tanstack-full-name-touched")).toHaveTextContent("false");
            await expect(await canvas.findByTestId("tanstack-email-touched")).toHaveTextContent("false");

            await userEvent.click(await canvas.findByTestId("tanstack-email-input"));
            await userEvent.tab();

            await waitFor(() => {
                expect(canvas.getByTestId("tanstack-email-touched")).toHaveTextContent("true");
            });
        });

        await step("Shows validation messages", async () => {
            await userEvent.click(await canvas.findByTestId("tanstack-submit"));
            await expect(await canvas.findByTestId("tanstack-full-name-error")).toHaveTextContent(
                "Full name must have at least 2 characters",
            );
            await expect(await canvas.findByTestId("tanstack-email-error")).toHaveTextContent("Email is required");
            await expect(await canvas.findByTestId("tanstack-travel-class-error")).toHaveTextContent(
                "Select travel class",
            );
            await expect(canvas.getByText("Pick a favorite city")).toBeVisible();
        });

        await step("Validates invalid email and then submits", async () => {
            const fullNameInput = await canvas.findByTestId("tanstack-full-name-input");
            const emailInput = await canvas.findByTestId("tanstack-email-input");
            const noteTextarea = await canvas.findByTestId("tanstack-note");

            await userEvent.clear(fullNameInput);
            await userEvent.type(fullNameInput, "Ja");
            await userEvent.clear(emailInput);
            await userEvent.type(emailInput, "invalid-email");
            await expect(emailInput).toHaveValue("invalid-email");
            await userEvent.tab();

            await waitFor(() => {
                expect(canvas.getByTestId("tanstack-email-error")).toHaveTextContent("Enter a valid email address");
            });

            await userEvent.clear(noteTextarea);
            await userEvent.type(noteTextarea, "short note");
            await userEvent.tab();
            await waitFor(() => {
                expect(canvas.getByTestId("tanstack-note-error")).toHaveTextContent(
                    "Note must have at least 15 characters",
                );
            });
            await userEvent.clear(emailInput);
            await userEvent.type(emailInput, "jane@example.com");
            await userEvent.clear(noteTextarea);
            await userEvent.type(noteTextarea, "This note is definitely long enough.");
            await userEvent.tab();
            await waitFor(() => {
                expect(canvas.getByTestId("tanstack-email-error")).not.toHaveTextContent("Enter a valid email address");
                expect(canvas.getByTestId("tanstack-note-error")).not.toHaveTextContent(
                    "Note must have at least 15 characters",
                );
            });

            await userEvent.click(await canvas.findByTestId("tanstack-set-values"));
            await waitFor(() => {
                expect(canvas.getByTestId("tanstack-combobox-single-control")).toHaveValue("Berlin");
            });
            await userEvent.clear(fullNameInput);
            await userEvent.type(fullNameInput, "Ja");
            await userEvent.clear(emailInput);
            await userEvent.type(emailInput, "jane@example.com");
            await userEvent.click(await canvas.findByTestId("tanstack-submit"));

            const output = await canvas.findByTestId("tanstack-output");
            await waitFor(() => {
                expect(output).not.toHaveTextContent("null");
            });
            await expect(output).toHaveTextContent('"fullName": "Ja"');
            await expect(output).toHaveTextContent('"email": "jane@example.com"');
            await expect(output).toHaveTextContent('"travelClass": "business"');
            await expect(output).toHaveTextContent('"favoriteCityId": "3"');
        });

        await step("Supports set and reset", async () => {
            await userEvent.click(await canvas.findByTestId("tanstack-set-values"));
            await expect(await canvas.findByTestId("tanstack-full-name-input")).toHaveValue("Preset User");
            await expect(await canvas.findByTestId("tanstack-combobox-single-control")).toHaveValue("Berlin");
            await userEvent.click(await canvas.findByTestId("tanstack-submit"));
            await expect(await canvas.findByTestId("tanstack-output")).toHaveTextContent('"marketingOptIn": true');

            await userEvent.click(await canvas.findByTestId("tanstack-reset"));
            await expect(await canvas.findByTestId("tanstack-full-name-input")).toHaveValue("");
            await expect(await canvas.findByTestId("tanstack-email-input")).toHaveValue("");
            await expect(await canvas.findByTestId("tanstack-combobox-single-control")).toHaveValue("");
        });
    },
    ...withSource(basicFieldsSource),
};

export const AdvancedFields: Story = {
    render: () => <AdvancedFieldsExample />,
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement);

        await step("Shows advanced validation messages", async () => {
            await userEvent.click(await canvas.findByTestId("tanstack-adv-submit"));
            await expect(canvas.getByText("You must accept terms")).toBeVisible();
            await expect(canvas.getByText("Enable updates")).toBeVisible();
            await expect(canvas.getByText("Select travel class")).toBeVisible();
            await expect(canvas.getByText("Select city is required")).toBeVisible();
        });

        await step("Fills advanced fields and submits", async () => {
            await userEvent.click(await canvas.findByTestId("tanstack-accept-terms"));
            await userEvent.click(await canvas.findByTestId("tanstack-updates-enabled"));
            await userEvent.click(await canvas.findByTestId("tanstack-adv-travel-class-business"));
            await userEvent.click(await canvas.findByTestId("tanstack-adv-interest-engineering"));
            await userEvent.click(await canvas.findByTestId("tanstack-adv-set-values"));
            await waitFor(() => {
                expect(canvas.getByTestId("tanstack-adv-combobox-single-control")).toHaveValue("Berlin");
            });

            await userEvent.click(await canvas.findByTestId("tanstack-adv-submit"));

            const output = await canvas.findByTestId("tanstack-adv-output");
            await waitFor(() => {
                expect(output).not.toHaveTextContent("null");
            });
            await expect(output).toHaveTextContent('"travelClass": "business"');
            await expect(output).toHaveTextContent('"cityId": "4"');
            await expect(output).toHaveTextContent('"favoriteCityId": "3"');
            await expect(output).toHaveTextContent('"visitedCityIds": [');
        });

        await step("setFieldValue updates UI", async () => {
            await userEvent.click(await canvas.findByTestId("tanstack-adv-set-values"));
            await expect(await canvas.findByTestId("tanstack-adv-combobox-single-control")).toHaveValue("Berlin");
        });
    },
    ...withSource(advancedFieldsSource),
};

export const FormLevelValidation: Story = {
    render: () => <FormLevelValidationExample />,
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement);

        await step("Shows all validation errors on submit", async () => {
            await userEvent.click(await canvas.findByTestId("form-level-submit"));

            await expect(await canvas.findByTestId("form-level-full-name-error")).toHaveTextContent(
                "Full name is required.",
            );
            await expect(await canvas.findByTestId("form-level-email-error")).toHaveTextContent("Email is required.");
            await expect(await canvas.findByTestId("form-level-age-error")).toHaveTextContent(
                "Age must be greater than 0.",
            );
            await expect(await canvas.findByTestId("form-level-accept-terms-error")).toHaveTextContent(
                "You must accept the terms.",
            );
        });

        await step("Validates on change after first submission", async () => {
            const fullNameInput = await canvas.findByTestId("form-level-full-name-input");

            await userEvent.clear(fullNameInput);
            await userEvent.type(fullNameInput, "Jo");

            await waitFor(() => {
                expect(canvas.getByTestId("form-level-full-name-error")).toHaveTextContent("At least 3 characters.");
            });

            await userEvent.type(fullNameInput, "hn Doe");

            await waitFor(() => {
                expect(canvas.getByTestId("form-level-full-name-error")).not.toHaveTextContent(
                    "At least 3 characters.",
                );
            });
        });

        await step("Validates email format and age constraints", async () => {
            const emailInput = await canvas.findByTestId("form-level-email-input");
            const ageInput = await canvas.findByTestId("form-level-age-input");

            await userEvent.clear(emailInput);
            await userEvent.type(emailInput, "invalid-email");

            await waitFor(() => {
                expect(canvas.getByTestId("form-level-email-error")).toHaveTextContent("Invalid email address.");
            });

            await userEvent.clear(ageInput);
            await userEvent.type(ageInput, "15");

            await waitFor(() => {
                expect(canvas.getByTestId("form-level-age-error")).toHaveTextContent(
                    "You must be at least 18 years old.",
                );
            });
        });

        await step("Successfully submits with valid values", async () => {
            await userEvent.click(await canvas.findByTestId("form-level-set-values"));

            await waitFor(() => {
                expect(canvas.getByTestId("form-level-full-name-input")).toHaveValue("John Doe");
            });

            await userEvent.click(await canvas.findByTestId("form-level-submit"));

            const output = await canvas.findByTestId("form-level-output");
            await waitFor(() => {
                expect(output).not.toHaveTextContent("null");
            });
            await expect(output).toHaveTextContent('"fullName": "John Doe"');
            await expect(output).toHaveTextContent('"email": "john@example.com"');
            await expect(output).toHaveTextContent('"age": 25');
            await expect(output).toHaveTextContent('"acceptTerms": true');
        });

        await step("Reset clears form", async () => {
            await userEvent.click(await canvas.findByTestId("form-level-reset"));
            await expect(await canvas.findByTestId("form-level-full-name-input")).toHaveValue("");
            await expect(await canvas.findByTestId("form-level-email-input")).toHaveValue("");
        });
    },
    ...withSource(formLevelValidationSource),
};
