import * as React from "react";

import {vi} from "vitest";
import type {Avatar} from "@base-ui/react";
import {render, screen} from "@testing-library/react";

import {IconView} from "../index";

vi.mock("@base-ui/react/avatar", () => {
    const resolveClassName = <State,>(
        className: string | ((state: State) => string | undefined) | undefined,
        state: State,
    ) => {
        return typeof className === "function" ? className(state) : className;
    };
    const rootState = {imageLoadingStatus: "loaded"} as Avatar.Root.State;
    const imageState = {imageLoadingStatus: "loaded"} as Avatar.Root.State;
    const fallbackState = {imageLoadingStatus: "loaded"} as Avatar.Root.State;

    const Root = React.forwardRef<HTMLSpanElement, Avatar.Root.Props>((props, ref) => {
        const {className, children, ...rest} = props;
        const resolvedClassName = resolveClassName(className, rootState);
        return (
            <span {...rest} ref={ref} className={resolvedClassName}>
                {children}
            </span>
        );
    });
    const Image = React.forwardRef<HTMLImageElement, Avatar.Image.Props>((props, ref) => {
        const {className, ...rest} = props;
        const resolvedClassName = resolveClassName(className, imageState);
        return <img {...rest} ref={ref} className={resolvedClassName} />;
    });
    const Fallback = React.forwardRef<HTMLSpanElement, Avatar.Fallback.Props>((props, ref) => {
        const {className, children, ...rest} = props;
        const resolvedClassName = resolveClassName(className, fallbackState);
        return (
            <span {...rest} ref={ref} className={resolvedClassName}>
                {children}
            </span>
        );
    });

    return {
        Avatar: {Root, Image, Fallback},
    };
});

describe("IconView (Base UI)", () => {
    it("renders root with default sizing", () => {
        render(
            <IconView.Root aria-label="Default icon">
                <IconView.Icon data-testid="icon-slot" icon={<svg />} />
            </IconView.Root>,
        );

        const root = screen.getByLabelText("Default icon");
        expect(root).toHaveClass("h-12", "w-12");
    });

    it("applies size classes from size prop", () => {
        render(
            <IconView.Root aria-label="Large icon" size="lg">
                <IconView.Icon data-testid="icon-slot" icon={<svg />} />
            </IconView.Root>,
        );

        const root = screen.getByLabelText("Large icon");
        expect(root).toHaveClass("h-14", "w-14");
    });

    it("applies shadow styles when shadow is true", () => {
        render(
            <IconView.Root aria-label="Shadow icon" shadow>
                <IconView.Icon data-testid="icon-slot" icon={<svg />} />
            </IconView.Root>,
        );

        const root = screen.getByLabelText("Shadow icon");
        expect(root).toHaveClass("shadow-[inset_0_0_8px_rgba(26,27,35,0.08)]");
    });

    it("renders fallback content when no image is provided", () => {
        render(
            <IconView.Root aria-label="Icon only">
                <IconView.Icon data-testid="icon-slot" icon={<svg />} />
            </IconView.Root>,
        );

        expect(screen.getByTestId("icon-slot")).toBeInTheDocument();
    });

    it("renders image with alt text", () => {
        render(
            <IconView.Root aria-label="Image root">
                <IconView.Image
                    alt="User avatar"
                    src="data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1 1'></svg>"
                />
            </IconView.Root>,
        );

        expect(screen.getByAltText(/user avatar/i)).toBeInTheDocument();
    });
});
