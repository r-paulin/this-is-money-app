import * as React from "react";

import type {IconViewSizeVariant} from "../iconView.types";

interface IconViewContextValue {
    size: IconViewSizeVariant;
}

const IconViewContext = React.createContext<IconViewContextValue | undefined>(undefined);

export function IconViewProvider({size, children}: {size: IconViewSizeVariant; children: React.ReactNode}) {
    const value = React.useMemo(() => ({size}), [size]);
    return <IconViewContext.Provider value={value}>{children}</IconViewContext.Provider>;
}

export function useIconViewContext() {
    const context = React.useContext(IconViewContext);
    if (!context) {
        throw new Error("IconView components must be used within an IconViewProvider");
    }
    return context;
}
