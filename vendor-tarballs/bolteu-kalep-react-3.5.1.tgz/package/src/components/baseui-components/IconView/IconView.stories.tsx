import * as React from "react";

import type {Meta, StoryObj} from "@storybook/react-webpack5";

import {Alert, Heart, RideStart} from "@bolteu/kalep-react-icons";

import type {IconViewSizeVariant} from "@/components/baseui-components/IconView/iconView.types";
import {Spinner} from "@/components/baseui-components/Spinner";

import DocumentationTemplate from "../docs/DocumentationTemplate.mdx";
import {IconView} from "./index";

const sampleImage = "https://picsum.photos/id/22/200";

const sizeVariants: {label: string; size: IconViewSizeVariant}[] = [
    {label: "2xs", size: "2xs"},
    {label: "xs", size: "xs"},
    {label: "sm", size: "sm"},
    {label: "md", size: "md"},
    {label: "lg", size: "lg"},
    {label: "xl", size: "xl"},
];

const meta = {
    // @ts-expect-error - some issue with compound components
    component: IconView,
    title: "BaseUI Playground/IconView",
    subcomponents: {
        "IconView.Root": IconView.Root,
        "IconView.Image": IconView.Image,
        "IconView.Fallback": IconView.Fallback,
        "IconView.Icon": IconView.Icon,
    },
    tags: ["experimental", "BaseUI", "autodocs"],
    parameters: {
        docs: {
            subtitle: "Base UI Avatar-based IconView.",
            page: DocumentationTemplate,
        },
    },
} satisfies Meta<typeof IconView>;

export default meta;

type Story = StoryObj<typeof IconView.Root>;

export const Default: Story = {
    render: (_args) => {
        return (
            <IconView.Root>
                <IconView.Icon icon={<RideStart className="text-action-primary" />} />
            </IconView.Root>
        );
    },
};

export const Variants: Story = {
    render: (_args) => {
        return (
            <div className="flex flex-col gap-6">
                <div className="flex flex-wrap items-end gap-4">
                    {sizeVariants.map((variant) => (
                        <div key={variant.label} className="flex flex-col items-center gap-2">
                            <IconView.Root size={variant.size}>
                                <IconView.Icon icon={<Heart className="text-danger-secondary" />} />
                            </IconView.Root>
                            <span className="text-xs">{variant.label}</span>
                        </div>
                    ))}
                </div>
                <div className="flex flex-wrap items-center gap-4">
                    <IconView.Root className="bg-layer-floor-1" shadow>
                        <IconView.Icon icon={<Heart className="text-action-primary" />} />
                    </IconView.Root>
                    <IconView.Root className="bg-neutral-secondary-hard">
                        <IconView.Icon icon={<Heart className="text-positive-primary" />} />
                    </IconView.Root>
                </div>
            </div>
        );
    },
};

export const States: Story = {
    render: (_args) => {
        return (
            <div className="flex flex-wrap items-center gap-6">
                <IconView.Root>
                    <IconView.Image src={sampleImage} alt="User avatar" />
                    <IconView.Fallback>FB</IconView.Fallback>
                </IconView.Root>
                <IconView.Root>
                    <IconView.Image src="data:image/svg+xml;utf8,invalid" alt="Broken avatar" />
                    <IconView.Icon icon={<Alert />} />
                </IconView.Root>
                <IconView.Root>
                    <IconView.Image src="data:image/svg+xml;utf8,invalid" alt="Loading avatar" />
                    <IconView.Fallback delay={300}>
                        <Spinner size="inherit" />
                    </IconView.Fallback>
                </IconView.Root>
            </div>
        );
    },
};

export const Accessibility: Story = {
    render: (_args) => {
        return (
            <div className="flex items-center gap-4">
                <IconView.Root>
                    <IconView.Icon icon={<Heart className="text-action-primary" />} />
                </IconView.Root>
                <IconView.Root>
                    <IconView.Image src={sampleImage} alt="User avatar" />
                </IconView.Root>
            </div>
        );
    },
};
