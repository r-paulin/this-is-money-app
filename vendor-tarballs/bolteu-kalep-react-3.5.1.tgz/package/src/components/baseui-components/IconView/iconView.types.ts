import type {Avatar as BaseUIAvatar} from "@base-ui/react";

export type IconViewSizeVariant = "2xs" | "xs" | "sm" | "md" | "lg" | "xl";

export interface IconViewExtendedState extends BaseUIAvatar.Root.State {
    size: IconViewSizeVariant;
}
