import * as React from "react";

import {Avatar as BaseUIAvatar} from "@base-ui/react/avatar";

import type {KalepIconElement} from "@bolteu/kalep-react-icons/dist/types";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

import {useIconViewContext} from "./context/IconViewContext";
import type {IconViewExtendedState} from "./iconView.types";
import {CLASSNAME_TW_ICON_SIZE} from "./shared-styles";

const CLASSNAME_TW_ICON_WRAPPER = "flex items-center justify-center text-primary";
const CLASSNAME_TW_ICON = "h-full w-full";

export interface IconViewIconProps extends Omit<BaseUIAvatar.Fallback.Props, "delay" | "className" | "children"> {
    className?: string | ((state: IconViewExtendedState) => string | undefined);
    icon: KalepIconElement;
}

export const IconViewIcon = React.forwardRef(function IconViewIcon(
    props: IconViewIconProps,
    forwardedRef: React.ForwardedRef<HTMLSpanElement>,
) {
    const {className, icon, ...rest} = props;
    const {size} = useIconViewContext();

    const getIconClassName = React.useCallback(
        (state: BaseUIAvatar.Root.State) =>
            cx(
                CLASSNAME_TW_ICON_WRAPPER,
                CLASSNAME_TW_ICON_SIZE[size],
                addConsumerClasses<IconViewExtendedState>({...state, size}, className),
            ),
        [className, size],
    );

    const content = React.useMemo(() => {
        const iconClassName = cx(CLASSNAME_TW_ICON, icon.props.className);
        const ariaHidden = icon.props["aria-hidden"];

        return React.cloneElement(icon, {
            className: iconClassName,
            "aria-hidden": ariaHidden ?? true,
        });
    }, [icon]);

    return (
        <BaseUIAvatar.Fallback {...rest} ref={forwardedRef} className={getIconClassName}>
            {content}
        </BaseUIAvatar.Fallback>
    );
});
