import * as React from "react";

import type {SelectContextType} from "@/components/baseui-components/Select/context/SelectContextProvider";
import {SelectContext} from "@/components/baseui-components/Select/context/SelectContextProvider";

interface SelectContextTypeReadonly extends SelectContextType {
    readonly customSelectProps: Readonly<SelectContextType["customSelectProps"]>;
}

function useSelectContext() {
    const context = React.useContext(SelectContext);
    if (!context) {
        throw new Error("Select components must be used within a SelectRoot component");
    }
    return context;
}

/**
 * A hook that allows selective access to the SelectContext using a selector function.
 *
 * @template T - The type of the value returned by the selector function
 * @param {function} select - A selector function that receives the SelectContext and returns a derived value
 * @returns {T} The value returned by the selector function
 *
 * @example
 * ```typescript
 * // Select the `size` property from the SelectContext
 * const size = useSelectContextSelector(context => context.customSelectProps.size);
 * ```
 */
export function useSelectContextSelector<T>(select: (context: SelectContextTypeReadonly) => T): T {
    const context = useSelectContext();

    return select(context);
}
