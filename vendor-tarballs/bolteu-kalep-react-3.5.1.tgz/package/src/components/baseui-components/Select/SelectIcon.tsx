import * as React from "react";

import {Select as BaseUISelect} from "@base-ui/react/select";

import ChevronDown from "@bolteu/kalep-react-icons/dist/ChevronDown";

import {useSelectContextSelector} from "@/components/baseui-components/Select/context/useSelectContext";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

export interface SelectIconState extends BaseUISelect.Icon.State {}

/**
 * ### Select.Icon
 * Decorative icon slot rendered at the trailing edge of the trigger. Renders a
 * `ChevronDown` icon by default, which rotates 180° when the dropdown is open.
 * Hidden entirely when the Select is in readonly mode.
 */
export const SelectIcon = React.forwardRef(function SelectIcon(
    props: BaseUISelect.Icon.Props,
    forwardedRef: React.ForwardedRef<HTMLSpanElement>,
) {
    const size = useSelectContextSelector((ctx) => ctx.customSelectProps.size);
    const disabled = useSelectContextSelector((ctx) => ctx.selectOwnProps.disabled);
    const readOnly = useSelectContextSelector((ctx) => ctx.selectOwnProps.readOnly);

    const {className, render, ...rest} = props;

    const IconRender = React.useCallback(
        (_props: BaseUISelect.Icon.Props, state: SelectIconState) => {
            return (
                <div
                    className={cx("flex flex-shrink-0 items-center justify-end", {
                        "gap-1": size !== "sm",
                    })}
                >
                    <ChevronDown
                        className={cx(`mx-1 flex-none text-primary transition-transform`, {
                            "rotate-180": state.open,
                            "text-tertiary": disabled,
                        })}
                        size={size === "sm" ? "md" : "lg"}
                        aria-hidden="true"
                    />
                </div>
            );
        },
        [size, disabled],
    );

    const getSelectIconClassNames = React.useCallback(
        (state: BaseUISelect.Icon.State) =>
            cx("w-full overflow-hidden text-ellipsis whitespace-nowrap", addConsumerClasses(state, className)),
        [className],
    );

    if (readOnly) {
        return null;
    }

    return (
        <BaseUISelect.Icon
            {...rest}
            ref={forwardedRef}
            className={getSelectIconClassNames}
            render={render ?? IconRender}
        />
    );
});
