import * as React from "react";

import {Select as BaseUISelect} from "@base-ui/react/select";

import {useSelectContextSelector} from "@/components/baseui-components/Select/context/useSelectContext";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Select.Value
 * Displays the currently selected value inside the trigger. Truncates to a single
 * line by default; wraps across multiple lines when `multiline` is enabled on
 * `Select.Root`.
 *
 * In readonly mode, the displayed value is selectable for copying. In readonly
 * multi-select mode, all selected values are displayed on a single horizontally
 * scrollable line, keeping the trigger height stable.
 */
export const SelectValue = React.forwardRef(function SelectValue(
    props: BaseUISelect.Value.Props,
    ref: React.ForwardedRef<HTMLSpanElement>,
) {
    const {className, ...rest} = props;

    const multiline = useSelectContextSelector((ctx) => ctx.customSelectProps.multiline);
    const multiple = useSelectContextSelector((ctx) => ctx.customSelectProps.multiple);
    const readOnly = useSelectContextSelector((ctx) => ctx.selectOwnProps.readOnly);

    const getSelectValueClassNames = React.useCallback(
        (state: BaseUISelect.Value.State) =>
            cx(
                "w-full",
                readOnly ? "select-text" : "overflow-hidden text-ellipsis",
                readOnly && multiple
                    ? `
                      overflow-x-auto whitespace-nowrap
                      [scrollbar-width:none]
                      [&::-webkit-scrollbar]:hidden
                    `
                    : multiline
                      ? "whitespace-normal"
                      : "truncate whitespace-nowrap",
                addConsumerClasses(state, className),
            ),
        [className, multiline, multiple, readOnly],
    );

    return (
        <BaseUISelect.Value
            {...rest}
            className={getSelectValueClassNames}
            ref={ref}
            tabIndex={readOnly ? 0 : undefined}
        />
    );
});
