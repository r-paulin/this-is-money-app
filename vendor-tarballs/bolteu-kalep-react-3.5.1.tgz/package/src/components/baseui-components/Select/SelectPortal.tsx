import {Select as BaseUISelect} from "@base-ui/react/select";

/**
 * ### Select.Portal
 * Renders the select popup content in a portal, outside the trigger's DOM subtree.
 */
export const SelectPortal = BaseUISelect.Portal;
