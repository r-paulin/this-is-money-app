import * as React from "react";

import {Select as BaseUISelect} from "@base-ui/react/select";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Select.Popup
 * Scrollable container rendered inside the positioner. Its width is anchored to
 * the trigger width via CSS custom properties, and its maximum height is capped
 * at `20rem` to keep long lists manageable.
 */
export const SelectPopup = React.forwardRef(function SelectPopup(
    props: BaseUISelect.Popup.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, ...rest} = props;

    const getSelectPopupClassNames = React.useCallback(
        (state: BaseUISelect.Popup.State) =>
            cx(
                `
                  max-h-80 min-w-[var(--anchor-width)] max-w-[var(--anchor-width)] overflow-hidden rounded-md
                  bg-layer-floor-3 shadow-md
                `,
                addConsumerClasses(state, className),
            ),
        [className],
    );
    return <BaseUISelect.Popup {...rest} className={getSelectPopupClassNames} ref={forwardedRef} />;
});
