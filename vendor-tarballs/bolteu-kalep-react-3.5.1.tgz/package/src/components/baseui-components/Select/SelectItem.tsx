import * as React from "react";

import {Select as BaseUISelect} from "@base-ui/react/select";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Select.Item
 * A single option row inside `Select.List`. Applies highlighted and disabled
 * visual states automatically. Compose with `Select.ItemText` and optionally
 * `Select.ItemIndicator` or `Select.CheckboxIndicator` for richer layouts.
 */
export const SelectItem = React.forwardRef(function SelectItem(
    props: BaseUISelect.Item.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, ...rest} = props;

    const getSelectItemClassNames = React.useCallback(
        (state: BaseUISelect.Item.State) =>
            cx(
                "flex min-h-12 w-full items-center gap-3 px-4 py-3 outline-none",
                {
                    "hover:bg-neutral-secondary focus:hover:bg-neutral-secondary": !state.disabled,
                    "bg-neutral-secondary": state.highlighted,
                    "cursor-not-allowed": state.disabled,
                },
                addConsumerClasses(state, className),
            ),
        [className],
    );
    return <BaseUISelect.Item {...rest} className={getSelectItemClassNames} ref={forwardedRef} />;
});
