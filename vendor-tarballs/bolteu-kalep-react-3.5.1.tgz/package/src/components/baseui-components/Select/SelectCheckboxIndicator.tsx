import * as React from "react";

import {Select as BaseUISelect} from "@base-ui/react/select";
import type {HTMLProps} from "@base-ui/react/utils/types";

import {
    CLASSNAME_TW_CHECKBOX_INDICATOR_BASE,
    getCheckboxIndicatorStateClass,
    renderCheckboxIndicatorDefault,
} from "@/components/baseui-components/utils/checkbox-indicator";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Select.CheckboxIndicator
 * Checkbox-style selection indicator for use inside `Select.Item` in
 * multi-select scenarios. Renders a filled square with a `Check` icon when
 * selected, and an outlined square when unselected. Stays mounted in the DOM
 * regardless of selection state to enable CSS transitions.
 */
export const SelectCheckboxIndicator = React.forwardRef(function SelectCheckboxIndicator(
    props: BaseUISelect.ItemIndicator.Props,
    ref: React.ForwardedRef<HTMLSpanElement>,
) {
    const {render, className, ...rest} = props;

    const getCheckboxIndicatorClassNames = React.useCallback(
        (state: BaseUISelect.ItemIndicator.State) =>
            cx(
                CLASSNAME_TW_CHECKBOX_INDICATOR_BASE,
                getCheckboxIndicatorStateClass(state.selected),
                addConsumerClasses(state, className),
            ),
        [className],
    );

    const defaultRender = React.useCallback(
        (renderProps: HTMLProps<HTMLSpanElement>, state: BaseUISelect.ItemIndicator.State) =>
            renderCheckboxIndicatorDefault(renderProps, state.selected),
        [],
    );

    return (
        <BaseUISelect.ItemIndicator
            keepMounted
            {...rest}
            ref={ref}
            className={getCheckboxIndicatorClassNames}
            render={render ?? defaultRender}
        />
    );
});
