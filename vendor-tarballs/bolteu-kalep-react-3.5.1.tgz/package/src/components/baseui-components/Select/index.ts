import {SelectCheckboxIndicator} from "./SelectCheckboxIndicator";
import {SelectIcon} from "./SelectIcon";
import {SelectItem} from "./SelectItem";
import {SelectItemIndicator} from "./SelectItemIndicator";
import {SelectItemText} from "./SelectItemText";
import {SelectList} from "./SelectList";
import {SelectPopup} from "./SelectPopup";
import {SelectPortal} from "./SelectPortal";
import {SelectPositioner} from "./SelectPositioner";
import {SelectRoot} from "./SelectRoot";
import {SelectTrigger} from "./SelectTrigger";
import {SelectValue} from "./SelectValue";

export const Select = {
    Root: SelectRoot,
    Trigger: SelectTrigger,
    Value: SelectValue,
    Icon: SelectIcon,
    Portal: SelectPortal,
    Positioner: SelectPositioner,
    Popup: SelectPopup,
    List: SelectList,
    Item: SelectItem,
    ItemIndicator: SelectItemIndicator,
    ItemText: SelectItemText,
    CheckboxIndicator: SelectCheckboxIndicator,
};

Object.assign(Select.Root, {displayName: "Select.Root"});
Select.Trigger.displayName = "Select.Trigger";
Select.Value.displayName = "Select.Value";
Select.Icon.displayName = "Select.Icon";
Select.Portal.displayName = "Select.Portal";
Select.Positioner.displayName = "Select.Positioner";
Select.Popup.displayName = "Select.Popup";
Select.List.displayName = "Select.List";
Select.Item.displayName = "Select.Item";
Select.ItemIndicator.displayName = "Select.ItemIndicator";
Select.ItemText.displayName = "Select.ItemText";
Select.CheckboxIndicator.displayName = "Select.CheckboxIndicator";

export {useSelectContextSelector} from "./context/useSelectContext";
