import * as React from "react";

import {render, screen} from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import {Select} from "./index";
import {SelectCheckboxIndicator} from "./SelectCheckboxIndicator";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

type StringOption = {label: string; value: string};

const options: StringOption[] = [
    {label: "Tallinn", value: "1"},
    {label: "Stockholm", value: "2"},
    {label: "Berlin", value: "3"},
    {label: "Warsaw", value: "4"},
    {label: "Paris", value: "5"},
];

function renderMultiSelect(props: {
    value?: string[];
    defaultValue?: string[];
    onValueChange?: (value: string[]) => void;
    disabled?: boolean;
}) {
    const {value, defaultValue, onValueChange, disabled} = props;
    const controlledProps = value !== undefined ? {value, onValueChange} : {defaultValue};

    return render(
        <Select.Root multiple items={options} disabled={disabled} {...controlledProps}>
            <Select.Trigger data-testid="trigger">
                <Select.Value placeholder="Select..." data-testid="value" />
                <Select.Icon />
            </Select.Trigger>
            <Select.Portal>
                <Select.Positioner>
                    <Select.Popup>
                        <Select.List data-testid="list">
                            {options.map((option) => (
                                <Select.Item key={option.value} value={option.value}>
                                    <Select.ItemText>{option.label}</Select.ItemText>
                                    <Select.ItemIndicator />
                                </Select.Item>
                            ))}
                        </Select.List>
                    </Select.Popup>
                </Select.Positioner>
            </Select.Portal>
        </Select.Root>,
    );
}

function renderSingleSelect(props: {value?: string | null; defaultValue?: string | null} = {}) {
    const {value, defaultValue} = props;
    const controlledProps = value !== undefined ? {value} : {defaultValue: defaultValue ?? null};

    return render(
        // Pass items so Base UI can resolve labels from the `items` prop
        <Select.Root items={options} {...controlledProps}>
            <Select.Trigger data-testid="trigger">
                <Select.Value placeholder="Select..." data-testid="value" />
                <Select.Icon />
            </Select.Trigger>
            <Select.Portal>
                <Select.Positioner>
                    <Select.Popup>
                        <Select.List data-testid="list">
                            {options.map((option) => (
                                <Select.Item key={option.value} value={option.value}>
                                    <Select.ItemText>{option.label}</Select.ItemText>
                                    <Select.ItemIndicator />
                                </Select.Item>
                            ))}
                        </Select.List>
                    </Select.Popup>
                </Select.Positioner>
            </Select.Portal>
        </Select.Root>,
    );
}

// ---------------------------------------------------------------------------
// SelectValue display
// ---------------------------------------------------------------------------

describe("SelectValue in multi-select mode", () => {
    test("shows placeholder when no items are selected", () => {
        renderMultiSelect({defaultValue: []});
        expect(screen.getByTestId("value")).toHaveTextContent("Select...");
    });

    test("shows single label when exactly one item is selected", () => {
        renderMultiSelect({value: ["1"], onValueChange: () => {}});
        expect(screen.getByTestId("value")).toHaveTextContent("Tallinn");
    });

    test("shows two labels joined by comma when exactly two items are selected", () => {
        renderMultiSelect({value: ["1", "3"], onValueChange: () => {}});
        expect(screen.getByTestId("value")).toHaveTextContent("Tallinn, Berlin");
    });

    test("shows all labels joined by comma when three items are selected", () => {
        renderMultiSelect({value: ["1", "2", "3"], onValueChange: () => {}});
        expect(screen.getByTestId("value")).toHaveTextContent("Tallinn, Stockholm, Berlin");
    });

    test("shows all labels joined by comma when five items are selected", () => {
        renderMultiSelect({value: ["1", "2", "3", "4", "5"], onValueChange: () => {}});
        expect(screen.getByTestId("value")).toHaveTextContent("Tallinn, Stockholm, Berlin, Warsaw, Paris");
    });
});

// ---------------------------------------------------------------------------
// SelectValue single-select mode (unchanged behaviour)
// ---------------------------------------------------------------------------

describe("SelectValue in single-select mode", () => {
    test("shows placeholder when nothing is selected", () => {
        renderSingleSelect();
        expect(screen.getByTestId("value")).toHaveTextContent("Select...");
    });

    test("shows the selected item label", () => {
        renderSingleSelect({value: "3"});
        expect(screen.getByTestId("value")).toHaveTextContent("Berlin");
    });
});

// ---------------------------------------------------------------------------
// Multi-select state management
// ---------------------------------------------------------------------------

describe("Multi-select state management", () => {
    test("uncontrolled: default selections are shown on mount", () => {
        renderMultiSelect({defaultValue: ["1", "3"]});
        expect(screen.getByTestId("value")).toHaveTextContent("Tallinn, Berlin");
    });

    test("controlled: reflects the value prop", () => {
        const {rerender} = render(
            <Select.Root multiple items={options} value={["1"]} onValueChange={() => {}}>
                <Select.Trigger>
                    <Select.Value data-testid="value" />
                </Select.Trigger>
                <Select.Portal>
                    <Select.Positioner>
                        <Select.Popup>
                            <Select.List>
                                {options.map((opt) => (
                                    <Select.Item key={opt.value} value={opt.value}>
                                        <Select.ItemText>{opt.label}</Select.ItemText>
                                    </Select.Item>
                                ))}
                            </Select.List>
                        </Select.Popup>
                    </Select.Positioner>
                </Select.Portal>
            </Select.Root>,
        );

        expect(screen.getByTestId("value")).toHaveTextContent("Tallinn");

        rerender(
            <Select.Root multiple items={options} value={["2", "4"]} onValueChange={() => {}}>
                <Select.Trigger>
                    <Select.Value data-testid="value" />
                </Select.Trigger>
                <Select.Portal>
                    <Select.Positioner>
                        <Select.Popup>
                            <Select.List>
                                {options.map((opt) => (
                                    <Select.Item key={opt.value} value={opt.value}>
                                        <Select.ItemText>{opt.label}</Select.ItemText>
                                    </Select.Item>
                                ))}
                            </Select.List>
                        </Select.Popup>
                    </Select.Positioner>
                </Select.Portal>
            </Select.Root>,
        );

        expect(screen.getByTestId("value")).toHaveTextContent("Stockholm, Warsaw");
    });

    test("onValueChange is called with updated Value[] when item is clicked", async () => {
        const user = userEvent.setup();
        const onValueChange = vi.fn();
        renderMultiSelect({value: ["1"], onValueChange});

        await user.click(screen.getByTestId("trigger"));
        await screen.findByTestId("list");

        const berlin = await screen.findByText("Berlin");
        await user.click(berlin);

        expect(onValueChange).toHaveBeenCalledWith(["1", "3"], expect.anything());
    });

    test("onValueChange removes item when already-selected item is clicked", async () => {
        const user = userEvent.setup();
        const onValueChange = vi.fn();
        renderMultiSelect({value: ["1", "3"], onValueChange});

        await user.click(screen.getByTestId("trigger"));
        await screen.findByTestId("list");

        const tallinn = await screen.findByText("Tallinn");
        await user.click(tallinn);

        expect(onValueChange).toHaveBeenCalledWith(["3"], expect.anything());
    });

    test("dropdown stays open after selecting an item", async () => {
        const user = userEvent.setup();
        renderMultiSelect({defaultValue: []});

        await user.click(screen.getByTestId("trigger"));
        const list = await screen.findByTestId("list");

        await user.click(screen.getByText("Tallinn"));

        // List must still be visible
        expect(list).toBeVisible();
    });

    test("controlled: ignoring onValueChange prevents selection change in UI", async () => {
        const user = userEvent.setup();
        // onValueChange is a no-op — parent never updates value
        render(
            <Select.Root multiple items={options} value={["1"]} onValueChange={() => {}}>
                <Select.Trigger>
                    <Select.Value data-testid="value" />
                </Select.Trigger>
                <Select.Portal>
                    <Select.Positioner>
                        <Select.Popup>
                            <Select.List>
                                {options.map((opt) => (
                                    <Select.Item key={opt.value} value={opt.value}>
                                        <Select.ItemText>{opt.label}</Select.ItemText>
                                    </Select.Item>
                                ))}
                            </Select.List>
                        </Select.Popup>
                    </Select.Positioner>
                </Select.Portal>
            </Select.Root>,
        );

        const trigger = screen.getByRole("combobox");
        await user.click(trigger);
        await user.click(screen.getByText("Berlin"));

        // value stays "Tallinn" because parent ignored the event
        expect(screen.getByTestId("value")).toHaveTextContent("Tallinn");
    });
});

// ---------------------------------------------------------------------------
// Accessibility
// ---------------------------------------------------------------------------

describe("Multi-select accessibility", () => {
    test("listbox has aria-multiselectable=true in multi-select mode", async () => {
        const user = userEvent.setup();
        renderMultiSelect({defaultValue: []});

        await user.click(screen.getByTestId("trigger"));
        const list = await screen.findByTestId("list");

        expect(list).toHaveAttribute("aria-multiselectable", "true");
    });

    test("selected items have aria-selected=true", async () => {
        const user = userEvent.setup();
        renderMultiSelect({value: ["1", "3"], onValueChange: () => {}});

        await user.click(screen.getByTestId("trigger"));
        await screen.findByTestId("list");

        const tallinnOption = screen.getByRole("option", {name: /Tallinn/i});
        const berlinOption = screen.getByRole("option", {name: /Berlin/i});
        const stockholmOption = screen.getByRole("option", {name: /Stockholm/i});

        expect(tallinnOption).toHaveAttribute("aria-selected", "true");
        expect(berlinOption).toHaveAttribute("aria-selected", "true");
        expect(stockholmOption).not.toHaveAttribute("aria-selected", "true");
    });

    test("disabled trigger has data-disabled attribute", () => {
        renderMultiSelect({defaultValue: [], disabled: true});
        expect(screen.getByRole("combobox")).toHaveAttribute("data-disabled");
    });

    test("disabled select does not open on click", async () => {
        const user = userEvent.setup();
        renderMultiSelect({defaultValue: [], disabled: true});

        await user.click(screen.getByTestId("trigger"));
        expect(screen.queryByTestId("list")).not.toBeInTheDocument();
    });
});

// ---------------------------------------------------------------------------
// TypeScript type enforcement (runtime validation via value shape)
// ---------------------------------------------------------------------------

describe("TypeScript value types — single vs multi-select", () => {
    test("single-select onValueChange receives string | null", async () => {
        const user = userEvent.setup();
        const onValueChange = vi.fn();

        render(
            <Select.Root items={options} onValueChange={onValueChange}>
                <Select.Trigger>
                    <Select.Value data-testid="value" />
                </Select.Trigger>
                <Select.Portal>
                    <Select.Positioner>
                        <Select.Popup>
                            <Select.List data-testid="list">
                                {options.map((opt) => (
                                    <Select.Item key={opt.value} value={opt.value}>
                                        <Select.ItemText>{opt.label}</Select.ItemText>
                                    </Select.Item>
                                ))}
                            </Select.List>
                        </Select.Popup>
                    </Select.Positioner>
                </Select.Portal>
            </Select.Root>,
        );

        await user.click(screen.getByRole("combobox"));
        await user.click(await screen.findByText("Tallinn"));

        // Single-select passes a string value (not an array)
        expect(onValueChange).toHaveBeenCalledWith("1", expect.anything());
        const receivedValue = onValueChange.mock.calls[0][0];
        expect(typeof receivedValue).toBe("string");
    });

    test("multi-select onValueChange receives string[]", async () => {
        const user = userEvent.setup();
        const onValueChange = vi.fn();

        renderMultiSelect({value: [], onValueChange});

        await user.click(screen.getByTestId("trigger"));
        await user.click(await screen.findByText("Tallinn"));

        // Multi-select passes an array
        expect(onValueChange).toHaveBeenCalledWith(expect.any(Array), expect.anything());
        const receivedValue = onValueChange.mock.calls[0][0];
        expect(Array.isArray(receivedValue)).toBe(true);
    });
});

// ---------------------------------------------------------------------------
// Focus management
// ---------------------------------------------------------------------------

describe("Multi-select focus management", () => {
    test("trigger regains focus after closing dropdown with Escape", async () => {
        const user = userEvent.setup();
        renderMultiSelect({defaultValue: []});

        const trigger = screen.getByTestId("trigger");
        await user.click(trigger);
        await screen.findByTestId("list");

        await user.keyboard("{Escape}");

        // After Escape, focus should return to the trigger
        expect(trigger).toHaveFocus();
    });

    test("trigger retains accessible role as combobox", () => {
        renderMultiSelect({defaultValue: []});
        expect(screen.getByRole("combobox")).toBeInTheDocument();
    });
});

// ---------------------------------------------------------------------------
// Keyboard navigation (4.1–4.5)
// ---------------------------------------------------------------------------

describe("Multi-select keyboard navigation", () => {
    test("4.1 Arrow keys navigate between items in multi-select dropdown", async () => {
        const user = userEvent.setup();
        renderMultiSelect({defaultValue: []});

        const trigger = screen.getByTestId("trigger");
        await user.click(trigger);
        await screen.findByTestId("list");

        // Arrow down should move focus through items
        await user.keyboard("{ArrowDown}");
        const options = screen.getAllByRole("option");
        // At least one option should have data-highlighted (Base UI uses this attribute)
        const highlighted = options.find((o) => o.hasAttribute("data-highlighted"));
        expect(highlighted).toBeDefined();
    });

    test("4.2 Space key toggles selection without closing dropdown", async () => {
        const user = userEvent.setup();
        const onValueChange = vi.fn();
        renderMultiSelect({value: [], onValueChange});

        const trigger = screen.getByTestId("trigger");
        await user.click(trigger);
        const list = await screen.findByTestId("list");

        // Navigate to first item then press Space
        await user.keyboard("{ArrowDown}");
        await user.keyboard(" ");

        // Dropdown stays open
        expect(list).toBeVisible();
        // Selection event was fired
        expect(onValueChange).toHaveBeenCalled();
    });

    test("4.3 Enter key toggles selection without closing dropdown", async () => {
        const user = userEvent.setup();
        const onValueChange = vi.fn();
        renderMultiSelect({value: [], onValueChange});

        const trigger = screen.getByTestId("trigger");
        await user.click(trigger);
        const list = await screen.findByTestId("list");

        // Navigate to first item then press Enter
        await user.keyboard("{ArrowDown}");
        await user.keyboard("{Enter}");

        // Dropdown stays open
        expect(list).toBeVisible();
        // Selection event was fired
        expect(onValueChange).toHaveBeenCalled();
    });

    test("4.4 Escape key closes dropdown and preserves existing selections", async () => {
        const user = userEvent.setup();
        renderMultiSelect({value: ["1", "3"], onValueChange: () => {}});

        const trigger = screen.getByTestId("trigger");
        await user.click(trigger);
        await screen.findByTestId("list");

        await user.keyboard("{Escape}");

        // Dropdown closes
        expect(screen.queryByTestId("list")).not.toBeVisible();
        // Selected values are still displayed (not reset)
        expect(screen.getByTestId("value")).toHaveTextContent("Tallinn, Berlin");
        // Focus returns to trigger
        expect(trigger).toHaveFocus();
    });

    test("4.5 Tab closes dropdown and moves focus away from trigger", async () => {
        const user = userEvent.setup();
        renderMultiSelect({defaultValue: ["1"]});

        const trigger = screen.getByTestId("trigger");
        await user.click(trigger);
        await screen.findByTestId("list");

        await user.keyboard("{Tab}");

        // Dropdown closes after Tab
        expect(screen.queryByTestId("list")).not.toBeVisible();
    });
});

// ---------------------------------------------------------------------------
// CheckboxIndicator
// ---------------------------------------------------------------------------

/**
 * Renders a minimal multi-select with CheckboxIndicator in each item.
 * The first option (value "1" / Tallinn) is pre-selected.
 */
function renderWithCheckboxIndicator() {
    return render(
        <Select.Root multiple items={options} defaultValue={["1"]}>
            <Select.Trigger data-testid="trigger">
                <Select.Value />
            </Select.Trigger>
            <Select.Portal>
                <Select.Positioner>
                    <Select.Popup>
                        <Select.List data-testid="list">
                            {options.map((opt) => (
                                <Select.Item key={opt.value} value={opt.value}>
                                    <SelectCheckboxIndicator data-testid={`checkbox-${opt.value}`} />
                                    <Select.ItemText>{opt.label}</Select.ItemText>
                                </Select.Item>
                            ))}
                        </Select.List>
                    </Select.Popup>
                </Select.Positioner>
            </Select.Portal>
        </Select.Root>,
    );
}

describe("CheckboxIndicator", () => {
    test("is present in every item regardless of selection state (always mounted)", async () => {
        const user = userEvent.setup();
        renderWithCheckboxIndicator();

        await user.click(screen.getByTestId("trigger"));
        await screen.findByTestId("list");

        // Every option has a CheckboxIndicator in the DOM — space is always reserved
        for (const opt of options) {
            expect(screen.getByTestId(`checkbox-${opt.value}`)).toBeInTheDocument();
        }
    });

    test("renders a check icon (SVG) in every item", async () => {
        const user = userEvent.setup();
        renderWithCheckboxIndicator();

        await user.click(screen.getByTestId("trigger"));
        await screen.findByTestId("list");

        // The SVG check icon is always in the DOM (opacity toggles via CSS)
        const allOptions = screen.getAllByRole("option");
        for (const option of allOptions) {
            expect(option.querySelector("svg")).toBeTruthy();
        }
    });

    test("accepts and forwards className to the outer wrapper", async () => {
        const user = userEvent.setup();
        render(
            <Select.Root multiple items={options} defaultValue={[]}>
                <Select.Trigger data-testid="trigger">
                    <Select.Value />
                </Select.Trigger>
                <Select.Portal>
                    <Select.Positioner>
                        <Select.Popup>
                            <Select.List data-testid="list">
                                <Select.Item value="1">
                                    {/* eslint-disable-next-line rulesdir/eslint-rule-require-cx */}
                                    <SelectCheckboxIndicator data-testid="cb" className="extra-class" />
                                    <Select.ItemText>Tallinn</Select.ItemText>
                                </Select.Item>
                            </Select.List>
                        </Select.Popup>
                    </Select.Positioner>
                </Select.Portal>
            </Select.Root>,
        );

        await user.click(screen.getByTestId("trigger"));
        await screen.findByTestId("list");

        expect(screen.getByTestId("cb")).toHaveClass("extra-class");
    });

    test("selected item indicator contains filled box class; unselected contains border box class", async () => {
        const user = userEvent.setup();
        renderWithCheckboxIndicator();

        await user.click(screen.getByTestId("trigger"));
        await screen.findByTestId("list");

        // Tallinn (value "1") is pre-selected — indicator root should be filled
        const selectedIndicator = screen.getByTestId("checkbox-1");
        expect(selectedIndicator).toHaveClass("bg-action-primary");

        // Stockholm (value "2") is NOT selected — indicator root should show border
        const unselectedIndicator = screen.getByTestId("checkbox-2");
        expect(unselectedIndicator).toHaveClass("border-neutral-primary");
    });
});

// ---------------------------------------------------------------------------
// Readonly helpers
// ---------------------------------------------------------------------------

function renderReadonlySingleSelect(props: {defaultValue?: string | null} = {}) {
    return render(
        <Select.Root items={options} readOnly defaultValue={props.defaultValue ?? null}>
            <Select.Trigger data-testid="trigger">
                <Select.Value placeholder="Select..." data-testid="value" />
                <Select.Icon data-testid="icon" />
            </Select.Trigger>
            <Select.Portal>
                <Select.Positioner>
                    <Select.Popup>
                        <Select.List data-testid="list">
                            {options.map((option) => (
                                <Select.Item key={option.value} value={option.value}>
                                    <Select.ItemText>{option.label}</Select.ItemText>
                                    <Select.ItemIndicator />
                                </Select.Item>
                            ))}
                        </Select.List>
                    </Select.Popup>
                </Select.Positioner>
            </Select.Portal>
        </Select.Root>,
    );
}

function renderReadonlyMultiSelect(props: {defaultValue?: string[]} = {}) {
    return render(
        <Select.Root multiple items={options} readOnly defaultValue={props.defaultValue ?? []}>
            <Select.Trigger data-testid="trigger">
                <Select.Value placeholder="Select..." data-testid="value" />
                <Select.Icon data-testid="icon" />
            </Select.Trigger>
            <Select.Portal>
                <Select.Positioner>
                    <Select.Popup>
                        <Select.List data-testid="list">
                            {options.map((option) => (
                                <Select.Item key={option.value} value={option.value}>
                                    <Select.ItemText>{option.label}</Select.ItemText>
                                    <Select.ItemIndicator />
                                </Select.Item>
                            ))}
                        </Select.List>
                    </Select.Popup>
                </Select.Positioner>
            </Select.Portal>
        </Select.Root>,
    );
}

// ---------------------------------------------------------------------------
// Readonly — single-select
// ---------------------------------------------------------------------------

describe("Readonly single-select", () => {
    test("6.1 trigger has data-readonly attribute", () => {
        renderReadonlySingleSelect({defaultValue: "3"});
        expect(screen.getByTestId("trigger")).toHaveAttribute("data-readonly");
    });

    test("6.2 click does not open popup", async () => {
        const user = userEvent.setup();
        renderReadonlySingleSelect({defaultValue: "3"});

        await user.click(screen.getByTestId("trigger"));
        // The list may be in the DOM (Base UI portal/forceMount) but must not be visible
        const list = screen.queryByTestId("list");
        if (list) {
            expect(list).not.toBeVisible();
        }
    });

    test("6.3 trigger is a button element (focusable, native semantics)", () => {
        renderReadonlySingleSelect({defaultValue: "3"});
        const trigger = screen.getByTestId("trigger");
        expect(trigger.tagName.toLowerCase()).toBe("button");
    });

    test("6.4 icon is absent from DOM when readOnly", () => {
        renderReadonlySingleSelect({defaultValue: "3"});
        // SelectIcon returns null in readonly mode — no icon wrapper in DOM
        expect(screen.queryByTestId("icon")).not.toBeInTheDocument();
    });

    test("selected value is displayed", () => {
        renderReadonlySingleSelect({defaultValue: "3"});
        expect(screen.getByTestId("value")).toHaveTextContent("Berlin");
    });
});

// ---------------------------------------------------------------------------
// Readonly — multi-select
// ---------------------------------------------------------------------------

describe("Readonly multi-select", () => {
    test("6.5 value span has whitespace-nowrap and overflow-x-auto classes (horizontal scroll)", () => {
        renderReadonlyMultiSelect({defaultValue: ["1", "3"]});
        const value = screen.getByTestId("value");
        expect(value).toHaveClass("whitespace-nowrap");
        expect(value).toHaveClass("overflow-x-auto");
    });

    test("6.6 all selected labels are present in DOM", () => {
        renderReadonlyMultiSelect({defaultValue: ["1", "2", "3", "4", "5"]});
        const value = screen.getByTestId("value");
        expect(value).toHaveTextContent("Tallinn");
        expect(value).toHaveTextContent("Stockholm");
        expect(value).toHaveTextContent("Berlin");
        expect(value).toHaveTextContent("Warsaw");
        expect(value).toHaveTextContent("Paris");
    });

    test("6.7 value span has select-text class (text is selectable)", () => {
        renderReadonlyMultiSelect({defaultValue: ["1", "3"]});
        expect(screen.getByTestId("value")).toHaveClass("select-text");
    });

    test("trigger has data-readonly attribute", () => {
        renderReadonlyMultiSelect({defaultValue: ["1", "3"]});
        expect(screen.getByTestId("trigger")).toHaveAttribute("data-readonly");
    });

    test("trigger is a button element (focusable, native semantics)", () => {
        renderReadonlyMultiSelect({defaultValue: ["1", "3"]});
        const trigger = screen.getByTestId("trigger");
        expect(trigger.tagName.toLowerCase()).toBe("button");
    });

    test("icon is absent from DOM when readOnly", () => {
        renderReadonlyMultiSelect({defaultValue: ["1", "3"]});
        expect(screen.queryByTestId("icon")).not.toBeInTheDocument();
    });

    test("click does not open popup", async () => {
        const user = userEvent.setup();
        renderReadonlyMultiSelect({defaultValue: ["1", "3"]});

        await user.click(screen.getByTestId("trigger"));
        // The list may be in the DOM (Base UI portal/forceMount) but must not be visible
        const list = screen.queryByTestId("list");
        if (list) {
            expect(list).not.toBeVisible();
        }
    });
});
