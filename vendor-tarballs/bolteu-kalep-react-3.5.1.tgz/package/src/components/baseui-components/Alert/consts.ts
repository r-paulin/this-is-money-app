import type {Severity} from "@/components/baseui-components/Alert/alert.types";

export const colors: Record<"background" | "action" | "iconColors", Record<Severity, string>> = {
    background: {
        error: "bg-danger-secondary",
        info: "bg-promo-secondary",
        promotion: "bg-layer-floor-1 border-separator",
        success: "bg-positive-secondary",
        warning: "bg-warning-secondary",
    },
    action: {
        error: "text-danger-primary",
        info: "text-promo-primary",
        promotion: "text-action-primary",
        success: "text-positive-primary",
        warning: "text-primary",
    },
    iconColors: {
        error: "text-danger-secondary",
        info: "text-promo-secondary",
        promotion: "text-primary",
        success: "text-action-secondary",
        warning: "text-warning-secondary",
    },
};
