import * as React from "react";

import {mergeProps, useRender} from "@base-ui/react";

import type {AlertState} from "@/components/baseui-components/Alert/alert.types";
import {useAlertContext} from "@/components/baseui-components/Alert/context/useAlertContext";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

export interface AlertContentProps extends Omit<useRender.ComponentProps<"div">, "className"> {
    className?: string | ((state: AlertState) => string);
}

export const AlertContent = React.forwardRef(function AlertContentWrapper(
    props: AlertContentProps,
    ref: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, render, ...otherComponentProps} = props;
    const {severity, visible} = useAlertContext();
    const state: AlertState = {severity, visible};

    const defaultProps: useRender.ElementProps<"div"> = {
        className: cx("flex w-full flex-col items-start gap-2", addConsumerClasses(state, className)),
        role: severity === "error" ? "alert" : "status",
        "aria-live": severity === "error" ? "assertive" : "polite",
    };

    return useRender({
        ref,
        defaultTagName: "div",
        render,
        state,
        props: mergeProps<"div">(defaultProps, otherComponentProps),
    });
});
