import * as React from "react";

import type {Severity} from "@/components/baseui-components/Alert/alert.types";

export type AlertContextType = {
    severity: Severity;
    visible: boolean;
    setVisible: React.Dispatch<React.SetStateAction<boolean>>;
    setDescriptionId: React.Dispatch<React.SetStateAction<string | undefined>>;
    setTitleId: React.Dispatch<React.SetStateAction<string | undefined>>;
    onVisibleChange: (newVisible: boolean) => void;
    descriptionId?: string;
    titleId?: string;
};

export const AlertContext = React.createContext<AlertContextType | null>(null);
