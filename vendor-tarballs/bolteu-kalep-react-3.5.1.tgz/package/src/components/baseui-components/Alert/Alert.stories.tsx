import * as React from "react";

import {expect, userEvent, within} from "storybook/test";
import type {Meta, StoryObj} from "@storybook/react-webpack5";

import type {Severity} from "@/components/baseui-components/Alert/alert.types";
import {Button} from "@/components/Button";

import DocumentationTemplate from "../docs/DocumentationTemplate.mdx";
import {Alert} from "./index";

const allSeverities: Severity[] = ["error", "warning", "promotion", "success", "info"];
const meta = {
    // @ts-expect-error - some issue with compound components
    component: Alert,
    title: "BaseUI Playground/Alert",
    subcomponents: {
        "Alert.Root": Alert.Root,
        "Alert.Icon": Alert.Icon,
        "Alert.Content": Alert.Content,
        "Alert.Title": Alert.Title,
        "Alert.Description": Alert.Description,
        "Alert.Action": Alert.Action,
        "Alert.Close": Alert.Close,
    },
    tags: ["experimental", "BaseUI", "autodocs"],
    parameters: {
        docs: {
            subtitle: "Components to display an Inline Alert message to the user.",
            page: DocumentationTemplate,
        },
    },
} satisfies Meta<typeof Alert>;

export default meta;

type Story = StoryObj<typeof Alert.Root>;

export const Default: Story = {
    args: {},
    render: (_args) => {
        return (
            <div className="flex flex-col gap-2">
                {allSeverities.map((sev) => (
                    <Alert.Root severity={sev} key={sev} data-testid={`alert-${sev}`}>
                        <Alert.Icon />
                        <Alert.Content>
                            <Alert.Title>{sev.toUpperCase()}</Alert.Title>
                            <Alert.Description>{sev} description</Alert.Description>
                        </Alert.Content>
                    </Alert.Root>
                ))}
            </div>
        );
    },
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement);

        await step("All severity alerts are rendered", async () => {
            const alerts = await canvas.findAllByRole("region");
            await expect(alerts).toHaveLength(allSeverities.length);
        });
        await step("Each alert has correct data-severity attribute", async () => {
            for (const sev of allSeverities) {
                const alert = await canvas.findByTestId(`alert-${sev}`);
                await expect(alert).toHaveAttribute("data-severity", sev);
            }
        });
        await step("Each alert content has correct aria attributes", async () => {
            for (const sev of allSeverities) {
                const alert = await canvas.findByTestId(`alert-${sev}`);
                const content = within(alert).getByRole(sev === "error" ? "alert" : "status");
                await expect(content).toHaveAttribute("aria-live", sev === "error" ? "assertive" : "polite");
            }
        });
    },
};

export const FullFeatured: Story = {
    args: {
        severity: "success",
    },
    render: (args) => {
        const {severity} = args;

        const onActionClick = React.useCallback(() => {
            alert("Action clicked");
        }, []);
        return (
            <Alert.Root severity={severity} data-testid="closable-alert">
                <Alert.Icon />
                <Alert.Content>
                    <Alert.Title>TITLE</Alert.Title>
                    <Alert.Description>CONTENT</Alert.Description>
                    <Alert.Action onClick={onActionClick}>Action button</Alert.Action>
                </Alert.Content>
                <Alert.Close data-testid="close-button" />
            </Alert.Root>
        );
    },
    play: async ({canvasElement, step, mount}) => {
        const canvas = within(canvasElement);

        await step("Alert can be closed when the close button is clicked", async () => {
            await mount();
            const alert = await canvas.findByRole("region");
            const closeButton = await canvas.findByTestId("close-button");
            await expect(alert).toBeVisible();
            await userEvent.click(closeButton);
            await expect(alert).not.toBeVisible();
            await mount();
        });
    },
};
export const PreventClosing: Story = {
    args: {
        severity: "promotion",
    },
    render: (args) => {
        const {severity} = args;
        const onClose: React.MouseEventHandler = React.useCallback((ev) => {
            ev.preventDefault();
            alert("We can do event.preventDefault() to prevent closing the alert.");
        }, []);

        const onActionClick = React.useCallback(() => {
            alert("Action clicked");
        }, []);
        return (
            <Alert.Root severity={severity} data-testid="prevent-close-alert">
                <Alert.Icon />
                <Alert.Content>
                    <Alert.Title>TITLE</Alert.Title>
                    <Alert.Description>CONTENT</Alert.Description>
                    <Alert.Action onClick={onActionClick}>Action button</Alert.Action>
                </Alert.Content>
                <Alert.Close onClick={onClose} data-testid="prevent-close-button" />
            </Alert.Root>
        );
    },
};

export const ControlledAlert: Story = {
    args: {
        severity: "warning",
        visible: false,
    },
    render: (args) => {
        const {severity, visible} = args;
        const [isOpen, setIsOpen] = React.useState(visible);

        const onVisibleChange = React.useCallback((newVisible: boolean) => {
            setIsOpen(newVisible);
        }, []);

        const toggleAlert = React.useCallback(() => {
            setIsOpen((prev) => !prev);
        }, []);

        return (
            <div className="flex flex-col gap-2">
                <Button onClick={toggleAlert} data-testid="toggle-button">
                    Click me to trigger
                </Button>
                <Alert.Root
                    severity={severity}
                    visible={isOpen}
                    onVisibleChange={onVisibleChange}
                    data-testid="controlled-alert"
                >
                    <Alert.Icon />
                    <Alert.Content>
                        <Alert.Title>TITLE</Alert.Title>
                        <Alert.Description>CONTENT</Alert.Description>
                    </Alert.Content>
                    <Alert.Close />
                </Alert.Root>
            </div>
        );
    },
};

export const WithoutTitle: Story = {
    args: {
        severity: "info",
    },
    render: (args) => {
        const {severity} = args;

        return (
            <Alert.Root severity={severity}>
                <Alert.Icon />
                <Alert.Content>
                    <Alert.Description>This alert has no title.</Alert.Description>
                </Alert.Content>
            </Alert.Root>
        );
    },
};
