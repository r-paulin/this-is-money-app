import * as React from "react";

import {mergeProps, useRender} from "@base-ui/react";

import Cross from "@bolteu/kalep-react-icons/dist/Cross";

import type {AlertState} from "@/components/baseui-components/Alert/alert.types";
import {useAlertContext} from "@/components/baseui-components/Alert/context/useAlertContext";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

export const DEFAULT_CLOSE_BUTTON_ARIA_LABEL = "close notification";
export interface AlertCloseProps extends Omit<useRender.ComponentProps<"button">, "className"> {
    className?: string | ((state: AlertState) => string);
}
export const AlertCloseButton = React.forwardRef(function AlertCloseButton(
    props: AlertCloseProps,
    ref: React.ForwardedRef<HTMLButtonElement>,
) {
    const {className, render, "aria-label": ariaLabelProp, ...otherComponentProps} = props;
    const {severity, setVisible, visible, onVisibleChange} = useAlertContext();
    const state: AlertState = {severity, visible};

    const defaultProps: useRender.ElementProps<"button"> = {
        className: cx("cursor-pointer border-none bg-transparent", "mb-auto p-1", addConsumerClasses(state, className)),
        type: "button",
        "aria-label": ariaLabelProp || DEFAULT_CLOSE_BUTTON_ARIA_LABEL,
        children: <Cross size="xs" className={cx("block")} />,
        onClick: (ev) => {
            if (!ev.isDefaultPrevented()) {
                onVisibleChange(false);
                setVisible(false);
            }
        },
    };
    return useRender({
        ref,
        render,
        defaultTagName: "button",
        state,
        props: mergeProps(defaultProps, otherComponentProps),
    });
});
