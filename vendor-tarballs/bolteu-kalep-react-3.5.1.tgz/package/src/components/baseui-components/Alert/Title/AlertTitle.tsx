import * as React from "react";

import {mergeProps, useRender} from "@base-ui/react";
import {useIsoLayoutEffect} from "@base-ui/utils/useIsoLayoutEffect";

import type {AlertState} from "@/components/baseui-components/Alert/alert.types";
import {useAlertContext} from "@/components/baseui-components/Alert/context/useAlertContext";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {useId} from "@/helpers";
import {cx} from "@/helpers/utils/cx";

export interface AlertTitleProps extends Omit<useRender.ComponentProps<"div">, "className"> {
    className?: string | ((state: AlertState) => string);
}
export const AlertTitle = React.forwardRef(function AlertTitle(
    props: AlertTitleProps,
    ref: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, render, id: idProp, ...otherComponentProps} = props;

    const {severity, setTitleId, visible} = useAlertContext();
    const generatedId = useId();
    const id = idProp ?? `kalep-alert-title-${generatedId}`;
    useIsoLayoutEffect(() => {
        setTitleId(id);
        return () => {
            setTitleId(undefined);
        };
    }, [id, setTitleId]);
    const state: AlertState = {severity, visible};
    const defaultProps: useRender.ElementProps<"div"> = {
        className: cx("font-semibold text-primary", addConsumerClasses(state, className)),
        id,
    };
    return useRender({
        ref,
        render,
        defaultTagName: "div",
        state,
        props: mergeProps<"div">(defaultProps, otherComponentProps),
    });
});
