---
name: 02-plan-and-scope
description: Define refactor scope, API contract, and success criteria.
---

# Skill 02 — Plan & Scope (Refactor Contract)

## Purpose

Create a refactor plan that defines the target API, states, and success criteria.

## Inputs

- Base UI docs ingestion summary (Skill 01)
- Legacy component code (or summary)
- Known consumers/usages
- Known variants/states (hover/focus/disabled/error/loading/etc.)
- Accessibility expectations (keyboard, labeling, focus behavior)

## Output (required)

Fill out the following:

## Refactor Plan

### 1) Scope

- In-scope:
    - <bullet list>
- Out-of-scope:
    - <bullet list>

### 2) Public API contract

- Base UI props used directly:
    - <prop>: <notes>
- Legacy props to remove or replace (only if explicitly requested to preserve, otherwise drop):
    - <prop>: <replacement or reason>
- Events/callbacks:
    - <list>
- Controlled/uncontrolled:
    - Value prop: <...>
    - Default value prop: <...>
    - Change callback: <...>
    - Notes: <...>

### 3) Composition contract

- Root element type: <e.g. button/div/ul/etc.>
- Subcomponents (if compound):
    - <Subcomponent>: <single element type + responsibility>

### 4) Styling contract

- Tailwind strategy:
    - Base classes:
    - Variants:
    - Data attributes / state styling:
- Styling location:
    - Component defaults vs stories (note if wrappers are needed for parity)
- Typography strategy:
    - Component choice (Typography vs TypographyStack):
    - Any overrides needed for parity:
- What must NOT be done:
    - wrapper divs purely for styling
    - empty elements for spacing

### 5) UX / a11y contract

- Keyboard interactions:
    - <list>
- Focus behavior:
    - <list>
- ARIA expectations:
    - <list>

### 6) Test & parity strategy

- Existing tests:
    - <list or none>
- Stories to add/update:
    - <list>
- Critical UI states to validate:
    - <list>

## Rules

- Do not start implementation until this plan exists.
- If Base UI docs ingestion is missing, pause and complete Skill 01 first.
- Prefer Base UI API and naming. Do not mirror legacy props unless explicitly requested.
- Visual-only props (padding/spacing/color/etc.) should be removed in favor of `className` and documented in the plan.
- Storybook stories are required for new/refactored components and must cover Default, Variants, States, and Accessibility.
- Wrapper components are allowed for styling parity but must keep Base UI props intact.

## Self-check

- Did I define controlled/uncontrolled behavior explicitly?
- Did I specify root + subcomponent responsibilities?
- Did I list critical UI states for parity?
