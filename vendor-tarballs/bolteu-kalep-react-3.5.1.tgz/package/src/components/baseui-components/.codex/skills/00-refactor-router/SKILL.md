---
name: 00-refactor-router
description: Route a legacy React to Base UI refactor through required skills and artifacts.
---

# Refactor Router (Legacy React -> Base UI)

## Purpose

Route the refactor through the correct sequence of skills and ensure required artifacts are produced.

## Inputs

- Legacy component name + path
- Target new component name + path (if different)
- Link(s) to legacy usage (search results / examples)
- Known stories, screenshots, or critical UI states (if available)

## Output (required)

Produce this block verbatim:

## Refactor Skill Route

- Component: <name>
- Refactor type: <1:1 replacement | multi-component compound | split/merge | behavior change>
- Skills to run (in order): <01, 02, 03, 04, 05, 06, 07>
- Required artifacts:
    - Base UI docs ingestion (Skill 01)
    - Plan doc (Skill 02)
    - Primitive decision + justification (Skill 03)
    - Composition contract + DOM-root check (Skill 04)
    - State/context inventory table (Skill 05)
    - UI parity checklist (Skill 06)
    - PR notes + risk assessment (Skill 07)

Note: Legacy prop parity refers to behavior and visuals, not preserving legacy prop names, unless explicitly instructed.

## Rules

- Never skip a skill.
- If a skill discovers unknowns, update Skill 02 plan and continue.
- If a rule conflict is discovered, prefer Base UI + accessibility constraints.

## Self-check

- Did I list the exact skills I will execute next?
- Did I commit to producing all required artifacts?
