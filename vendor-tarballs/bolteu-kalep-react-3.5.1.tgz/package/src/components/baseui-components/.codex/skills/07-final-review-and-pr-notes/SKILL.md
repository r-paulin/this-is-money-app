---
name: 07-final-review-and-pr-notes
description: Produce a refactor review summary and risk assessment.
---

# Skill 07 — Final Review & Refactor Summary

## Purpose

Produce a reviewer-quality summary and ensure the refactor is safe to land.

## Inputs

- Outputs of Skills 02–06
- Test results (if run)

## Output (required)

Copy and fill:

## Refactor Skill Report (Refactor Summary)

### What changed

- <high-level bullets>

### Primitive usage

- Primitive(s) used: <...>
- What was extended: <...>
- What was NOT reimplemented: <...>

### Composition

- Single-element rule: <PASS/FAIL>
- Compound structure: <Root + Subcomponents list>

### State/context

- State count: <N>
- Context used: <YES/NO>
- Notes on minimization: <...>

### UI parity

- Checklist status: <PASS/IN PROGRESS>
- Known deltas (if any): <bullets>

### Tests

- Lint/typecheck: <PASS/NOT RUN>
- Unit tests: <PASS/NOT RUN>
- Storybook/Playwright: <PASS/NOT RUN>

### Risk assessment

- Risk level: <Low/Medium/High>
- Main risk areas:
    - <bullets>
- Rollback plan:
    - <bullets>

## Rules

- If any section is unknown, say so explicitly and state what’s needed to confirm.
- Avoid “should be fine” language without evidence.

## Self-check

- Did I produce an honest risk assessment?
- Did I record intentional behavior changes as deltas?
