---
name: 03-baseui-primitive-first
description: Choose Base UI primitive(s) and justify any exceptions.
---

# Skill 03 — Base UI Primitive Decision (API-First)

## Purpose

Select the correct Base UI primitive(s) for the refactor and define:

- the Base UI API we will use directly
- what (if anything) we extend without reimplementing behavior

This skill exists to prevent:

- rebuilding primitive behavior from scratch
- leaking internal implementation details into the public API
- introducing unnecessary aliases for Base UI props

---

## Mandatory Inputs

- Refactor Plan (Skill 02)
- Base UI Docs Ingestion (Skill 01)

If Skill 01 is missing, STOP and run it first.

---

## Procedure (mandatory order)

1) Verify that all props and types used in component code, stories, and tests exist in the Base UI primitives and local component types. Replace any invalid props with composition or `className`-based styling.

---

## Output (required)

Paste the following block verbatim and fill it in:

## Base UI Primitive Decision

### Base UI primitive(s) selected

- Primary primitive(s):
    - <Primitive name>
- Secondary / supporting primitives (if any):
    - <Primitive name>

### Docs consulted

- <links from Skill 01>

### Base UI API alignment

- Base UI prop names used directly:
    - <e.g. multiple, value, defaultValue, onValueChange>
- Legacy props removed or migrated (only if explicitly requested to preserve):
    - <e.g. exclusive -> use multiple; paddingStart -> className>
- Wrapper components (if any) only add styling defaults; no prop renaming.
- Inner wrappers are allowed only for animation parity and must be documented in code.

### Responsibilities

- Base UI handles:
    - <state, ARIA, keyboard nav, focus>
- We extend only:
    - <styling, slots, layout>
- Default visual parity plan:
    - <which part components carry legacy spacing/typography>

### Must NOT reimplement

- <state/ARIA/keyboard behavior covered by Base UI>

### Exceptions (only if necessary)

- Exception: <what>
- Reason: <why unavoidable>
- Mitigation: <tests/a11y/risks>
