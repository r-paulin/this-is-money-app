import * as React from "react";

import {expect,within} from "storybook/test";
import type {Meta, StoryObj} from "@storybook/react-webpack5";

import {Heart} from "@bolteu/kalep-react-icons";

import {Badge} from "@/components/baseui-components/Badge/Badge";
import {IconButton} from "@/components/baseui-components/IconButton";

import DocumentationTemplate from "../docs/DocumentationTemplate.mdx";
import type {BadgeAppearance, BadgePlacement, BadgeVariant} from "./badge.types";

const meta = {
    component: Badge,
    title: "BaseUI Playground/Badge",
    tags: ["experimental", "BaseUI", "autodocs"],
    parameters: {
        docs: {
            subtitle: "A primitive Badge component",
            page: DocumentationTemplate,
        },
    },
} satisfies Meta<typeof Badge>;

export default meta;

type Story = StoryObj<typeof meta>;

export const Default: Story = {
    args: {
        badgeContent: 8,
        standalone: true,
    },
    render: (args) => {
        return (
            <div className="flex items-center gap-4">
                <Badge {...args} data-testid="standalone-badge" />
                <div className="relative">
                    <IconButton icon={<Heart />} aria-label={`${args.badgeContent} unread messages`} />
                    <Badge {...args} standalone={false} />
                </div>
            </div>
        );
    },
    play: async ({canvasElement, args}) => {
        const canvas = within(canvasElement);
        const testedElement = await canvas.findByTestId("standalone-badge");
        await expect(testedElement).toHaveTextContent(args.badgeContent!.toString() as string);
    },
};

export const MaxCount: Story = {
    args: {
        badgeContent: 12,
        maxCount: 9,
        standalone: true,
    },
    play: async ({canvasElement, args}) => {
        const canvas = within(canvasElement);
        await expect(canvas.queryByText(args.badgeContent as number)).not.toBeInTheDocument();
    },
};

export const StandaloneAppearances: Story = {
    args: {},
    render: (_args) => {
        const appearances: BadgeAppearance[] = ["danger", "action", "promo", "neutral", "warning"];
        const variants: BadgeVariant[] = ["standard", "dot", "s-dot"];
        return (
            <div className="flex flex-col gap-5 bg-layer-surface p-6">
                {appearances.map((appearance) => (
                    <div className="flex gap-9" key={appearance}>
                        {variants.map((variant) =>
                            variant === "standard" ? (
                                <React.Fragment key={`${appearance}-${variant}`}>
                                    <div className="flex items-center justify-center">
                                        <div className="flex items-center gap-2">
                                            <Badge
                                                badgeContent={8}
                                                appearance={appearance}
                                                variant={variant}
                                                standalone
                                            />
                                            <Badge
                                                stroke
                                                badgeContent={8}
                                                appearance={appearance}
                                                variant={variant}
                                                standalone
                                            />
                                        </div>
                                    </div>
                                    <div className="flex items-center justify-center">
                                        <div className="flex items-center gap-2">
                                            <Badge
                                                badgeContent={8}
                                                maxCount={5}
                                                appearance={appearance}
                                                variant={variant}
                                                standalone
                                            />
                                            <Badge
                                                stroke
                                                badgeContent={8}
                                                maxCount={5}
                                                appearance={appearance}
                                                variant={variant}
                                                standalone
                                            />
                                        </div>
                                    </div>
                                </React.Fragment>
                            ) : (
                                <div key={`${appearance}-${variant}`} className="flex items-center justify-center">
                                    <div className="flex items-center gap-2">
                                        <Badge appearance={appearance} variant={variant} standalone />
                                        <Badge stroke appearance={appearance} variant={variant} standalone />
                                    </div>
                                </div>
                            ),
                        )}
                    </div>
                ))}
            </div>
        );
    },
};
export const WithContentAppearances: Story = {
    args: {},
    render: (_args) => {
        const appearances: BadgeAppearance[] = ["danger", "action", "promo", "neutral", "warning"];
        const variants: BadgeVariant[] = ["standard", "dot", "s-dot"];
        return (
            <div className="flex flex-col gap-5 p-6">
                {appearances.map((appearance) => (
                    <div className="flex gap-9" key={appearance}>
                        {variants.map((variant) =>
                            variant === "standard" ? (
                                <React.Fragment key={`${appearance}-${variant}`}>
                                    <div className="flex items-center justify-center">
                                        <div className="flex items-center gap-2">
                                            <div className="relative">
                                                <IconButton icon={<Heart />} />
                                                <Badge badgeContent={8} appearance={appearance} variant={variant} />
                                            </div>
                                            <div className="relative">
                                                <IconButton icon={<Heart />} />
                                                <Badge
                                                    stroke
                                                    badgeContent={8}
                                                    appearance={appearance}
                                                    variant={variant}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                    <div className="flex items-center justify-center">
                                        <div className="flex items-center gap-2">
                                            <div className="relative">
                                                <IconButton icon={<Heart />} />
                                                <Badge
                                                    badgeContent={8}
                                                    maxCount={5}
                                                    appearance={appearance}
                                                    variant={variant}
                                                />
                                            </div>
                                            <div className="relative">
                                                <IconButton icon={<Heart />} />
                                                <Badge
                                                    stroke
                                                    badgeContent={8}
                                                    maxCount={5}
                                                    appearance={appearance}
                                                    variant={variant}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </React.Fragment>
                            ) : (
                                <div key={`${appearance}-${variant}`} className="flex items-center justify-center">
                                    <div className="flex items-center gap-2">
                                        <div className="relative">
                                            <IconButton icon={<Heart />} />
                                            <Badge appearance={appearance} variant={variant} />
                                        </div>
                                        <div className="relative">
                                            <IconButton icon={<Heart />} />
                                            <Badge stroke appearance={appearance} variant={variant} />
                                        </div>
                                    </div>
                                </div>
                            ),
                        )}
                    </div>
                ))}
            </div>
        );
    },
};

export const Placements: Story = {
    args: {},
    render: (_args) => {
        const placements: BadgePlacement[] = ["top-right", "top-left", "bottom-left", "bottom-right"];
        return (
            <div className="flex flex-col gap-5 p-6">
                {placements.map((placement) => (
                    <div key={placement} className="flex gap-8">
                        <div className="relative">
                            <IconButton icon={<Heart />} />
                            <Badge badgeContent={8} placement={placement} />
                        </div>
                        <div className="relative flex">
                            <div className="flex items-center bg-layer-surface p-3 shadow">
                                I wasn&#39;t there, so I&#39;m square
                            </div>
                            <Badge badgeContent={8} placement={placement} placementOverlap="rectangular" />
                        </div>
                    </div>
                ))}
            </div>
        );
    },
};
