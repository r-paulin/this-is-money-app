import * as React from "react";

import {mergeProps, useRender} from "@base-ui/react";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

import {useListItemLayoutContext} from "./context/useListItemLayoutContext";
import type {ListItemLayoutSlotProps} from "./ListItemLayout.types";

export const ListItemLayoutSlot = React.forwardRef(function ListItemLayoutSlot(
    props: ListItemLayoutSlotProps,
    ref: React.ForwardedRef<HTMLDivElement>,
) {
    const {render, className, children, ...otherComponentProps} = props;
    const state = useListItemLayoutContext();

    const defaultProps: useRender.ElementProps<"div"> = {
        className: cx("flex h-full shrink-0 items-center", addConsumerClasses(state, className)),
        children,
    };

    return useRender({
        defaultTagName: "div",
        render,
        ref,
        state,
        props: mergeProps<"div">(defaultProps, otherComponentProps),
    });
});

