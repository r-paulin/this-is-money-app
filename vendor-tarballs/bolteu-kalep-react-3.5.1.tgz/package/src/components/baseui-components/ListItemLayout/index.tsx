import {ListItemLayoutContent} from "./ListItemLayoutContent";
import {ListItemLayoutRoot} from "./ListItemLayoutRoot";
import {ListItemLayoutSlot} from "./ListItemLayoutSlot";

/**
 * ListItemLayout compound component.
 *
 * Provides a set of subcomponents for building list item layouts:
 * - `ListItemLayout.Root`: the main container
 * - `ListItemLayout.Content`: flexible content container
 * - `ListItemLayout.Slot`: slot wrapper for leading or trailing content
 *
 * Use `TypographyStack` for primary/secondary text and compose selection indicators via slots.
 * For selectable rows, prefer attaching the `onClick` handler to `ListItemLayout.Root` and fully control the
 * selection component rendered inside a `ListItemLayout.Slot` to keep interaction consistent.
 *
 * ### Composition guide
 * ```tsx
 * <ListItemLayout.Root onClick={onClick}>
 *   <ListItemLayout.Slot>
 *     <Icon size="md" />
 *   </ListItemLayout.Slot>
 *   <ListItemLayout.Content>
 *     <TypographyStack>
 *       <TypographyStack.Primary>Primary</TypographyStack.Primary>
 *       <TypographyStack.Secondary>Secondary</TypographyStack.Secondary>
 *     </TypographyStack>
 *   </ListItemLayout.Content>
 *   <ListItemLayout.Slot>
 *     <Check size="md" />
 *   </ListItemLayout.Slot>
 * </ListItemLayout.Root>
 * ```
 */
export const ListItemLayout = {
    Root: ListItemLayoutRoot,
    Content: ListItemLayoutContent,
    Slot: ListItemLayoutSlot,
};

ListItemLayout.Root.displayName = "ListItemLayout.Root";
ListItemLayout.Content.displayName = "ListItemLayout.Content";
ListItemLayout.Slot.displayName = "ListItemLayout.Slot";

export {useListItemLayoutContext} from "./context/useListItemLayoutContext";
export type {
    ListItemLayoutContentProps,
    ListItemLayoutRootProps,
    ListItemLayoutSlotProps,
    ListItemLayoutState,
} from "./ListItemLayout.types";
