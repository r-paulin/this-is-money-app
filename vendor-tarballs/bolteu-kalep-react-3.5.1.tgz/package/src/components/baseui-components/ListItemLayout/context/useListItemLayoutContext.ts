import * as React from "react";

import {ListItemLayoutContext} from "./ListItemLayoutContext";

export function useListItemLayoutContext() {
    const context = React.useContext(ListItemLayoutContext);
    if (!context) {
        throw new Error("useListItemLayoutContext must be used within a ListItemLayout.Root component");
    }
    return context;
}
