import * as React from "react";

import type {ListItemLayoutState} from "../ListItemLayout.types";

export type ListItemLayoutContextValue = ListItemLayoutState;

export const ListItemLayoutContext = React.createContext<ListItemLayoutContextValue | null>(null);
