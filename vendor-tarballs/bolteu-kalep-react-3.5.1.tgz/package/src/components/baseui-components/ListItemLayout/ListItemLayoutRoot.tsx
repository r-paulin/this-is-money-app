import * as React from "react";

import {mergeProps, useRender} from "@base-ui/react";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

import {ListItemLayoutContext} from "./context/ListItemLayoutContext";
import type {ListItemLayoutRootProps, ListItemLayoutState} from "./ListItemLayout.types";

const listItemLayoutVariantClasses: Record<NonNullable<ListItemLayoutRootProps["variant"]>, string> = {
    base: "py-3 gap-3 min-h-12",
    sm: "py-[6px] gap-3 min-h-9",
};

export const ListItemLayoutRoot = React.forwardRef(function ListItemLayoutRoot(
    props: ListItemLayoutRootProps,
    ref: React.ForwardedRef<HTMLDivElement>,
) {
    const {
        render,
        className,
        variant = "base",
        disabled = false,
        separator = false,
        children,
        ...otherComponentProps
    } = props;
    const onClick = props.onClick;

    const isClickable = typeof onClick === "function";

    const state: ListItemLayoutState = React.useMemo(
        () => ({
            variant,
            disabled,
            clickable: isClickable,
        }),
        [variant, disabled, isClickable],
    );

    const handleKeyDown = React.useCallback(
        (event: React.KeyboardEvent<HTMLDivElement>) => {
            if (!isClickable || disabled || event.isDefaultPrevented()) {
                return;
            }
            if (event.key === "Enter" || event.key === " ") {
                event.preventDefault();
                event.currentTarget.click();
            }
        },
        [disabled, isClickable],
    );

    const handleClickCapture = React.useCallback(
        (event: React.MouseEvent<HTMLDivElement>) => {
            if (!isClickable || !disabled) {
                return;
            }
            event.preventDefault();
            event.stopPropagation();
        },
        [disabled, isClickable],
    );

    const defaultProps: useRender.ElementProps<"div"> = {
        className: cx(
            "flex w-full items-center px-4",
            listItemLayoutVariantClasses[variant],
            separator && "border-0 border-b border-solid border-separator",
            isClickable && "cursor-pointer",
            isClickable && disabled && "cursor-not-allowed",
            isClickable &&
                !disabled &&
                `
                  hover:bg-neutral-secondary
                  focus:hover:bg-neutral-secondary
                `,
            addConsumerClasses(state, className),
        ),
        role: isClickable ? "button" : undefined,
        tabIndex: isClickable && !disabled ? 0 : undefined,
        "aria-disabled": isClickable ? disabled : undefined,
        onKeyDown: isClickable ? handleKeyDown : undefined,
        onClickCapture: disabled ? handleClickCapture : undefined,
        children,
    };

    const element = useRender({
        defaultTagName: "div",
        render,
        ref,
        state,
        props: mergeProps<"div">(defaultProps, otherComponentProps),
    });

    return <ListItemLayoutContext.Provider value={state}>{element}</ListItemLayoutContext.Provider>;
});
