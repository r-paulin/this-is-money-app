import {Toast as BaseUIToast} from "@base-ui/react/toast";

/**
 * Snackbar.Portal
 *
 * Portals snackbar stack rendering outside local layout containers.
 */
export const SnackbarPortal = BaseUIToast.Portal;
