import * as React from "react";

import {Toast as BaseUIToast} from "@base-ui/react/toast";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

import {useSnackbarViewportPlacement} from "./context";

const CLASSNAME_TW_SNACKBAR_CSS_VARS = [
    "[--gap:1.25rem]",
    "[--peek:0.75rem]",
    "[--scale:max(0,_calc(1_-_var(--toast-index)_*_0.04))]",
    "[--shrink:calc(1-var(--scale))]",
    "[--height:var(--toast-frontmost-height,var(--toast-height))]",
];
const CLASSNAME_TW_SNACKBAR_OFFSET_Y_TOP =
    "[--offset-y:calc(var(--toast-offset-y)+(var(--toast-index)*var(--gap))+var(--toast-swipe-movement-y))]";
const CLASSNAME_TW_SNACKBAR_OFFSET_Y_BOTTOM =
    "[--offset-y:calc(var(--toast-offset-y)*-1+(var(--toast-index)*var(--gap)*-1)+var(--toast-swipe-movement-y))]";
const CLASSNAME_TW_SNACKBAR_POSITION_TOP = "absolute left-auto right-0 top-0 m-0 mr-0 box-border w-full";
const CLASSNAME_TW_SNACKBAR_POSITION_BOTTOM = "absolute bottom-0 left-auto right-0 m-0 mr-0 box-border w-full";
const CLASSNAME_TW_SNACKBAR_SURFACE = `
  bolt-font-body-s-regular rounded-[12px] border bg-neutral-primary p-4 text-primary-inverted
`;
const CLASSNAME_TW_SNACKBAR_BEHAVIOR = "cursor-default select-none bg-clip-padding shadow-md";
const CLASSNAME_TW_SNACKBAR_TRANSITION = `
  transition-[transform,opacity,height] duration-[200ms,200ms,150ms] ease-in-out
`;
const CLASSNAME_TW_SNACKBAR_AFTER_SPACER =
    'after:absolute after:left-0 after:top-full after:h-[calc(var(--gap)+1px)] after:w-full after:content-[""]';
const CLASSNAME_TW_SNACKBAR_STACK_LAYER = "z-[calc(1000-var(--toast-index))]";
const CLASSNAME_TW_SNACKBAR_ORIGIN_TOP = "origin-top";
const CLASSNAME_TW_SNACKBAR_ORIGIN_BOTTOM = "origin-bottom";
const CLASSNAME_TW_SNACKBAR_HEIGHT = "h-[var(--height)]";
const CLASSNAME_TW_SNACKBAR_SWIPE_TRANSLATE_X = "translate-x-[var(--toast-swipe-movement-x)]";
const CLASSNAME_TW_SNACKBAR_STACK_TRANSLATE_TOP =
    "translate-y-[calc(var(--toast-swipe-movement-y)+(var(--toast-index)*var(--peek))+(var(--shrink)*var(--height)))]";
const CLASSNAME_TW_SNACKBAR_STACK_TRANSLATE_BOTTOM =
    "translate-y-[calc(var(--toast-swipe-movement-y)-(var(--toast-index)*var(--peek))-(var(--shrink)*var(--height)))]";
const CLASSNAME_TW_SNACKBAR_STACK_SCALE = "scale-[var(--scale)]";
const CLASSNAME_TW_SNACKBAR_EXPANDED_STATE =
    "h-[var(--toast-height)] translate-x-[var(--toast-swipe-movement-x)] translate-y-[var(--offset-y)] scale-100";
const CLASSNAME_TW_SNACKBAR_EXIT_Y = "translate-y-[150%]";
const CLASSNAME_TW_SNACKBAR_EXIT_Y_TOP = "-translate-y-[150%]";
const CLASSNAME_TW_SNACKBAR_EXIT_UP = "translate-y-[calc(var(--toast-swipe-movement-y)-150%)]";
const CLASSNAME_TW_SNACKBAR_EXIT_LEFT = `
  translate-x-[calc(var(--toast-swipe-movement-x)-150%)] translate-y-[var(--offset-y)]
`;
const CLASSNAME_TW_SNACKBAR_EXIT_RIGHT = `
  translate-x-[calc(var(--toast-swipe-movement-x)+150%)] translate-y-[var(--offset-y)]
`;
const CLASSNAME_TW_SNACKBAR_EXIT_DOWN = "translate-y-[calc(var(--toast-swipe-movement-y)+150%)]";
const CLASSNAME_TW_SNACKBAR_ITEM_HIDDEN = "opacity-0";

/**
 * ### Snackbar.Root
 * Base UI toast root styled to match Kalep snackbars.
 *
 * ```tsx
 * <Snackbar.Root toast={toast}>
 *   <Snackbar.Content>
 *     <div>
 *       <Snackbar.Title />
 *       <Snackbar.Description />
 *     </div>
 *   </Snackbar.Content>
 *   <Snackbar.Close />
 * </Snackbar.Root>
 * ```
 */
export const SnackbarRoot = React.forwardRef(function SnackbarRoot(
    props: BaseUIToast.Root.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, ...rest} = props;

    const placement = useSnackbarViewportPlacement();
    const isTopPlacement = placement.startsWith("top");

    const getRootClassNames = React.useCallback(
        (state: BaseUIToast.Root.State) =>
            cx(
                ...CLASSNAME_TW_SNACKBAR_CSS_VARS,
                isTopPlacement ? CLASSNAME_TW_SNACKBAR_OFFSET_Y_TOP : CLASSNAME_TW_SNACKBAR_OFFSET_Y_BOTTOM,
                isTopPlacement ? CLASSNAME_TW_SNACKBAR_POSITION_TOP : CLASSNAME_TW_SNACKBAR_POSITION_BOTTOM,
                CLASSNAME_TW_SNACKBAR_SURFACE,
                CLASSNAME_TW_SNACKBAR_BEHAVIOR,
                CLASSNAME_TW_SNACKBAR_TRANSITION,
                CLASSNAME_TW_SNACKBAR_AFTER_SPACER,
                CLASSNAME_TW_SNACKBAR_STACK_LAYER,
                isTopPlacement ? CLASSNAME_TW_SNACKBAR_ORIGIN_TOP : CLASSNAME_TW_SNACKBAR_ORIGIN_BOTTOM,
                CLASSNAME_TW_SNACKBAR_HEIGHT,
                CLASSNAME_TW_SNACKBAR_SWIPE_TRANSLATE_X,
                isTopPlacement
                    ? CLASSNAME_TW_SNACKBAR_STACK_TRANSLATE_TOP
                    : CLASSNAME_TW_SNACKBAR_STACK_TRANSLATE_BOTTOM,
                CLASSNAME_TW_SNACKBAR_STACK_SCALE,
                {
                    [CLASSNAME_TW_SNACKBAR_EXPANDED_STATE]: state.expanded,
                    [CLASSNAME_TW_SNACKBAR_EXIT_Y]:
                        !isTopPlacement &&
                        (state.transitionStatus === "starting" || state.transitionStatus === "ending"),
                    [CLASSNAME_TW_SNACKBAR_EXIT_Y_TOP]:
                        isTopPlacement &&
                        (state.transitionStatus === "starting" || state.transitionStatus === "ending"),
                    [CLASSNAME_TW_SNACKBAR_ITEM_HIDDEN]: state.limited || state.transitionStatus === "ending",
                    [CLASSNAME_TW_SNACKBAR_EXIT_UP]:
                        state.transitionStatus === "ending" && state.swipeDirection === "up",
                    [CLASSNAME_TW_SNACKBAR_EXIT_LEFT]:
                        state.transitionStatus === "ending" && state.swipeDirection === "left",
                    [CLASSNAME_TW_SNACKBAR_EXIT_RIGHT]:
                        state.transitionStatus === "ending" && state.swipeDirection === "right",
                    [CLASSNAME_TW_SNACKBAR_EXIT_DOWN]:
                        state.transitionStatus === "ending" && state.swipeDirection === "down",
                },
                addConsumerClasses(state, className),
            ),
        [className, isTopPlacement],
    );

    return <BaseUIToast.Root {...rest} className={getRootClassNames} ref={forwardedRef} />;
});
