import * as React from "react";

import {Toast as BaseUIToast} from "@base-ui/react/toast";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Snackbar.Title
 * Optional title for the snackbar message.
 *
 * ```tsx
 * <Snackbar.Title>Update complete</Snackbar.Title>
 * ```
 */
export const SnackbarTitle = React.forwardRef(function SnackbarTitle(
    props: BaseUIToast.Title.Props,
    forwardedRef: React.ForwardedRef<HTMLHeadingElement>,
) {
    const {className, render, ...rest} = props;

    const getTitleClassNames = React.useCallback(
        (state: BaseUIToast.Title.State) => cx("m-0 font-semibold", addConsumerClasses(state, className)),
        [className],
    );

    return (
        <BaseUIToast.Title
            {...rest}
            className={getTitleClassNames}
            ref={forwardedRef}
            // by default it's rendered as h2 element, but we want to render it as p for snackbar
            render={render ?? <p />}
        />
    );
});
