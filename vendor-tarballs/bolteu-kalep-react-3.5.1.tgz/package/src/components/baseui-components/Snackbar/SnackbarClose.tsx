import * as React from "react";

import {Toast as BaseUIToast} from "@base-ui/react/toast";
import type {HTMLProps} from "@base-ui/react/utils/types";

import Cross from "@bolteu/kalep-react-icons/dist/Cross";

import {IconButton} from "@/components/baseui-components/IconButton";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Snackbar.Close
 * Dismiss button rendered inside the snackbar.
 *
 * ```tsx
 * <Snackbar.Close aria-label="Close" />
 * ```
 */
export const SnackbarClose = React.forwardRef(function SnackbarClose(
    props: BaseUIToast.Close.Props,
    forwardedRef: React.ForwardedRef<HTMLButtonElement>,
) {
    const {className, render, "aria-label": ariaLabel, ...rest} = props;

    const getCloseClassNames = React.useCallback(
        (state: BaseUIToast.Close.State) =>
            cx(
                "inline-flex h-5 w-5 items-center justify-center",
                "text-primary-inverted",
                "hover:opacity-80",
                addConsumerClasses(state, className),
            ),
        [className],
    );

    const renderDefault = React.useCallback(
        (iconProps: HTMLProps<HTMLButtonElement>) => {
            const {children: _children, ...restIconProps} = iconProps;
            return <IconButton {...restIconProps} aria-label={ariaLabel ?? "Close"} icon={<Cross size="sm" />} />;
        },
        [ariaLabel],
    );

    return (
        <BaseUIToast.Close
            {...rest}
            aria-label={ariaLabel ?? "Close"}
            className={getCloseClassNames}
            render={render ?? renderDefault}
            ref={forwardedRef}
        />
    );
});
