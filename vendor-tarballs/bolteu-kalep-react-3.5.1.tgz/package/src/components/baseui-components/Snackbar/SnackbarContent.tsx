import * as React from "react";

import {Toast as BaseUIToast} from "@base-ui/react/toast";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Snackbar.Content
 * Layout wrapper for snackbar body, title, and actions.
 *
 * ```tsx
 * <Snackbar.Content>
 *   <div>
 *     <Snackbar.Title />
 *     <Snackbar.Description />
 *   </div>
 * </Snackbar.Content>
 * ```
 */
export const SnackbarContent = React.forwardRef(function SnackbarContent(
    props: BaseUIToast.Content.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, ...rest} = props;

    const getContentClassNames = React.useCallback(
        (state: BaseUIToast.Content.State) =>
            cx(
                `
                  flex w-full flex-row flex-wrap items-center gap-3 overflow-hidden transition-opacity duration-300
                  ease-in-out
                `,
                {
                    "opacity-0": state.behind,
                    "opacity-100": state.expanded,
                },
                addConsumerClasses(state, className),
            ),
        [className],
    );

    return <BaseUIToast.Content {...rest} className={getContentClassNames} ref={forwardedRef} />;
});
