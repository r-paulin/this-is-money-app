import * as React from "react";

import {Toast as BaseUIToast} from "@base-ui/react/toast";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

import {type SnackbarPlacement, SnackbarViewportContextProvider} from "./context";

export interface SnackbarViewportProps extends BaseUIToast.Viewport.Props {
    placement?: SnackbarPlacement;
}

const CLASSNAME_TW_SNACKBAR_VIEWPORT_PLACEMENT: Record<SnackbarPlacement, string> = {
    "bottom-left": "bottom-4 left-4 items-start",
    "bottom-right": "bottom-4 right-4 items-end",
    "bottom-center": "bottom-4 left-1/2 -translate-x-1/2 items-center",
    "top-left": "left-4 top-4 items-start",
    "top-right": "right-4 top-4 items-end",
    "top-center": "left-1/2 top-4 -translate-x-1/2 items-center",
};

/**
 * ### Snackbar.Viewport
 * Container that positions the snackbar stack.
 *
 * ```tsx
 * <Snackbar.Viewport placement="bottom-left" />
 * ```
 */
export const SnackbarViewport = React.forwardRef(function SnackbarViewport(
    props: SnackbarViewportProps,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, placement = "bottom-left", ...rest} = props;

    const getViewportClassNames = React.useCallback(
        (state: BaseUIToast.Viewport.State) =>
            cx(
                `
                  fixed z-50 flex w-[calc(100%-2rem)] max-w-sm gap-2 outline-none
                  [&:empty]:pointer-events-none
                `,
                placement.startsWith("top") ? "flex-col" : "flex-col-reverse",
                CLASSNAME_TW_SNACKBAR_VIEWPORT_PLACEMENT[placement],
                addConsumerClasses(state, className),
            ),
        [className, placement],
    );

    return (
        <SnackbarViewportContextProvider placement={placement}>
            <BaseUIToast.Viewport {...rest} className={getViewportClassNames} ref={forwardedRef} />
        </SnackbarViewportContextProvider>
    );
});
