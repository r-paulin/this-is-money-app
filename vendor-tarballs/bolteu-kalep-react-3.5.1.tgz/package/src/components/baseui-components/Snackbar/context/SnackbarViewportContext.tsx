import * as React from "react";

export type SnackbarPlacement =
    | "bottom-left"
    | "bottom-right"
    | "bottom-center"
    | "top-left"
    | "top-right"
    | "top-center";

const SnackbarViewportContext = React.createContext<SnackbarPlacement>("bottom-left");

export function SnackbarViewportContextProvider({
    placement,
    children,
}: {
    placement: SnackbarPlacement;
    children: React.ReactNode;
}) {
    const value = React.useMemo(() => placement, [placement]);

    return <SnackbarViewportContext.Provider value={value}>{children}</SnackbarViewportContext.Provider>;
}

export function useSnackbarViewportPlacement() {
    return React.useContext(SnackbarViewportContext);
}
