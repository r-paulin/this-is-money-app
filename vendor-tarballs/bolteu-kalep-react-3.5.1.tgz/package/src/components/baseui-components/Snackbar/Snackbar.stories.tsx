import * as React from "react";

import {expect, screen, userEvent, waitFor, within} from "storybook/test";
import type {Meta, StoryObj} from "@storybook/react-webpack5";

import {Button} from "@/components/baseui-components/Button";
import {cx} from "@/helpers/utils/cx";

import DocumentationTemplate from "../docs/DocumentationTemplate.mdx";
import {Snackbar, type SnackbarPlacement} from "./index";

type SnackbarStoryAction = {
    label: string;
    onClick?: () => void;
};

type SnackbarStoryArgs = {
    placement: SnackbarPlacement;
    limit: number;
};

type SnackbarStoryContent = {
    title?: string;
    description: string;
    descriptionClassName?: string;
    actions?: SnackbarStoryAction[];
    dismissible?: boolean;
    timeout?: number;
};

function SnackbarStoryComponent(args: SnackbarStoryArgs) {
    return (
        <Snackbar.Provider limit={args.limit}>
            <SnackbarStory placement={args.placement} content={{description: "This is a snackbar"}} />
        </Snackbar.Provider>
    );
}

const meta = {
    component: SnackbarStoryComponent,
    title: "BaseUI Playground/Snackbar",
    tags: ["experimental", "BaseUI", "autodocs"],
    subcomponents: {
        "Snackbar.Provider": Snackbar.Provider,
        "Snackbar.Portal": Snackbar.Portal,
        "Snackbar.Viewport": Snackbar.Viewport,
        "Snackbar.Root": Snackbar.Root,
        "Snackbar.Content": Snackbar.Content,
        "Snackbar.Title": Snackbar.Title,
        "Snackbar.Description": Snackbar.Description,
        "Snackbar.Action": Snackbar.Action,
        "Snackbar.Close": Snackbar.Close,
    },
    parameters: {
        docs: {
            toc: true,
            subtitle: "Composition patterns and API for the Base UI Snackbar",
            page: DocumentationTemplate,
        },
    },
    argTypes: {
        placement: {
            control: "select",
            options: ["bottom-left", "bottom-right", "bottom-center", "top-left", "top-right", "top-center"],
        },
        limit: {
            control: "number",
        },
    },
    args: {
        placement: "bottom-left",
        limit: 4,
    },
} satisfies Meta<SnackbarStoryArgs>;

export default meta;

type Story = StoryObj<SnackbarStoryArgs>;

const withSource = (code: string) => ({
    parameters: {
        docs: {
            source: {
                code,
            },
        },
    },
});

function SnackbarStack({placement, container}: {placement: SnackbarPlacement; container: HTMLDivElement | null}) {
    const {toasts, close} = Snackbar.useToastManager();

    if (!container) {
        return <span data-testid="snackbar-container-pending">Not ready</span>;
    }

    return (
        <Snackbar.Portal container={container}>
            <Snackbar.Viewport placement={placement}>
                {toasts.map((toast) => {
                    const data = toast.data as SnackbarStoryContent | undefined;
                    const actions = data?.actions;
                    const descriptionClassName = data?.descriptionClassName;
                    const showClose = actions?.length ? false : (data?.dismissible ?? true);
                    const isSingleRow = !data?.title && !actions?.length;

                    return (
                        <Snackbar.Root key={toast.id} toast={toast}>
                            <Snackbar.Content className={isSingleRow ? "flex-nowrap" : undefined}>
                                {data?.title ? (
                                    <div>
                                        <Snackbar.Title />
                                        <Snackbar.Description className={descriptionClassName} />
                                    </div>
                                ) : (
                                    <Snackbar.Description className={cx("truncate", descriptionClassName)} />
                                )}
                                {actions?.length ? (
                                    <div className={cx("ml-auto flex items-center")}>
                                        <div className={cx("flex w-full justify-end gap-6")}>
                                            {actions.map((action) => (
                                                <Snackbar.Action
                                                    key={action.label}
                                                    onClick={() => {
                                                        action.onClick?.();
                                                        close(toast.id);
                                                    }}
                                                >
                                                    {action.label}
                                                </Snackbar.Action>
                                            ))}
                                        </div>
                                    </div>
                                ) : null}
                                {showClose ? (
                                    <div className={cx("ml-auto flex items-center")}>
                                        <Snackbar.Close aria-label="Close" />
                                    </div>
                                ) : null}
                            </Snackbar.Content>
                        </Snackbar.Root>
                    );
                })}
            </Snackbar.Viewport>
        </Snackbar.Portal>
    );
}

function SnackbarStory({content, placement}: {content: SnackbarStoryContent; placement: SnackbarPlacement}) {
    const {add} = Snackbar.useToastManager();
    const [container, setContainer] = React.useState<HTMLDivElement | null>(null);

    return (
        <div id="snackbar-story" ref={setContainer}>
            <div className={cx("flex min-h-48 gap-2")}>
                <Button
                    onClick={() =>
                        add({
                            title: content.title,
                            description: content.description,
                            timeout: content.timeout ?? 0,
                            data: content,
                        })
                    }
                >
                    Show Snackbar
                </Button>
                <SnackbarStack placement={placement} container={container} />
            </div>
        </div>
    );
}

const defaultCode = `
import {Snackbar} from "@bolteu/kalep-react";

const {toasts, add} = Snackbar.useToastManager();

<Snackbar.Provider limit={3}>
  <Button
    onClick={() =>
      add({
        description: "This is a snackbar",
      })
    }
  >
    Show message
  </Button>
  <Snackbar.Portal>
    <Snackbar.Viewport placement="bottom-left">
      {toasts.map((toast) => (
        <Snackbar.Root key={toast.id} toast={toast}>
          <Snackbar.Content>
            <Snackbar.Description className="truncate" />
            <div className="ml-auto flex items-center">
              <Snackbar.Close aria-label="Close" />
            </div>
          </Snackbar.Content>
        </Snackbar.Root>
      ))}
    </Snackbar.Viewport>
  </Snackbar.Portal>
</Snackbar.Provider>
`;

export const Default: Story = {
    ...withSource(defaultCode),
    render: (args) => (
        <Snackbar.Provider limit={args.limit}>
            <SnackbarStory
                placement={args.placement}
                content={{description: "This is a snackbar", descriptionClassName: "truncate", dismissible: true}}
            />
        </Snackbar.Provider>
    ),
    play: async ({canvasElement}) => {
        const canvas = within(canvasElement);
        await userEvent.click(canvas.getByRole("button", {name: "Show Snackbar"}));

        const region = await screen.findByRole("region", {name: "Notifications"});
        await userEvent.hover(region);

        await expect(within(region).getByText("This is a snackbar")).toBeInTheDocument();

        const closeButton = await within(region).findByRole("button", {name: "Close"});

        // WebKit can find the button before it is truly interactable (0x0 box during transitions).
        await waitFor(
            () => {
                const r = closeButton.getBoundingClientRect();
                expect(r.width).toBeGreaterThan(0);
                expect(r.height).toBeGreaterThan(0);
            },
            {timeout: 2000},
        );

        await userEvent.click(closeButton);

        try {
            await waitFor(
                () => {
                    expect(within(region).queryByText("This is a snackbar")).not.toBeInTheDocument();
                },
                {timeout: 1200},
            );
        } catch {
            closeButton.focus();
            await userEvent.keyboard("{Enter}");
        }

        await waitFor(
            () => {
                expect(within(region).queryByText("This is a snackbar")).not.toBeInTheDocument();
            },
            {timeout: 2500},
        );
    },
};

const actionsCode = `
import {Snackbar} from "@bolteu/kalep-react";

const {toasts, add} = Snackbar.useToastManager();

<Snackbar.Provider>
  <Button
    onClick={() =>
      add({
        description: "This is a snackbar with actions",
        data: {actions: [{label: "Got it"}]},
      })
    }
  >
    Show message
  </Button>
  <Snackbar.Portal>
    <Snackbar.Viewport>
      {toasts.map((toast) => (
        <Snackbar.Root key={toast.id} toast={toast}>
          <Snackbar.Content>
            <Snackbar.Description />
            <div className="ml-auto flex items-center">
              <Snackbar.Action>Got it</Snackbar.Action>
            </div>
          </Snackbar.Content>
        </Snackbar.Root>
      ))}
    </Snackbar.Viewport>
  </Snackbar.Portal>
</Snackbar.Provider>
`;

export const Actions: Story = {
    ...withSource(actionsCode),
    render: (args) => (
        <Snackbar.Provider limit={args.limit}>
            <SnackbarStory
                placement={args.placement}
                content={{
                    description: "This is a snackbar with actions",
                    actions: [{label: "Got it"}],
                }}
            />
        </Snackbar.Provider>
    ),
    play: async ({canvasElement}) => {
        const canvas = within(canvasElement);
        await userEvent.click(canvas.getByRole("button", {name: "Show Snackbar"}));

        const region = await screen.findByRole("region", {name: "Notifications"});
        await userEvent.hover(region);

        await expect(within(region).getByText("This is a snackbar with actions")).toBeInTheDocument();
        await expect(within(region).getByText("Got it")).toBeInTheDocument();
        await expect(within(region).queryByRole("button", {name: "Close"})).not.toBeInTheDocument();

        const actionButton = await within(region).findByRole("button", {name: "Got it"});

        await waitFor(
            () => {
                const r = actionButton.getBoundingClientRect();
                expect(r.width).toBeGreaterThan(0);
                expect(r.height).toBeGreaterThan(0);
            },
            {timeout: 2000},
        );

        await userEvent.click(actionButton);

        try {
            await waitFor(
                () => {
                    expect(within(region).queryByText("This is a snackbar with actions")).not.toBeInTheDocument();
                },
                {timeout: 1200},
            );
        } catch {
            actionButton.focus();
            await userEvent.keyboard("{Enter}");
        }

        await waitFor(
            () => {
                expect(within(region).queryByText("This is a snackbar with actions")).not.toBeInTheDocument();
            },
            {timeout: 2500},
        );
    },
};

const anatomyCode = `
import {Snackbar} from "@bolteu/kalep-react";

const {toasts, add} = Snackbar.useToastManager();

<Snackbar.Provider>
  <Button
    onClick={() =>
      add({
        title: "This is snackbar title (optional)",
        description:
          "This is snackbar description (required) and it is very long so it spans on multiple lines",
        data: {
          actions: [
            {label: "Tell me more"},
            {label: "Gotcha"},
          ],
        },
      })
    }
  >
    Show message
  </Button>
  <Snackbar.Portal>
    <Snackbar.Viewport>
      {toasts.map((toast) => (
        <Snackbar.Root key={toast.id} toast={toast}>
          <Snackbar.Content>
            <div>
              <Snackbar.Title />
              <Snackbar.Description />
            </div>
            <div className="ml-auto flex items-center">
              <Snackbar.Action>Tell me more</Snackbar.Action>
              <Snackbar.Action>Gotcha</Snackbar.Action>
            </div>
          </Snackbar.Content>
        </Snackbar.Root>
      ))}
    </Snackbar.Viewport>
  </Snackbar.Portal>
</Snackbar.Provider>
`;

export const Anatomy: Story = {
    ...withSource(anatomyCode),
    render: (args) => (
        <Snackbar.Provider limit={args.limit}>
            <SnackbarStory
                placement={args.placement}
                content={{
                    title: "This is snackbar title (optional)",
                    description:
                        "This is snackbar description (required) and it is very long so it spans on multiple lines",
                    actions: [{label: "Tell me more"}, {label: "Gotcha"}],
                }}
            />
        </Snackbar.Provider>
    ),
    play: async ({canvasElement}) => {
        const canvas = within(canvasElement);
        await userEvent.click(canvas.getByRole("button", {name: "Show Snackbar"}));

        const region = await screen.findByRole("region", {name: "Notifications"});
        await userEvent.hover(region);

        await expect(within(region).getByText("This is snackbar title (optional)")).toBeInTheDocument();
        await expect(within(region).getByText("Tell me more")).toBeInTheDocument();
        await expect(within(region).getByText("Gotcha")).toBeInTheDocument();
        await expect(within(region).queryByRole("button", {name: "Close"})).not.toBeInTheDocument();

        const actionButton = await within(region).findByRole("button", {name: "Gotcha"});

        await waitFor(
            () => {
                const r = actionButton.getBoundingClientRect();
                expect(r.width).toBeGreaterThan(0);
                expect(r.height).toBeGreaterThan(0);
            },
            {timeout: 2000},
        );

        await userEvent.click(actionButton);

        try {
            await waitFor(
                () => {
                    expect(within(region).queryByText("This is snackbar title (optional)")).not.toBeInTheDocument();
                },
                {timeout: 1200},
            );
        } catch {
            actionButton.focus();
            await userEvent.keyboard("{Enter}");
        }

        await waitFor(
            () => {
                expect(within(region).queryByText("This is snackbar title (optional)")).not.toBeInTheDocument();
            },
            {timeout: 2500},
        );
    },
};

const autoDismissCode = `
import {Snackbar} from "@bolteu/kalep-react";

const {toasts, add} = Snackbar.useToastManager();

<Snackbar.Provider>
  <Button
    onClick={() =>
      add({
        description: "This is a snackbar which disappears after 5 seconds",
        timeout: 5000,
      })
    }
  >
    Show message
  </Button>
  <Snackbar.Portal>
    <Snackbar.Viewport>
      {toasts.map((toast) => (
        <Snackbar.Root key={toast.id} toast={toast}>
          <Snackbar.Content>
            <Snackbar.Description className="truncate" />
          </Snackbar.Content>
        </Snackbar.Root>
      ))}
    </Snackbar.Viewport>
  </Snackbar.Portal>
</Snackbar.Provider>
`;

export const Autodismiss: Story = {
    ...withSource(autoDismissCode),
    render: (args) => (
        <Snackbar.Provider limit={args.limit}>
            <SnackbarStory
                placement={args.placement}
                content={{
                    description: "This is a snackbar which disappears after 3 seconds",
                    descriptionClassName: "truncate",
                    timeout: 3000,
                }}
            />
        </Snackbar.Provider>
    ),
    play: async ({canvasElement}) => {
        const canvas = within(canvasElement);
        await userEvent.click(canvas.getByRole("button", {name: "Show Snackbar"}));
        const region = await screen.findByRole("region", {name: "Notifications"});
        await expect(
            within(region).getByText("This is a snackbar which disappears after 3 seconds"),
        ).toBeInTheDocument();
        await waitFor(
            () => {
                expect(
                    within(region).queryByText("This is a snackbar which disappears after 3 seconds"),
                ).not.toBeInTheDocument();
            },
            {timeout: 8000},
        );
    },
};

const emptyViewportCode = `
import {Snackbar} from "@bolteu/kalep-react";

<Snackbar.Provider>
  <Snackbar.Portal>
    <Snackbar.Viewport placement="bottom-left" />
  </Snackbar.Portal>
</Snackbar.Provider>
`;

export const EmptyViewport: Story = {
    ...withSource(emptyViewportCode),
    render: (args) => (
        <Snackbar.Provider limit={args.limit}>
            <SnackbarStory placement={args.placement} content={{description: "This is a snackbar"}} />
        </Snackbar.Provider>
    ),
    play: async () => {
        const region = await screen.findByRole("region", {name: "Notifications"});

        await waitFor(() => {
            const rect = region.getBoundingClientRect();
            expect(rect.height).toBeLessThanOrEqual(1);
            expect(getComputedStyle(region).pointerEvents).toBe("none");
        });
    },
};
