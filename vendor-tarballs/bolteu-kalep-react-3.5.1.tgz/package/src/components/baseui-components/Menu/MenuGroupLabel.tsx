import * as React from "react";

import {Menu as BaseUIMenu} from "@base-ui/react/menu";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Menu.GroupLabel
 * Non-interactive label for grouped menu items.
 *
 * ```tsx
 * <Menu.GroupLabel>Actions</Menu.GroupLabel>
 * ```
 */
export const MenuGroupLabel = React.forwardRef(function MenuGroupLabel(
    props: BaseUIMenu.GroupLabel.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, ...rest} = props;

    const getGroupLabelClassNames = React.useCallback(
        (state: BaseUIMenu.GroupLabel.State) =>
            cx(
                "bolt-font-body-s-regular cursor-default px-4 py-2 text-secondary",
                addConsumerClasses(state, className),
            ),
        [className],
    );

    return <BaseUIMenu.GroupLabel {...rest} className={getGroupLabelClassNames} ref={forwardedRef} />;
});
