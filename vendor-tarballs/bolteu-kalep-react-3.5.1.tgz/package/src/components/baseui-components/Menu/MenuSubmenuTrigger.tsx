import * as React from "react";

import {Menu as BaseUIMenu} from "@base-ui/react/menu";
import type {HTMLProps} from "@base-ui/react/utils/types";

import {ListItemLayout} from "@/components/baseui-components/ListItemLayout";
import {getItemDefaultClassNames} from "@/components/baseui-components/Menu/shared-styles";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

const DEFAULT_DELAY = 0;
const DEFAULT_CLOSE_DELAY = 0;

/**
 * ### Menu.SubmenuTrigger
 * Menu item that opens a nested submenu.
 * Renders a ListItemLayout.Root component internally, so you can use ListItemLayout slots if needed.
 *
 * Regular usage:
 * ```tsx
 * <Menu.SubmenuTrigger>More</Menu.SubmenuTrigger>
 * ```
 *
 * Composed with slots:
 * ```tsx
 * <Menu.SubmenuTrigger>
 *   <ListItemLayout.Slot>
 *     <Icon size="md" />
 *   </ListItemLayout.Slot>
 *   <ListItemLayout.Content>
 *     <TypographyStack>
 *       <TypographyStack.Primary>More</TypographyStack.Primary>
 *       <TypographyStack.Secondary>Additional options</TypographyStack.Secondary>
 *     </TypographyStack>
 *   </ListItemLayout.Content>
 *   <ListItemLayout.Slot>
 *     <ChevronRight size="md" />
 *   </ListItemLayout.Slot>
 * </Menu.SubmenuTrigger>
 * ```
 */
export const MenuSubmenuTrigger = React.forwardRef(function MenuSubmenuTrigger(
    props: BaseUIMenu.SubmenuTrigger.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, delay = DEFAULT_DELAY, closeDelay = DEFAULT_CLOSE_DELAY, children, render, ...rest} = props;

    const getSubmenuTriggerClassNames = React.useCallback(
        (state: BaseUIMenu.SubmenuTrigger.State) =>
            cx(getItemDefaultClassNames(state), addConsumerClasses(state, className)),
        [className],
    );

    const defaultRender = React.useCallback(
        (triggerProps: HTMLProps, state: BaseUIMenu.SubmenuTrigger.State) => {
            return (
                <ListItemLayout.Root {...triggerProps} disabled={state.disabled}>
                    {children}
                </ListItemLayout.Root>
            );
        },
        [children],
    );

    return (
        <BaseUIMenu.SubmenuTrigger
            {...rest}
            delay={delay}
            closeDelay={closeDelay}
            render={render ?? defaultRender}
            className={getSubmenuTriggerClassNames}
            ref={forwardedRef}
        >
            {children}
        </BaseUIMenu.SubmenuTrigger>
    );
});
