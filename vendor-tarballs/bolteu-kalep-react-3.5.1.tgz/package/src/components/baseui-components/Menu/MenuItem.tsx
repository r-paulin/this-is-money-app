import * as React from "react";

import {Menu as BaseUIMenu} from "@base-ui/react/menu";
import type {HTMLProps} from "@base-ui/react/utils/types";

import {ListItemLayout} from "@/components/baseui-components/ListItemLayout";
import {getItemDefaultClassNames} from "@/components/baseui-components/Menu/shared-styles";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Menu.Item
 * Single action row rendered inside `Menu.Popup`.
 * Renders a ListItemLayout.Root component internally, so you can use ListItemLayout slots if needed.
 *
 * Regular usage:
 * ```tsx
 * <Menu.Item>Profile</Menu.Item>
 * ```
 *
 * Composed with slots:
 * ```tsx
 * <Menu.Item>
 *   <ListItemLayout.Slot>
 *     <Icon size="md" />
 *   </ListItemLayout.Slot>
 *   <ListItemLayout.Content>
 *     <TypographyStack>
 *       <TypographyStack.Primary>Profile</TypographyStack.Primary>
 *       <TypographyStack.Secondary>View and edit your profile</TypographyStack.Secondary>
 *     </TypographyStack>
 *   </ListItemLayout.Content>
 *   <ListItemLayout.Slot>
 *     <ChevronRight size="md" />
 *   </ListItemLayout.Slot>
 * </Menu.Item>
 * ```
 */
export const MenuItem = React.forwardRef(function MenuItem(
    props: BaseUIMenu.Item.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, children, render, ...rest} = props;

    const getItemClassNames = React.useCallback(
        (state: BaseUIMenu.Item.State) => cx(getItemDefaultClassNames(state), addConsumerClasses(state, className)),
        [className],
    );

    const defaultRender = React.useCallback(
        (itemProps: HTMLProps, state: BaseUIMenu.Item.State) => {
            return (
                <ListItemLayout.Root {...itemProps} disabled={state.disabled}>
                    {children}
                </ListItemLayout.Root>
            );
        },
        [children],
    );

    return (
        <BaseUIMenu.Item {...rest} ref={forwardedRef} render={render ?? defaultRender} className={getItemClassNames}>
            {children}
        </BaseUIMenu.Item>
    );
});
