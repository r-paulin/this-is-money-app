import {Menu as BaseUIMenu} from "@base-ui/react/menu";

/**
 * Menu.SubmenuRoot
 *
 * Root container for a nested submenu branch inside a parent menu.
 */
export const MenuSubmenuRoot = BaseUIMenu.SubmenuRoot;
