import * as React from "react";

import {Menu as BaseUIMenu} from "@base-ui/react/menu";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

const DEFAULT_DELAY = 0;
const DEFAULT_CLOSE_DELAY = 0;

/**
 * ### Menu.Trigger
 * Interactive element that opens the menu.
 *
 * ```tsx
 * <Menu.Trigger>Open</Menu.Trigger>
 * ```
 */
export const MenuTrigger = React.forwardRef(function MenuTrigger<Payload>(
    props: BaseUIMenu.Trigger.Props<Payload>,
    forwardedRef: React.ForwardedRef<HTMLButtonElement>,
) {
    const {className, delay = DEFAULT_DELAY, closeDelay = DEFAULT_CLOSE_DELAY, ...rest} = props;

    const getTriggerClassNames = React.useCallback(
        (state: BaseUIMenu.Trigger.State) => cx(addConsumerClasses(state, className)),
        [className],
    );

    return (
        <BaseUIMenu.Trigger
            {...rest}
            delay={delay}
            closeDelay={closeDelay}
            className={getTriggerClassNames}
            ref={forwardedRef}
        />
    );
});
