import * as React from "react";

import {mergeProps, useRender} from "@base-ui/react";

import Cross from "@bolteu/kalep-react-icons/dist/Cross";

import {useChipContext} from "@/components/baseui-components/Chip/ChipContext";
import {cx} from "@/helpers/utils/cx";

import {withSize} from "./Chip.utils";

export interface ChipRemoveProps extends Omit<useRender.ComponentProps<"span">, "className"> {
    className?: string;
}

export const ChipRemove = React.forwardRef<HTMLSpanElement, ChipRemoveProps>(function ChipRemove(props, ref) {
    const {className, render, ...otherComponentProps} = props;
    const context = useChipContext();
    const removeHandler = context?.onRemove;
    const disabled = context?.disabled ?? false;

    const onRemove = React.useCallback(
        (event: React.MouseEvent<HTMLSpanElement>) => {
            if (disabled) return;
            // So that the click doesn't trigger the Chip's onClick
            event.stopPropagation();
            removeHandler?.(event);
        },
        [disabled, removeHandler],
    );

    const defaultProps: useRender.ElementProps<"span"> = {
        onClick: onRemove,
        role: "button",
        "aria-hidden": "true",
        className: cx("-mx-2 flex h-full cursor-pointer items-center pe-1 ps-2", className, {
            "pointer-events-none cursor-not-allowed": disabled,
        }),
        children: withSize(<Cross />, context?.size ?? "md"),
    };

    return useRender({
        defaultTagName: "span",
        render,
        ref,
        state: {},
        props: mergeProps<"span">(defaultProps, otherComponentProps),
    });
});
