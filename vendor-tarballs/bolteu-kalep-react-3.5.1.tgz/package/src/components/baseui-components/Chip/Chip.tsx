import {ChipIcon} from "./ChipIcon";
import {ChipRemove} from "./ChipRemove";
import {ChipRoot} from "./ChipRoot";

ChipRoot.displayName = "Chip";
ChipIcon.displayName = "Chip.Icon";
ChipRemove.displayName = "Chip.Remove";

export const Chip = Object.assign(ChipRoot, {
    Icon: ChipIcon,
    Remove: ChipRemove,
});
