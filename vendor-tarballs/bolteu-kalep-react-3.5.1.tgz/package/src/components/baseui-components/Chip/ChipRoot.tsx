import * as React from "react";

import {Toggle as BaseUIToggle} from "@base-ui/react";
import type {BaseUIEvent} from "@base-ui/react/utils/types";

import type {ChipContextValue} from "@/components/baseui-components/Chip/ChipContext";
import {ChipProvider} from "@/components/baseui-components/Chip/ChipContext";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

import type {ChipProps, ChipSize} from "./Chip.types";

const sizes: Record<ChipSize, string> = {
    xs: "h-6 px-2",
    sm: "h-7 px-3",
    md: "h-9 px-4",
};

/**
 * ### Composition guide
 * Regular usage:
 * ```tsx
 * <Chip>
 *   Label
 * </Chip>
 * ```
 *
 * With icon and remove action:
 * ```tsx
 * <Chip onRemove={handleRemove}>
 *   <Chip.Icon icon={<Lock size="sm" />} />
 *   Secure
 *   <Chip.Remove />
 * </Chip>
 * ```
 *
 * Include `Chip.Remove` when providing `onRemove` so the remove affordance is visible.
 */
export const ChipRoot = React.forwardRef<HTMLButtonElement, ChipProps>(function ChipRoot(
    props: ChipProps,
    ref: React.ForwardedRef<HTMLButtonElement>,
) {
    const {
        children,
        className,
        disabled = false,
        onClick,
        onRemove,
        onKeyDown,
        selected,
        size = "md",
        variant = "filled",
        ...restProps
    } = props;

    const isSimple = variant === "simple";
    const isOutlined = variant === "outline";
    const isClickable = typeof onClick === "function" && !disabled;
    const isSelected = selected ?? false;
    const isInvertedColorScheme = isSimple || isSelected;

    const handleKeyDown = React.useCallback(
        (event: BaseUIEvent<React.KeyboardEvent<HTMLButtonElement>>) => {
            onKeyDown?.(event);
            const removeHandler = onRemove;
            if (removeHandler && (event.key === "Backspace" || event.key === "Delete")) {
                removeHandler(event);
            }
        },
        [onKeyDown, onRemove],
    );

    const chipClassName = React.useCallback(
        (state: BaseUIToggle.State) => {
            const pressed = state.pressed ?? false;
            return cx(
                "inline-flex items-center justify-center gap-2 rounded-full border-[2px] border-solid",
                "border-neutral-secondary bg-neutral-secondary text-primary",
                "bolt-font-body-s-regular truncate",
                {
                    "cursor-default border-none": isSimple,
                    "cursor-pointer": !isSimple,
                    "hover:bg-active-neutral-secondary": !isSimple && !pressed,
                    "bg-active-neutral-secondary": pressed,
                    "active:scale-975 active:duration-100 active:ease-in-out": isClickable,
                    "bg-special-nulled dark:bg-special-nulled": isOutlined && !pressed,
                    "pointer-events-none": state.disabled,
                    "bg-neutral-primary text-primary-inverted": isInvertedColorScheme,
                },
                sizes[size],
                addConsumerClasses(state, className),
            );
        },
        [className, isClickable, isInvertedColorScheme, isOutlined, isSimple, size],
    );

    const contextValue = React.useMemo<ChipContextValue>(
        () => ({
            size,
            variant,
            disabled,
            selected: isSelected,
            onRemove,
        }),
        [disabled, isSelected, onRemove, size, variant],
    );

    return (
        <ChipProvider value={contextValue}>
            <BaseUIToggle
                {...restProps}
                onClick={onClick}
                onKeyDown={handleKeyDown}
                pressed={isSelected}
                disabled={disabled}
                className={chipClassName}
                ref={ref}
            >
                {children}
            </BaseUIToggle>
        </ChipProvider>
    );
});

ChipRoot.displayName = "Chip";
