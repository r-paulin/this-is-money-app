import * as React from "react";

import type {KalepIconElement} from "@bolteu/kalep-react-icons/dist/types";

import type {ChipSize} from "./Chip.types";

export function withSize(icon: KalepIconElement, size: ChipSize) {
    const actualSize = size === "md" ? "md" : "xs";
    return React.cloneElement(icon, {size: actualSize});
}
