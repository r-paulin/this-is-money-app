import * as React from "react";

import type {ChipVariant} from "@/components/Chip/Chip.types";

import type {ChipSize} from "./Chip.types";

export type ChipContextValue = {
    size: ChipSize;
    variant: ChipVariant;
    disabled: boolean;
    selected: boolean;
    onRemove?: (event: React.KeyboardEvent | React.MouseEvent) => void;
};

const ChipContext = React.createContext<ChipContextValue | null>(null);

export function ChipProvider({value, children}: {value: ChipContextValue; children: React.ReactNode}) {
    const memoValue = React.useMemo(
        () => value,
        [value.disabled, value.selected, value.size, value.variant, value.onRemove],
    );
    return <ChipContext.Provider value={memoValue}>{children}</ChipContext.Provider>;
}

export function useChipContext() {
    return React.useContext(ChipContext);
}
