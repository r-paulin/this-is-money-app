import * as React from "react";

import {mergeProps, useRender} from "@base-ui/react";

import type {KalepIconElement} from "@bolteu/kalep-react-icons/dist/types";

import {withSize} from "@/components/baseui-components/Chip/Chip.utils";
import {useChipContext} from "@/components/baseui-components/Chip/ChipContext";
import {cx} from "@/helpers/utils/cx";

export interface ChipIconProps extends Omit<useRender.ComponentProps<"span">, "className"> {
    icon?: KalepIconElement;
    children?: KalepIconElement;
    className?: string;
}

export const ChipIcon = React.forwardRef<HTMLSpanElement, ChipIconProps>(function ChipIcon(props, ref) {
    const {icon, children, className, render, ...otherComponentProps} = props;
    const context = useChipContext();
    const iconToRender = icon ?? children;

    const size = context?.size ?? "md";

    const defaultProps: useRender.ElementProps<"span"> = {
        className: cx(
            `
              -ms-1
              [&>svg]:block
            `,
            className,
        ),
        children: iconToRender ? withSize(iconToRender, size) : iconToRender,
    };

    return useRender({
        defaultTagName: "span",
        render,
        ref,
        state: {},
        props: mergeProps<"span">(defaultProps, otherComponentProps),
    });
});
