import * as React from "react";

import type {Meta, StoryFn} from "@storybook/react-webpack5";

import Heart from "@bolteu/kalep-react-icons/dist/Heart";
import Offer from "@bolteu/kalep-react-icons/dist/Offer";

import {Checkbox} from "@/components/Checkbox";
import {IconButton} from "@/components/IconButton";
import {cx} from "@/helpers/utils/cx";

import type {ListItemLayoutProps} from "../ListItemLayout";
import type {ListProps} from "./index";
import {List} from "./index";

export default {
    title: "Data Display/List",
    component: List.Root,
    tags: ["autodocs"],
} as Meta<typeof List>;

function renderStartSlot({disabled}: ListItemLayoutProps) {
    return <Offer size="md" className={cx(disabled ? "text-secondary" : "text-primary")} />;
}

const items: ListItemLayoutProps[] = [
    {
        renderStartSlot,
        key: "1",
        primary: "War and Peace",
        secondary: "Lev Tolstoy",
        renderEndSlot({disabled}) {
            return <IconButton disabled={disabled} icon={<Heart />} size="sm" aria-label="like War and Peace" />;
        },
    },
    {renderStartSlot, key: "2", primary: "A Picture of Dorian Gray", secondary: "Oscar Wilde"},
    {
        renderStartSlot,
        key: "3",
        primary: "Pride and Prejudice",
        secondary: "Jane Austen",
        renderEndSlot({disabled}) {
            return <Checkbox disabled={disabled} aria-label="read Crime and Punishment" defaultChecked />;
        },
    },
    {renderStartSlot, key: "4", primary: "1984", secondary: "George Orwell"},
];

export const Default: StoryFn<typeof List> = (args: ListProps) => (
    <div className="max-w-[400px]">
        <List.Root {...args}>
            {items.map(function renderItem(itemProps: ListItemLayoutProps) {
                return <List.Item key={itemProps.key} primary={itemProps.primary} secondary={itemProps.secondary} />;
            })}
        </List.Root>
    </div>
);

export const WithRenderSlots: StoryFn<typeof List> = (args: ListProps) => (
    <div className="max-w-[400px]">
        <List.Root {...args}>
            {items.map(function renderItem(itemProps: ListItemLayoutProps) {
                return <List.Item {...itemProps} />;
            })}
        </List.Root>
    </div>
);

export const WithDisabledItems: StoryFn<typeof List> = (args: ListProps) => (
    <div className="max-w-[400px]">
        <List.Root {...args}>
            {items.map(function renderItem(itemProps: ListItemLayoutProps, index: number) {
                return <List.Item {...itemProps} disabled={index % 2 === 0} />;
            })}
        </List.Root>
    </div>
);
