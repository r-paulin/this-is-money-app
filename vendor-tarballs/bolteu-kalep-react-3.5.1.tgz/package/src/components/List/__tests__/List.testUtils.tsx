import * as React from "react";

import type {RenderResult} from "@testing-library/react";
import {render, screen} from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import type {ListItemLayoutProps} from "@/components/ListItemLayout";

import {List} from "../List";
import type {ListProps} from "../List.types";

export * from "@testing-library/react";
export {userEvent};

export const defaultProps = {
    "aria-label": "best employees",
};

export const defaultItems: ListItemLayoutProps[] = [
    {
        primary: "John Dough",
        secondary: "Senior Staff Software Developer",
        disabled: false,
        key: "john",
    },
    {
        primary: "Jane Watson",
        secondary: "Chief Technology Officer",
        disabled: true,
        key: "jane",
    },
];

export function renderList(props?: Partial<ListProps>, items = defaultItems): RenderResult {
    const utils = render(
        <List.Root {...defaultProps} {...props}>
            {items.map(function renderItem(itemProps: ListItemLayoutProps) {
                return <List.Item {...itemProps} />;
            })}
        </List.Root>,
    );

    return utils;
}

export function getList(): HTMLUListElement {
    return screen.getByRole("list", {name: defaultProps["aria-label"]});
}

export function getItems(): HTMLLIElement[] {
    return screen.getAllByRole("listitem");
}
