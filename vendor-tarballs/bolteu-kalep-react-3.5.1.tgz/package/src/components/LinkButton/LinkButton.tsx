import * as React from "react";

import type {KalepIconElement} from "@bolteu/kalep-react-icons/dist/types";

import {cx} from "@/helpers/utils/cx";

type Size = "sm" | "md" | "lg";
type Variant = "primary" | "secondary" | "danger" | "tertiary" | "floating";

export interface LinkButtonVisualProps {
    size?: Size;
    variant?: Variant;
    disabled?: boolean;
    fullWidth?: boolean;
    startIcon?: KalepIconElement;
    endIcon?: KalepIconElement;
}

export interface LinkButtonProps extends LinkButtonVisualProps, Omit<React.ComponentPropsWithoutRef<"a">, "className"> {
    children?: React.ReactNode;
}

const sizes: Record<Size, string> = {
    sm: "px-4 py-0 h-9 gap-1 bolt-font-body-s-accent",
    md: "px-6 py-0 h-12 gap-2 bolt-font-body-m-accent",
    lg: "px-6 py-0 h-14 gap-2 bolt-font-body-l-accent",
};

const variants: Record<Variant, string> = {
    primary: "bg-action-primary hover:bg-active-action-primary active:bg-active-action-primary text-static-key-light",
    secondary: "bg-neutral-secondary hover:bg-active-neutral-secondary active:bg-active-neutral-secondary text-primary",
    danger: "bg-danger-primary hover:bg-active-danger-primary active:bg-active-danger-primary text-static-key-light",
    tertiary: "bg-special-nulled hover:bg-action-secondary active:bg-action-secondary text-action-primary",
    floating: "bg-layer-floor-2 shadow-md hover:shadow active:shadow disabled:shadow-md text-primary",
};

/**
 * Always set the size prop to the same value as the LinkButton size.
 * @returns IconElement with given size prop.
 */
function withSize(icon: KalepIconElement, size: Size): KalepIconElement {
    return React.cloneElement(icon, {size});
}

function LinkButton(
    {
        children,
        size = "md",
        variant = "primary",
        disabled = false,
        fullWidth = false,
        startIcon,
        endIcon,
        rel = "noopener",
        ...rest
    }: LinkButtonProps,
    ref: React.Ref<HTMLAnchorElement>,
) {
    const buttonContent = (
        <>
            {startIcon && withSize(startIcon, size)}
            {children}
            {endIcon && withSize(endIcon, size)}
        </>
    );

    return (
        <a
            className={cx(
                /* reset */ "no-underline",
                "relative inline-flex flex-none items-center justify-center rounded-full duration-150 ease-linear",
                fullWidth ? "w-full" : "w-fit",
                sizes[size],
                variants[variant],
                disabled
                    ? `
                      pointer-events-none cursor-not-allowed bg-neutral-secondary text-tertiary
                      hover:bg-neutral-secondary
                      active:bg-neutral-secondary
                    `
                    : "active:scale-975 active:duration-100 active:ease-in-out",
            )}
            style={variant === "primary" ? {backgroundImage: "var(--color-bg-action-primary)"} : {}} // allows gradient backgrounds
            ref={ref}
            rel={rel}
            {...rest}
        >
            {buttonContent}
        </a>
    );
}

const ForwardedLinkButton = React.forwardRef<HTMLAnchorElement, LinkButtonProps>(LinkButton);

export {ForwardedLinkButton as LinkButton};
