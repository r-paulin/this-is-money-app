import * as React from "react";

import type {Meta, StoryFn} from "@storybook/react-webpack5";

import {Island} from "./index";

export default {
    title: "Layout/Island",
    tags: ["autodocs"],
    component: Island,
} as Meta<typeof Island>;

const Template: StoryFn<typeof Island> = (args: any) => (
    <Island {...args}>Island defines the physical appearance of the block.</Island>
);

export const Default = Template.bind({});
Default.args = {};
