import * as React from "react";

import type {Meta} from "@storybook/react-webpack5";

import {Checkbox} from "@/components/Checkbox";
import {Island} from "@/components/Island";
import {Radio, RadioGroup} from "@/components/RadioGroup";
import {Select} from "@/components/Select";
import {TextField} from "@/components/TextField";

import {Grid} from "./Grid";

export default {
    title: "Layout/Grid",
    tags: ["autodocs"],
    component: Grid,
    // Downshift uses role="combobox" on Select trigger button and a11y plugin complains about it
    parameters: {
        a11y: {
            config: {
                rules: [
                    {
                        id: "aria-allowed-role",
                        enabled: false,
                    },
                ],
            },
        },
    },
} as Meta<typeof Grid>;

const Sample = ({children}: React.PropsWithChildren<unknown>) => (
    <Island elevation="surface">
        <div className="flex justify-center">{children}</div>
    </Island>
);

export const Simple = () => (
    <Grid columns={3}>
        <Sample>1</Sample>
        <Sample>2</Sample>
        <Sample>3</Sample>
    </Grid>
);

export const MixedItems = () => (
    <Grid columns={6}>
        <Grid.Item colSpan={3}>
            <Sample>colSpan=3 out of 6 column grid</Sample>
        </Grid.Item>
        <span>Inline element</span>
        <Sample>Regular block</Sample>
        <Sample>Regular block</Sample>
    </Grid>
);

export const MultiRow = () => (
    <Grid columns={2}>
        <Sample>1</Sample>
        <Sample>2</Sample>
        <Sample>3</Sample>
        <Sample>4</Sample>
    </Grid>
);

export const ColumnSpan = () => (
    <Grid columns={2}>
        <Sample>1</Sample>
        <Sample>2</Sample>
        <Grid.Item colSpan={2}>
            <section className="flex justify-center rounded-lg bg-warning-secondary p-5">3: colSpan=2</section>
        </Grid.Item>
        <Sample>4</Sample>
        <Sample>5</Sample>
    </Grid>
);

export const RowSpan = () => (
    <Grid columns={2}>
        <Sample>1</Sample>
        <Sample>2</Sample>
        <Grid.Item rowSpan={2}>
            <section className="grid h-full place-items-center rounded-lg bg-warning-secondary p-5">
                3: rowSpan=2
            </section>
        </Grid.Item>
        <Sample>4</Sample>
        <Sample>5</Sample>
        <Sample>6</Sample>
        <Sample>7</Sample>
    </Grid>
);

export const AdminForm = () => (
    <section className="max-w-[1232px]">
        <Island>
            <Grid columns={4}>
                <h2 className="m-0 font-sans text-xl font-normal">Section heading</h2>

                <Grid columns={12} colSpan={3}>
                    <Grid.Item colSpan={7}>
                        <TextField label="Code" size="sm" fullWidth />
                    </Grid.Item>
                    <Grid.Item colSpan={5}>
                        <TextField label="Visibility" size="sm" fullWidth />
                    </Grid.Item>

                    <Grid.Item colSpan={4}>
                        <TextField label="Code valid days" size="sm" fullWidth />
                    </Grid.Item>
                    <Grid.Item colSpan={4}>
                        <TextField label="Max usages by same riders" size="sm" fullWidth />
                    </Grid.Item>
                    <Grid.Item colSpan={4}>
                        <TextField label="Max Code Targets" size="sm" fullWidth />
                    </Grid.Item>

                    <hr className="col-span-full m-0 w-full border-0 border-t border-solid border-separator" />

                    <Grid columns={3} colSpan={12}>
                        <fieldset className="m-0 border-0 p-0">
                            <legend className="font-sans text-sm font-semibold">Campaign applies to</legend>
                            <div className="mt-3 flex flex-col gap-2">
                                <Checkbox label="Rides" />
                                <Checkbox label="Rental" />
                            </div>
                        </fieldset>
                        <fieldset className="m-0 border-0 p-0">
                            <legend className="font-sans text-sm font-semibold">Is first ride campaign</legend>
                            <div className="mt-3 flex flex-col gap-2">
                                <Checkbox label="Rides" />
                                <Checkbox label="Rental" />
                            </div>
                        </fieldset>
                        <fieldset className="m-0 border-0 p-0">
                            <legend className="font-sans text-sm font-semibold">Payment profile</legend>
                            <div className="mt-3 flex flex-col gap-2">
                                <Checkbox label="Personal" />
                                <Checkbox label="Work" />
                            </div>
                        </fieldset>
                    </Grid>

                    <hr className="col-span-full m-0 w-full border-0 border-t border-solid border-separator" />

                    <Grid columns={3} colSpan={12}>
                        <Select
                            label="Spend Objective"
                            required
                            options={[
                                {title: "Acquisition", value: 1},
                                {title: "Activation", value: 2},
                                {title: "Retention", value: 3},
                                {title: "Engagement", value: 4},
                            ]}
                            size="sm"
                            fullWidth
                        />
                        <TextField label="Spend target" name="spend_target" prefix="€" size="sm" fullWidth />
                        <TextField label="Spend target (GMV %)" name="spend_target_pc" prefix="%" size="sm" fullWidth />
                    </Grid>
                </Grid>
            </Grid>
        </Island>
    </section>
);

export const ItemVisibility = () => {
    const [visibility, setVisibility] = React.useState<"HIDDEN_LEAVE_HOLE" | "HIDDEN_REMOVE_FIELD" | "VISIBLE">(
        "VISIBLE",
    );
    const handleChange = React.useCallback((event) => setVisibility(event.target.value), []);

    return (
        <div className="flex flex-col gap-4">
            <RadioGroup name="blah" value={visibility} onChange={handleChange}>
                <label className="inline-flex gap-2">
                    <Radio value="VISIBLE" />
                    <code>visible=&quot;VISIBLE&quot;</code> <em>(default)</em>
                </label>
                <label className="inline-flex gap-2">
                    <Radio value="HIDDEN_LEAVE_HOLE" />
                    <code>visible=&quot;HIDDEN_LEAVE_HOLE&quot;</code>
                </label>
                <label className="inline-flex gap-2">
                    <Radio value="HIDDEN_REMOVE_FIELD" />
                    <code>visible=&quot;HIDDEN_REMOVE_FIELD&quot;</code>
                </label>
            </RadioGroup>

            <Island>
                <Grid columns={4}>
                    <Sample>1</Sample>
                    <Grid.Item visible={visibility}>
                        <section className="flex justify-center rounded-lg bg-warning-secondary p-5">2</section>
                    </Grid.Item>
                    <Sample>3</Sample>
                    <Sample>4</Sample>
                </Grid>
            </Island>
        </div>
    );
};

ItemVisibility.story = {
    parameters: {
        docs: {
            storyDescription: `
The "visible" prop on <code>Grid.Item</code> is a legacy feature carried over from Admin v1.
It can be used to conditionally show a grid item and choosing if an empty slot
should be left in the grid or the item skipped completely.\n\n
Play with the visibility of item 2:
            `,
        },
    },
};
