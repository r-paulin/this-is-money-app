import * as React from "react";

import {render, screen} from "@testing-library/react";

import {Grid} from "@/components/Layout/";

describe("Grid tests", () => {
    test("Grid component creates a div with display:grid style and 100% width", () => {
        const textContent = "Test grid styling";
        render(<Grid>{textContent}</Grid>);

        const gridElement = screen.getByText(textContent);
        expect(gridElement).toBeInTheDocument();
        expect(gridElement).toHaveAttribute("style");
        expect(window.getComputedStyle(gridElement).display).toBe("grid");
        expect(window.getComputedStyle(gridElement).width).toBe("100%");
    });

    test("Grid creates a 12 column grid on request", () => {
        const textContent = "Test grid styling";
        render(<Grid columns={12}>{textContent}</Grid>);

        const gridElement = screen.getByText(textContent);

        /**
         * Actually we want to do this:
         * expect(window.getComputedStyle(gridElement).gridTemplateColumns.split(" ").length).toBe(12);
         *
         * Browsers resolve the repeat statement like this:
         * in a 800px wide container grid-template-columns: repeat(4, 1fr) is calculated to:
         * "200px 200px 200px 200px", which would let us count how many pieces it created, without
         * having to know which style string exactly was applied.
         * However, it's not calculated in JSDOM: https://github.com/jsdom/cssstyle/issues/146
         *
         * So we just expect the same string to be found. Update when needed.
         */
        expect(window.getComputedStyle(gridElement).gridTemplateColumns).toBe("repeat(12, minmax(10px, 1fr))");
    });

    test("Grid gap px value is calculated by multiplying the gap prop value with 4 (spacing step)", () => {
        const textContent = "Test grid styling";
        const spacingStep = 4;
        const gap = 3;
        render(
            <Grid columns={2} gap={gap}>
                {textContent}
            </Grid>,
        );

        const gridElement = screen.getByText(textContent);
        expect(window.getComputedStyle(gridElement).gap).toBe(`${gap * spacingStep}px`);
    });

    test.todo("Grid can behave as a grid item and accepts span props");
    test.todo("Grid.Item styles (start, span) are applied correctly");
    test.todo("Grid.Item visible prop is handled correctly");
});
