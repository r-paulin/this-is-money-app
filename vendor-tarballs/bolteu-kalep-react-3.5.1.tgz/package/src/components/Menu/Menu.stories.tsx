import * as React from "react";

import type {Meta, StoryFn} from "@storybook/react-webpack5";

import {LogOut} from "@bolteu/kalep-react-icons";
import AddressDot from "@bolteu/kalep-react-icons/dist/AddressVisited";
import Check from "@bolteu/kalep-react-icons/dist/Check";
import Heart from "@bolteu/kalep-react-icons/dist/Heart";
import HeartOutlined from "@bolteu/kalep-react-icons/dist/HeartOutlined";
import OpenIn from "@bolteu/kalep-react-icons/dist/OpenIn";

import {Button} from "@/components/Button";
import {cx} from "@/helpers/utils/cx";

import type {MenuItemClickEvent, MenuItemProps} from "./index";
import {Menu, MenuDivider, MenuHeader, MenuItem, SubMenu} from "./index";
import type {MenuItemRenderProps} from "./Menu.types";

export default {
    title: "Navigation/Menu",
    component: Menu,
    tags: ["autodocs"],
} as Meta<typeof Menu>;

const menuButton = <Button variant="tertiary">Open menu</Button>;

const renderHeart = (item: MenuItemProps) => {
    return item.value ? (
        <Heart className={cx("text-danger-secondary")} />
    ) : (
        <HeartOutlined className={cx("text-tertiary")} />
    );
};

const renderOnline = () => <AddressDot className={cx("text-positive-primary")} />;
const renderBusy = () => <AddressDot className={cx("text-warning-primary")} />;
const renderOffline = () => <AddressDot className={cx("text-danger-secondary")} />;

const renderCheck = () => <Check className={cx("text-primary")} />;

const renderCustomLabel = () => (
    <p className="m-0">
        I am quite <span className={cx("font-semibold text-danger-primary")}>busy</span>
    </p>
);

const renderLink = () => <OpenIn className={cx("text-primary")} />;

export const Default: StoryFn<typeof Menu> = () => {
    const handleClick = React.useCallback((event: MenuItemClickEvent) => {
        alert(`Item clicked: ${event.value}`);
        console.log("Item clicked full data", event);
    }, []);

    return (
        <Menu menuButton={menuButton}>
            <MenuItem value={1} onClick={handleClick} label="One" />
            <MenuItem value={2} onClick={handleClick} label="Two" />
            <MenuItem value={3} onClick={handleClick} label="Three" />
        </Menu>
    );
};

export const CustomRenderers: StoryFn<typeof Menu> = () => {
    return (
        <div className="flex gap-4">
            <Menu menuButton={<Button variant="tertiary">Render start</Button>}>
                <MenuItem label="Online" renderStartSlot={renderOnline} />
                <MenuItem label="Busy" renderStartSlot={renderBusy} />
                <MenuItem label="Offline" renderStartSlot={renderOffline} />
            </Menu>
            <Menu menuButton={<Button variant="tertiary">Render end</Button>}>
                <MenuItem label="Online" renderEndSlot={renderHeart} value={1} />
                <MenuItem label="Busy" renderEndSlot={renderHeart} />
                <MenuItem label="Offline" renderEndSlot={renderHeart} />
            </Menu>
            <Menu menuButton={<Button variant="tertiary">Render start and end</Button>}>
                <MenuItem label="Online" renderStartSlot={renderOnline} renderEndSlot={renderCheck} />
                <MenuItem label="Busy" renderStartSlot={renderBusy} />
                <MenuItem label="Offline" renderStartSlot={renderOffline} />
            </Menu>
            <Menu menuButton={<Button variant="tertiary">Custom label</Button>}>
                <MenuItem label="Online" />
                <MenuItem renderLabel={renderCustomLabel} renderEndSlot={renderCheck} />
                <MenuItem label="Offline" />
            </Menu>
        </div>
    );
};

export const Submenu: StoryFn<typeof Menu> = () => {
    return (
        <Menu menuButton={menuButton}>
            <MenuItem label="Profile" />
            <SubMenu label="Settings">
                <MenuItem label="Account" />
                <MenuItem label="Billing" />
                <MenuItem label="General" />
            </SubMenu>
            <MenuItem label="Help" />
        </Menu>
    );
};

export const Overflows: StoryFn<typeof Menu> = () => {
    return (
        <div className="flex gap-2">
            <Menu menuButton={<Button variant="tertiary">Default</Button>} overrideClassName="w-60">
                <MenuItem label="Label" />
                <MenuItem label="Another label" />
                <MenuItem label="Long label that does not seem to fit" />
            </Menu>
            <Menu menuButton={<Button variant="tertiary">Wrapped text</Button>} overrideClassName="w-60">
                <MenuItem label="Label" />
                <MenuItem label="Another label" />
                <MenuItem label="Long label that does not seem to fit" wrapText />
            </Menu>
        </div>
    );
};

export const DisabledItems: StoryFn<typeof Menu> = () => {
    return (
        <Menu menuButton={menuButton}>
            <MenuItem label="Copy" />
            <MenuItem label="Cut" />
            <MenuItem label="Paste is disabled" disabled />
            <MenuItem label="Undo" />
        </Menu>
    );
};

export const LinkItems: StoryFn<typeof Menu> = () => {
    return (
        <Menu menuButton={menuButton}>
            <MenuItem label="Profile" />
            <MenuItem label="Settings" />
            <MenuItem label="Careers" href="https://bolt.eu/en/careers" renderEndSlot={renderLink} target="_blank" />
        </Menu>
    );
};

export const Description: StoryFn<typeof Menu> = () => {
    return (
        <Menu menuButton={menuButton}>
            <MenuItem
                label="Solved"
                description="Solution was offered to the user longlongtext"
                renderEndSlot={renderCheck}
            />
            <MenuItem label="Pending" description="More info is required from the user" />
            <MenuItem label="On hold" description="Issue needs more investigation" />
        </Menu>
    );
};

export const Divider: StoryFn<typeof Menu> = () => {
    return (
        <Menu menuButton={menuButton}>
            <MenuItem label="Online" />
            <MenuItem label="Away" />
            <MenuDivider />
            <MenuItem label="Sign out" />
        </Menu>
    );
};

export const CustomHeader: StoryFn<typeof Menu> = () => {
    return (
        <div className="flex gap-4">
            <Menu menuButton={<Button variant="tertiary">Basic text</Button>}>
                <MenuHeader>
                    <p className="px-4 py-2 font-sans text-sm font-semibold text-primary">Set status</p>
                </MenuHeader>
                <MenuItem label="Online" />
                <MenuItem label="Away" />
                <MenuDivider />
                <MenuItem label="Sign out" />
            </Menu>
            <Menu menuButton={<Button variant="tertiary">Complex components</Button>}>
                <MenuHeader>
                    <div className="flex items-center justify-start gap-3 px-4 py-2 font-sans">
                        <div className={`
                          relative flex h-12 w-12 items-center justify-center rounded-full bg-neutral-secondary text-xl
                          text-secondary
                        `}>
                            <span>E</span>
                            <div className={`
                              absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-solid border-[white]
                              bg-positive-primary
                            `} />
                        </div>
                        <div>
                            <div className="text-base text-primary">Elvy Kalep</div>
                            <div className="text-sm text-tertiary">Online</div>
                        </div>
                    </div>
                </MenuHeader>
                <MenuItem label="Profile" />
                <MenuItem label="Settings" />
                <MenuDivider />
                <MenuItem label="Sign out" />
            </Menu>
        </div>
    );
};

const CustomLink = React.forwardRef(
    (
        {
            to,
            children,
            onClick,
            className,
        }: {to: string; children: React.ReactNode} & React.HTMLAttributes<HTMLAnchorElement>,
        ref,
    ) => {
        const handleClick = React.useCallback(
            (event: React.MouseEvent<HTMLAnchorElement>) => {
                alert(`You are going to be redirected to ${to} any moment now! 🚀`);
                onClick?.(event);
            },
            [to, onClick],
        );

        return (
            <a ref={ref as React.LegacyRef<HTMLAnchorElement>} href={to} onClick={handleClick} className={className}>
                {children}
            </a>
        );
    },
);
CustomLink.displayName = "CustomLink";

const renderCustomLink = (to: string, label: React.ReactNode) => {
    return ({className, ...rest}: MenuItemRenderProps) => (
        <CustomLink to={to} className={cx(className, "flex justify-between")} {...rest}>
            {label}
        </CustomLink>
    );
};

export const CustomMenuItems: StoryFn<typeof Menu> = () => {
    return (
        <Menu menuButton={menuButton}>
            <MenuItem render={renderCustomLink("/?path=/story/menus-menu--custom-menu-items/profile", "Profile")} />
            <SubMenu label="Directory">
                <MenuItem
                    render={renderCustomLink("/?path=/story/menus-menu--custom-menu-items/suppliers", "Suppliers")}
                />
                <MenuItem render={renderCustomLink("/?path=/story/menus-menu--custom-menu-items/users", "Users")} />
                <MenuItem
                    render={renderCustomLink(
                        "/?path=/story/menus-menu--custom-menu-items/logout",
                        <>
                            Log out
                            <LogOut />
                        </>,
                    )}
                />
            </SubMenu>
        </Menu>
    );
};

export const HoverableMenu: StoryFn<typeof Menu> = () => {
    const handleClick = React.useCallback((event: MenuItemClickEvent) => {
        alert(`Item clicked: ${event.value}`);
        console.log("Item clicked full data", event);
    }, []);

    return (
        <Menu menuButton={menuButton} openOnHover>
            <MenuItem value={1} onClick={handleClick} label="One" />
            <MenuItem value={2} onClick={handleClick} label="Two" />
            <MenuItem value={3} onClick={handleClick} label="Three" />
        </Menu>
    );
};

export const Controlled: StoryFn<typeof Menu> = () => {
    const [open, setOpen] = React.useState(false);

    return (
        <Menu menuButton={menuButton} open={open} onOpenChange={setOpen}>
            <MenuItem value={1} label="One" />
            <MenuItem value={2} label="Two" />
            <MenuItem value={3} label="Three" />
        </Menu>
    );
};

export const ControlledHover: StoryFn<typeof Menu> = () => {
    const [open, setOpen] = React.useState(false);

    return (
        <Menu menuButton={menuButton} open={open} onOpenChange={setOpen} openOnHover>
            <MenuItem value={1} label="One" />
            <MenuItem value={2} label="Two" />
            <MenuItem value={3} label="Three" />
        </Menu>
    );
};
