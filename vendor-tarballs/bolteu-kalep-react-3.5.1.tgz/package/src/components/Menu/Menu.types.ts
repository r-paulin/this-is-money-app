import type React from "react";

import type {
    ClickEvent,
    ControlledMenuProps as InnerMenuProps,
    MenuButtonModifiers,
    MenuItemTypeProp,
    RenderProp,
} from "@szhsin/react-menu";

export interface MenuProps extends Omit<InnerMenuProps, "className" | "state" | "onClose"> {
    overrideClassName?: string;
    /**
     * If true, the menu will open on hover.
     */
    openOnHover?: boolean;
    open?: boolean;
    onOpenChange?: (open: boolean) => void;

    /**
     * Can be a `MenuButton`, a `button` element, or a React component.
     * It also can be a render function that returns one.
     *
     * If a React component is provided, it needs to implement the following contracts:
     * - Accepts a `ref` prop that is forwarded to an element to which menu will be positioned.
     * The element should be able to receive focus.
     * - Accepts `onClick` and `onKeyDown` event props.
     */
    menuButton: RenderProp<MenuButtonModifiers, React.ReactElement>; // ControlledMenuProps does not
}

export interface MenuItemRenderProps {
    /**
     * Indicates if the focusable item is disabled.
     */
    disabled: boolean;
    /**
     * Indicates if the focusable item is being hovered.
     */
    hover: boolean;
    /**
     * A ref to be attached to the element which should receive focus when this focusable item is hovered.
     *
     * If you render a React component, it needs to expose a `focus` method or implement ref forwarding.
     */
    ref: React.RefObject<any>;
    onClick: ({detail}: {detail: number}) => void;
    className?: string;
}

export interface MenuItemProps {
    label?: string | React.ReactNode;
    value?: string | number | boolean; // Allowing only primitive types for now
    description?: string;
    disabled?: boolean;
    wrapText?: boolean;
    href?: string;
    target?: string;
    onClick?: MenuItemClickEventHandler;
    renderStartSlot?: (props: MenuItemProps) => React.ReactNode;
    renderEndSlot?: (props: MenuItemProps) => React.ReactNode;
    renderLabel?: (props: MenuItemProps) => React.ReactNode;
    render?: (props: MenuItemRenderProps) => React.ReactNode;
}

export interface SubMenuProps {
    label: string;
    children: React.ReactNode;
}
export interface SubMenuLabelProps {
    label: string;
}

export type MenuItemClickEventHandler = (event: ClickEvent) => void;

export type MenuItemClickEvent = ClickEvent;

export interface MenuItemClassnameProps {
    type?: MenuItemTypeProp | undefined;
    disabled: boolean;
    hover: boolean;
    checked: boolean;
    anchor: boolean;
}
