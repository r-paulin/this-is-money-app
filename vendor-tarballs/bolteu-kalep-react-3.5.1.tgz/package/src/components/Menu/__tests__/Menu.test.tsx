import * as React from "react";

import {vi} from "vitest";
import {render as testingLibraryRender, screen, waitFor} from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import {Button} from "../../Button";
import {Menu, MenuItem} from "../index";
import {SubMenu} from "../Menu";
import type {MenuProps} from "../Menu.types";

const menuButtonLabel = "Testbutton";
const menuButton = <Button>{menuButtonLabel}</Button>;
const menuItems = [<MenuItem key={1} label="Foo" />, <MenuItem key={2} label="Bar" />];

function render(
    props: MenuProps = {
        menuButton,
        children: menuItems,
    },
) {
    const {rerender} = testingLibraryRender(<Menu {...props} />);
    return (propsOverride: Partial<MenuProps>) => rerender(<Menu {...props} {...propsOverride} />);
}

describe("Menu test suite", () => {
    test("renders button and closed menu to document", () => {
        render();
        expect(screen.getByText(menuButtonLabel)).toBeInTheDocument();
        expect(screen.queryByText("Foo")).toBeInTheDocument();
        expect(screen.queryByText("Foo")).not.toBeVisible();
    });

    test("renders button that is focusable", async () => {
        render();
        const user = userEvent.setup();
        await user.tab();
        expect(screen.getByRole("button", {name: menuButtonLabel})).toHaveFocus();
    });

    test("opens menu items upon clicking menu button", async () => {
        render();
        const user = userEvent.setup();
        await user.click(screen.getByText(menuButtonLabel));

        expect(screen.getByText("Foo")).toBeInTheDocument();
        expect(screen.getByText("Bar")).toBeInTheDocument();
    });

    test("opens menu items using space", async () => {
        render();
        const user = userEvent.setup();
        await user.tab();
        await user.keyboard("[Space]");

        expect(screen.getByText("Foo")).toBeInTheDocument();
    });

    test("opens menu items using enter", async () => {
        render();
        const user = userEvent.setup();
        await user.tab();
        await user.keyboard("[Enter]");

        expect(screen.getByText("Foo")).toBeInTheDocument();
    });

    test("opens menu items using arrow down", async () => {
        render();
        const user = userEvent.setup();
        await user.tab();
        await user.keyboard("[ArrowDown]");

        expect(screen.getByText("Foo")).toBeInTheDocument();
    });

    // TODO: Investigate why the following test fails
    test.skip("closes menu items using escape", async () => {
        render();
        const user = userEvent.setup();
        await user.click(screen.getByText(menuButtonLabel));
        expect(screen.getByRole("menu")).toBeVisible();

        await user.keyboard("[Escape]");
        await waitFor(() => expect(screen.getByRole("menu")).not.toBeVisible());
    });

    test("handles item click event properly", async () => {
        const onItemClick = vi.fn();
        const itemLabel = "Foo";
        const itemValue = 123;

        render({onItemClick, menuButton, children: [<MenuItem value={itemValue} label={itemLabel} key={1} />]});

        const user = userEvent.setup();
        await user.click(screen.getByText(menuButtonLabel));
        await user.click(screen.getByText(itemLabel));

        expect(onItemClick).toHaveBeenCalledTimes(1);
        expect(onItemClick).toHaveBeenCalledWith(
            expect.objectContaining({
                value: itemValue,
                // Expecting synthetic event here is complex due to timestamps
            }),
        );
    });
});

describe("Hoverable menu test suite", () => {
    test("renders button and closed menu to document", () => {
        render({menuButton, children: menuItems, openOnHover: true});
        expect(screen.getByText(menuButtonLabel)).toBeInTheDocument();
        const menuItem = screen.queryByText("Foo");
        expect(menuItem).toBeInTheDocument();
        expect(menuItem).not.toBeVisible();
    });

    test("renders button that is focusable", async () => {
        render({menuButton, children: menuItems, openOnHover: true});
        const user = userEvent.setup();
        await user.tab();
        expect(screen.getByRole("button", {name: menuButtonLabel})).toHaveFocus();
    });

    test("opens menu items upon clicking menu button", async () => {
        render({menuButton, children: menuItems, openOnHover: true});
        const user = userEvent.setup();
        await user.click(screen.getByText(menuButtonLabel));

        expect(screen.getByText("Foo")).toBeInTheDocument();
        expect(screen.getByText("Bar")).toBeInTheDocument();
    });

    test("opens menu items upon hovering on menu button", async () => {
        render({menuButton, children: menuItems, openOnHover: true});
        const user = userEvent.setup();
        await user.hover(screen.getByText(menuButtonLabel));

        expect(screen.getByText("Foo")).toBeInTheDocument();
        expect(screen.getByText("Bar")).toBeInTheDocument();
    });

    test("opens menu items using space", async () => {
        render({menuButton, children: menuItems, openOnHover: true});
        const user = userEvent.setup();
        await user.tab();
        await user.keyboard("[Space]");

        expect(screen.getByText("Foo")).toBeInTheDocument();
    });

    test("opens menu items using enter", async () => {
        render({menuButton, children: menuItems, openOnHover: true});
        const user = userEvent.setup();
        await user.tab();
        await user.keyboard("[Enter]");

        expect(screen.getByText("Foo")).toBeInTheDocument();
    });

    test("opens menu items using arrow down", async () => {
        render({menuButton, children: menuItems, openOnHover: true});
        const user = userEvent.setup();
        await user.tab();
        await user.keyboard("[ArrowDown]");

        expect(screen.getByText("Foo")).toBeInTheDocument();
    });

    // TODO: Investigate why the following test fails
    test.skip("closes menu items using escape", async () => {
        render({menuButton, children: menuItems, openOnHover: true});
        const user = userEvent.setup();
        await user.click(screen.getByText(menuButtonLabel));
        expect(screen.getByRole("menu")).toBeVisible();

        await user.keyboard("[Escape]");
        await waitFor(() => expect(screen.getByRole("menu")).not.toBeVisible());
    });

    test("handles item click event properly", async () => {
        const onItemClick = vi.fn();
        const itemLabel = "Foo";
        const itemValue = 123;

        render({
            onItemClick,
            menuButton,
            children: [<MenuItem value={itemValue} label={itemLabel} key={1} />],
            openOnHover: true,
        });

        const user = userEvent.setup();
        await user.click(screen.getByText(menuButtonLabel));
        await user.click(screen.getByText(itemLabel));

        expect(onItemClick).toHaveBeenCalledTimes(1);
        expect(onItemClick).toHaveBeenCalledWith(
            expect.objectContaining({
                value: itemValue,
                // Expecting synthetic event here is complex due to timestamps
            }),
        );
    });
});

describe("Submenu test suite", () => {
    test("opens submenu upon clicking submenu parent menuitem", async () => {
        const submenuLabel = "Foo";
        const submenuItemLabel = "Bar";
        render({
            menuButton,
            children: [
                <SubMenu label={submenuLabel} key={1}>
                    <MenuItem label={submenuItemLabel} key={2} />
                </SubMenu>,
            ],
        });

        const user = userEvent.setup();
        await user.click(screen.getByText(menuButtonLabel));

        expect(screen.getByText(submenuLabel)).toBeInTheDocument();
        expect(screen.queryByText(submenuItemLabel)).not.toBeInTheDocument();
        await user.click(screen.getByText(submenuLabel));

        expect(screen.getByText(submenuItemLabel)).toBeInTheDocument();
    });

    test("opens submenu upon hovering submenu parent menuitem", async () => {
        const submenuLabel = "Foo";
        const submenuItemLabel = "Bar";
        render({
            menuButton,
            children: [
                <SubMenu label={submenuLabel} key={1}>
                    <MenuItem label={submenuItemLabel} key={2} />
                </SubMenu>,
            ],
        });

        const user = userEvent.setup();
        await user.click(screen.getByText(menuButtonLabel));

        expect(screen.getByText(submenuLabel)).toBeInTheDocument();
        expect(screen.queryByText(submenuItemLabel)).not.toBeInTheDocument();

        await user.hover(screen.getByText(submenuLabel));
        // TODO: Figure out a better way to handle timeouts!
        await waitFor(() => expect(screen.getByText(submenuItemLabel)).toBeInTheDocument());
    });
});

describe("MenuItem test suite", () => {
    test("handles click event properly", async () => {
        const clickHandler = vi.fn();
        const itemLabel = "Foo";
        const itemValue = 123;

        render({
            menuButton,
            children: [<MenuItem value={itemValue} label={itemLabel} onClick={clickHandler} key={1} />],
        });

        const user = userEvent.setup();
        await user.click(screen.getByText(menuButtonLabel));
        await user.click(screen.getByText(itemLabel));

        expect(clickHandler).toHaveBeenCalledTimes(1);
        expect(clickHandler).toHaveBeenCalledWith(
            expect.objectContaining({
                value: itemValue,
                // Expecting synthetic event here is complex due to timestamps
            }),
        );
    });

    test("renders custom label", async () => {
        const label = "Foo";
        const customLabel = "Bar";
        const mockRender = vi.fn(() => <p>{customLabel}</p>);

        render({
            menuButton,
            children: [<MenuItem label={label} key={1} renderLabel={mockRender} />],
        });

        const user = userEvent.setup();
        await user.click(screen.getByText(menuButtonLabel));

        expect(screen.queryByText(label)).not.toBeInTheDocument();
        expect(screen.queryByText(customLabel)).toBeInTheDocument();
        expect(mockRender).toHaveBeenCalled();
    });

    test("renders custom start and end slot", async () => {
        const label = "Foo";
        const startSlotLabel = "Bar";
        const endSlotLabel = "Baz";
        const mockRenderStart = vi.fn(() => <p>{startSlotLabel}</p>);
        const mockRenderEnd = vi.fn(() => <p>{endSlotLabel}</p>);

        render({
            menuButton,
            children: [
                <MenuItem label={label} key={1} renderStartSlot={mockRenderStart} renderEndSlot={mockRenderEnd} />,
            ],
        });

        const user = userEvent.setup();
        await user.click(screen.getByText(menuButtonLabel));

        expect(screen.queryByText(label)).toBeInTheDocument();
        expect(screen.queryByText(startSlotLabel)).toBeInTheDocument();
        expect(screen.queryByText(endSlotLabel)).toBeInTheDocument();

        expect(mockRenderStart).toHaveBeenCalled();
        expect(mockRenderEnd).toHaveBeenCalled();
    });

    test("renders description", async () => {
        const label = "Foo";
        const description = "Bar";

        render({
            menuButton,
            children: [<MenuItem label={label} key={1} description={description} />],
        });

        const user = userEvent.setup();
        await user.click(screen.getByText(menuButtonLabel));

        expect(screen.queryByText(label)).toBeInTheDocument();
        expect(screen.queryByText(description)).toBeInTheDocument();
    });

    test("does not fire onclick when disabled", async () => {
        const label = "Foo";
        const clickHandler = vi.fn();

        render({
            menuButton,
            children: [<MenuItem label={label} key={1} onClick={clickHandler} disabled />],
        });

        const user = userEvent.setup();
        await user.click(screen.getByText(menuButtonLabel));
        await user.click(screen.getByText(label));

        expect(clickHandler).not.toHaveBeenCalled();
    });

    test("renders link properly", async () => {
        const label = "Foo";
        const link = "https://bolt.eu/";

        render({
            menuButton,
            children: [<MenuItem label={label} key={1} href={link} />],
        });

        const user = userEvent.setup();
        await user.click(screen.getByText(menuButtonLabel));

        expect(screen.getByText(label).closest("a")).toHaveAttribute("href", link);
    });
});
