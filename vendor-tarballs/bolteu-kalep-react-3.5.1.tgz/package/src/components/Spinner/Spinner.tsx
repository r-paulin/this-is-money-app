import * as React from "react";

import {SpinnerIcon, type SpinnerIconSize} from "@/components/_internal/SpinnerIcon";
import {cx} from "@/helpers/utils/cx";

export type SpinnerSizes = Extract<SpinnerIconSize, 400 | 500 | 600 | 700 | "inherit">;
export type SpinnerColors = keyof typeof colorsToClassnamesMap;

export type SpinnerProps = {
    size?: SpinnerSizes;
    color?: SpinnerColors | string;
};

const colorsToClassnamesMap = {
    // FIXME: we can do without this because we have the color css custom properties
    primary: "text-primary",
    "primary-inverted": "text-primary-inverted",
    secondary: "text-secondary",
    tertiary: "text-tertiary",
    "action-primary": "text-action-primary",
    "action-secondary": "text-action-secondary",
    "danger-primary": "text-danger-primary",
    "danger-secondary": "text-danger-secondary",
    "warning-primary": "text-warning-primary",
    "warning-secondary": "text-warning-secondary",
    "positive-primary": "text-positive-primary",
    "positive-secondary": "text-positive-secondary",
    "promo-primary": "text-promo-primary",
    "promo-secondary": "text-promo-secondary",
    "link-primary": "text-link-primary",
    "link-secondary": "text-link-secondary",
};

export function Spinner({size = 500, color}: SpinnerProps) {
    const colorName = color ?? "action-primary";
    const isCustomColor = color && !Object.keys(colorsToClassnamesMap).includes(color);

    return (
        <SpinnerIcon
            role="status"
            size={size}
            className={cx(
                "inline-block animate-spin",
                isCustomColor ? colorName : colorsToClassnamesMap[colorName as SpinnerColors],
            )}
        />
    );
}
