import * as React from "react";

import type {KalepIcon} from "@bolteu/kalep-react-icons";
import Clear from "@bolteu/kalep-react-icons/dist/Clear";

import {cx} from "@/helpers/utils/cx";

import {Tooltip} from "../Tooltip";

export interface ClearInputButtonProps {
    clearTextLabel?: string;
    onClick: () => void;
    size?: KalepIcon["size"];
    buttonClassname?: string;
}

export function ClearInputButton({clearTextLabel, onClick, size, buttonClassname}: ClearInputButtonProps): JSX.Element {
    return (
        <Tooltip content={clearTextLabel || ""}>
            <button
                aria-label={clearTextLabel}
                className={cx("group/clearbutton cursor-pointer border-0 bg-transparent p-1", buttonClassname)}
                onClick={onClick}
                type="button"
            >
                <Clear
                    aria-hidden="true"
                    className={cx("block text-tertiary", "group-hover/clearbutton:text-secondary")}
                    size={size}
                />
            </button>
        </Tooltip>
    );
}
