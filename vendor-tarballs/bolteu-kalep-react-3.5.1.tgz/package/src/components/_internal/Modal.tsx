import React from "react";

import {AlertDialog as RadixAlertDialog, Dialog as RadixDialog} from "radix-ui";

import {Cross} from "@bolteu/kalep-react-icons";

import {cx} from "@/helpers/utils/cx";
import {IconButton} from "@/index";

export const KALEP_MODAL_CONTENT_ID = "kalep__modal-content";

type ModalContextType = {isOpen: boolean; isOverflowVisible?: boolean};
export const ModalContext = React.createContext<ModalContextType>({isOpen: false, isOverflowVisible: false});

export interface ModalHeaderProps {
    title: string | React.ReactNode;
    variant?: "default" | "alert";
    onClose: () => void;
}

export interface ModalContentProps {
    children: React.ReactNode;
}
export interface ModalFooterProps {
    children: React.ReactNode;
}

export interface ModalCloseProps {
    onClose: () => void;
    autoFocus?: boolean;
}

export function ModalHeader({title, variant, onClose}: ModalHeaderProps) {
    return (
        <div
            className={cx(
                "flex items-baseline gap-6 px-6 pb-4 pt-5",
                variant === "alert" ? "justify-center" : "justify-between",
            )}
            data-kalep-comp="dialog/header"
        >
            {title && <span className={cx("bolt-font-heading-s-accent text-primary")}>{title}</span>}
            {/* eslint-disable-next-line jsx-a11y/no-autofocus -- I don't know why its here, I am just refactoring eslint atm */}
            {variant === "default" ? <ModalClose onClose={onClose} autoFocus /> : null}
        </div>
    );
}

export function RadixModalHeader({title, variant, onClose}: ModalHeaderProps) {
    const RaxixDialogTitleComponent = variant === "alert" ? RadixAlertDialog.Title : RadixDialog.Title;
    return (
        <div
            className={cx(
                "flex items-baseline gap-6 px-6 pb-4 pt-5",
                variant === "alert" ? "justify-center" : "justify-between",
            )}
            data-kalep-comp="dialog/header"
        >
            {title && (
                <RaxixDialogTitleComponent asChild>
                    <span className={cx("bolt-font-heading-s-accent text-primary")}>{title}</span>
                </RaxixDialogTitleComponent>
            )}

            {/* eslint-disable-next-line jsx-a11y/no-autofocus -- I don't know why its here, I am just refactoring eslint atm */}
            {variant === "default" ? <ModalClose onClose={onClose} autoFocus /> : null}
        </div>
    );
}

export function ModalContent({children}: ModalContentProps) {
    const contentRef = React.useRef<HTMLElement>(null);

    React.useLayoutEffect(() => {
        const contentElement = contentRef.current;
        if ((contentElement?.scrollHeight || 0) > (contentElement?.clientHeight || 0)) {
            contentElement?.classList.add("border-y");
            contentElement?.classList.add("border-y-separator");
        }
    }, []);

    return (
        <section
            ref={contentRef}
            className={cx(
                "border-0 border-solid px-6 py-2",
                "flex-grow",
                "text-base font-normal text-primary",
                "overflow-y-auto",
            )}
            data-kalep-comp="basemodal/content"
        >
            {children}
        </section>
    );
}

export function ModalFooter({children}: ModalFooterProps) {
    const [primaryAction, secondaryAction, ...remainingActions] = React.Children.toArray(children);

    return (
        <footer className={cx("px-6 pb-6 pt-4")} data-kalep-comp="basemodal/footer">
            <div className={cx("flex flex-row-reverse justify-between gap-4")}>
                <div className={cx("flex flex-row-reverse gap-4")}>
                    {primaryAction}
                    {secondaryAction}
                </div>
                {remainingActions.length > 0 && <div>{remainingActions}</div>}
            </div>
        </footer>
    );
}

export function ModalClose({onClose, autoFocus}: ModalCloseProps) {
    return (
        <IconButton
            overrideClassName="-mt-1 -me-1"
            icon={<Cross />}
            size="sm"
            onClick={onClose}
            aria-label="Close"
            // eslint-disable-next-line jsx-a11y/no-autofocus -- I don't know why its here, I am just refactoring eslint atm
            autoFocus={autoFocus}
        />
    );
}
