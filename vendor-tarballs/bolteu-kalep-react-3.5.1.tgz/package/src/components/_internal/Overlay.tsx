import type {AriaPositionProps} from "@react-aria/overlays";

export interface OverlayProps {
    minWidth?: number;
    maxWidth?: number;
    position?: Partial<AriaPositionProps>;
}

export function guessOverlayPosition(target: HTMLElement): number {
    const {top, height} = target.getBoundingClientRect();
    const {clientHeight} = document.documentElement;
    const {scrollTop, clientTop} = document.documentElement;

    const topOffset = top + height + scrollTop - clientTop + 4;

    if (topOffset + 384 > clientHeight) {
        return Math.max(topOffset - 384 - height, 0);
    }

    return topOffset;
}
