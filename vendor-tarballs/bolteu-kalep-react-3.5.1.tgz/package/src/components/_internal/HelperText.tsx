import * as React from "react";

import {cx} from "@/helpers/utils/cx";

interface HelperTextProps {
    helperTextId: string;
    error?: boolean;
    disabled?: boolean;
    helperText?: React.ReactNode;
}

export function renderHelperTextDefault({
    error,
    disabled,
    helperText,
    helperTextId,
}: HelperTextProps): JSX.Element | null {
    if (!helperText) {
        return null;
    }

    return (
        <div
            className={cx(
                "bolt-font-body-s-regular text-secondary",
                disabled && "text-tertiary",
                error && "text-danger-primary",
            )}
            id={helperTextId}
        >
            {helperText}
        </div>
    );
}
