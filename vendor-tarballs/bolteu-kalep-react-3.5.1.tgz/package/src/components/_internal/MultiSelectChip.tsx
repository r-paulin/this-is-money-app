import React from "react";

import {Clear} from "@bolteu/kalep-react-icons";

import {GhostButton} from "@/components/GhostButton";
import type {Size} from "@/components/Select/Select.types";
import {cx} from "@/helpers/utils/cx";

export interface MultiSelectChipProps {
    label: string;
    disabled?: boolean;
    shrink?: boolean;
    hidden?: boolean;
    size?: Size;
    onDelete?: () => void;
}

export const MultiSelectChip = React.forwardRef<HTMLDivElement, MultiSelectChipProps>(
    ({label, disabled, shrink, hidden, size, onDelete}, ref) => {
        const handleClickDelete = React.useCallback(
            (_e: React.MouseEvent | React.KeyboardEvent) => {
                onDelete?.();
            },
            [onDelete],
        );

        return (
            <div
                ref={ref}
                className={cx(
                    "flex items-center gap-[6px]",
                    `
                      box-border whitespace-nowrap rounded-md border-2 border-solid border-neutral-secondary px-[6px]
                      py-[2px]
                    `,
                    size === "sm" ? "bolt-font-body-xs-regular" : "bolt-font-body-s-regular",
                    shrink ? "flex-shrink-1 overflow-hidden text-ellipsis" : "flex-shrink-0 overflow-auto",
                    disabled ? "text-tertiary" : "bg-neutral-secondary text-primary",
                    hidden && "invisible",
                    "overflow-y-hidden",
                )}
            >
                <div className={cx("truncate")}>{label}</div>
                {typeof onDelete === "function" && (
                    <GhostButton
                        overrideClassName={cx("flex h-4 items-center")}
                        onClick={handleClickDelete}
                        disabled={disabled}
                        tabIndex={-1}
                    >
                        <Clear size="xs" className={cx(disabled ? "text-tertiary" : "text-secondary")} />
                    </GhostButton>
                )}
            </div>
        );
    },
);
MultiSelectChip.displayName = "MultiSelectChip";
