import * as React from "react";

export type SpinnerIconSize = "xs" | "sm" | "md" | "lg" | "xl" | 400 | 500 | 600 | 700 | "inherit";

export type SpinnerIconProps = React.SVGProps<SVGSVGElement> & {
    size?: SpinnerIconSize;
};

const sizeToDimensionsMap: Record<string, number | string> = {
    xs: 16,
    sm: 20,
    md: 20,
    lg: 24,
    xl: 36,
    "400": 16,
    "500": 24,
    "600": 36,
    "700": 48,
    inherit: "100%",
};

export function SpinnerIcon({size = "lg", ...props}: SpinnerIconProps) {
    const dimensions = sizeToDimensionsMap[size.toString()] ?? sizeToDimensionsMap.lg;

    return (
        <svg
            width={dimensions}
            height={dimensions}
            viewBox="0 0 24 24"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            {...props}
        >
            <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M9.85401 1.21137C11.9878 0.78693 14.1995 1.00477 16.2095 1.83733C18.2195 2.66989 19.9375 4.07979 21.1462 5.88873C22.3549 7.69767 23 9.82441 23 12C23 13.0125 22.1792 13.8333 21.1667 13.8333C20.1541 13.8333 19.3333 13.0125 19.3333 12C19.3333 10.5496 18.9032 9.13178 18.0974 7.92582C17.2916 6.71986 16.1463 5.77993 14.8063 5.22489C13.4664 4.66984 11.9919 4.52462 10.5693 4.80758C9.14681 5.09054 7.84014 5.78897 6.81455 6.81455C5.78897 7.84014 5.09054 9.14681 4.80758 10.5693C4.52462 11.9919 4.66985 13.4664 5.22489 14.8063C5.77993 16.1463 6.71986 17.2916 7.92582 18.0974C9.13178 18.9032 10.5496 19.3333 12 19.3333C13.0125 19.3333 13.8333 20.1541 13.8333 21.1667C13.8333 22.1792 13.0125 23 12 23C9.82441 23 7.69767 22.3549 5.88873 21.1462C4.07979 19.9375 2.66989 18.2195 1.83733 16.2095C1.00477 14.1995 0.786929 11.9878 1.21137 9.85401C1.6358 7.72022 2.68345 5.76021 4.22183 4.22183C5.76021 2.68345 7.72022 1.6358 9.85401 1.21137Z"
                fill="currentColor"
            />
        </svg>
    );
}
