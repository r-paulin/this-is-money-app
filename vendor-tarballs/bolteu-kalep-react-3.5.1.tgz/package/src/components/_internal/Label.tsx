import * as React from "react";

import {InfoCircle} from "@bolteu/kalep-react-icons";

import {Tooltip} from "@/components/Tooltip";
import {cx} from "@/helpers/utils/cx";

export interface LabelProps {
    text: string;
    infoText?: string;
    required?: boolean;
    disabled?: boolean;
    htmlFor?: string;
    htmlProps?: React.ComponentPropsWithoutRef<"label">;
}

export const Label = React.forwardRef<HTMLLabelElement, LabelProps>(
    ({text, infoText, required, disabled, htmlFor, htmlProps}: LabelProps, ref): JSX.Element => {
        return (
            <label
                ref={ref}
                className={cx(
                    "bolt-font-body-s-accent",
                    "flex items-center gap-1",
                    disabled ? "text-tertiary" : "text-primary",
                )}
                htmlFor={htmlFor}
                {...htmlProps}
            >
                <span data-testid="kalep-label">
                    {text}
                    {required && <span className={cx("pl-[2px] text-danger-primary")}>*</span>}
                </span>
                {infoText && (
                    <Tooltip content={infoText}>
                        {/* eslint-disable-next-line jsx-a11y/no-noninteractive-tabindex -- It is fine here */}
                        <div className={cx("box-border flex items-center")} tabIndex={0}>
                            <InfoCircle size="xs" />
                        </div>
                    </Tooltip>
                )}
            </label>
        );
    },
);
Label.displayName = "Label";
