import * as React from "react";

import {ListItemLayout} from "../ListItemLayout";

export type SelectOption = {
    value: string | number | null;
    title?: string | (() => string);
    secondary?: React.ReactNode;
    disabled?: boolean;
    isCustom?: boolean;
};

export type OptionProps = React.ComponentPropsWithRef<"li"> & {
    key: string;
    option: SelectOption;
    highlighted: boolean;
    selected: boolean;
    label: string;
    size?: "sm" | "md" | "lg";
};

export const Option = React.forwardRef<HTMLLIElement, OptionProps>(function OptionComponent(
    {option, highlighted, selected, label, size = "md", ...rest},
    ref,
): JSX.Element {
    return (
        <li ref={ref} {...rest} data-value={option.value}>
            <ListItemLayout
                primary={label}
                selected={selected}
                secondary={option.secondary}
                disabled={option.disabled}
                selectionMode="solo-checkmark"
                variant={size === "sm" ? "sm" : "base"}
                highlighted={highlighted}
            />
        </li>
    );
});

export function renderOptionDefault(props: OptionProps): JSX.Element {
    return <Option {...props} />;
}

export function getOptionLabelDefault(option: SelectOption | null): string {
    if (!option) {
        return "";
    }

    if (option.title === undefined) {
        return String(option.value ?? "");
    }

    if (typeof option.title === "function") {
        return option.title();
    }

    return option.title;
}
