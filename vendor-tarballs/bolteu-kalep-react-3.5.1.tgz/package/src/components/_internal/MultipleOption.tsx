import * as React from "react";

import {ListItemLayout} from "@/components/ListItemLayout";

import type {OptionProps} from "./Option";

export const MultipleOption = React.forwardRef<HTMLLIElement, OptionProps>(function OptionComponent(
    {option, selected, size = "md", highlighted, label, ...rest},
    ref,
): JSX.Element {
    return (
        <li ref={ref} {...rest}>
            <ListItemLayout
                primary={label}
                disabled={option.disabled}
                secondary={option.secondary}
                selected={!option.isCustom ? selected : undefined}
                selectionMode="multiple"
                variant={size === "sm" ? "sm" : "base"}
                highlighted={highlighted}
            />
        </li>
    );
});

export function renderMultipleOptionDefault(props: OptionProps): JSX.Element {
    return <MultipleOption {...props} />;
}
