import * as React from "react";

import type {Meta, StoryFn} from "@storybook/react-webpack5";

import {Alert, Heart, Lock, RideStart} from "@bolteu/kalep-react-icons";

import {Button} from "@/components/Button";
import {Typography} from "@/components/Typography";

import type {IconViewProps} from "./index";
import {IconView} from "./index";

export default {
    title: "Data Display/IconView",
    component: IconView,
    tags: ["autodocs"],
    argTypes: {
        icon: {
            options: ["Heart", "Lock", "Alert", "RideStart"],
            mapping: {
                Heart: <Heart />,
                Lock: <Lock />,
                Alert: <Alert />,
                RideStart: <RideStart />,
            },
        },
    },
} as Meta<typeof IconView>;

const Template: StoryFn<typeof IconView> = (args: IconViewProps) => {
    return (
        <div className="flex items-end gap-4">
            <IconView {...args} size="2xs" alt="2xs icon view" />
            <IconView {...args} size="xs" alt="xs icon view" />
            <IconView {...args} size="sm" alt="sm icon view" />
            <IconView {...args} size="md" alt="md icon view" />
            <IconView {...args} size="lg" alt="lg icon view" />
            <IconView {...args} size="xl" alt="xl icon view" />
        </div>
    );
};

export const DefaultIconView = Template.bind({});
DefaultIconView.args = {
    icon: <Heart />,
    color: "text-danger-secondary",
    shadow: false,
};

export const WithImage = Template.bind({});
WithImage.args = {
    imageUrl: "https://picsum.photos/id/22/200",
    shadow: true,
};

export const WithSpinner: StoryFn<typeof IconView> = () => {
    const [isLoading, setIsLoading] = React.useState(false);

    const toggle = React.useCallback(() => setIsLoading((l) => !l), [setIsLoading]);

    return (
        <div className="flex flex-col gap-4">
            <Typography>Click to start an action</Typography>
            <Button variant="secondary" onClick={toggle}>
                Start loading
            </Button>
            <div className="flex items-end gap-4">
                <IconView icon={<RideStart />} size="lg" loading={isLoading} alt="Ride" />
                <IconView
                    imageUrl="https://picsum.photos/id/40/200"
                    size="lg"
                    alt="User's avatar"
                    loading={isLoading}
                />
            </div>
        </div>
    );
};
