import * as React from "react";

import {Spinner} from "@/components/Spinner";
import {cx} from "@/helpers/utils/cx";

import type {IconViewProps, IconViewSizeVariant} from "./IconView.types";

const sizes: Record<IconViewSizeVariant, string> = {
    "2xs": "w-5 h-5",
    xs: "w-7 h-7",
    sm: "w-9 h-9",
    md: "w-12 h-12",
    lg: "w-14 h-14",
    xl: "w-20 h-20",
};
const contentSizes: Record<IconViewSizeVariant, string> = {
    "2xs": "w-3 h-3",
    xs: "w-5 h-5",
    sm: "w-5 h-5",
    md: "w-6 h-6",
    lg: "w-6 h-6",
    xl: "w-10 h-10",
};

interface ContentWrapperProps {
    sizeClasses: string;
    children: React.ReactNode;
}

function ContentWrapper({sizeClasses, children}: ContentWrapperProps) {
    return <div className={cx(sizeClasses, "flex items-center justify-center")}>{children}</div>;
}

function IconView(
    {
        alt,
        size = "md",
        backgroundColor = "bg-neutral-secondary",
        color,
        icon,
        imageUrl,
        shadow,
        loading = false,
        ...rest
    }: IconViewProps,
    ref: React.Ref<HTMLDivElement>,
) {
    // for images shadow should be on by default
    const hasShadow = shadow === undefined && imageUrl ? true : shadow;
    const contentColorClass = color || (imageUrl ? "text-static-key-light" : "text-primary");

    let content = null;

    if (loading) {
        content = (
            <ContentWrapper sizeClasses={contentSizes[size]}>
                <Spinner color={contentColorClass} size="inherit" />
            </ContentWrapper>
        );
    } else if (icon && !imageUrl) {
        content = (
            <ContentWrapper sizeClasses={contentSizes[size]}>
                {React.cloneElement(icon!, {
                    className: cx(contentColorClass),
                    width: "100%",
                    height: "100%",
                    role: "img",
                    "aria-label": alt,
                })}
            </ContentWrapper>
        );
    }

    const containerClasses = cx(
        sizes[size],
        "rounded-full border-0",
        "bg-cover",
        "flex items-center justify-center",
        hasShadow && "shadow-[inset_0_0_8px_rgba(26,27,35,0.08)]",
        imageUrl && loading && "brightness-90",
        backgroundColor,
    );
    const containerStyles = imageUrl ? {backgroundImage: `url(${imageUrl})`} : {};

    return (
        <div ref={ref} className={containerClasses} style={containerStyles} title={alt} {...rest}>
            {content}
        </div>
    );
}

const ForwardedIconView = React.forwardRef<HTMLDivElement, IconViewProps>(IconView);

export {ForwardedIconView as IconView};
