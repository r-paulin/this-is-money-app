import * as React from "react";

import {render, screen} from "@testing-library/react";

import {IconView} from "../IconView";

describe("IconView", () => {
    const iconMock = <svg />;
    const imageUrlMock = "https://example.com/image.jpg";

    it("renders icon when provided", () => {
        render(<IconView icon={iconMock} />);
        expect(screen.queryByRole("img")).toBeInTheDocument();
        expect(screen.queryByRole("status")).not.toBeInTheDocument();
    });

    it("renders spinner when loading is true", () => {
        render(<IconView loading />);
        expect(screen.queryByRole("status")).toBeInTheDocument();
        expect(screen.queryByRole("img")).not.toBeInTheDocument();
    });

    it("renders image when imageUrl is provided", () => {
        render(<IconView imageUrl={imageUrlMock} alt="test" />);
        expect(screen.queryByTitle("test")).toHaveStyle(`backgroundImage: url(${imageUrlMock})`);
    });

    it("renders with default size and color", () => {
        render(<IconView alt="test" />);
        expect(screen.queryByTitle("test")).toHaveClass("w-12", "h-12");
    });

    it("renders with custom size and background color", () => {
        render(<IconView size="lg" backgroundColor="bg-neutral-secondary-hard" alt="test" />);
        expect(screen.queryByTitle("test")).toHaveClass("w-14", "w-14", "bg-neutral-secondary-hard");
    });

    it("renders with shadow when imageUrl is provided", () => {
        render(<IconView imageUrl={imageUrlMock} alt="test" />);
        expect(screen.queryByTitle("test")).toHaveClass("shadow-[inset_0_0_8px_rgba(26,27,35,0.08)]");
    });

    it("does not render shadow by default", () => {
        render(<IconView alt="test" />);
        expect(screen.queryByTitle("test")).not.toHaveClass("shadow-[inset_0_0_8px_rgba(26,27,35,0.08)]");
    });
});
