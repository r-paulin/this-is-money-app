import type {UseMultipleSelectionState, UseMultipleSelectionStateChangeOptions} from "downshift";
import {useMultipleSelection} from "downshift";

import type {SelectOption} from "@/components/_internal/Option";

import type {Size} from "./ComboBox.types";

export type FilterOptionsConfig = {
    inputValue: string;
    getOptionLabel: (option: SelectOption) => string;
    freeSolo?: boolean;
};

export function filterOptionsDefault(
    options: SelectOption[],
    {inputValue, getOptionLabel, freeSolo}: FilterOptionsConfig,
): SelectOption[] {
    const lowerCasedInputValue = inputValue.toLowerCase();
    const filtered = options.filter(function filterOption(option) {
        const optionLabel = getOptionLabel(option);

        return optionLabel.toLowerCase().includes(lowerCasedInputValue);
    });

    if (freeSolo && inputValue !== "" && filtered.length === 0) {
        filtered.push({
            value: inputValue,
            title: `Add "${inputValue}"`,
            isCustom: true,
        });
    }

    return filtered;
}

export function virtualizerEstimateHeightBySize(size: Size): number {
    return size === "sm" ? 36 : 48;
}

export function useMultipleSelectionStateReducer(
    state: UseMultipleSelectionState<SelectOption>,
    {type, changes}: UseMultipleSelectionStateChangeOptions<SelectOption>,
) {
    switch (type) {
        case useMultipleSelection.stateChangeTypes.SelectedItemKeyDownNavigationNext:
            // when reaching last item then arrow right, stop navigation
            return {...changes, activeIndex: changes.activeIndex === -1 ? state.activeIndex : changes.activeIndex};
        case useMultipleSelection.stateChangeTypes.SelectedItemKeyDownNavigationPrevious:
            // when reaching first item then arrow left, focus
            return {...changes, activeIndex: state.activeIndex === 0 ? -1 : changes.activeIndex};
        case useMultipleSelection.stateChangeTypes.DropdownKeyDownNavigationPrevious:
            // do nothing when hitting arrow left
            return state;
        case useMultipleSelection.stateChangeTypes.DropdownKeyDownBackspace:
            return state;
        default:
            return changes;
    }
}
