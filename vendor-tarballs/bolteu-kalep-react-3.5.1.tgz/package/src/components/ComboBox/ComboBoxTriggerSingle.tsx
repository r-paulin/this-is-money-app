import React from "react";

import {ChevronDown} from "@bolteu/kalep-react-icons";

import {ClearInputButton} from "@/components/_internal/ClearInputButton";
import {SpinnerIcon} from "@/components/_internal/SpinnerIcon";
import {BaseTextField} from "@/components/TextField/BaseTextField";
import type {RenderFunction} from "@/helpers";
import {cx} from "@/helpers/utils/cx";
import {noopNull} from "@/helpers/utils/noop";
import type {TextFieldRenderProps} from "@/index";

import {DEFAULT_LOADING_SPINNER_ARIA_LABEL, DEFAULT_TOGGLE_BUTTON_ARIA_LABEL} from "./BaseComboBox";
import type {ComboBoxTriggerProps, Size} from "./ComboBox.types";

const sizes: Record<Size, string> = {
    sm: "pr-2 pl-3",
    md: "pr-2 gap-2",
    lg: "pr-2 gap-2 pl-3",
};

export function ComboBoxTriggerSingle(props: ComboBoxTriggerProps) {
    const {
        comboBoxId,
        clearable,
        controlledInputValue,
        disabled,
        error,
        fullWidth,
        id,
        isOpen,
        generatedId,
        getInputProps,
        getToggleButtonProps,
        inputValue,
        inputWrapperRef,
        loading,
        loadingSpinnerAriaLabel = DEFAULT_LOADING_SPINNER_ARIA_LABEL,
        // multiline, // TODO: Add support
        name,
        noResultsMessageId,
        onClear,
        onInputChange,
        openMenu,
        placeholder,
        required,
        shouldShowNoResultsMessage,
        shouldRenderEndSlotIcon = true,
        size = "md",
        toggleButtonAriaLabel = DEFAULT_TOGGLE_BUTTON_ARIA_LABEL,
        toggleButtonRef,
        value,
    } = props;
    const inputRef = React.useRef<HTMLInputElement>(null);

    const inputA11yProps = getInputProps({
        ref: inputRef,
        disabled,
        onChange: onInputChange,
    });

    const loadingSpinnerId = id ?? `kalep-combo-box-loading-spinner-${generatedId}`;

    if (loading) {
        inputA11yProps["aria-labelledby"] = `${inputA11yProps["aria-labelledby"]} ${loadingSpinnerId}`;
    }
    if (shouldShowNoResultsMessage) {
        inputA11yProps["aria-labelledby"] = `${inputA11yProps["aria-labelledby"]} ${noResultsMessageId}`;
    }

    const handleClearButtonClick = React.useCallback(() => {
        if (typeof onInputChange === "function" && controlledInputValue) {
            /* In case of controlled input call onInputChange */
            const event = {
                target: {
                    value: "",
                },
            } as React.ChangeEvent<HTMLInputElement>;

            onInputChange(event);
        } else {
            /* In case of uncontrolled input set input value to empty string */
            const nativeInputValueSetter = Object.getOwnPropertyDescriptor(
                window.HTMLInputElement.prototype,
                "value",
            )?.set;
            const input = inputWrapperRef?.current?.getElementsByTagName("input")?.[0];

            nativeInputValueSetter?.call(input, "");
            input?.dispatchEvent(new Event("input", {bubbles: true}));
            input?.focus();
        }
        onClear?.();
    }, [controlledInputValue, inputWrapperRef, onInputChange, onClear]);

    const renderEndSlot = React.useCallback<RenderFunction<TextFieldRenderProps>>(
        (renderEndSlotProps) => {
            if (props.renderEndSlot) {
                return (
                    <div className={cx("flex max-w-6 shrink-0 items-center gap-1")}>
                        {props.renderEndSlot(props, noopNull)}
                    </div>
                );
            }
            const showClearButton = !disabled && (!!value || !!inputValue) && clearable;
            return (
                <div className={cx("flex items-center gap-1")}>
                    {showClearButton && (
                        <ClearInputButton
                            onClick={handleClearButtonClick}
                            size={size === "sm" ? "md" : "lg"}
                            buttonClassname={cx(`
                              hidden
                              group-hover/trigger:block
                            `, isOpen && "block")}
                        />
                    )}

                    {loading && (
                        <SpinnerIcon
                            id={loadingSpinnerId}
                            aria-label={loadingSpinnerAriaLabel}
                            className={cx("m-1 flex-none animate-spin text-action-secondary")}
                            size={size}
                            role="status"
                        />
                    )}

                    {!loading && shouldRenderEndSlotIcon && (
                        <button
                            type="button"
                            {...getToggleButtonProps({ref: toggleButtonRef, "aria-label": toggleButtonAriaLabel})}
                            className={cx(
                                "m-0 flex cursor-pointer items-center border-0 bg-transparent p-0",
                                renderEndSlotProps.disabled && "cursor-not-allowed",
                            )}
                            disabled={renderEndSlotProps.disabled}
                        >
                            <ChevronDown
                                className={cx(
                                    "m-1 flex-none transition-transform",
                                    renderEndSlotProps.disabled ? "text-tertiary" : "text-primary",
                                    isOpen && "rotate-180",
                                )}
                                size={size === "sm" ? "md" : "lg"}
                            />
                        </button>
                    )}
                </div>
            );
        },

        [
            props,
            disabled,
            value,
            inputValue,
            clearable,
            handleClearButtonClick,
            size,
            isOpen,
            loading,
            loadingSpinnerId,
            loadingSpinnerAriaLabel,
            shouldRenderEndSlotIcon,
            getToggleButtonProps,
            toggleButtonRef,
            toggleButtonAriaLabel,
        ],
    );

    const renderInput = React.useCallback<RenderFunction<TextFieldRenderProps>>(
        (inputRenderProps, defaultInputRender) => {
            return React.cloneElement(defaultInputRender(inputRenderProps) as JSX.Element, {
                ...inputA11yProps,
                required: false,
                "aria-required": required,
            });
        },
        [inputA11yProps, required],
    );

    const renderStartSlotForTextField = React.useCallback<RenderFunction<TextFieldRenderProps>>(
        (textFieldRenderProps, defaultTextFieldRender) => {
            if (props.renderStartSlot) {
                return (
                    <div className={cx("flex max-w-6 shrink-0 items-center")}>
                        {props.renderStartSlot(props, () => null)}
                    </div>
                );
            }

            return defaultTextFieldRender(textFieldRenderProps);
        },
        [props],
    );

    const onClick = React.useCallback(
        (e: React.MouseEvent) => {
            if (disabled) {
                return;
            }

            if (!toggleButtonRef?.current?.contains(e.target as Node)) {
                openMenu();
            }
        },
        [openMenu, toggleButtonRef, disabled],
    );

    return (
        <BaseTextField
            ref={inputRef}
            inputWrapperRef={inputWrapperRef}
            disabled={disabled}
            error={error}
            fullWidth={fullWidth}
            id={comboBoxId}
            name={name}
            onClick={onClick}
            overrideClassName={cx(sizes[size], "group/trigger")}
            placeholder={placeholder}
            renderEndSlot={renderEndSlot}
            renderInput={renderInput}
            size={size}
            value={inputValue}
            renderStartSlot={renderStartSlotForTextField}
        />
    );
}
