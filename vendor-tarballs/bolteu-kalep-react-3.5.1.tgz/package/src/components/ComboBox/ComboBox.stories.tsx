import * as React from "react";

import type {Meta, StoryFn} from "@storybook/react-webpack5";

import {Search} from "@bolteu/kalep-react-icons";

import type {SelectOption} from "@/components/_internal/Option";
import {cx} from "@/helpers/utils/cx";

import {Grid} from "../Layout";
import {Typography} from "../Typography";
import type {ComboBoxProps} from "./index";
import {ComboBox} from "./index";

export default {
    title: "Inputs/ComboBox",
    tags: ["autodocs"],
    component: ComboBox,
} as Meta<typeof ComboBox>;

const options = [
    {title: "Tallinn", value: "tallinn"},
    {title: "Bucharest", value: "bucharest"},
    {title: "Warsaw", value: "warsaw"},
    {title: "Berlin", value: "berlin"},
    {title: "Prague", value: "prague"},
    {title: "Milan", value: "milan"},
    {title: "Rome", value: "rome"},
    {title: "Paris", value: "paris"},
    {title: "Vienna", value: "vienna"},
    {title: "Llanfair­pwllgwyngyll­gogery­chwyrn­drobwll­llan­tysilio­gogo­goch", value: "llanfair"},
    {title: "El Pueblo de Nuestra Señora la Reina de los Ángeles del Río de Porciúncula", value: "losangeles"},
];

const virtualisedOptions: SelectOption[] = [];

for (let i = 0; i < 1000; i++) {
    virtualisedOptions.push({title: `Item ${i}`, value: `value-${i}`, secondary: `Description of item ${i}`});
}

const Template: StoryFn<typeof ComboBox> = (args: ComboBoxProps) => <ComboBox {...args} />;

export const Default = Template.bind({});
Default.args = {
    options,
    label: "Label",
    placeholder: "Placeholder",
    helperText: "Helper text is displayed below the trigger",
    infoText: "Optional info text, shown in a Tooltip",
    noResultsMessage: "No city found",
};

export const Sizes: StoryFn<typeof ComboBox> = () => (
    <div className="flex flex-col gap-8">
        <Typography variant="title-secondary">Single</Typography>
        <ComboBox helperText="Pick anything" label="Small" options={options} size="sm" placeholder="City" />
        <ComboBox helperText="Pick anything" label="Medium (default)" options={options} placeholder="City" />
        <ComboBox helperText="Pick anything" label="Large" options={options} size="lg" placeholder="City" />
        <div className="my-4 h-[1px] bg-neutral-secondary" />
        <Typography variant="title-secondary">Multiple</Typography>
        <ComboBox helperText="Pick anything" label="Small" options={options} size="sm" placeholder="City" multiple />
        <ComboBox helperText="Pick anything" label="Medium (default)" options={options} placeholder="City" multiple />
        <ComboBox helperText="Pick anything" label="Large" options={options} size="lg" placeholder="City" multiple />
    </div>
);

export const Disabled = Template.bind({});
Disabled.args = {
    ...Default.args,
    disabled: true,
    value: options[0],
};

export const Error = Template.bind({});
Error.args = {
    ...Default.args,
    value: {title: "Helsinki", value: "0"},
    error: true,
};

export const Required = Template.bind({});
Required.args = {
    ...Default.args,
    required: true,
};

export const Loading = Template.bind({});
Loading.args = {
    ...Default.args,
    loading: true,
    loadingSpinnerAriaLabel: "I am loading",
};

export const WithoutClearing = Template.bind({});
WithoutClearing.args = {
    ...Default.args,
    clearable: false,
    helperText: "Turn off clear button for smaller inputs",
};

export const StartSlot = Template.bind({});
StartSlot.args = {
    ...Default.args,
    renderStartSlot: () => <Search size="lg" />,
};

export const EndSlot = Template.bind({});
EndSlot.args = {
    ...Default.args,
    renderEndSlot: () => <Search size="lg" />,
};

export const Readonly = Template.bind({});
Readonly.args = {
    ...Default.args,
    readonly: true,
    value: options[0],
    helperText: "You can still provide helper text for secondary content",
};

export const MultipleReadonly = Template.bind({});
MultipleReadonly.args = {
    ...Default.args,
    readonly: true,
    value: [options[0], options[2], options[3]],
    helperText: "You can still provide helper text for secondary content",
};

export const DisabledItems = Template.bind({});
const modifiedOptions = options.map((option, i) => (i % 4 !== 0 ? option : {...option, disabled: true}));
DisabledItems.args = {
    ...Default.args,
    options: modifiedOptions,
};

export const Controlled: StoryFn<typeof ComboBox> = (args: ComboBoxProps) => {
    const [value, setValue] = React.useState<SelectOption | null>(null);
    const handleChange = React.useCallback((newValue) => setValue(newValue), []);

    return (
        <ComboBox
            {...args}
            onChange={handleChange}
            value={value}
            helperText={value ? `${value.title} has been picked` : "Pick something to see this text change"}
        />
    );
};

export const ControlledMultiple: StoryFn<typeof ComboBox> = (args: ComboBoxProps) => {
    const [value, setValue] = React.useState<SelectOption[]>([]);

    const handleChange = React.useCallback(
        (newValue: SelectOption | SelectOption[] | null) => setValue(Array.isArray(newValue) ? newValue : []),
        [],
    );

    return (
        <ComboBox
            {...args}
            options={options}
            placeholder="Select multiple cities"
            multiple
            onChange={handleChange}
            value={value}
            noResultsMessage="No city found"
            helperText={
                value.length
                    ? `${value.map((item) => item.title).join(", ")} have been been picked`
                    : "Pick something to see this text change"
            }
        />
    );
};

Controlled.args = {
    ...Default.args,
};
Controlled.argTypes = {
    value: {
        control: {
            disable: true,
        },
    },
    helperText: {
        control: {
            disable: true,
        },
    },
};

export const ControlledInput: StoryFn<typeof ComboBox> = (args: ComboBoxProps) => {
    const [inputValue, setInputValue] = React.useState<string>("");
    const handleInputChange = React.useCallback(({target: {value: newValue}}) => {
        setInputValue(newValue);
    }, []);

    return <ComboBox {...args} onInputChange={handleInputChange} inputValue={inputValue} />;
};

ControlledInput.args = {
    ...Default.args,
};

const optionsWithSecondaryDescription: SelectOption[] = [
    {title: "Tallinn", value: "tallinn", secondary: "Capital of Estonia"},
    {title: "Bucharest", value: "bucharest", secondary: "Capital of Romania"},
    {title: "Warsaw", value: "warsaw", secondary: "Capital of Poland"},
    {title: "Berlin", value: "berlin", secondary: "Capital of Germany"},
    {title: "Prague", value: "prague", secondary: "Capital of Czechia"},
    {title: "Milan", value: "milan", secondary: "Definitely not capital of Italy 👀"},
    {title: "Rome", value: "rome", secondary: "Capital of Italy"},
    {title: "Paris", value: "paris", secondary: "Capital of France"},
    {title: "Vienna", value: "vienna", secondary: "Capital of Austria"},
];

export const SecondaryDescription = Template.bind({});
SecondaryDescription.args = {
    ...Default.args,
    options: optionsWithSecondaryDescription,
    helperText: "Give users more context to make a more informed choice!",
};

export const MultipleSecondaryDescription = Template.bind({});
MultipleSecondaryDescription.args = {
    ...Default.args,
    multiple: true,
    options: optionsWithSecondaryDescription,
    helperText: "Give users more context to make a more informed choice!",
};

export const CustomOptionRenderer: StoryFn<typeof ComboBox> = () => {
    const renderOption = React.useCallback(
        (props) => (
            <li
                onClick={props.onClick}
                className={cx(
                    `
                      cursor-pointer px-4 py-3 text-base
                      hover:bg-promo-secondary
                    `,
                    props.selected && "font-semibold",
                )}
                {...props}
            >
                {props.selected && "👉 "}
                {props.option.title}
            </li>
        ),
        [],
    );

    return (
        <ComboBox
            label="Best dance in the world:"
            placeholder="Select Dance"
            options={options}
            renderOption={renderOption}
        />
    );
};

export const CustomOverlayFooter = Template.bind({});
CustomOverlayFooter.args = {
    ...Default.args,
    renderOverlayFooter: () => <div className="p-2 text-center text-xs text-secondary">© OpenStreetMap</div>,
};

export const MultipleSelection = Template.bind({});
MultipleSelection.args = {
    ...Default.args,
    multiple: true,
    helperText: "Pick as many options as you want",
    defaultValue: [options[0], options[2]],
};

export const MultipleSelectionDisabled = Template.bind({});
MultipleSelectionDisabled.args = {
    ...Default.args,
    multiple: true,
    disabled: true,
    onChange: (...args) => console.log(args),
    defaultValue: [options[0], options[1]],
};

export const MultipleStartSlot = Template.bind({});
MultipleStartSlot.args = {
    ...Default.args,
    multiple: true,
    defaultValue: [options[0], options[2]],
    renderStartSlot: () => <Search size="lg" />,
};

export const MultipleSelectionMultiline = Template.bind({});
MultipleSelectionMultiline.args = {
    ...Default.args,
    multiple: true,
    helperText: "Pick as many options as you want",
    defaultValue: [options[0], options[2], options[3], options[4]],
    multiline: true,
};

export const DisabledCloseOnSelect = Template.bind({});
DisabledCloseOnSelect.args = {
    ...Default.args,
    disableCloseOnSelect: true,
};

export const FreeSolo = Template.bind({});
FreeSolo.args = {
    ...Default.args,
    freeSolo: true,
};

export const FreeSoloMultiple = Template.bind({});
FreeSoloMultiple.args = {
    ...Default.args,
    freeSolo: true,
    multiple: true,
};

export const FullWidth: StoryFn<typeof ComboBox> = () => (
    <Grid columns={15} alignItems="flex-end">
        <Grid.Item colSpan={2}>
            <ComboBox
                options={[
                    {value: "yes", title: "Yes"},
                    {value: "no", title: "No"},
                ]}
                fullWidth
                label="Is active"
            />
        </Grid.Item>
        <Grid.Item colSpan={2}>
            <ComboBox
                options={[
                    {value: "yes", title: "Yes"},
                    {value: "maybe", title: "Also yes, but less likely"},
                ]}
                fullWidth
                label="Is deactivated"
            />
        </Grid.Item>
        <Grid.Item colSpan={9}>
            <ComboBox
                options={[
                    {value: "user1", title: "User 1"},
                    {value: "user2", title: "User 2"},
                ]}
                fullWidth
                label="Filter by user"
                multiple
            />
        </Grid.Item>
        <Grid.Item colSpan={2}>
            <ComboBox
                options={[
                    {value: "yes", title: "Yes"},
                    {value: "maybe", title: "Also yes, but less likely. By default this makes it go wide."},
                ]}
                fullWidth
                label="Is inactive"
            />
        </Grid.Item>
    </Grid>
);

export const Virtualisation = Template.bind({});
Virtualisation.args = {
    label: "A thousand options:",
    placeholder: "Select an option",
    helperText: "We render just a handful at a time",
    options: virtualisedOptions,
};

export const NoChevron = Template.bind({});
NoChevron.args = {
    ...Default.args,
    shouldRenderEndSlotIcon: false,
};

export const OverlayConfiguration = () => (
    <Grid columns={12}>
        <Grid.Item colSpan={1}>
            <ComboBox
                options={optionsWithSecondaryDescription}
                label="City"
                placeholder="🏰"
                helperText="Regular"
                fullWidth
            />
        </Grid.Item>
        <Grid.Item colSpan={1}>
            <ComboBox
                options={optionsWithSecondaryDescription}
                label="City"
                placeholder="🏰"
                helperText="Forced small"
                overlayConfig={{maxWidth: 100}}
                fullWidth
            />
        </Grid.Item>
        <Grid.Item colSpan={1}>
            <ComboBox
                options={optionsWithSecondaryDescription}
                label="City"
                placeholder="🏰"
                helperText="Forced large"
                overlayConfig={{minWidth: 600}}
                fullWidth
            />
        </Grid.Item>
        <Grid.Item visible="HIDDEN_LEAVE_HOLE">🤷‍♂️</Grid.Item>
        <Grid.Item colSpan={2}>
            <ComboBox
                options={optionsWithSecondaryDescription}
                label="City"
                placeholder="e.g Tallinn"
                helperText="Opens 100px down and 300px to the right"
                overlayConfig={{position: {offset: 100, crossOffset: 300}}}
                fullWidth
            />
        </Grid.Item>
    </Grid>
);

const testOptions = [
    ...options,
    {title: "Delivery Courier Administration", value: "foo"},
    {title: "taxify_delivery_eater_campaign_targeting", value: "bar"},
];

export function AllWidths() {
    // array of numbers from 100 to 200 with a step of 10
    const widths = Array.from({length: 16}, (_, i) => i * 10 + 100);

    return (
        <>
            <div className="mb-8 resize-x overflow-hidden border border-solid border-separator p-4">
                <ComboBox
                    options={testOptions}
                    size="md"
                    multiple
                    label="Resize my container!"
                    defaultValue={[testOptions[0]]}
                    fullWidth
                />
            </div>
            <div className="flex gap-8">
                <div className="flex flex-col gap-8">
                    {widths.map((width, index) => (
                        <div style={{width: `${width}px`}} key={width}>
                            <ComboBox
                                options={testOptions}
                                size={index % 2 === 0 ? "sm" : "md"}
                                multiple
                                label={`Width: ${width}px`}
                                defaultValue={[testOptions[0]]}
                                fullWidth
                                placeholder="e.g Tallinn"
                            />
                        </div>
                    ))}
                </div>
                <div className="flex flex-col gap-8">
                    {widths.map((width, index) => (
                        <div style={{width: `${width}px`}} key={width}>
                            <ComboBox
                                options={testOptions}
                                size={index % 2 === 0 ? "sm" : "md"}
                                multiple
                                label={`Width: ${width}px`}
                                defaultValue={[testOptions[testOptions.length - 1]]}
                                fullWidth
                                placeholder="e.g Tallinn"
                                renderStartSlot={
                                    width > 200 ? () => <Search size={index % 2 === 0 ? "sm" : "md"} /> : undefined
                                }
                            />
                        </div>
                    ))}
                </div>
                <div className="flex flex-col gap-8">
                    {widths.map((width, index) => (
                        <div style={{width: `${width}px`}} key={width}>
                            <ComboBox
                                options={testOptions}
                                size={index % 2 === 0 ? "sm" : "md"}
                                multiple
                                label={`Width: ${width}px`}
                                defaultValue={[testOptions[testOptions.length - 2]]}
                                fullWidth
                                placeholder="e.g Tallinn"
                            />
                        </div>
                    ))}
                </div>
            </div>
        </>
    );
}
