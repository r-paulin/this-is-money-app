import * as React from "react";

import {vi} from "vitest";
import {screen} from "@testing-library/react";

import type {SelectOption} from "@/components/_internal/Option";

import {DEFAULT_LOADING_SPINNER_ARIA_LABEL} from "../BaseComboBox";
import {
    changeInput,
    clickOnOption,
    clickOnToggleButton,
    defaultProps,
    getInput,
    getOptions,
    getToggleButton,
    menuSize,
    renderComboBox,
    tab,
    userEvent,
} from "./ComboBox.testUtils";

beforeEach(() => {
    // https://github.com/TanStack/virtual/issues/641
    vi.spyOn(Element.prototype, "getBoundingClientRect").mockImplementation(() => ({
        width: 120,
        height: 120,
        top: 0,
        left: 0,
        bottom: 0,
        right: 0,
        x: 0,
        y: 0,
        toJSON: () => {},
    }));
});

afterEach(() => {
    vi.restoreAllMocks();
});

test("renders a closed combobox", function comboboxBaseRender() {
    renderComboBox();

    expect(getInput()).toBeInTheDocument();
    expect(getToggleButton()).toBeInTheDocument();
    expect(screen.getByPlaceholderText(defaultProps.placeholder)).toBeInTheDocument();
});

test("toggle button aria label can be custom", function customToggleButtonAriaLabel() {
    const toggleButtonAriaLabel = "open this pls";
    renderComboBox({toggleButtonAriaLabel});

    expect(getToggleButton(toggleButtonAriaLabel)).toBeInTheDocument();
});

test("combobox can have options selected", async function optionSelect() {
    const onChange = vi.fn();
    const option = defaultProps.options[1];

    renderComboBox({onChange});

    await clickOnToggleButton();

    expect(getOptions()).toHaveLength(defaultProps.options.length);

    await clickOnOption(option.title);

    expect(getInput()).toHaveValue(option.title);
    expect(getOptions()).toHaveLength(0);
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith(option);
});

test("combobox can have options filtered", async function optionsFiltering() {
    const option = defaultProps.options[0];

    renderComboBox();

    await changeInput(option.title.slice(0, 3));

    expect(getOptions()).toHaveLength(1);
});

test("combobox should display message when no options are available", async function showNoResultsMessage() {
    renderComboBox();

    await changeInput("$#@!#%");

    const options = getOptions();

    expect(options).toHaveLength(0);
    expect(screen.getByText(defaultProps.noResultsMessage)).toBeInTheDocument();
    expect(getInput(`${defaultProps.label} ${defaultProps.noResultsMessage}`)).toBeInTheDocument();

    await tab();

    expect(screen.queryByText(defaultProps.noResultsMessage)).not.toBeInTheDocument();
});

test("input should have aria-invalid set to true based on the error prop", function invalidState() {
    renderComboBox({error: true});

    expect(getInput()).toHaveAttribute("aria-invalid", "true");
});

test("combobox should have a default value based on the defaultValue prop", async function defaultValueProp() {
    const defaultValue = defaultProps.options[2];
    const newValue = defaultProps.options[1];

    renderComboBox({defaultValue});

    expect(getInput()).toHaveValue(defaultValue.title);

    await clickOnToggleButton();
    await clickOnOption(newValue.title);

    expect(getInput()).toHaveValue(newValue.title);
});

test("value prop should have precedence over defaultValue if both are passed", function controlledPrecedence() {
    const defaultValue = defaultProps.options[1];
    const value = defaultProps.options[2];

    renderComboBox({defaultValue, value});

    expect(getInput()).toHaveValue(value.title);
});

test("combobox should have its value controlled by the value prop", async function controlledValue() {
    const value = defaultProps.options[1];
    const newValue = defaultProps.options[2];
    const selectedValue = defaultProps.options[3];

    const {rerender} = renderComboBox({value});

    expect(getInput()).toHaveValue(value.title);

    await clickOnToggleButton();
    await clickOnOption(selectedValue.title);

    rerender({value: newValue});

    expect(getInput()).toHaveValue(newValue.title);
});

test("input should be disabled based on the disabled prop", function disabledState() {
    renderComboBox({disabled: true});

    expect(getInput()).toBeDisabled();
    expect(getToggleButton()).toBeDisabled();
});

test("combobox should show all the options after selection", async function allOptionsAfterSelection() {
    const option = defaultProps.options[0];
    renderComboBox();

    await clickOnToggleButton();
    await changeInput(option.title.slice(0, 3));
    await clickOnOption(option.title);
    await clickOnToggleButton();

    expect(getOptions()).toHaveLength(4);
    expect(getInput()).toHaveValue(option.title);

    await clickOnToggleButton();
    await clickOnToggleButton();

    expect(getOptions()).toHaveLength(4);
    expect(getInput()).toHaveValue(option.title);

    await changeInput(option.title, true);

    expect(getOptions()).toHaveLength(1);
    expect(getInput()).toHaveValue(option.title);
});

test("items can be disabled", async function disabledItems() {
    const options = [...defaultProps.options];
    const disabledOption = options[0];
    const enabledOption = options[1];
    disabledOption.disabled = true;

    renderComboBox({options});

    await clickOnToggleButton();

    await clickOnOption(disabledOption.title);

    expect(getInput()).not.toHaveValue(disabledOption.title);
    expect(getOptions()).toHaveLength(options.length);

    await clickOnOption(enabledOption.title);

    expect(getInput()).toHaveValue(enabledOption.title);
    expect(getOptions()).toHaveLength(0);
});

test("menu does not close on item selection if disableCloseOnSelect is passed", async function stayOpenOnSelect() {
    const option = defaultProps.options[1];

    renderComboBox({disableCloseOnSelect: true});

    await clickOnToggleButton();
    await clickOnOption(option.title);

    expect(getOptions()).toHaveLength(4);
});

test("combobox can be in a loading state", function loadingComboBox() {
    renderComboBox({loading: true});

    expect(screen.getByRole("status", {name: DEFAULT_LOADING_SPINNER_ARIA_LABEL})).toBeInTheDocument();
    expect(getInput(`${defaultProps.label} ${DEFAULT_LOADING_SPINNER_ARIA_LABEL}`)).toBeInTheDocument();
});

test("loading spinner aria label can be custom", function customLoadingSpinnerAriaLabel() {
    const loadingSpinnerAriaLabel = "I am loading, wait pls.";

    renderComboBox({loading: true, loadingSpinnerAriaLabel});

    expect(getInput(`${defaultProps.label} ${loadingSpinnerAriaLabel}`)).toBeInTheDocument();
});

test("combobox options can have custom string equivalent", async function customOptionLabel() {
    const optionString = "I am an option";
    const getOptionLabel = vi.fn().mockImplementation(() => optionString);

    renderComboBox({getOptionLabel});

    await clickOnToggleButton();

    expect(screen.getAllByRole("option", {name: optionString})).toHaveLength(4);
    for (let index = 0; index < defaultProps.options.length; index++) {
        expect(getOptionLabel).toHaveBeenNthCalledWith(index + 1, defaultProps.options[index]);
    }
});

test("combobox options can be filtered customly", async function customFilter() {
    const filterOptions = vi
        .fn<
            SelectOption[],
            [
                options: SelectOption[],
                filterHelpers: {inputValue: string; getOptionLabel: (option: SelectOption) => string},
            ]
        >()
        .mockImplementation((options) => {
            return options.slice(0, 2);
        });

    renderComboBox({filterOptions});
    await clickOnToggleButton();
    await changeInput("hello");

    expect(getOptions()).toHaveLength(2);
});

test("combobox can have a name", function withName() {
    const name = "test";

    renderComboBox({name});

    expect(getInput()).toHaveAttribute("name", name);
});

test("combobox can be marked as required", function withRequired() {
    const label = "Required";
    const requiredSuffix = " *";
    renderComboBox({required: true, label});
    expect(getInput(label + requiredSuffix)).toHaveAttribute("aria-required", "true");
});

test("required combobox is marked invalid in Constraint Validation API when no value is selected", async function withRequired2() {
    const label = "Required2";
    const requiredSuffix = " *";
    renderComboBox({required: true, label, name: label});

    const input = getInput(label + requiredSuffix);

    expect(input.checkValidity()).toBe(false);
    expect(input.validationMessage).toBe("Please select an option.");

    // and even if something is written in input as filter but nothing is still selected
    if (document.activeElement !== input) {
        await tab(); // if it's not the only one in the tab order, use input.focus()
    }

    const user = userEvent.setup();

    await user.keyboard("hello");

    expect(input.value).toBe("hello");
    expect(input.checkValidity()).toBe(false);
});

test("required combobox is marked valid in Constraint Validation API when a value is selected", async function withRequired3() {
    const label = "Required3";
    const requiredSuffix = " *";
    renderComboBox({required: true, label, name: label});

    const input = getInput(label + requiredSuffix);

    expect(input.checkValidity()).toBe(false);

    const option = defaultProps.options[1];

    await clickOnToggleButton();

    expect(screen.queryAllByRole("option")).toHaveLength(defaultProps.options.length);

    await clickOnOption(option.title);

    expect(input).toHaveValue(option.title);
    expect(input.checkValidity()).toBe(true);
});

test("combobox can receive onInputChange callback", async function onInputChangeCallback() {
    const inputValue = "dance";
    const callArguments: string[] = [];
    const expectedCallArguments = new Array<string>(inputValue.length)
        .fill("")
        .map((_subString, index) => inputValue.slice(0, index + 1));
    const onInputChange = vi
        .fn<void, [React.ChangeEvent<HTMLInputElement>]>()
        .mockImplementation((e) => callArguments.push(e.target.value));

    renderComboBox({onInputChange});

    await changeInput(inputValue);

    expect(onInputChange).toHaveBeenCalledTimes(inputValue.length);
    expect(callArguments).toEqual(expectedCallArguments);
});

test("combobox can receive onInputChange callback with freeSolo", async function onInputChangeWithFreeSoloCallback() {
    const inputValue = "dance";
    const callArguments: string[] = [];
    const expectedCallArguments = new Array<string>(inputValue.length)
        .fill("")
        .map((_subString, index) => inputValue.slice(0, index + 1));
    const onInputChange = vi
        .fn<void, [React.ChangeEvent<HTMLInputElement>]>()
        .mockImplementation((e) => callArguments.push(e.target.value));

    renderComboBox({onInputChange, freeSolo: true});

    await changeInput(inputValue);

    expect(onInputChange).toHaveBeenCalledTimes(inputValue.length);
    expect(callArguments).toEqual(expectedCallArguments);
});

test("combobox can have its inputValue controlled", async function controlInputValue() {
    const controlledInputValue = "red";
    const inputValue = "blue";

    renderComboBox({inputValue: controlledInputValue});

    await changeInput(inputValue);

    expect(getInput()).toHaveValue(controlledInputValue);
});

test("combobox can have inputValue initialised", async function initialInputValue() {
    const defaultInputValue = "red";
    const inputValue = "blue";

    renderComboBox({defaultInputValue});

    await changeInput(inputValue);

    expect(getInput()).toHaveValue(inputValue);
});

test("combobox can have its options changed", async function optionsChange() {
    const options1 = [{value: "1"}, {value: "2"}];
    const options2 = [{value: "a"}, {value: "b"}];

    const {rerender} = renderComboBox({options: options1});

    await clickOnToggleButton();

    const initialRenderOptions = getOptions();

    expect(initialRenderOptions[0]).toHaveTextContent(options1[0].value);
    expect(initialRenderOptions[1]).toHaveTextContent(options1[1].value);

    rerender({options: options2});

    const finalRenderOptions = getOptions();

    expect(finalRenderOptions[0]).toHaveTextContent(options2[0].value);
    expect(finalRenderOptions[1]).toHaveTextContent(options2[1].value);
});

test("combobox can have a custom value in freeSolo mode", async function initialInputValue() {
    const inputValue = "Custom value";
    const noResultsMessage = "No results";
    const onChange = vi.fn();
    const addOptionLabel = `Add "${inputValue}"`;

    renderComboBox({freeSolo: true, noResultsMessage, onChange});

    await changeInput(inputValue);

    expect(getOptions()).toHaveLength(1);
    expect(getOptions()[0]).toHaveTextContent(addOptionLabel);
    expect(screen.getByRole("option", {name: addOptionLabel})).toBeInTheDocument();

    await clickOnOption(addOptionLabel);

    expect(getInput()).toHaveValue(inputValue);
    expect(screen.queryByText(noResultsMessage)).not.toBeInTheDocument();
    expect(onChange).toHaveBeenCalledTimes(1);
});

test("onChange is also called when selected item is cleared", async function onChangeOnClear() {
    const defaultValue = defaultProps.options[1];
    const onChange = vi.fn();

    renderComboBox({defaultValue, onChange});

    await changeInput("{Escape}");

    expect(getInput()).toHaveValue("");
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith(null);
});

test("renderOption is called when passed", async () => {
    const optionContent = "hello";
    const renderOption = vi.fn().mockImplementation((props) => <div key={props.option.value}>{optionContent}</div>);

    renderComboBox({renderOption});

    await clickOnToggleButton();

    expect(screen.getAllByText(optionContent)).toHaveLength(menuSize);
});

test("Empty string for label renders ComboBox correctly", async () => {
    const placeholder = "test-combobox-label";
    renderComboBox({required: true, placeholder, label: ""});

    expect(screen.getByPlaceholderText(placeholder)).toBeInTheDocument();
});

test("undefined for label renders ComboBox correctly", async () => {
    const placeholder = "test-combobox-label";
    renderComboBox({required: true, placeholder, label: undefined});

    expect(screen.getByPlaceholderText(placeholder)).toBeInTheDocument();
});
