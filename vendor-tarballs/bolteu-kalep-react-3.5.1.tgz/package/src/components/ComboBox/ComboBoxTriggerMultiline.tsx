import React from "react";

import {ChevronDown, Clear} from "@bolteu/kalep-react-icons";

import {MultiSelectChip} from "@/components/_internal/MultiSelectChip";
import {SpinnerIcon} from "@/components/_internal/SpinnerIcon";
import type {State} from "@/components/TextField/TextField.types";
import {cx} from "@/helpers/utils/cx";
import {noop, noopNull} from "@/helpers/utils/noop";
import {GhostButton} from "@/index";

import {DEFAULT_LOADING_SPINNER_ARIA_LABEL, DEFAULT_TOGGLE_BUTTON_ARIA_LABEL} from "./BaseComboBox";
import type {ComboBoxTriggerProps, Size} from "./ComboBox.types";

const sizeStyles: Record<Size, string> = {
    sm: "min-h-9 pl-3 pr-2 bolt-font-body-s-regular gap-2",
    md: "min-h-12 pl-3 pr-2 bolt-font-body-m-regular gap-2",
    lg: "min-h-14 pl-3 pr-2 bolt-font-body-m-regular gap-2",
};

const wrapperStyles: Record<State, string> = {
    idle: "border-special-nulled focus:border-action-primary text-primary",
    disabled: "border-neutral-secondary cursor-not-allowed text-tertiary bg-special-nulled placeholder-tertiary",
    error: "border-danger-primary text-primary",
};

const getInputTextStyles = (disabled?: boolean, hasValue?: boolean) => {
    if (disabled) {
        return "text-tertiary placeholder-tertiary";
    }

    if (hasValue) {
        return "text-primary placeholder-secondary";
    }

    return "text-secondary placeholder-secondary";
};

export function ComboBoxTriggerMultiline(props: ComboBoxTriggerProps) {
    const {
        clearable,
        closeMenu,
        disabled,
        error,
        id,
        isOpen,
        generatedId,
        getDropdownProps,
        getInputProps,
        getOptionLabel,
        getToggleButtonProps,
        inputValue,
        inputWrapperRef,
        loading,
        loadingSpinnerAriaLabel = DEFAULT_LOADING_SPINNER_ARIA_LABEL,
        name,
        noResultsMessageId,
        onClear,
        onDelete,
        onInputChange,
        openMenu,
        placeholder,
        required,
        renderStartSlot,
        shouldShowNoResultsMessage,
        shouldRenderEndSlotIcon = true,
        size = "md",
        toggleButtonAriaLabel = DEFAULT_TOGGLE_BUTTON_ARIA_LABEL,
        toggleButtonRef,
        value,
    } = props;

    const inputRef = React.useRef<HTMLInputElement>(null);
    const chipRefs = React.useRef<Record<string, React.RefObject<HTMLDivElement>>>({});

    const isValueArray = Array.isArray(value);
    const chipGap = React.useMemo(() => (size === "sm" ? 4 : 6), [size]);

    const loadingSpinnerId = id ?? `kalep-combo-box-loading-spinner-${generatedId}`;
    const hasValue = isValueArray ? Boolean(value.length) : Boolean(value);
    const hasMoreThanOneChip = isValueArray && value.length > 1;

    if (isValueArray) {
        value.forEach((option) => {
            if (option.value && !chipRefs.current[option.value]) {
                chipRefs.current[option.value] = chipRefs.current[option.value] || React.createRef<HTMLDivElement>();
            }
        });
    }

    const ddProps = getDropdownProps?.(inputRef);

    const inputA11yProps = getInputProps({
        ref: inputRef,
        disabled,
        onChange: onInputChange,
        ...ddProps,
        onKeyDown: (e: React.KeyboardEvent) => {
            ddProps?.onKeyDown?.(e);
            if (inputValue.length === 0 && e.key === "Backspace" && isValueArray && value.length > 0) {
                onDelete?.(value.length - 1); // Remove last selected item
            }

            if (e.key === "Escape") {
                inputRef.current?.blur();
            }
        },
    });

    if (loading) {
        inputA11yProps["aria-labelledby"] = `${inputA11yProps["aria-labelledby"]} ${loadingSpinnerId}`;
    }
    if (shouldShowNoResultsMessage) {
        inputA11yProps["aria-labelledby"] = `${inputA11yProps["aria-labelledby"]} ${noResultsMessageId}`;
    }

    const handleClearButtonClick = React.useCallback(
        (e: React.MouseEvent<Element, MouseEvent> | React.KeyboardEvent<Element>) => {
            onClear?.();
            e.preventDefault();
            e.stopPropagation();
        },
        [onClear],
    );

    const onClick = React.useCallback(
        (e: React.MouseEvent) => {
            if (disabled) {
                return;
            }

            if (!toggleButtonRef?.current?.contains(e.target as Node)) {
                openMenu();
            }

            if (toggleButtonRef?.current?.contains(e.target as Node) && isOpen) {
                closeMenu();
            }
        },
        [openMenu, closeMenu, isOpen, toggleButtonRef, disabled],
    );

    const renderEndSlot = React.useCallback(() => {
        if (props.renderEndSlot) {
            return (
                <div className={cx("flex max-w-6 shrink-0 items-center gap-1")}>
                    {props.renderEndSlot(props, noopNull)}
                </div>
            );
        }
        const showClearButton = !disabled && clearable && hasMoreThanOneChip;
        return (
            <div className={cx("flex flex-shrink-0 items-center justify-end", size !== "sm" && "gap-1")}>
                <GhostButton
                    onClick={handleClearButtonClick}
                    overrideClassName={cx(
                        "group/clear",
                        "invisible mx-1 w-6 flex-shrink-0",
                        "z-[1021]", // Above the dropdown
                        showClearButton && "group-hover/trigger:visible",
                    )}
                    tabIndex={-1}
                >
                    <div
                        className={cx(
                            isOpen ? "flex" : "hidden",
                            "group-hover/trigger:flex",
                            "items-center justify-center",
                        )}
                    >
                        <Clear
                            aria-hidden="true"
                            className={cx(`
                              text-tertiary
                              group-hover/clear:text-secondary
                            `)}
                            size={size === "sm" ? "md" : "lg"}
                        />
                    </div>
                </GhostButton>

                {loading && (
                    <SpinnerIcon
                        id={loadingSpinnerId}
                        aria-label={loadingSpinnerAriaLabel}
                        className={cx("mx-1 flex-none animate-spin text-action-secondary")}
                        size={size}
                        role="status"
                    />
                )}

                {!loading && shouldRenderEndSlotIcon && (
                    <button
                        type="button"
                        {...getToggleButtonProps({ref: toggleButtonRef, "aria-label": toggleButtonAriaLabel})}
                        className={cx(
                            "m-0 flex cursor-pointer items-center border-0 bg-transparent p-0",
                            disabled && "cursor-not-allowed",
                        )}
                        disabled={disabled}
                    >
                        <ChevronDown
                            className={cx(
                                "m-1 flex-none transition-transform",
                                disabled ? "text-tertiary" : "text-primary",
                                isOpen && "rotate-180",
                            )}
                            size={size === "sm" ? "md" : "lg"}
                        />
                    </button>
                )}
            </div>
        );
    }, [
        props,
        disabled,
        clearable,
        hasMoreThanOneChip,
        size,
        handleClearButtonClick,
        isOpen,
        loading,
        loadingSpinnerId,
        loadingSpinnerAriaLabel,
        shouldRenderEndSlotIcon,
        getToggleButtonProps,
        toggleButtonRef,
        toggleButtonAriaLabel,
    ]);

    return (
        <div
            ref={inputWrapperRef}
            className={cx(
                "group/trigger",
                "flex w-full items-center justify-end",
                "rounded-md border-2 border-solid",
                "overflow-hidden outline-none",
                "caret-border-action-primary bg-neutral-secondary",
                "duration-100 ease-linear",
                disabled ? "cursor-not-allowed" : "cursor-text",
                disabled && wrapperStyles.disabled,
                error && wrapperStyles.error,
                !disabled && !error && wrapperStyles.idle,
                sizeStyles[size],
                !error && isOpen && "border-action-primary bg-special-nulled",
            )}
            onClick={onClick}
            onKeyPress={noop}
            role="textbox"
            tabIndex={-1}
        >
            {typeof renderStartSlot === "function" && (
                <div className={cx("flex max-w-6 items-center")}>{renderStartSlot(props, noopNull)} </div>
            )}

            <div className={cx("w-full min-w-0")}>
                <div
                    className={cx(
                        "relative flex w-full flex-1 items-center transition-transform",
                        "min-w-0", // Preventing overflowing flex container - https://stackoverflow.com/questions/36230944/prevent-flex-items-from-overflowing-a-container
                        "flex-wrap overflow-visible",
                        "py-2",
                    )}
                    style={{gap: chipGap}}
                >
                    {hasValue && Array.isArray(value) ? (
                        <>
                            {value.map((option, i) => (
                                <MultiSelectChip
                                    key={option.value}
                                    ref={option.value ? chipRefs.current[option.value] : undefined}
                                    label={getOptionLabel(option)}
                                    disabled={disabled}
                                    size={size}
                                    onDelete={() => onDelete?.(i)}
                                />
                            ))}
                        </>
                    ) : null}

                    <input
                        ref={inputRef}
                        disabled={disabled}
                        name={name}
                        onChange={onInputChange}
                        onFocus={openMenu}
                        className={cx(
                            "block border-none bg-special-nulled p-0 outline-none",
                            size === "sm" ? "bolt-font-body-s-regular h-6" : "bolt-font-body-m-regular h-7",
                            disabled ? "cursor-not-allowed" : "cursor-text",
                            "w-full min-w-12 flex-1 truncate",
                            getInputTextStyles(disabled, !!inputValue.length),
                        )}
                        placeholder={placeholder}
                        type="text"
                        aria-required={required}
                        {...inputA11yProps}
                    />
                </div>
            </div>
            {renderEndSlot()}
        </div>
    );
}
