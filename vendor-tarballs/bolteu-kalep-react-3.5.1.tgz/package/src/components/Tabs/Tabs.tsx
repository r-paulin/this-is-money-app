import * as React from "react";

import {GhostButton} from "@/components/GhostButton";
import {cx} from "@/helpers/utils/cx";

type Alignment = "left" | "right" | "center";
type Size = "sm" | "md";

const sizes: Record<Size, string> = {
    sm: "p-2 bolt-font-body-s-accent",
    md: "p-3 bolt-font-body-m-accent",
};

/**
 * The generic type `T` allows flexibility in specifying the `id` property type.
 * When `T` is not explicitly provided and inferred from `id`, the `id` type will be a more generic
 * type (`string` or `number`) instead of a specific value.
 */
interface TabInfo<T extends string | number> {
    id: T extends string ? string : number;
}

export interface TabsProps<T extends string | number = string> {
    selectedTab: T;
    onChange: (selectedTab: T) => void;
    children: React.ReactNode;
    alignment?: Alignment;
    size?: Size;
    overrideClassName?: string;
}

export interface TabProps<T extends string | number> extends TabInfo<T> {
    label?: string;
    children?: React.ReactNode;
    disabled?: boolean;
    href?: string;
    render?: (props: InnerTabProps<T>) => JSX.Element;
}

export interface InnerTabProps<T extends string | number> extends TabProps<T> {
    active: boolean;
    onClick: (id: T) => void;
    size?: Size;
}

const alignStyles: Record<Alignment, string> = {
    left: "justify-start",
    right: "justify-end",
    center: "justify-center",
};

function InnerTab<T extends string | number>({
    id: key,
    label,
    disabled,
    onClick,
    active,
    size = "md",
    children,
    href,
    render,
}: InnerTabProps<T>) {
    const handleClick = React.useCallback(() => {
        onClick(key as T);
    }, [onClick, key]);

    if (render) {
        return render({
            id: key,
            disabled,
            onClick: handleClick,
            active,
            children,
            href,
            size,
        });
    }

    return (
        <GhostButton
            key={key}
            disabled={disabled}
            onClick={handleClick}
            role="tab"
            aria-selected={active}
            as={href ? "a" : "div"}
            {...(href ? {href, overrideClassName: "no-underline"} : {})}
        >
            <div
                className={cx(
                    "border-0 border-b-[0.1875rem] border-solid border-b-transparent text-secondary",
                    sizes[size],
                    active && "border-b-action-primary text-primary",
                    disabled && "text-tertiary",
                )}
            >
                {label || children}
            </div>
        </GhostButton>
    );
}

export function Tabs<T extends string | number>({
    selectedTab,
    children,
    onChange,
    alignment,
    size,
    overrideClassName,
}: TabsProps<T>) {
    const tabs = React.Children.map(children, (child: any) => {
        if (!React.isValidElement<TabProps<T>>(child)) {
            return null;
        }

        const {label, id, disabled: isDisabled} = child.props;

        if (!child.props.id || (!child.props.children && !child.props.label)) {
            return null;
        }

        const isActive = child.props.id === selectedTab;

        return (
            <InnerTab
                {...child.props}
                key={id}
                id={id}
                label={label}
                disabled={isDisabled}
                onClick={onChange}
                active={isActive}
                size={size}
            />
        );
    });

    return (
        <div
            role="tablist"
            className={cx(
                "flex border-0 border-b border-solid border-separator",
                alignStyles[alignment || "left"],
                overrideClassName,
            )}
        >
            {tabs}
        </div>
    );
}

function Tab<T extends string | number>(_props: TabProps<T>) {
    return null;
}

Tabs.Tab = Tab;
