import * as React from "react";

import type {Meta, StoryFn} from "@storybook/react-webpack5";

import {cx} from "@/helpers/utils/cx";

import {Badge} from "../Badge";
import {Tabs} from "./index";
import type {InnerTabProps} from "./Tabs";

export default {
    title: "Navigation/Tabs",
    component: Tabs,
    tags: ["autodocs"],
} as Meta<typeof Tabs>;

const Template: StoryFn<typeof Tabs> = (args) => {
    const [selectedTab, setSelectedTab] = React.useState<string>("foo");

    return (
        <>
            <Tabs {...args} onChange={setSelectedTab} selectedTab={selectedTab}>
                <Tabs.Tab id="foo" label="Foo" />
                <Tabs.Tab id="bar" label="Bar" />
                <Tabs.Tab id="baz" label="Baz" />
            </Tabs>
            <div role="tabpanel" className="mt-2">
                {selectedTab === "foo" && "Foo content"}
                {selectedTab === "bar" && "Bar content"}
                {selectedTab === "baz" && "Baz content"}
            </div>
        </>
    );
};

export const Default = Template.bind({});
Default.args = {
    alignment: "left",
};

export const Small = Template.bind({});
Small.args = {
    size: "sm",
};

export const DisabledTabs = () => {
    const [selectedTab, setSelectedTab] = React.useState<number>(1);
    const handleChange = React.useCallback((newValue: number) => {
        setSelectedTab(newValue);
    }, []);

    return (
        <Tabs onChange={handleChange} selectedTab={selectedTab}>
            <Tabs.Tab id={1} label="Foo" />
            <Tabs.Tab id={2} label="Bar" />
            <Tabs.Tab id={3} label="Baz" disabled />
        </Tabs>
    );
};

export const LinkTabs = () => {
    const [selectedTab, setSelectedTab] = React.useState<number>(() => {
        const urlParams = new URLSearchParams(window.location.search);
        const tabId = urlParams.get("tab");

        if (tabId && !Number.isNaN(Number(tabId))) {
            return Number(tabId);
        }

        return 1;
    });

    const handleChange = React.useCallback((newValue: number) => {
        setSelectedTab(newValue);
    }, []);

    return (
        <Tabs onChange={handleChange} selectedTab={selectedTab}>
            <Tabs.Tab id={1} href="/?path=/story/navigation-tabs--custom-tabs&tab=1">
                <span className="mr-2">All</span>
                <Badge badgeContent="8" color="green" />
            </Tabs.Tab>
            <Tabs.Tab id={2} href="/?path=/story/navigation-tabs--custom-tabs&tab=2">
                <span className="mr-2">Backlog</span>
                <Badge badgeContent="3" color="green" />
            </Tabs.Tab>
            <Tabs.Tab id={3} disabled href="/?path=/story/navigation-tabs--custom-tabs&tab=3">
                <span className="mr-2">My assigned</span>
                <Badge badgeContent="4" color="neutral" />
            </Tabs.Tab>
            <Tabs.Tab id={4} href="/?path=/story/navigation-tabs--custom-tabs&tab=4">
                <span className="mr-2">The Rest</span>
                <Badge badgeContent="NEW!" />
            </Tabs.Tab>
        </Tabs>
    );
};

const CustomTab = ({children, active, onClick, id, ...rest}: InnerTabProps<number>) => {
    const handleClick = React.useCallback(() => {
        onClick(id);
    }, [id, onClick]);

    return (
        <button
            type="button"
            role="tab"
            aria-selected={active}
            className={cx(
                "flex cursor-pointer items-center rounded-t px-4 py-3 font-semibold",
                active ? "bg-warning-secondary" : "bg-layer-floor-1",
            )}
            onClick={handleClick}
            {...rest}
        >
            {children}
        </button>
    );
};

export const CustomTabs = () => {
    const [selectedTab, setSelectedTab] = React.useState<number>(1);

    const renderCustomTab = React.useCallback((props: InnerTabProps<number>) => {
        return <CustomTab {...props} />;
    }, []);

    const handleChange = React.useCallback((newValue: number) => {
        setSelectedTab(newValue);
    }, []);

    return (
        <Tabs onChange={handleChange} selectedTab={selectedTab}>
            <Tabs.Tab id={1} render={renderCustomTab}>
                <span className="mr-2">All</span>
                <Badge badgeContent="8" color="green" />
            </Tabs.Tab>
            <Tabs.Tab id={2} render={renderCustomTab}>
                <span className="mr-2">Backlog</span>
                <Badge badgeContent="3" color="green" />
            </Tabs.Tab>
            <Tabs.Tab id={3} disabled render={renderCustomTab}>
                <span className="mr-2">My assigned</span>
                <Badge badgeContent="4" color="neutral" />
            </Tabs.Tab>
            <Tabs.Tab id={4} render={renderCustomTab}>
                <span className="mr-2">The Rest</span>
                <Badge badgeContent="NEW!" />
            </Tabs.Tab>
        </Tabs>
    );
};
