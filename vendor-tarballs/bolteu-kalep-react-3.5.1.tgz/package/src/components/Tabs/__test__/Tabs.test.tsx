import * as React from "react";

import {vi} from "vitest";
import {render as testingLibraryRender, screen} from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import type {TabsProps} from "../index";
import {Tabs} from "../index";

const tabs = [<Tabs.Tab key="foo" id="foo" label="Foo" />, <Tabs.Tab key="bar" id="bar" label="Bar" />];
const noop = () => {};

function render({selectedTab = "foo", onChange = noop, children = tabs}: Partial<TabsProps> = {}) {
    return testingLibraryRender(
        <Tabs selectedTab={selectedTab} onChange={onChange}>
            {children}
        </Tabs>,
    );
}

describe("Tabs test suite", () => {
    test("renders to document", () => {
        render();
        expect(screen.getByRole("tablist")).toBeInTheDocument();
    });

    test("has a selected tab", () => {
        render();
        const selectedTab = screen.getByRole("tab", {selected: true});
        expect(selectedTab).toBeInTheDocument();
        expect(selectedTab.children[0]).toHaveTextContent("Foo");
    });

    test("has an unselected tab by default", () => {
        render();
        const unselectedTab = screen.getByRole("tab", {selected: false});
        expect(unselectedTab).toBeInTheDocument();
        expect(unselectedTab.children[0]).toHaveTextContent("Bar");
    });

    test("calls onChange when tab is clicked", async () => {
        const onChange = vi.fn();
        render({onChange});

        const user = userEvent.setup();
        await user.click(screen.getByRole("tab", {selected: false}));

        expect(onChange).toHaveBeenCalledTimes(1);
        expect(onChange).toHaveBeenCalledWith("bar");
    });

    test("renders disabled tab properly", async () => {
        const onChange = vi.fn();
        render({
            onChange,
            children: [
                <Tabs.Tab key="foo" label="Foo" id="foo" />,
                <Tabs.Tab key="bar" label="Bar" id="bar" disabled />,
            ],
            selectedTab: "foo",
        });

        const tab = screen.getByRole("tab", {name: "Bar"});
        expect(tab).toHaveAttribute("aria-disabled", "true");

        const user = userEvent.setup();
        await user.click(tab);

        expect(onChange).not.toHaveBeenCalled();
    });

    test("ignores non-tab children", async () => {
        const randomContent = "Randomstuff";
        render({children: [<Tabs.Tab key="foo" label="Foo" id="foo" />, <div key="hello">{randomContent}</div>]});
        expect(screen.queryByText(randomContent)).not.toBeInTheDocument();
    });
});
