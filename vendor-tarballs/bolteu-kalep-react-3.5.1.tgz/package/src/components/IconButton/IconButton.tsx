import * as React from "react";

import type {KalepIconElement} from "@bolteu/kalep-react-icons/dist/types";

import {SpinnerIcon} from "@/components/_internal/SpinnerIcon";
import {cx} from "@/helpers/utils/cx";

import {Tooltip} from "../Tooltip";

const NOOP = () => {};

type Size = "sm" | "md" | "lg";
type Shape = "square" | "round";
export type Variant = "primary" | "secondary" | "ghost" | "danger" | "floating" | "inverted" | "floating-inverted";
type State = "disabled" | "loading" | "selected";
type LabelType = "hidden" | "tooltip" | "text"; // This naming could really be a lot better. Needs research.

export interface IconButtonProps extends Omit<React.ComponentPropsWithoutRef<"button">, "className"> {
    size?: Size;
    variant?: Variant;
    shape?: Shape;
    loading?: boolean;
    selected?: boolean;
    labelType?: LabelType;
    overrideClassName?: string;
    width?: number | string;
    icon: KalepIconElement;
    "aria-label": string;
}

const sizes: Record<Size, string> = {
    sm: "w-9 h-9",
    md: "w-12 h-12",
    lg: "w-14 h-14",
};

const variants: Record<Variant, string> = {
    primary: "bg-action-primary hover:bg-active-action-primary text-static-key-light",
    ghost: "bg-transparent hover:bg-active-neutral-secondary text-primary",
    secondary: "bg-neutral-secondary hover:bg-active-neutral-secondary text-primary",
    danger: "bg-danger-primary hover:bg-active-danger-primary text-static-key-light",
    floating: "bg-layer-floor-2 shadow-md hover:shadow active:shadow text-primary",
    inverted: "bg-neutral-primary hover:bg-active-neutral-primary text-primary-inverted",
    "floating-inverted": "bg-neutral-primary shadow-md hover:bg-active-neutral-primary text-primary-inverted",
};

const shapes: Record<Shape, string> = {
    round: "rounded-full",
    square: "rounded-md",
};

const states: Record<State, string | Partial<Record<Variant, string>>> = {
    disabled: {
        primary:
            "bg-neutral-secondary hover:bg-neutral-secondary active:bg-neutral-secondary cursor-not-allowed text-tertiary",
        secondary: "bg-transparent hover:bg-transparent active:bg-transparent cursor-not-allowed text-tertiary",
        floating: "cursor-not-allowed text-tertiary shadow-md",
    },
    loading: "bg-active-neutral-secondary text-primary cursor-progress",
    selected: "bg-neutral-primary text-primary-inverted",
};

const labelStyles: Record<Size, string> = {
    sm: "bolt-font-body-xs-regular w-9",
    md: "bolt-font-body-xs-regular w-12",
    lg: "bolt-font-body-s-regular w-14",
};

/**
 * Decides which classlist to apply. Allows defining order of priority between various states.
 * @returns string of Tailwind classes
 */
function selectClasses(variant: Variant, disabled: boolean, selected: boolean, loading: boolean) {
    if (disabled) {
        if (["secondary", "ghost", "filled"].includes(variant)) {
            return (states.disabled as Partial<Record<Variant, string>>).secondary;
        }
        if (["floating", "floating-inverted"].includes(variant)) {
            return (states.disabled as Partial<Record<Variant, string>>).floating;
        }

        return (states.disabled as Partial<Record<Variant, string>>).primary;
    }
    if (loading) {
        return states.loading;
    }
    if (selected) {
        return states.selected;
    }

    return variants[variant];
}

/**
 * Always set the size prop to the same value as the Button size.
 * @returns IconElement with given size prop.
 */
function withSize(icon: KalepIconElement, size: Size) {
    return React.cloneElement(icon, {size: size === "md" ? "lg" : size});
}

function IconButton(
    {
        icon,
        size = "md",
        variant = "secondary",
        shape = "round",
        type = "button",
        selected = false,
        disabled = false,
        loading = false,
        labelType = "hidden",
        onClick,
        overrideClassName,
        width,
        ...props
    }: IconButtonProps,
    ref: React.Ref<HTMLButtonElement>,
) {
    // it does not make sense to be disabled and loading at the same time.
    const isLoading = !disabled && loading;

    const buttonContent = withSize(icon, size);
    const content = isLoading ? withSize(<SpinnerIcon className={cx("animate-spin")} />, size) : buttonContent;

    const iconButton = (
        <button
            type={type}
            disabled={disabled}
            onClick={isLoading ? NOOP : onClick}
            className={cx(
                "inline-flex flex-col items-center justify-center",
                "cursor-pointer border-none bg-special-nulled p-0",
                shape === "round" && labelType !== "text" ? "rounded-full" : "rounded-md",
                overrideClassName,
            )}
            {...props}
            ref={ref}
            style={width ? {...(props.style || {}), width} : props.style}
        >
            <span
                className={cx(
                    "flex items-center justify-center",
                    "duration-150 ease-linear",
                    !disabled && "active:scale-975 active:duration-100 active:ease-in-out",
                    sizes[size],
                    shapes[shape],
                    selectClasses(variant, disabled, selected, loading),
                    overrideClassName,
                )}
            >
                {content}
            </span>
            {labelType === "text" && (
                <span
                    className={cx(
                        "inline-block truncate pt-1 text-primary antialiased",
                        labelStyles[size],
                        width && "!w-full",
                    )}
                >
                    {props["aria-label"]}
                </span>
            )}
        </button>
    );

    if (labelType === "tooltip") {
        return <Tooltip content={props["aria-label"]}>{iconButton}</Tooltip>;
    }

    return iconButton;
}

const ForwardedIconButton = React.forwardRef<HTMLButtonElement, IconButtonProps>(IconButton);

export {ForwardedIconButton as IconButton};
