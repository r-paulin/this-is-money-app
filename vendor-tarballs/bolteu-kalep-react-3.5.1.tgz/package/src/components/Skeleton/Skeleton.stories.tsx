import * as React from "react";

import type {Meta, StoryFn} from "@storybook/react-webpack5";

import {Skeleton} from "./index";

export default {
    title: "Data Display/Skeleton",
    component: Skeleton,
    tags: ["autodocs"],
    parameters: {
        docs: {
            description: {
                component: "Skeleton is used as a placeholder for loading content.",
            },
        },
    },
    argTypes: {
        variant: {
            description: "The variant to use.",
            defaultValue: "rounded",
            table: {
                defaultValue: {summary: "rounded"},
            },
        },
        textSize: {
            description: "Manage the size (`height`) of the `text` skeleton.",
            defaultValue: "text-base",
            table: {
                defaultValue: {summary: "text-base"},
            },
        },
        width: {
            description: "Manage the `width` of the skeleton. For `circular` variant, it will be the diameter.",
            defaultValue: "100%",
            table: {
                defaultValue: {summary: "100%"},
            },
        },
        height: {
            description: "Manage the `height` of the `rounded` skeleton.",
            defaultValue: "2rem",
            table: {
                defaultValue: {summary: "2rem"},
            },
        },
    },
} as Meta<typeof Skeleton>;

export const Default: StoryFn<typeof Skeleton> = (args) => {
    const width = args.variant === "circular" ? "3rem" : args.width;

    return (
        <div className={`
          m-0 flex max-h-80 w-96 flex-col gap-y-3 overflow-y-auto px-0 py-1
          empty:py-0
        `}>
            <Skeleton {...args} width={width} />
        </div>
    );
};

Default.args = {
    variant: "text",
};

export const Layout: StoryFn<typeof Skeleton> = () => (
    <div className={`
      m-0 flex w-[400px] flex-col gap-y-3 rounded border border-solid border-neutral-secondary px-4 py-4 shadow
    `}>
        <div className="flex flex-1 items-center gap-x-2">
            <div className="shrink-0">
                <Skeleton variant="circular" />
            </div>
            <div className="flex flex-1 flex-col gap-y-1">
                <Skeleton variant="text" textSize="text-sm" />
                <Skeleton variant="text" width="66%" textSize="text-sm" />
            </div>
        </div>
        <Skeleton variant="rounded" height="200px" />
        <div className="flex flex-1 flex-col gap-y-1">
            <Skeleton variant="text" textSize="text-sm" />
            <Skeleton variant="text" width="88%" textSize="text-sm" />
        </div>
    </div>
);

export const Gallery: StoryFn<typeof Skeleton> = () => (
    <div className="m-0 flex max-w-[640px] flex-row gap-x-3 px-0 py-1">
        <div className="flex flex-1 flex-col gap-y-1">
            <Skeleton variant="rounded" height="120px" />
            <Skeleton variant="text" />
            <Skeleton variant="text" width="66%" />
        </div>
        <div className="flex flex-1 flex-col gap-y-1">
            <Skeleton variant="rounded" height="120px" />
            <Skeleton variant="text" />
            <Skeleton variant="text" width="66%" />
        </div>
        <div className="flex flex-1 flex-col gap-y-1">
            <Skeleton variant="rounded" height="120px" />
            <Skeleton variant="text" />
            <Skeleton variant="text" width="66%" />
        </div>
    </div>
);
