import React from "react";

import {cx} from "@/helpers/utils/cx";

import type {SkeletonProps, SkeletonTypographySize, SkeletonVariant} from "./Skeleton.types";

const styles: {
    base: string;
    variants: Record<SkeletonVariant, string>;
    textHeightVariants: Record<SkeletonTypographySize, string>;
    textPaddingVariants: Record<SkeletonTypographySize, string>;
} = {
    base: "bg-active-neutral-secondary animate-pulse w-full",
    variants: {
        text: "rounded-sm",
        circular: "rounded-full",
        rounded: "rounded-sm",
    },
    textHeightVariants: {
        "text-xs": "0.625rem",
        "text-sm": "0.75rem",
        "text-base": "0.875rem",
        "text-lg": "1rem",
        "text-xl": "1.125rem",
        "text-2xl": "1.375rem",
        "text-3xl": "1.625rem",
        "text-4xl": "2rem",
        "text-5xl": "2.125rem",
        "text-6xl": "2.625rem",
    },
    textPaddingVariants: {
        "text-xs": "0.1875rem 0",
        "text-sm": "0.25rem 0",
        "text-base": "0.3125rem 0",
        "text-lg": "0.25rem 0",
        "text-xl": "0.1875rem 0",
        "text-2xl": "0.3125rem 0",
        "text-3xl": "0.3125rem 0",
        "text-4xl": "0.25rem 0",
        "text-5xl": "0.1875rem 0",
        "text-6xl": "0.1875rem 0",
    },
};

export function Skeleton(props: SkeletonProps) {
    const {variant} = props;

    switch (variant) {
        case "circular": {
            return (
                <div
                    className={cx(styles.base, styles.variants[variant])}
                    style={{
                        width: props.width ?? "3rem",
                        height: props.width ?? "3rem",
                    }}
                />
            );
        }

        case "text": {
            const size = props.textSize ?? "text-base";
            return (
                <div style={{padding: styles.textPaddingVariants[size]}}>
                    <div
                        className={cx(styles.base, styles.variants[variant])}
                        style={{
                            width: props.width ?? "100%",
                            height: styles.textHeightVariants[size],
                        }}
                    />
                </div>
            );
        }

        case "rounded":
        default: {
            return (
                <div
                    className={cx(styles.base, styles.variants[variant])}
                    style={{
                        width: props.width ?? "100%",
                        height: props.height ?? "2rem",
                    }}
                />
            );
        }
    }
}
