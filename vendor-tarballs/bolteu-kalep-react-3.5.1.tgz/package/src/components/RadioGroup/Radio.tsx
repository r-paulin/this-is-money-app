import * as React from "react";

import {RadioGroupContext} from "@/components/RadioGroup/RadioGroup";
import {cx} from "@/helpers/utils/cx";

export interface RadioProps extends Omit<React.ComponentPropsWithoutRef<"input">, "className"> {
    disabled?: boolean;
    checked?: boolean;
    label?: string;
    name?: string;
    value?: string;
}

function Radio(
    {
        disabled = false,
        checked,
        defaultChecked,
        label,
        onChange: onChangeProp,
        name: nameProp,
        value: valueProp,
        required,
        ...props
    }: RadioProps,
    ref: React.Ref<HTMLInputElement>,
) {
    // If we are inside a RadioGroup, get some props from that context
    const group = React.useContext(RadioGroupContext);
    const name = group?.name ?? nameProp; // group name overrides local name.
    const isDisabled = disabled || group?.disabled;
    const isRequired = required || group?.required;
    const isError = group?.error;

    /*
        Scenarios:

        1. Radio is not used inside RadioGroup but is controlled by the user
            - "checked" prop is assumed to be true/false and is passed to the input,
            - "defaultChecked" should not be passed, React will complain.
            - "onChange" is directly passed to the input

        2. Radio is not used inside RadioGroup but is uncontrolled
            - "checked" is either not provided or explicitly undefined
            - "defaultChecked" is passed to the input,
            - "onChange" is directly passed to the input

        3. RadioGroup is used and is controlled by the user (value is provided to RadioGroup)
            - checked value is derived from the group value and the value of the current Radio
            - "defaultChecked" should not be passed, React will complain.
            - "onChange" is passed to the input, but it is wrapped in a function that calls the group onChange

        4. RadioGroup is used and is uncontrolled (value is not provided to RadioGroup)
            - value coming from the group is undefined, comparing that to the value of the current Radio will always return false
            - "defaultValue" from group is compared to the value of the current Radio -> defaultChecked value is derived
            - "onChange" is passed to the input, but it is wrapped in a function that calls the group onChange
        
        Note: we do not handle nested RadioGroups
    */

    let isChecked = checked;
    let isDefaultChecked = defaultChecked;

    if (group && group.value && valueProp != null) {
        isChecked = group.value === valueProp;
    }

    if (group && !group.value && group.defaultValue) {
        isDefaultChecked = group.defaultValue === valueProp;
    }

    let onChange = onChangeProp;
    if (group?.onChange && valueProp != null) {
        onChange = (event: React.ChangeEvent<HTMLInputElement>) => {
            group.onChange?.(event);
            onChangeProp?.(event);
        };
    }

    const inputElement = (
        <input
            type="radio"
            {...props}
            name={name}
            defaultChecked={isDefaultChecked}
            checked={isChecked}
            disabled={isDisabled}
            onChange={onChange}
            value={valueProp}
            ref={ref}
            required={isRequired}
            className={cx(
                /* shape */ "m-0 h-6 w-6 shrink-0 appearance-none rounded-full",
                /* cursor */ `
                  cursor-pointer
                  disabled:cursor-not-allowed
                `,
                /* unchecked */ "border-2 border-solid bg-special-nulled",
                /* unchecked border color */ isError ? "border-danger-primary" : "border-neutral-primary",
                /* checked */ "checked:border-[7px] checked:bg-static-key-light",
                /* checked border color */ !isError && "checked:border-action-primary",
                /* disabled */ "disabled:border-0 disabled:bg-special-disabled",
                /* disabled + checked */ `
                  disabled:checked:border-[7px] disabled:checked:border-separator disabled:checked:bg-special-nulled
                `, // this border-separator usage is not safe
                /* hover */ !isDisabled &&
                    (isError
                        ? "hover:border-active-danger-primary"
                        : "hover:border-active-neutral-primary hover:checked:border-active-action-primary"),
                /* animate */ "duration-150 ease-linear",
            )}
        />
    );

    if (label) {
        return (
            <label
                className={cx(
                    "bolt-font-body-m-regular inline-flex gap-2",
                    isError ? "text-danger-primary" : "text-primary",
                    !isDisabled && "cursor-pointer",
                )}
            >
                {inputElement}
                {label}
            </label>
        );
    }

    return inputElement;
}

const ForwardedRadio = React.forwardRef<HTMLInputElement, RadioProps>(Radio);

export {ForwardedRadio as Radio};
