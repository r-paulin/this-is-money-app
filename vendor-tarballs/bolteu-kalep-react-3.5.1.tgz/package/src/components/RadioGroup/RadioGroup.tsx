import * as React from "react";

import type {RenderFunction} from "@/helpers";
import {useId} from "@/helpers";
import {cx} from "@/helpers/utils/cx";

export interface RadioContextType {
    name: string;
    value?: string;
    defaultValue?: string;
    disabled?: boolean;
    onChange?: React.ChangeEventHandler<HTMLInputElement>; // DOM API gives us back only strings
    required?: boolean;
    error?: boolean;
}

export interface RadioGroupProps {
    /**
     * If the  label prop is not provided, indicate where an accessible label for
     * this RadioGroup can be found.
     */
    "aria-labelledby"?: string;
    children: React.ReactNode;
    /**
     * default checked item in an uncontrolled RadioGroup
     */
    defaultValue?: string;
    /**
     * Disables all child Radio components, regardless of their own disabled prop
     */
    disabled?: boolean;
    /**
     * The Radio group can be in an error state.
     */
    error?: boolean;
    /**
     * Helper text to be displayed below the Radio group
     */
    helperText?: React.ReactNode;
    /**
     * When provided creates an accessible label for the whole group.
     * If you need a custom label, please construct your own label and link it
     * to the radiogroup via the aria-labelledby prop.
     */
    label?: string;
    /**
     * name prop will be applied to each child Radio component
     */
    name: string;
    /**
     * Called with the value prop of selected Radio component
     */
    onChange?: React.ChangeEventHandler<HTMLInputElement>;
    /**
     * Marks the Radio children as required in order to make the whole group required.
     */
    required?: boolean;
    /**
     * Custom renderer for helperText
     */
    renderHelperText?: RenderFunction<RadioGroupProps & {helperTextId: string}>;
    /**
     * Changes the layout to row instead of default column
     */
    row?: boolean;
    /**
     * when value is set, RadioGroup is a controlled component
     */
    value?: string;
}

export const RadioGroupContext = React.createContext<RadioContextType | null>(null);

function RadioGroup(props: RadioGroupProps, ref: React.Ref<HTMLDivElement>) {
    const {
        name,
        value,
        defaultValue,
        disabled,
        error = false,
        label,
        "aria-labelledby": ariaLabelledBy,
        onChange,
        required = false,
        renderHelperText = renderHelperTextDefault,
        row = false,
        children,
        helperText: _helperText,
    } = props;
    const generatedId = useId();
    const localLabelId = `${generatedId}-label`;
    const helperTextId = `${generatedId}-helptext`;
    const labelId = ariaLabelledBy ?? localLabelId;

    const contextValues = React.useMemo(
        () => ({
            name,
            value,
            defaultValue,
            disabled,
            onChange,
            required,
            error,
        }),
        [name, value, defaultValue, disabled, onChange, required, error],
    );
    return (
        <RadioGroupContext.Provider value={contextValues}>
            <div
                aria-invalid={error}
                aria-labelledby={labelId}
                aria-orientation={row ? "horizontal" : "vertical"}
                role="radiogroup"
                className={cx("flex flex-col gap-3")}
                ref={ref}
            >
                {label && (
                    <span
                        className={cx(
                            "bolt-font-body-s-accent text-primary",
                            required && "after:text-danger-primary after:content-['_*']",
                        )}
                        id={labelId}
                    >
                        {label}
                    </span>
                )}
                <div className={cx("flex gap-3", row ? "flex-row" : "flex-col items-start")}>{children}</div>
                {renderHelperText({...props, helperTextId}, renderHelperTextDefault)}
            </div>
        </RadioGroupContext.Provider>
    );
}

function renderHelperTextDefault({
    helperText,
    error,
    helperTextId,
    disabled,
}: RadioGroupProps & {helperTextId: string}): JSX.Element | null {
    if (!helperText) {
        return null;
    }

    return (
        <p
            className={cx(
                "bolt-font-body-s-regular m-0 text-secondary",
                disabled && "text-tertiary",
                error && "text-danger-primary",
            )}
            id={helperTextId}
        >
            {helperText}
        </p>
    );
}

const forwardedRadioGroup = React.forwardRef<HTMLDivElement, RadioGroupProps>(RadioGroup);

export {forwardedRadioGroup as RadioGroup};
