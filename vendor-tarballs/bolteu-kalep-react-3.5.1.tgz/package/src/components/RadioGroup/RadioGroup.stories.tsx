import * as React from "react";

import type {Meta, StoryFn} from "@storybook/react-webpack5";

import type {RadioGroupProps, RadioProps} from "@/components/RadioGroup";
import {Radio, RadioGroup} from "@/components/RadioGroup";

export default {
    title: "Inputs/RadioGroup",
    component: RadioGroup,
    tags: ["autodocs"],
    subcomponents: {Radio},
} as Meta<typeof RadioGroup>;

const items = ["A", "B", "C", "D"];
const longLabel = "Lorem ipsum dolor sit, amet consectetur adipisicing elit.";

const RadioGroupTemplate: StoryFn<typeof RadioGroup> = (args: RadioGroupProps) => (
    <div className="w-80 p-4">
        <RadioGroup {...args}>
            {items.map((item) => (
                <Radio value={item} label={item === "C" ? longLabel : `Item ${item}`} key={item} />
            ))}
        </RadioGroup>
    </div>
);

export const Primary = RadioGroupTemplate.bind({});
Primary.args = {
    name: "letter",
    disabled: false,
    defaultValue: "B",
    row: false,
    label: "Choose an item to play with",
    helperText: "Use helperText to provide additional context to the radio group",
    onChange: (event: React.ChangeEvent<HTMLInputElement>) => console.log(event.target.value),
};

const RadioTemplate: StoryFn<typeof Radio> = (args: RadioProps) => <Radio {...args} />;
export const SingleRadioButton = RadioTemplate.bind({});
SingleRadioButton.args = {
    disabled: false,
    checked: undefined,
    label: "Providing the label prop renders this ... label",
    name: "name-of-field",
    value: "value-to-identify-the-option",
};

export const Required = RadioGroupTemplate.bind({});
Required.args = {
    ...Primary.args,
    name: "required-story",
    required: true,
};

export const Error = RadioGroupTemplate.bind({});
Error.args = {
    ...Primary.args,
    name: "error-story",
    error: true,
};

export const ControlledRadioGroup = () => {
    const [val, setVal] = React.useState<string>("2");
    const handleChange = React.useCallback(
        (event: React.ChangeEvent<HTMLInputElement>) => setVal(event.target.value),
        [],
    );

    return (
        <RadioGroup name="blah" value={val} onChange={handleChange}>
            <Radio label="Item 1" value="1" />
            <Radio label="Item 2" value="2" />
            <Radio label="Item 3" value="3" disabled />
        </RadioGroup>
    );
};

export const UncontrolledRadioGroup = () => {
    const logArguments = React.useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
        console.log(event.target.value);
    }, []);

    return (
        <RadioGroup name="blah2" onChange={logArguments} row>
            <Radio label="Item 1" value="a" />
            <Radio label="Item 2" value="b" />
            <Radio label="Item 3" value="c" />
        </RadioGroup>
    );
};

export const WithoutRadioGroup = () => {
    return (
        <div className="flex gap-3">
            <Radio label="Item 1" value="a" name="blah3" />
            <Radio label="Item 2" value="b" name="blah3" />
            <Radio label="Item 3" value="c" name="blah3" />
        </div>
    );
};
