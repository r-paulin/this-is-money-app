import * as React from "react";

import {vi} from "vitest";
import type {RenderResult} from "@testing-library/react";
import {render, screen} from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import type {RadioGroupProps, RadioProps} from "@/components/RadioGroup";
import {Radio, RadioGroup} from "@/components/RadioGroup";

const defaultRadioItems: RadioProps[] = [
    {value: "on", label: "On"},
    {value: "off", label: "Off"},
];

function renderRadioGroup(props?: Partial<RadioGroupProps>): RenderResult {
    const utils = render(
        <RadioGroup name="test" {...props}>
            {defaultRadioItems.map((radioProps) => (
                <Radio {...radioProps} key={radioProps.value} />
            ))}
        </RadioGroup>,
    );

    return utils;
}

describe("RadioGroup test suite", () => {
    test("renders into document with expected radio buttons", () => {
        renderRadioGroup();

        const radioGroup = screen.getByRole("radiogroup");

        expect(radioGroup).toBeInTheDocument();
        expect(radioGroup).toHaveAttribute("aria-invalid", "false");
        expect(radioGroup).toHaveAttribute("aria-orientation", "vertical");
        expect(screen.getAllByRole("radio")).toHaveLength(2);
        expect(screen.getByLabelText("On")).toBeInTheDocument();
        expect(screen.getByLabelText("Off")).toBeInTheDocument();
    });

    test("can have a checked child", () => {
        render(
            <RadioGroup name="test" onChange={vi.fn()}>
                <Radio value="1" checked />
                <Radio value="2" />
                <Radio value="3" />
            </RadioGroup>,
        );

        const inputs = screen.getAllByRole<HTMLInputElement>("radio");
        inputs.forEach((input, index) => {
            expect(input.checked).toEqual(index === 0);
        });
    });

    test("controlled RadioGroup sets expected child Radio checked", () => {
        render(
            <RadioGroup name="test" value="3" onChange={vi.fn()}>
                <Radio value="1" />
                <Radio value="2" />
                <Radio value="3" />
            </RadioGroup>,
        );

        const inputs = screen.getAllByRole<HTMLInputElement>("radio");
        inputs.forEach((input, index) => {
            expect(input.checked).toEqual(index === 2);
        });
    });

    test("ignores checked prop on Radio if group is controlled", () => {
        render(
            <RadioGroup name="test" value="3" onChange={vi.fn()}>
                <Radio value="1" />
                <Radio value="2" checked />
                <Radio value="3" />
            </RadioGroup>,
        );

        const inputs = screen.getAllByRole<HTMLInputElement>("radio");
        inputs.forEach((input, index) => {
            expect(input.checked).toEqual(index === 2); // only the value=3 input is checked, despite value=2 having checked prop
        });
    });

    test("ignores name prop on Radio when wrapped in RadioGroup", () => {
        render(
            <RadioGroup name="this-is-more-important">
                <Radio />
                <Radio name="but-i-want-my-own-name" />
                <Radio name="me-toooo" />
            </RadioGroup>,
        );

        const inputs = screen.getAllByRole<HTMLInputElement>("radio");
        inputs.forEach((input) => {
            expect(input).toHaveAttribute("name", "this-is-more-important");
        });
    });

    test("name is passed along to children", () => {
        const name = "test-this-here";
        render(
            <RadioGroup name={name}>
                <Radio />
                <Radio />
                <Radio />
            </RadioGroup>,
        );

        const inputs = screen.getAllByRole<HTMLInputElement>("radio");
        inputs.forEach((input) => {
            expect(input).toHaveAttribute("name", name);
        });
    });

    test("disables children if group is disabled", () => {
        render(
            <RadioGroup name="test" disabled>
                <Radio />
                <Radio />
                <Radio />
            </RadioGroup>,
        );

        const inputs = screen.getAllByRole<HTMLInputElement>("radio");
        inputs.forEach((input) => {
            expect(input).toBeDisabled();
        });
    });

    test("can have a label", () => {
        const label = "stuff";
        renderRadioGroup({label});

        expect(screen.getByText(label, {selector: "span"})).toBeInTheDocument();
    });

    test("can be required", () => {
        const label = "required stuff";
        renderRadioGroup({label, required: true});

        const inputs = screen.getAllByRole<HTMLInputElement>("radio");
        inputs.forEach((input) => {
            expect(input).toBeRequired();
        });
        expect(screen.getByText(new RegExp(label), {selector: "span"})).toHaveClass(
            "after:text-danger-primary after:content-['_*']",
        );
    });

    test("can be in an error state", () => {
        renderRadioGroup({error: true});

        expect(screen.getByRole("radiogroup")).toHaveAttribute("aria-invalid", "true");
    });

    test("can have a horizontal orientation", () => {
        renderRadioGroup({row: true});

        expect(screen.getByRole("radiogroup")).toHaveAttribute("aria-orientation", "horizontal");
    });

    test("child Radio can be disabled apart from group", () => {
        render(
            <RadioGroup name="test" disabled={false}>
                <Radio />
                <Radio disabled />
                <Radio />
            </RadioGroup>,
        );

        const inputs = screen.getAllByRole<HTMLInputElement>("radio");
        inputs.forEach((input, index) => {
            expect(input.disabled).toEqual(index === 1);
        });
    });

    test("onChange is called when unchecked Radio button is clicked", async () => {
        const onChange = vi.fn();
        const singleRadioOnChange = vi.fn();

        render(
            <RadioGroup name="test" onChange={onChange}>
                {defaultRadioItems.map((radioProps) => (
                    <Radio {...radioProps} onChange={singleRadioOnChange} key={radioProps.value} />
                ))}
            </RadioGroup>,
        );

        expect(screen.getByLabelText("On")).not.toBeChecked();

        await userEvent.click(screen.getByLabelText("On"));

        expect(screen.getByLabelText("On")).toBeChecked();
        expect(onChange).toHaveBeenCalledTimes(1);
        expect(onChange).toHaveBeenCalledWith(
            expect.objectContaining({target: expect.objectContaining({value: "on"})}),
        );
        expect(singleRadioOnChange).toHaveBeenCalledTimes(1);
        expect(singleRadioOnChange).toHaveBeenCalledWith(
            expect.objectContaining({target: expect.objectContaining({value: "on"})}),
        );
    });

    test("defaultValue checks the appropriate child Radio", async () => {
        render(
            <RadioGroup name="test" defaultValue="2">
                <Radio value="0" />
                <Radio value="1" />
                <Radio value="2" />
            </RadioGroup>,
        );

        const inputs = screen.getAllByRole<HTMLInputElement>("radio");
        inputs.forEach((input, index) => {
            expect(input.checked).toEqual(index === 2);
        });
    });
});
