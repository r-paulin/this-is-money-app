import type {BadgeAppearance, BadgeColorOverrides} from "./Badge.types";
import {isBadgeColorConfig} from "./Badge.types";

export function selectBadgeColors(appearance: BadgeAppearance): BadgeColorOverrides {
    if (isBadgeColorConfig(appearance)) {
        return {
            "--badge-bg": appearance.light.main,
            "--badge-content": appearance.light.content ?? "var(--color-static-content-key-light)",
            "--badge-bg-dark": appearance.dark?.main /* ?? generateDarkMainColor */,
            "--badge-content-dark": appearance.dark?.content,
        };
    }

    return {
        "--badge-bg":
            appearance === "neutral"
                ? "var(--color-bg-neutral-secondary-hard)"
                : `var(--color-bg-${appearance}-primary)`,
        "--badge-content": "var(--color-static-content-key-light)",
    };
}
