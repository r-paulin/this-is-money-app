import * as React from "react";

import type {RenderResult} from "@testing-library/react";
import {render} from "@testing-library/react";

import type {BadgeProps} from "../Badge";
import {Badge} from "../Badge";

export * from "@testing-library/react";

export const childContent = "Hello World!";

export const defaultProps = {
    badgeContent: 3,
    children: <div>{childContent}</div>,
};

export function renderBadge(props?: Partial<BadgeProps>): RenderResult {
    const utils = render(<Badge {...defaultProps} {...props} />);

    return utils;
}
