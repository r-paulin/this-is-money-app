import React from "react";

import figma from "@figma/code-connect";

import {Badge} from "@/components/Badge";

figma.connect(
    Badge,
    "https://www.figma.com/design/nU1QBYZxTAYsIZ4X0jW4tV/%F0%9F%8C%88-Kalep-Web-Semantic-Components?node-id=691-5204&t=XbYA9XHNm3b1pDkW-4",
    {
        imports: ["import { Badge } from '@bolteu/kalep-react'"],
        props: {
            variant: figma.enum("- type", {
                "01 - Content": "standard",
                "02 - MaxCount": "standard",
                "03 - m-Dot": "dot",
                "04 - s-Dot": "s-dot",
            }),
            badgeContent: figma.enum("- type", {
                "01 - Content": figma.textContent("8"),
                "03 - m-Dot": figma.textContent("8"),
                "04 - s-Dot": figma.textContent("8"),
                "02 - MaxCount": 10,
            }),
            maxCount: figma.enum("- type", {
                "02 - MaxCount": 9,
            }),
            stroke: figma.boolean("stroke"),
            appearance: figma.enum("- color", {
                "01 - Green": "action",
                "02 - Red": "danger",
                "03 - Purple": "promo",
                "04 - Grey": "neutral",
                "05 - Yellow": "warning",
            }),
        },
        example: ({variant, badgeContent, maxCount, stroke, appearance}) => {
            return (
                <Badge
                    variant={variant}
                    badgeContent={badgeContent}
                    maxCount={maxCount}
                    stroke={stroke}
                    appearance={appearance}
                />
            );
        },
    },
);
