export interface BottomSheetProps {
    children: React.ReactNode;
    /**
     * The controlled open state of the BottomSheet.
     */
    isOpen: boolean;
    /**
     * Event handler called when the open state of the BottomSheet changes.
     *
     * @param isOpen boolean
     * @returns void
     */
    onOpenChange: (isOpen: boolean) => void;
    /**
     * Gets triggered after the open or close animation ends, it receives an open argument with the open state of the BottomSheet by the time the function was triggered. Useful to revert any state changes for example.
     *
     * @param isOpen boolean
     * @returns void
     */
    onAnimationChange?: (isOpen: boolean) => void;
    /**
     * Specify a container element to portal the BottomSheet into.
     */
    container?: HTMLElement | null;
    /**
     * When `false` dragging, clicking outside, pressing esc, etc. will not close the BottomSheet. Use this in combination with the open prop, otherwise you won't be able to open/close the BottomSheet.
     *
     * @default true
     */
    isDismissible?: boolean;
    /**
     * Whether the bottom sheet displays overlay or not.
     *
     * @default true
     */
    hasOverlay?: boolean;
    /**
     * Whether the bottom sheet has a handle or not.
     *
     * @default true
     */
    hasHandle?: boolean;
    /**
     * Whether the bottom sheet has a close button.
     *
     * @default false
     */
    hasCloseButton?: boolean;
    /**
     * Array of numbers from 0 to 1 that corresponds to % of the screen a given snap point should take up. You can also use px values, which doesn't take screen height into account.
     */
    snapPoints?: (string | number)[];
}
