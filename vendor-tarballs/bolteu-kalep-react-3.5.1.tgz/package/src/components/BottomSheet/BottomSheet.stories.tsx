import * as React from "react";

import type {Meta, StoryObj} from "@storybook/react-webpack5";

import {Calendar} from "@bolteu/kalep-react-icons";

import {cx} from "@/helpers/utils/cx";
import {ComboBox, Select, TextField} from "@/index";

import {Button} from "../Button";
import {BottomSheet} from "./BottomSheet";

export default {
    title: "Layout/BottomSheet",
    component: BottomSheet,
    tags: ["autodocs"],
    argTypes: {},
} as Meta<typeof BottomSheet>;

export const Default: StoryObj<typeof BottomSheet> = () => {
    const [isOpen, setOpen] = React.useState(false);
    const handleClick = React.useCallback(() => setOpen(true), []);

    return (
        <>
            <div className={cx("flex justify-center p-8")}>
                <Button variant="tertiary" onClick={handleClick}>
                    Click to open
                </Button>
            </div>
            <BottomSheet isOpen={isOpen} onOpenChange={setOpen}>
                <div className={cx("h-48 py-2 text-center")}>Content goes here</div>
            </BottomSheet>
        </>
    );
};

Default.args = {};

export const SnapPoints: StoryObj<typeof BottomSheet> = () => {
    const [isOpen, setOpen] = React.useState(false);
    const handleClick = React.useCallback(() => setOpen(true), []);

    return (
        <div>
            <div className={cx("flex justify-center p-8")}>
                <Button variant="tertiary" onClick={handleClick}>
                    Click to open
                </Button>
            </div>
            <BottomSheet isOpen={isOpen} onOpenChange={setOpen} snapPoints={[0.3, 0.7, 1]}>
                <div className={cx("h-80 py-2 text-center text-base")}>
                    <div>BottomSheet snaps to given snapPoints here:</div>
                    <div>30%, 70% and 100% of the screen height.</div>
                </div>
            </BottomSheet>
        </div>
    );
};

SnapPoints.args = {};

export const WithCloseButton: StoryObj<typeof BottomSheet> = () => {
    const [isOpen, setOpen] = React.useState(false);
    const handleClick = React.useCallback(() => setOpen(true), []);
    const containerRef = React.useRef<HTMLDivElement>(null);

    return (
        <>
            <div className={cx("flex justify-center p-8")} ref={containerRef}>
                <Button variant="tertiary" onClick={handleClick}>
                    Click to open
                </Button>
            </div>
            {/* Setting the container here to make it portal inside story div which controls LTR/RTL behaviour */}
            <BottomSheet isOpen={isOpen} onOpenChange={setOpen} hasCloseButton container={containerRef.current}>
                <div className={cx("h-80 py-2 text-center")}>Content goes here</div>
            </BottomSheet>
        </>
    );
};

WithCloseButton.args = {};

export const FormElements: StoryObj<typeof BottomSheet> = () => {
    const [isOpen, setOpen] = React.useState(false);
    const handleClickOpen = React.useCallback(() => setOpen(true), []);
    const handleClickClose = React.useCallback(() => setOpen(false), []);

    return (
        <>
            <div className={cx("flex justify-center p-8")}>
                <Button variant="tertiary" onClick={handleClickOpen}>
                    Click to open
                </Button>
            </div>
            <BottomSheet isOpen={isOpen} onOpenChange={setOpen}>
                <div className="flex flex-col gap-6 p-4 pb-8">
                    <div className="flex gap-4">
                        <div className="w-1/3">
                            <TextField label="User ID" fullWidth placeholder="12345" />
                        </div>
                        <TextField label="Username" fullWidth placeholder="bolt.first.lastname" />
                    </div>
                    <Select
                        placeholder="Pick a country"
                        options={[
                            {title: "Estonia", value: "estonia"},
                            {title: "Latvia", value: "latvia"},
                            {title: "Lithuania", value: "lithuania"},
                            {title: "Romania", value: "romania"},
                        ]}
                        label="Country"
                        fullWidth
                    />
                    <ComboBox
                        options={[
                            {title: "Tallinn", value: "tln"},
                            {title: "Tartu", value: "trt"},
                            {title: "Riga", value: "rix"},
                            {title: "Bucharest", value: "buc"},
                        ]}
                        label="City"
                        fullWidth
                        placeholder="Pick a city"
                    />
                    <ComboBox
                        options={[
                            {title: "Admin", value: "1"},
                            {title: "Moderator", value: "2"},
                            {title: "OPS Country Manager", value: "3"},
                            {title: "CS UK", value: "4"},
                        ]}
                        label="Role"
                        placeholder="e.g. OPS Country Manager"
                        fullWidth
                    />
                    <TextField
                        label="Created on"
                        placeholder="30-05-2020"
                        type="text"
                        renderEndSlot={() => <Calendar />}
                        fullWidth
                    />
                    <ComboBox
                        multiple
                        label="Verticals"
                        options={[
                            {title: "Driver", value: "1"},
                            {title: "Rider", value: "2"},
                            {title: "Delivery", value: "3"},
                            {title: "Rentals", value: "4"},
                            {title: "Business", value: "5"},
                        ]}
                        fullWidth
                        placeholder="e.g Rentals, Delivery"
                    />
                    <div className={cx("mb-2 flex items-center justify-end gap-2")}>
                        <Button onClick={handleClickClose}>Apply</Button>
                        <Button variant="secondary" onClick={handleClickClose}>
                            Cancel
                        </Button>
                    </div>
                </div>
            </BottomSheet>
        </>
    );
};

FormElements.args = {};
