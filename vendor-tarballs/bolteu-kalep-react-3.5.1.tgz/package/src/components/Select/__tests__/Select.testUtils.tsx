import * as React from "react";

import type {RenderResult} from "@testing-library/react";
import {render, screen, within} from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import {Select} from "../Select";
import type {SelectProps} from "../Select.types";

export * from "@testing-library/react";
export {userEvent};

interface RenderSelectResult extends Omit<RenderResult, "rerender"> {
    rerender: (props: Partial<SelectProps>) => void;
}

export const defaultProps: {
    options: {title: string; value: string; disabled?: boolean}[];
    placeholder: string;
    label: string;
} = {
    options: [
        {title: "Red", value: "color_1"},
        {title: "Blue", value: "color_2"},
        {title: "Green", value: "color_3"},
        {title: "Yellow", value: "color_4"},
    ],
    placeholder: "Pick a color",
    label: "Wall Paint:",
};
export const menuSize = defaultProps.options.length;

export const user = userEvent.setup();

export function renderSelect(props?: Partial<SelectProps>): RenderSelectResult {
    const utils = render(<Select {...defaultProps} {...props} />);

    function rerender(rerenderProps: Partial<SelectProps>): void {
        utils.rerender(<Select {...defaultProps} {...rerenderProps} />);
    }

    return {...utils, rerender};
}

export function getToggleButton(name = defaultProps.label): HTMLElement {
    return screen.getByLabelText(name, {selector: "button"});
}

export function getMenu(name = defaultProps.label): HTMLElement {
    return screen.getByRole("listbox", {name});
}

export function getOptions(): HTMLElement[] {
    return screen.queryAllByRole("option");
}

export async function clickOnToggleButton(): Promise<void> {
    await user.click(getToggleButton());
}

export async function clickOnOption(optionTitle: string): Promise<void> {
    await user.click(screen.getByRole("option", {name: optionTitle}));
}

export function getSelectedOption(selectedOptionName: string): HTMLSpanElement | null {
    const toggleButton = getToggleButton();
    return within(toggleButton).getByText(selectedOptionName);
}

export async function clickOnSelectedOption(selectedOptionName: string): Promise<void> {
    await user.click(getSelectedOption(selectedOptionName) as HTMLSpanElement);
}
