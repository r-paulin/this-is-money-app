import * as React from "react";

import {vi} from "vitest";

import {DEFAULT_LOADING_SPINNER_ARIA_LABEL} from "../SelectTrigger";
import {
    clickOnOption,
    clickOnToggleButton,
    defaultProps,
    getMenu,
    getOptions,
    getToggleButton,
    menuSize,
    renderSelect,
    screen,
} from "./Select.testUtils";

beforeEach(() => {
    // https://github.com/TanStack/virtual/issues/641
    vi.spyOn(Element.prototype, "getBoundingClientRect").mockImplementation(() => ({
        width: 120,
        height: 120,
        top: 0,
        left: 0,
        bottom: 0,
        right: 0,
        x: 0,
        y: 0,
        toJSON: () => {},
    }));
});

afterEach(() => {
    vi.restoreAllMocks();
});

test("renders a closed select", function selectBaseRender() {
    renderSelect();

    const toggleButton = getToggleButton();

    expect(toggleButton).toHaveTextContent(defaultProps.placeholder);
    expect(toggleButton).not.toHaveAttribute("aria-describedby");
});

test("menu opens on button click", async function selectOpenOnClick() {
    renderSelect();

    await clickOnToggleButton();

    expect(getOptions()).toHaveLength(menuSize);
});

test("can have a helper text", function helperTexts() {
    const helperTextString = "Pick the first option!";

    renderSelect({helperText: helperTextString});

    expect(screen.getByText(helperTextString)).toBeInTheDocument();
    expect(getToggleButton()).toHaveAttribute("aria-describedby", expect.any(String));
});

test("can have a label", function errorSelect() {
    const label = "Your options:";

    renderSelect({label});

    expect(screen.getByTestId("kalep-label")).toHaveTextContent(label);
});

test("can have a name", function namedSelect() {
    const name = "select-a-country";

    renderSelect({name});

    expect(getToggleButton()).toHaveAttribute("name", name);
});

test("can be disabled", function errorSelect() {
    renderSelect({disabled: true});

    expect(getToggleButton()).toBeDisabled();
});

test("options can be selected by clicking", async function selectOption() {
    const option = defaultProps.options[1];
    const onChange = vi.fn();
    renderSelect({onChange});

    await clickOnToggleButton();
    await clickOnOption(option.title);

    expect(getToggleButton()).toBeInTheDocument();
    expect(getToggleButton()).toHaveTextContent(option.title);
    expect(onChange).toHaveBeenCalledWith(option);
    expect(onChange).toHaveBeenCalledTimes(1);
});

test("select should have a default value based on the defaultValue prop", async () => {
    const defaultValue = defaultProps.options[2];
    const newValue = defaultProps.options[1];

    renderSelect({defaultValue});

    expect(getToggleButton()).toHaveTextContent(defaultValue.title);

    await clickOnToggleButton();
    await clickOnOption(newValue.title);

    expect(getToggleButton()).toHaveTextContent(newValue.title);
});

test("value prop should have precedence over defaultValue if both are passed", () => {
    const defaultValue = defaultProps.options[1];
    const value = defaultProps.options[2];

    renderSelect({defaultValue, value});

    expect(getToggleButton()).toHaveTextContent(value.title);
});

test("select should have its value controlled by the value prop", async () => {
    const value = defaultProps.options[1];
    const newValue = defaultProps.options[2];
    const selectedValue = defaultProps.options[3];

    const {rerender} = renderSelect({value});

    expect(getToggleButton()).toHaveTextContent(value.title);

    await clickOnToggleButton();
    await clickOnOption(selectedValue.title);

    expect(getToggleButton()).toHaveTextContent(value.title);

    rerender({value: newValue});

    expect(getToggleButton()).toHaveTextContent(newValue.title);
});

test("renderOption is called when passed", async () => {
    const optionContent = "hello";
    const renderOption = vi.fn().mockImplementation((props) => <div key={props.option.value}>{optionContent}</div>);

    renderSelect({renderOption});

    await clickOnToggleButton();

    expect(screen.getAllByText(optionContent)).toHaveLength(menuSize);
});

test("helperText custom render", function helperTextRender() {
    const customHelperText = "I am so custom right now.";
    const renderHelperText = vi.fn().mockReturnValue(<div>{customHelperText}</div>);
    renderSelect({renderHelperText});

    expect(screen.getByText(customHelperText)).toBeInTheDocument();
    expect(renderHelperText).toHaveBeenCalledWith(
        expect.objectContaining({renderHelperText, helperTextId: expect.any(String)}),
        expect.any(Function),
    );
    expect(renderHelperText).toHaveBeenCalledTimes(1);
});

test("option title can be a function", async function optionTitleAsFunction() {
    const title = "hello";
    renderSelect({options: [{title: () => title, value: "whatever"}]});

    await clickOnToggleButton();

    expect(screen.getByRole("option", {name: title})).toBeInTheDocument();
});

test("without option title, render empty string option", async function optionTitleAsFunction() {
    renderSelect({options: [{value: "whatever"}]});

    await clickOnToggleButton();

    expect(screen.getByRole("option")).toBeInTheDocument();
});

test("open prop control the open state", async function openControl() {
    const optionToSelect = defaultProps.options[0].title;
    const {rerender} = renderSelect({open: true});

    expect(getOptions()).toHaveLength(menuSize);

    await clickOnToggleButton();

    expect(getOptions()).toHaveLength(menuSize);

    await clickOnOption(optionToSelect);

    expect(getOptions()).toHaveLength(menuSize);
    expect(getToggleButton()).toHaveTextContent(optionToSelect);

    rerender({open: false});

    expect(getOptions()).toHaveLength(0);

    await clickOnToggleButton();

    expect(getOptions()).toHaveLength(0);
});

test.skip("defaultOpen provides initial value", async function defaultOpen() {
    renderSelect({defaultOpen: true});

    expect(getOptions()).toHaveLength(menuSize);

    await clickOnToggleButton();

    expect(getOptions()).toHaveLength(0);
});

test("onOpenChange is called when passed", async function onOpenChangeCall() {
    const onOpenChange = vi.fn();

    renderSelect({onOpenChange});

    await clickOnToggleButton();

    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(true);

    await clickOnOption(defaultProps.options[0].title);

    expect(onOpenChange).toHaveBeenCalledTimes(2);
    expect(onOpenChange).toHaveBeenCalledWith(false);
});

test("items can be disabled", async function disabledItems() {
    const options = [...defaultProps.options];
    const disabledOption = options[0];
    const enabledOption = options[1];
    disabledOption.disabled = true;

    renderSelect({options});

    await clickOnToggleButton();

    await clickOnOption(disabledOption.title);

    expect(getToggleButton()).not.toHaveTextContent(disabledOption.title);
    expect(getOptions()).toHaveLength(options.length);

    await clickOnOption(enabledOption.title);

    expect(getToggleButton()).toHaveTextContent(enabledOption.title);
    expect(getOptions()).toHaveLength(0);
});

test("select can be in a loading state", async function loadingComboBox() {
    renderSelect({loading: true});

    expect(screen.getByRole("status", {name: DEFAULT_LOADING_SPINNER_ARIA_LABEL})).toBeInTheDocument();
    expect(getToggleButton()).toHaveAttribute(
        "aria-labelledby",
        expect.stringMatching(/kalep-select-[\w-:]+-label kalep-select-[\w:-]+-loading-spinner/),
    );

    await clickOnToggleButton();

    expect(getMenu(`${defaultProps.label} ${DEFAULT_LOADING_SPINNER_ARIA_LABEL}`)).toBeInTheDocument();
});

test("loading spinner aria label can be custom", async function customLoadingSpinnerAriaLabel() {
    const loadingSpinnerAriaLabel = "I am loading, wait pls.";

    renderSelect({loading: true, loadingSpinnerAriaLabel});

    expect(getToggleButton()).toHaveAccessibleName(`${defaultProps.label} ${loadingSpinnerAriaLabel}`);

    await clickOnToggleButton();

    expect(getMenu(`${defaultProps.label} ${loadingSpinnerAriaLabel}`)).toBeInTheDocument();
});

test("combobox options can have custom string equivalent", async function customOptionLabel() {
    const optionString = "I am an option";
    const getOptionLabel = vi.fn().mockImplementation(() => optionString);

    renderSelect({getOptionLabel});

    await clickOnToggleButton();

    expect(screen.getAllByRole("option", {name: optionString})).toHaveLength(4);
    for (let index = 0; index < defaultProps.options.length; index++) {
        expect(getOptionLabel).toHaveBeenCalledWith(defaultProps.options[index]);
    }
});
