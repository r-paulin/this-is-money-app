import type {
    UseMultipleSelectionState,
    UseMultipleSelectionStateChangeOptions,
    UseSelectState,
    UseSelectStateChangeOptions,
} from "downshift";
import {useMultipleSelection, useSelect} from "downshift";

import type {SelectOption} from "@/components/_internal/Option";

import type {Size} from "./Select.types";

export function isOptionEqualToValueDefault(option: SelectOption, value: SelectOption): boolean {
    return option === value;
}

export function virtualizerEstimateHeightBySize(size: Size): number {
    return size === "sm" ? 36 : 48;
}

export function useSelectStateReducerForMultipleSelect(
    state: UseSelectState<SelectOption>,
    change: UseSelectStateChangeOptions<SelectOption>,
): Partial<UseSelectState<SelectOption>> {
    switch (change.type) {
        // Workaround to https://github.com/downshift-js/downshift/issues/1554
        case useSelect.stateChangeTypes.ToggleButtonBlur:
            return {
                ...change.changes,
                selectedItem: null,
            };
        // Do not allow selection with character keys for multiple selection
        case useSelect.stateChangeTypes.ToggleButtonKeyDownCharacter:
            return state;
        // Do not close the menu after selection, in multiple mode
        case useSelect.stateChangeTypes.ToggleButtonKeyDownEnter:
        case useSelect.stateChangeTypes.ToggleButtonKeyDownSpaceButton:
        case useSelect.stateChangeTypes.ItemClick:
            return {
                ...change.changes,
                isOpen: true,
                highlightedIndex: state.highlightedIndex,
            };
        default:
            return change.changes;
    }
}

export function useMultipleSelectionStateReducer(
    state: UseMultipleSelectionState<SelectOption>,
    {type, changes}: UseMultipleSelectionStateChangeOptions<SelectOption>,
) {
    switch (type) {
        case useMultipleSelection.stateChangeTypes.SelectedItemKeyDownNavigationNext:
            // when reaching last item then arrow right, stop navigation.
            return {...changes, activeIndex: changes.activeIndex === -1 ? state.activeIndex : changes.activeIndex};
        case useMultipleSelection.stateChangeTypes.SelectedItemKeyDownNavigationPrevious:
            // when reaching first item then arrow left, focus the Select.
            return {...changes, activeIndex: state.activeIndex === 0 ? -1 : changes.activeIndex};
        case useMultipleSelection.stateChangeTypes.DropdownKeyDownNavigationPrevious:
            // do nothing when hitting arrow left on Select.
            return state;
        case useMultipleSelection.stateChangeTypes.DropdownKeyDownBackspace:
            return state;
        default:
            return changes;
    }
}
