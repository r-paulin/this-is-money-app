import type {UseSelectGetToggleButtonReturnValue} from "downshift";

import type {OptionProps, SelectOption} from "@/components/_internal/Option";
import type {OverlayProps} from "@/components/_internal/Overlay";
import type {RenderFunction} from "@/helpers/types";

export type Size = "sm" | "md" | "lg";

export interface BaseSelectProps extends SelectProps {
    onClear?: () => void;
}

export interface SelectProps {
    options: SelectOption[];

    onChange?: (newValue: SelectOption | SelectOption[] | null) => void;
    onOpenChange?: (open: boolean) => void;

    id?: string;
    name?: string;
    value?: SelectOption | SelectOption[] | null;
    multiple?: boolean;
    multiline?: boolean;
    readonly?: boolean;
    clearable?: boolean;
    open?: boolean;

    required?: boolean;
    disabled?: boolean;
    error?: boolean;
    loading?: boolean;

    defaultValue?: SelectOption | SelectOption[];
    defaultOpen?: boolean;

    label?: string;
    placeholder?: string;
    helperText?: React.ReactNode;
    infoText?: string;

    size?: Size;
    fullWidth?: boolean;
    rootClassName?: string;
    overlayConfig?: OverlayProps;
    loadingSpinnerAriaLabel?: string;

    renderOption?: RenderFunction<OptionProps>;
    getOptionLabel?: (option: SelectOption | null) => string;
    getValueFromOption?: (option: SelectOption | null) => string;
    isOptionEqualToValue?: (option: SelectOption, value: SelectOption) => boolean;

    renderHelperText?: RenderFunction<SelectHelperTextProps>;
    renderTrigger?: (props: SelectProps & UseSelectGetToggleButtonReturnValue) => JSX.Element;
    renderOverlayFooter?: RenderFunction<SelectProps>;

    portalContainer?: HTMLElement;
}

export interface SelectHelperTextProps extends SelectProps {
    helperTextId: string;
}

export interface SelectTriggerProps {
    valueToString: (option: SelectOption | null) => string;
    value?: SelectOption | SelectOption[] | null;
    ariaDescribedby?: string;
    disabled?: boolean;
    error?: boolean;
    multiple?: boolean;
    multiline?: boolean;
    loading?: boolean;
    loadingSpinnerId?: string;
    loadingSpinnerAriaLabel?: string;
    name?: string;
    isOpen?: boolean;
    placeholder?: string;
    size?: Size;
    renderLoader?: () => React.ReactNode;
    renderError?: () => React.ReactNode;
    onClear?: () => void;
    clearable?: boolean;
}

export interface SelectLoaderProps {
    loadingSpinnerId?: string;
    loadingSpinnerAriaLabel?: string;
    size?: Size;
}

export interface SelectErrorProps {
    size?: Size;
}
