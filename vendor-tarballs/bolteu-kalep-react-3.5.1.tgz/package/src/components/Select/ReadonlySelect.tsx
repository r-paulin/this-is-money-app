import React from "react";

import {Label} from "@/components/_internal/Label";
import {MultiSelectChip} from "@/components/_internal/MultiSelectChip";
import {getOptionLabelDefault} from "@/components/_internal/Option";
import {TypographyStack} from "@/components/Typography";
import {cx} from "@/helpers/utils/cx";

import type {SelectProps} from "./Select.types";

export function ReadOnlySelect({
    label,
    infoText,
    value = null,
    getValueFromOption,
    getOptionLabel = getOptionLabelDefault,
    helperText,
    required,
    fullWidth,
    rootClassName,
    multiple,
    size,
}: SelectProps) {
    const singleValueRenderer = getValueFromOption || getOptionLabel;
    return (
        <div className={cx(rootClassName)}>
            <div className={cx("flex flex-col gap-2", fullWidth ? "w-full" : "w-96")}>
                {label && <Label text={label} infoText={infoText} required={required} />}
                {Array.isArray(value) || multiple ? (
                    <>
                        <div className={cx("flex gap-1")}>
                            {Array.isArray(value)
                                ? value.map((option) => (
                                      <MultiSelectChip
                                          key={option.value}
                                          label={singleValueRenderer(option)}
                                          size={size}
                                      />
                                  ))
                                : null}
                        </div>
                        {helperText && (
                            <TypographyStack secondary={helperText} variant={size === "sm" ? "sm" : "base"} />
                        )}
                    </>
                ) : (
                    <TypographyStack
                        primary={singleValueRenderer(value)}
                        secondary={helperText}
                        variant={size === "sm" ? "sm" : "base"}
                    />
                )}
            </div>
        </div>
    );
}
