import * as React from "react";

import {BaseSelect} from "./BaseSelect";
import type {SelectProps} from "./index";
import {MultipleSelect} from "./MultipleSelect";
import {ReadOnlySelect} from "./ReadonlySelect";

export function Select(props: SelectProps): JSX.Element {
    if (props.readonly) {
        return <ReadOnlySelect {...props} />;
    }

    if (props.multiple) {
        return <MultipleSelect {...props} />;
    }

    return <BaseSelect {...props} />;
}
