import * as React from "react";

import {ChevronDown, Clear} from "@bolteu/kalep-react-icons";

import {MultiSelectChip} from "@/components/_internal/MultiSelectChip";
import type {SelectOption} from "@/components/_internal/Option";
import {SpinnerIcon} from "@/components/_internal/SpinnerIcon";
import {GhostButton} from "@/components/GhostButton";
import type {State} from "@/components/TextField/TextField.types";
import {cx} from "@/helpers/utils/cx";

import type {SelectTriggerProps, Size} from "./Select.types";

const sizes: Record<Size, string> = {
    sm: "min-h-9 py-1 pl-3 pr-2 bolt-font-body-s-regular gap-2",
    md: "min-h-12 py-2 pl-3 pr-2 bolt-font-body-m-regular gap-2",
    lg: "min-h-14 py-3 pl-3 pr-2 bolt-font-body-m-regular gap-2",
};

const states: Record<State, string> = {
    idle: "border-special-nulled focus:border-action-primary",
    disabled: "border-neutral-secondary cursor-not-allowed text-tertiary bg-special-nulled placeholder-tertiary",
    error: "border-danger-primary",
};

export const DEFAULT_LOADING_SPINNER_ARIA_LABEL = "loading results";
const CHIPS_COUNT_SAFEAREA = 24;

const getValueString = (
    valueToString: (option: SelectOption | null) => string,
    value?: SelectOption | SelectOption[] | null,
    placeholder?: string,
) => {
    if (!value) {
        return placeholder;
    }

    if (Array.isArray(value)) {
        return value.length ? value.map((item) => valueToString(item)).join(", ") : placeholder;
    }

    return valueToString(value);
};

export const SelectTrigger = React.forwardRef<HTMLButtonElement, SelectTriggerProps>((props, ref): JSX.Element => {
    const {
        isOpen,
        ariaDescribedby,
        value,
        multiple,
        disabled,
        error,
        size = "md",
        name,
        valueToString,
        placeholder,
        multiline,
        loading,
        loadingSpinnerId,
        loadingSpinnerAriaLabel = DEFAULT_LOADING_SPINNER_ARIA_LABEL,
        onClear,
        clearable,
        ...rest
    } = props;

    const isValueArray = Array.isArray(value);
    const hasValue = isValueArray ? Boolean(value.length) : Boolean(value);

    const multiChipContainerRef = React.useRef<HTMLDivElement>(null);
    const chipRefs = React.useRef<Record<string, React.RefObject<HTMLDivElement>>>({});

    const [maxChipIndex, setMaxChipIndex] = React.useState<number>(isValueArray ? value.length - 1 : -1);
    const [visibleChipOffset, setVisibleChipOffset] = React.useState<number>(0);
    const [chipTransform, setChipTransform] = React.useState<number>(0);

    const hiddenChipCount = isValueArray ? value.length - maxChipIndex - 1 : 0;
    const chipGap = React.useMemo(() => (size === "sm" ? 4 : 6), [size]);

    const handleClearButtonClick = React.useCallback(
        (e: React.MouseEvent<Element, MouseEvent> | React.KeyboardEvent<Element>) => {
            onClear?.();
            e.preventDefault();
            e.stopPropagation();
        },
        [onClear],
    );

    if (isValueArray) {
        value.forEach((option) => {
            if (option.value && !chipRefs.current[option.value]) {
                chipRefs.current[option.value] = chipRefs.current[option.value] || React.createRef<HTMLDivElement>();
            }
        });
    }

    React.useLayoutEffect(() => {
        if (!multiline && isValueArray && multiChipContainerRef.current) {
            const containerWidth = multiChipContainerRef.current.getBoundingClientRect().width;
            const safetyAreaWidth = CHIPS_COUNT_SAFEAREA + chipGap; // For the +1 indicator

            let chipsFullWidth = 0;
            let chipsVisibleWidth = 0;
            let chipsOverflow = false;
            let maxIndexToShow = 0;

            for (let i = 0; i < value.length; i++) {
                const option = value[i];

                if (option.value && chipRefs.current[option.value]) {
                    const chipElement = chipRefs.current[option.value].current;

                    if (chipElement) {
                        let chipWidth = chipElement.getBoundingClientRect().width;

                        if (chipWidth + safetyAreaWidth >= containerWidth) {
                            chipWidth = containerWidth - safetyAreaWidth;
                            chipElement.style.width = `${chipWidth}px`;
                            chipElement.style.overflow = "hidden";
                            chipElement.style.textOverflow = "ellipsis";
                        }

                        const gap = i === 0 ? 0 : chipGap;
                        chipsFullWidth += gap + chipWidth;

                        if (!chipsOverflow) {
                            if (chipsFullWidth + safetyAreaWidth <= containerWidth) {
                                chipsVisibleWidth += gap + chipWidth;
                                maxIndexToShow = i;
                            } else {
                                chipsOverflow = true;
                            }
                        }
                    }
                }
            }

            setMaxChipIndex(maxIndexToShow);
            setVisibleChipOffset(chipsVisibleWidth);
            setChipTransform(Math.min(containerWidth - chipsFullWidth, 0));
        }
    }, [value, multiline, isValueArray, isOpen, chipGap]);

    return (
        <button
            ref={ref}
            aria-describedby={ariaDescribedby}
            className={cx(
                "cursor-pointer border-solid", // Reset
                "group/trigger",
                "flex items-center justify-end",
                "w-full overflow-hidden rounded-md border-2 outline-none",
                "bg-neutral-secondary text-left",
                "duration-100 ease-linear",
                "focus-within:bg-special-nulled",
                hasValue && !disabled ? "text-primary" : "text-secondary",
                disabled && states.disabled,
                error && states.error,
                !disabled && !error && states.idle,
                sizes[size],
                !error && isOpen && "border-action-primary bg-special-nulled",
            )}
            disabled={disabled}
            name={name}
            type="button"
            {...rest}
        >
            {multiple && isValueArray && value.length ? (
                <div
                    ref={multiChipContainerRef}
                    className={cx(
                        "relative flex w-full flex-1 transition-transform",
                        !multiline && isOpen ? "overflow-visible" : "overflow-hidden",
                        multiline && "flex-wrap overflow-auto",
                    )}
                    style={{
                        transform: `translateX(${!multiline && isOpen && hiddenChipCount > 0 ? chipTransform : 0}px)`,
                        gap: chipGap,
                    }}
                >
                    {value.map((option, i) => (
                        <MultiSelectChip
                            key={option.value}
                            ref={option.value ? chipRefs.current[option.value] : undefined}
                            label={valueToString(option)}
                            disabled={disabled}
                            hidden={i > maxChipIndex && !multiline && !isOpen}
                            shrink={multiline}
                            size={size}
                        />
                    ))}
                    {!multiline && hiddenChipCount > 0 && !isOpen && (
                        <div
                            className={cx(
                                "absolute top-0 w-6 py-1 text-left",
                                size === "sm" ? "bolt-font-body-xs-regular" : "bolt-font-body-s-regular",
                                disabled ? "text-tertiary" : "text-primary",
                            )}
                            style={{left: visibleChipOffset + chipGap}}
                        >{`+${hiddenChipCount}`}</div>
                    )}
                </div>
            ) : (
                <div className={cx("w-full", !multiline && "overflow-hidden text-ellipsis whitespace-nowrap")}>
                    {getValueString(valueToString, value, placeholder)}
                </div>
            )}

            <div className={cx("flex flex-shrink-0 items-center justify-end", size !== "sm" && "gap-1")}>
                {!disabled && hasValue && clearable && (
                    <GhostButton
                        onClick={handleClearButtonClick}
                        overrideClassName={cx("group/clear", "mx-1 w-6 flex-shrink-0")}
                        tabIndex={-1}
                    >
                        <div
                            className={cx(
                                isOpen ? "flex" : "hidden",
                                "group-hover/trigger:flex",
                                "items-center justify-center",
                            )}
                        >
                            <Clear
                                aria-hidden="true"
                                className={cx(`
                                  text-tertiary
                                  group-hover/clear:text-secondary
                                `)}
                                size={size === "sm" ? "md" : "lg"}
                            />
                        </div>
                    </GhostButton>
                )}

                {loading ? (
                    <SpinnerIcon
                        id={loadingSpinnerId}
                        aria-label={loadingSpinnerAriaLabel}
                        className={cx("mx-1 flex-none animate-spin text-action-secondary")}
                        size={size}
                        role="status"
                    />
                ) : (
                    <ChevronDown
                        className={cx(
                            "mx-1 flex-none transition-transform",
                            disabled ? "text-tertiary" : "text-primary",
                            isOpen && "rotate-180",
                        )}
                        size={size === "sm" ? "md" : "lg"}
                    />
                )}
            </div>
        </button>
    );
});
SelectTrigger.displayName = "SelectTrigger";
