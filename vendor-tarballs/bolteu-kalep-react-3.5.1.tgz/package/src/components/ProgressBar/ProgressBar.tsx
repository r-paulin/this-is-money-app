import * as React from "react";

import {useId} from "@/helpers";
import {cx} from "@/helpers/utils/cx";

import type {ProgressBarProps} from "./ProgressBar.types";

const MIN_VALUE = 0;
const MAX_VALUE = 100;
const INDETERMINATE_BAR_WIDTH = "60%";

export function ProgressBar({isIndeterminate, value = MIN_VALUE, caption, ...rest}: ProgressBarProps) {
    const generatedId = useId();
    const labelId = rest["aria-labelledby"] ?? generatedId;
    const isComplete = value >= MAX_VALUE;
    const barWidthStyle = isIndeterminate && !isComplete ? {width: INDETERMINATE_BAR_WIDTH} : {width: `${value}%`};

    return (
        <div className={cx("w-full")}>
            <div
                className={cx("h-1 overflow-x-hidden rounded bg-neutral-secondary-hard")}
                role="progressbar"
                aria-valuemin={MIN_VALUE}
                aria-valuemax={MAX_VALUE}
                aria-valuenow={value}
                aria-busy={!isComplete}
                aria-labelledby={labelId}
                {...rest}
            >
                <div
                    className={cx(
                        "relative h-full w-0 bg-action-primary",
                        !isComplete && !isIndeterminate && "animate-pulse transition-[width]",
                        !isComplete && isIndeterminate && "animate-indeterminateProgress",
                    )}
                    style={barWidthStyle}
                />
            </div>
            {caption && (
                <div id={labelId} className={cx("bolt-font-body-s-accent mt-2 text-center")}>
                    {caption}
                </div>
            )}
        </div>
    );
}
