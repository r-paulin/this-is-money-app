import * as React from "react";

import type {Meta, StoryFn} from "@storybook/react-webpack5";

import {Button} from "@/components/Button";

import {ProgressBar} from "./ProgressBar";
import type {ProgressBarProps} from "./ProgressBar.types";

export default {
    title: "Feedback/ProgressBar",
    component: ProgressBar,
    tags: ["autodocs"],
} as Meta<typeof ProgressBar>;

const IndeterminateStory: StoryFn<typeof ProgressBar> = (args: ProgressBarProps) => {
    const [value, setValue] = React.useState(0);
    const toggleLoading = React.useCallback(() => setValue(value === 100 ? 0 : 100), [value]);

    return (
        <div className="flex flex-col items-start gap-6">
            <ProgressBar {...args} value={value} />
            <Button onClick={toggleLoading}>{value === 100 ? "Restart loading" : "Finish loading"}</Button>
        </div>
    );
};

export const Indeterminate = IndeterminateStory.bind({});
Indeterminate.args = {
    isIndeterminate: true,
    "aria-label": "Loading content",
    caption: "",
};

const DeterminateStory: StoryFn<typeof ProgressBar> = (args: ProgressBarProps) => {
    const [value, setValue] = React.useState(0);
    const caption = value >= 100 ? "Done" : `${value}% complete.`;

    React.useEffect(() => {
        const increaseValue = setInterval(() => {
            if (value >= 100) {
                clearInterval(increaseValue);
            } else {
                setValue(value + 5);
            }
        }, 1000);

        return () => {
            clearInterval(increaseValue);
        };
    }, [value]);

    return <ProgressBar {...args} value={value} caption={caption} />;
};

export const Determinate = DeterminateStory.bind({});
Determinate.args = {
    "aria-label": "Loading content",
};
