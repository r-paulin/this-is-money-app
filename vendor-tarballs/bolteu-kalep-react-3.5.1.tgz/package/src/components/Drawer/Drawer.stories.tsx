import * as React from "react";

import type {Meta} from "@storybook/react-webpack5";

import {Button} from "@/components/Button";
import {Drawer} from "@/components/Drawer";
import {TextField} from "@/components/TextField";
import {cx} from "@/helpers/utils/cx";
import {Alert} from "@/index";

import {ComboBox} from "../ComboBox";

export default {
    title: "Layout/Drawer",
    tags: ["autodocs"],
    component: Drawer,
} as Meta<typeof Drawer>;

const LongContent = () => (
    <Drawer.Content>
        <div className="mb-6">
            Drawers are great Dialog replacements when more content or form elements are required to be shown, like we
            have showcased below.
        </div>
        <div className="flex flex-col gap-6">
            <div className="flex gap-4">
                <div className="w-1/3">
                    <TextField label="User ID" fullWidth placeholder="12345" />
                </div>
                <TextField label="Username" fullWidth placeholder="bolt.something" />
            </div>
            <ComboBox
                options={[
                    {title: "Estonia", value: "estonia"},
                    {title: "Latvia", value: "latvia"},
                    {title: "Lithuania", value: "lithuania"},
                    {title: "Romania", value: "romania"},
                ]}
                label="Country"
                fullWidth
                placeholder="e.g. Estonia"
            />
            <ComboBox
                options={[
                    {title: "Tallinn", value: "tln"},
                    {title: "Tartu", value: "trt"},
                    {title: "Riga", value: "rix"},
                    {title: "Bucharest", value: "buc"},
                ]}
                label="City"
                fullWidth
                placeholder="e.g. Tallinn"
            />
            <ComboBox
                options={[
                    {title: "Admin", value: "1"},
                    {title: "Moderator", value: "2"},
                    {title: "OPS Country Manager", value: "3"},
                    {title: "CS UK", value: "4"},
                ]}
                label="Role"
                placeholder="e.g. OPS Country Manager"
                fullWidth
            />
            <ComboBox
                multiple
                label="Vertical"
                options={[
                    {title: "Rides", value: "2"},
                    {title: "Delivery", value: "3"},
                    {title: "Rentals", value: "4"},
                    {title: "Business", value: "5"},
                ]}
                fullWidth
                placeholder="e.g Rentals, Delivery"
            />
        </div>
    </Drawer.Content>
);

export const Default = () => {
    const [isOpen, setIsOpen] = React.useState(false);

    const onOpen = React.useCallback(() => setIsOpen(true), [setIsOpen]);
    const onClose = React.useCallback(() => setIsOpen(false), [setIsOpen]);

    return (
        <>
            <Button onClick={onOpen}>Open Drawer</Button>

            <Drawer isOpen={isOpen} onRequestClose={onClose} title="The default Drawer">
                <LongContent />
                <Drawer.Footer>
                    <Button onClick={onClose}>Apply</Button>
                    <Button variant="secondary" onClick={onClose}>
                        Cancel
                    </Button>
                </Drawer.Footer>
            </Drawer>
        </>
    );
};

export const CustomSizeDrawer = () => {
    const [isOpen, setIsOpen] = React.useState(false);

    const onOpen = React.useCallback(() => setIsOpen(true), [setIsOpen]);
    const onClose = React.useCallback(() => setIsOpen(false), [setIsOpen]);

    return (
        <>
            <Button onClick={onOpen}>Open Drawer</Button>

            <Drawer isOpen={isOpen} size="custom" onRequestClose={onClose} title="Custom size drawer">
                <Drawer.Content>
                    <div className={`
                      w-full
                      md:w-[680px]
                    `}>
                        <p>This content aims to be 680px wide if possible</p>
                    </div>
                </Drawer.Content>
                <Drawer.Footer>
                    <Button variant="secondary" onClick={onClose}>
                        Cancel
                    </Button>
                </Drawer.Footer>
            </Drawer>
        </>
    );
};

export const BottomSheetFallback = () => {
    const [isOpen, setIsOpen] = React.useState(false);

    const onOpen = React.useCallback(() => setIsOpen(true), [setIsOpen]);
    const onClose = React.useCallback(() => setIsOpen(false), [setIsOpen]);

    return (
        <>
            <Alert severity="info" title="Mobile-first Drawer" overrideClassName={cx("mb-8")}>
                Pass the <code className={cx("font-semibold")}>useBottomSheet</code> flag to make the Drawer use
                BottomSheet component on smaller screens (width is smaller than 640px). Resize the Storybook window or
                select a responsive layout from the top menu to observe this change.
            </Alert>
            <Button onClick={onOpen}>Open Drawer</Button>

            <Drawer isOpen={isOpen} onRequestClose={onClose} title="Filters" useBottomSheet>
                <LongContent />
                <Drawer.Footer>
                    <Button onClick={onClose}>Apply Filters</Button>
                    <Button variant="secondary" onClick={onClose}>
                        Cancel
                    </Button>
                </Drawer.Footer>
            </Drawer>
        </>
    );
};

export const BottomSheetFallbackWithFullHeight = () => {
    const [isOpen, setIsOpen] = React.useState(false);

    const onOpen = React.useCallback(() => setIsOpen(true), [setIsOpen]);
    const onClose = React.useCallback(() => setIsOpen(false), [setIsOpen]);

    return (
        <>
            <Alert severity="info" title="Mobile-first Drawer" overrideClassName={cx("mb-8")}>
                Pass the <code className={cx("font-semibold")}>useBottomSheet</code> flag to make the Drawer use
                BottomSheet component on smaller screens (width is smaller than 640px). Resize the Storybook window or
                select a responsive layout from the top menu to observe this change.
            </Alert>
            <Button onClick={onOpen}>Open Drawer</Button>

            <Drawer
                isOpen={isOpen}
                onRequestClose={onClose}
                title="Filters"
                useBottomSheet
                bottomSheetProps={{snapPoints: [1]}}
            >
                <LongContent />
                <Drawer.Footer>
                    <Button onClick={onClose}>Apply Filters</Button>
                    <Button variant="secondary" onClick={onClose}>
                        Cancel
                    </Button>
                </Drawer.Footer>
            </Drawer>
        </>
    );
};
