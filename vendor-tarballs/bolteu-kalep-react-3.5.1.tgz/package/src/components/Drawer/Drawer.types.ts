import type * as React from "react";

import type {BottomSheetProps} from "../BottomSheet";

export type DrawerSize = "sm" | "md" | "lg" | "xl" | "custom";
export interface DrawerProps {
    isOpen: boolean;
    title: React.ReactNode;
    onRequestClose: () => void;
    size?: DrawerSize;
    children: React.ReactNode;
    /**
     * Whether the Drawer renders as BottomSheet on smaller screens
     *
     * @default false
     */
    useBottomSheet?: boolean;
    /**
     * To provide extra props to the BottomSheet component when its used for mobile widths
     */
    bottomSheetProps?: Pick<
        BottomSheetProps,
        "isDismissible" | "hasOverlay" | "hasHandle" | "hasCloseButton" | "snapPoints"
    >;
    /**
     * Specify a container element to portal the content into
     */
    portalContainer?: HTMLElement | null;
}
