import * as React from "react";

import {Dialog as RadixDialog} from "radix-ui";

import {DEFAULT_MOBILE_BREAKPOINT, useViewportWidth} from "@/helpers";
import {cx} from "@/helpers/utils/cx";
import {BottomSheet} from "@/index";

import {KALEP_MODAL_CONTENT_ID, ModalContent, ModalHeader, RadixModalHeader} from "../_internal/Modal";
import type {DrawerProps, DrawerSize} from "./Drawer.types";

const sizes: Record<DrawerSize, string> = {
    sm: "sm:w-[360px]",
    md: "sm:w-[480px]",
    lg: "sm:w-[640px]",
    xl: "sm:w-[736px]",
    custom: "sm:w-auto",
};

export function Drawer({
    isOpen,
    title,
    onRequestClose,
    size = "md",
    children,
    useBottomSheet,
    portalContainer,
    bottomSheetProps = {},
}: DrawerProps) {
    const {width} = useViewportWidth();

    const handleOnOpenChange = React.useCallback(
        (newOpen: boolean) => {
            if (!newOpen) {
                onRequestClose();
            }
        },
        [onRequestClose],
    );

    if (width < DEFAULT_MOBILE_BREAKPOINT && useBottomSheet) {
        const heightClass = bottomSheetProps.snapPoints?.length ? "max-h-[94vh]" : "max-h-[80vh]";
        return (
            <BottomSheet
                isOpen={isOpen}
                onOpenChange={handleOnOpenChange}
                container={portalContainer}
                {...bottomSheetProps}
            >
                <div className={cx(heightClass, "flex w-full flex-col bg-layer-floor-1")}>
                    <ModalHeader title={title} variant="default" onClose={onRequestClose} />
                    {children}
                </div>
            </BottomSheet>
        );
    }

    return (
        <RadixDialog.Root open={isOpen} onOpenChange={handleOnOpenChange}>
            <RadixDialog.Portal container={portalContainer}>
                <RadixDialog.Overlay
                    className={cx(
                        "fixed inset-0 z-modalOverlay bg-special-scrim",
                        "data-[state=open]:animate-overlayShow",
                        "data-[state=closed]:animate-overlayHide",
                    )}
                />
                <RadixDialog.Content
                    className={cx(
                        "fixed right-[0.5rem] top-[0.5rem] z-modal rounded-lg",
                        "h-[calc(100vh-1rem)] max-h-full",
                        "focus:outline-none",
                        "data-[state=open]:animate-slideInRight",
                        "data-[state=closed]:animate-slideOutRight",
                    )}
                    aria-describedby={undefined} // Cant use Radix.Description as content is unknown
                >
                    <div
                        id={KALEP_MODAL_CONTENT_ID}
                        className={cx(
                            "w-[calc(100vw-1rem)]",
                            sizes[size],
                            "flex h-full flex-col",
                            "rounded-lg bg-layer-floor-1 text-primary",
                        )}
                    >
                        <RadixModalHeader title={title} variant="default" onClose={onRequestClose} />
                        {children}
                    </div>
                </RadixDialog.Content>
            </RadixDialog.Portal>
        </RadixDialog.Root>
    );
}

function DrawerFooter({children}: {children: React.ReactNode}) {
    // split children to pieces, assuming that we get them in this order:
    // <Primary action>, <Secondary action>, ...<All the rest>

    const [primaryAction, secondaryAction, ...remainingActions] = React.Children.toArray(children);

    return (
        <footer className={cx("pb-6 pl-6 pr-6 pt-4", "flex flex-row-reverse justify-between gap-4")}>
            <div className={cx("flex flex-row-reverse gap-4")}>
                {primaryAction}
                {secondaryAction}
            </div>
            <div>{remainingActions}</div>
        </footer>
    );
}

Drawer.Content = ModalContent;
Drawer.Footer = DrawerFooter;
