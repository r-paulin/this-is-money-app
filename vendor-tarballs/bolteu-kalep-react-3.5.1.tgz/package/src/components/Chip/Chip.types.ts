import type {KalepIconElement} from "@bolteu/kalep-react-icons/dist/types";

import type {Appearance} from "@/helpers/utils/utilityTypes";

export type ChipSize = "xs" | "sm" | "md";
export type ChipVariant = "filled" | "outline" | "simple";

export interface BaseChipProps extends React.ComponentPropsWithoutRef<"span"> {
    children: React.ReactNode;
    size: ChipSize;
    variant: ChipVariant;
    selected: boolean;
    disabled: boolean;
    appearance?: ChipAppearance;
}

export interface ChipProps {
    label: string;
    size?: ChipSize;
    variant?: ChipVariant;
    selected?: boolean;
    disabled?: boolean;
    tabIndex?: number;
    onClick?: (event: React.MouseEvent<HTMLSpanElement>) => void;
    onKeyDown?: (event: React.KeyboardEvent<HTMLSpanElement>) => void;
    onRemove?: (event: React.MouseEvent | React.KeyboardEvent) => void;
    startIcon?: KalepIconElement;
    /**
     * @default "neutral"
     *
     * Value can be "neutral" | "danger" | "action" | "promo" | "warning"
     * OR a config object to define custom colors for the chip.
     *
     * To have the chip create a colorset from one HEX color value use the following format:
     * appearance={{ light: { main: "#ff0000" } }}
     *
     * For more complex setups refer to the examples in kalep-react Storybook.
     */
    appearance?: ChipAppearance;
}

export type ChipAppearance = Appearance<ChipColorConfig>;

export type ChipColorConfigMinimal = {
    light: {
        main: string;
    };
};

export type ChipColorConfigFull = {
    light: {
        main: string;
        bg: string;
        bgActive: string;
        border: string;
    };
    dark?: {
        main?: string;
        bg?: string;
        bgActive?: string;
        border?: string;
    };
};

export type ChipColorConfig = ChipColorConfigMinimal | ChipColorConfigFull;

export type ChipColorOverrides = {
    "--chip-bg": string;
    "--chip-bg-hover": string;
    "--chip-border": string;
    "--chip-content": string;
    "--chip-bg-dark"?: string;
    "--chip-bg-hover-dark"?: string;
    "--chip-border-dark"?: string;
    "--chip-content-dark"?: string;
};

// Type predicate to check if the value is a color config
export function isChipColorConfig(appearance: ChipAppearance): appearance is ChipColorConfig {
    return typeof appearance === "object" && "light" in appearance;
}

// Type predicate to check for full color config
export function isChipColorConfigFull(appearance: ChipAppearance): appearance is ChipColorConfigFull {
    return typeof appearance === "object" && "bg" in appearance.light;
}
