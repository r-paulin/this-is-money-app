import * as React from "react";

import {vi} from "vitest";

import {
    act,
    blurTrigger,
    clickTrigger,
    defaultProps,
    focusTrigger,
    getTrigger,
    hoverTrigger,
    renderTooltip,
    screen,
    unhoverTrigger,
    user,
} from "./Tooltip.testUtils";

test("tooltip does not appear without an action", function noTooltipTest() {
    renderTooltip();

    expect(screen.queryByText(defaultProps.content)).not.toBeInTheDocument();
    expect(getTrigger()).not.toHaveAttribute("aria-describedby");
});

test.skip("tooltip appears on hover", async function tooltipOnHover() {
    vi.useFakeTimers();

    renderTooltip();

    await unhoverTrigger();
    await hoverTrigger();
    act(function runTooltipTimer() {
        vi.runAllTimers();
    });

    expect(screen.getByRole("tooltip", {name: defaultProps.content})).toBeInTheDocument();
    expect(getTrigger()).toHaveAttribute("aria-describedby", screen.getByText(defaultProps.content).id);

    await unhoverTrigger();
    act(function runTooltipTimer() {
        vi.runAllTimers();
    });

    expect(screen.queryByRole("tooltip", {name: defaultProps.content})).not.toBeInTheDocument();

    vi.useRealTimers();
});

test("tooltip delay can be changed", async function tooltipDelay() {
    const delay = 200; // Shorter delay for testing

    renderTooltip({delay});

    await hoverTrigger();
    
    // Tooltip should not appear immediately
    expect(screen.queryByRole("tooltip", {name: defaultProps.content})).not.toBeInTheDocument();

    // Wait for tooltip to appear after delay
    await screen.findByRole("tooltip", {name: defaultProps.content}, {timeout: delay + 200});
});

test("tooltip does not override keydown handlers", async function tooltipNoKeydownOverrides() {
    const onClick = vi.fn();
    const children = (
        <button type="button" onClick={onClick}>
            Do not override my keydown!
        </button>
    );

    renderTooltip({children});

    await act(async () => {
        await focusTrigger();
        await user.keyboard(" ");
    });

    expect(onClick).toHaveBeenCalledTimes(1);

    await act(async () => {
        await user.keyboard("{enter}");
    });

    expect(onClick).toHaveBeenCalledTimes(2);
});

test("button press handlers not triggered if disabled", async function tooltipEmptyContent() {
    const onClick = vi.fn();
    const children = (
        <button type="button" onClick={onClick} disabled>
            Hello
        </button>
    );

    renderTooltip({children});

    await act(async () => {
        await focusTrigger();
        await user.keyboard(" ");
    });

    expect(onClick).not.toHaveBeenCalled();

    await act(async () => {
        await user.keyboard("{enter}");
    });

    expect(onClick).not.toHaveBeenCalled();

    await act(async () => {
        await clickTrigger();
    });

    expect(onClick).not.toHaveBeenCalled();
});

test.skip("tooltip appears on focus", async function tooltipOnFocus() {
    renderTooltip();
    await focusTrigger();

    expect(screen.queryByText(defaultProps.content)).toBeInTheDocument();
    expect(getTrigger()).toHaveAttribute("aria-describedby", screen.getByText(defaultProps.content).id);

    await blurTrigger();

    expect(screen.queryByText(defaultProps.content)).not.toBeInTheDocument();
    expect(getTrigger()).not.toHaveAttribute("aria-describedby");
});

test("tooltip returns children if empty content", async function tooltipEmptyContent() {
    const content = "";
    renderTooltip({content});

    await focusTrigger();

    expect(screen.queryByRole("tooltip")).not.toBeInTheDocument();
    expect(getTrigger().parentElement?.childElementCount).toBe(1);
});

test.skip("tooltip does not hide on click", async function tooltipEmptyContent() {
    renderTooltip();

    await focusTrigger();
    expect(screen.getByRole("tooltip", {name: defaultProps.content})).toBeInTheDocument();

    await act(async () => {
        await clickTrigger();
    });

    expect(screen.queryByRole("tooltip")).toBeInTheDocument();
});
