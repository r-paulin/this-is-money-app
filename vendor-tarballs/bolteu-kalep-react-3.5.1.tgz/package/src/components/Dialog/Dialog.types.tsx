import type * as React from "react";

import type {BottomSheetProps} from "../BottomSheet";

export interface DialogProps {
    /**
     * Defines if the Dialog is visible or not.
     * Note that Dialog content always exists in DOM, but is set
     * to display: none by this prop.
     */
    isOpen: boolean;
    /**
     * Try to keep it reasonably concise. Long text will break to new line.
     */
    title: string | React.ReactNode;
    /**
     * default - dismissible Dialog, with a close button.
     * alert - a Dialog that can only be closed by making a choice - i.e close only by provided actions
     */
    variant?: "default" | "alert";
    /**
     * Called e.g when Esc is tapped, or user clicks outside of Dialog.
     * You will need to set isOpen to false to actually close the Dialog.
     */
    onRequestClose: () => void;
    /**
     * Dialog content and actions. It expects the following content:
     *
     * <Dialog.Content> your dialog content here </Dialog.Content>
     * <Dialog.Footer> your Buttons here </Dialog.Footer>
     */
    children: React.ReactNode;
    size?: "custom";
    /**
     * Whether the Dialog renders as BottomSheet on smaller screens
     *
     * @default false
     */
    useBottomSheet?: boolean;
    /**
     * To provide extra props to the BottomSheet component when its used for mobile widths
     */
    bottomSheetProps?: Pick<
        BottomSheetProps,
        "isDismissible" | "hasOverlay" | "hasHandle" | "hasCloseButton" | "snapPoints"
    >;
    /**
     * Specify a container element to portal the content into
     */
    portalContainer?: HTMLElement | null;
}
