import * as React from "react";

import ChevronRight from "@bolteu/kalep-react-icons/dist/ChevronRight";
import MoreIos from "@bolteu/kalep-react-icons/dist/MoreIos";

import {Menu, MenuItem} from "@/components/Menu";
import {cx} from "@/helpers/utils/cx";

const ITEMS_BEFORE_COLLAPSE = 1;
const ITEMS_AFTER_COLLAPSE = 2;

export const DEFAULT_COLLAPSED_ITEMS_ARIA_LABEL = "Expanded breadcrumbs menu button";

export interface BreadcrumbItemType {
    title: string | React.ReactNode;
    href?: string;
    target?: string;
    onClick?: React.MouseEventHandler<HTMLAnchorElement>;
}

interface SeparatorProps {
    separator?: React.ReactNode;
}

interface CollapsedMenuProps {
    items: BreadcrumbItemType[];
    separator?: React.ReactNode;
    collapsedItemsAriaLabel?: string;
}

interface BreadCrumbItemProps extends BreadcrumbItemType {
    isCurrent?: boolean;
    separator?: React.ReactNode;
}

export interface BreadcrumbProps extends React.ComponentPropsWithoutRef<"nav"> {
    items: BreadcrumbItemType[];
    separator?: React.ReactNode;
    collapsedItemsAriaLabel?: string;
    renderItem?: (item: BreadcrumbItemType) => React.ReactNode;
}

const splitBreadcrumbItems = (
    items: BreadcrumbItemType[],
): {visibleItems: BreadcrumbItemType[]; collapsedItems: BreadcrumbItemType[]} => {
    const visibleItems = [...items]; // Make a copy of the array to safely splice
    const collapsedItems = visibleItems.splice(
        ITEMS_BEFORE_COLLAPSE,
        Math.max(items.length - ITEMS_AFTER_COLLAPSE - 1, 0),
    );

    return {
        visibleItems,
        collapsedItems,
    };
};

function SeparatorItem({separator}: SeparatorProps): JSX.Element {
    // context for the [&>svg]:block thing below: https://taxify.slack.com/archives/C030WAFUZBQ/p1674208953062119
    return (
        <li aria-hidden className={cx("[&>svg]:block")}>
            {separator ?? <ChevronRight className={cx(`
              text-tertiary
              rtl:rotate-180
            `)} size="xs" />}
        </li>
    );
}

function CollapsedMenu({
    items,
    separator,
    collapsedItemsAriaLabel = DEFAULT_COLLAPSED_ITEMS_ARIA_LABEL,
}: CollapsedMenuProps): JSX.Element {
    return (
        <>
            <li>
                <Menu
                    menuButton={
                        <button
                            type="button"
                            className={cx(
                                `
                                  block cursor-pointer border-none bg-transparent p-0 text-link-primary
                                  hover:text-active-link-primary
                                `,
                            )}
                            aria-label={collapsedItemsAriaLabel}
                        >
                            <MoreIos size="xs" className={cx("block")} />
                        </button>
                    }
                >
                    {items.map((item, index) => (
                        <MenuItem label={item.title} href={item.href} target={item.target} key={item.href ?? index} />
                    ))}
                </Menu>
            </li>
            <SeparatorItem separator={separator} />
        </>
    );
}

function BreadcrumbItem({
    title,
    href,
    target = "_self",
    onClick,
    isCurrent,
    separator,
}: BreadCrumbItemProps): JSX.Element {
    return (
        <>
            <li className={cx("bolt-font-body-s-regular")}>
                {isCurrent ? (
                    <span className={cx("text-primary")}>{title}</span>
                ) : (
                    <a
                        href={href}
                        target={href ? target : undefined}
                        onClick={onClick}
                        className={cx(`
                          cursor-pointer text-link-primary no-underline
                          hover:text-active-link-primary
                        `)}
                    >
                        {title}
                    </a>
                )}
            </li>
            {!isCurrent && <SeparatorItem separator={separator} />}
        </>
    );
}

export function Breadcrumb({
    items,
    separator,
    collapsedItemsAriaLabel,
    renderItem,
    ...rest
}: BreadcrumbProps): JSX.Element | null {
    const {visibleItems, collapsedItems} = splitBreadcrumbItems(items);
    const hasCustomRenderer = typeof renderItem === "function";
    const itemsToUse = hasCustomRenderer ? items : visibleItems;

    return (
        <nav {...rest}>
            <ol className={cx("m-0 list-none p-0", "flex flex-wrap items-center gap-1")}>
                {itemsToUse.map((item, index) => {
                    const isCurrent = index === itemsToUse.length - 1;
                    const fragmentKey = `${index}${item.href}`; // guards against several items with "" as href.

                    return (
                        <React.Fragment key={fragmentKey}>
                            {hasCustomRenderer ? (
                                <>
                                    {renderItem(item)}
                                    {!isCurrent && <SeparatorItem separator={separator} />}
                                </>
                            ) : (
                                <BreadcrumbItem
                                    title={item.title}
                                    href={item.href}
                                    target={item.target}
                                    onClick={item.onClick}
                                    isCurrent={isCurrent}
                                    separator={separator}
                                />
                            )}
                            {index === 0 && collapsedItems.length && !hasCustomRenderer ? (
                                <CollapsedMenu
                                    items={collapsedItems}
                                    collapsedItemsAriaLabel={collapsedItemsAriaLabel}
                                />
                            ) : null}
                        </React.Fragment>
                    );
                })}
            </ol>
        </nav>
    );
}
