import * as React from "react";

import {vi} from "vitest";
import {render as testingLibraryRender, screen} from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import type {BreadcrumbProps} from "../Breadcrumb";
import {Breadcrumb, DEFAULT_COLLAPSED_ITEMS_ARIA_LABEL} from "../Breadcrumb";
import type {BreadcrumbItem} from "../index";

interface SimpleBreadCrumbItem extends BreadcrumbItem {
    title: string;
}

const breadcrumbItems: SimpleBreadCrumbItem[] = [
    {
        title: "Foo",
        href: "foo",
        target: "_foo",
    },
    {
        title: "Bar",
        href: "bar",
    },
    {
        title: "Baz",
        href: "baz",
    },
];
const customSeparatorText = "Hello";
const customSeparator = <span>{customSeparatorText}</span>;

function render(
    props: BreadcrumbProps = {
        items: breadcrumbItems,
    },
) {
    const {rerender} = testingLibraryRender(<Breadcrumb {...props} />);
    return (propsOverride: Partial<BreadcrumbProps>) => rerender(<Breadcrumb {...props} {...propsOverride} />);
}

describe("Breadcrumb test suite", () => {
    test("renders all items to document", () => {
        render();
        expect(screen.getByText(breadcrumbItems[0].title)).toBeInTheDocument();
        expect(screen.getByText(breadcrumbItems[1].title)).toBeInTheDocument();
        expect(screen.getByText(breadcrumbItems[2].title)).toBeInTheDocument();

        expect(screen.getByText(breadcrumbItems[0].title)).toHaveAttribute("href", breadcrumbItems[0].href);
        expect(screen.getByText(breadcrumbItems[1].title)).toHaveAttribute("href", breadcrumbItems[1].href);
        expect(screen.getByText(breadcrumbItems[2].title)).not.toHaveAttribute("href");
    });

    test("collapses some items if more than three items provided", async () => {
        const lastItem = {title: "Last item", href: "lasthref"};
        render({
            items: [...breadcrumbItems, lastItem],
        });
        expect(screen.getByText(breadcrumbItems[0].title)).toBeInTheDocument();
        expect(screen.getByText(breadcrumbItems[2].title)).toBeInTheDocument();
        expect(screen.getByText(lastItem.title)).toBeInTheDocument();

        expect(screen.getByRole("button")).toBeInTheDocument();
        expect(screen.queryByText(breadcrumbItems[1].title)).toBeInTheDocument();
        expect(screen.queryByText(breadcrumbItems[1].title)).not.toBeVisible();

        const user = userEvent.setup();
        await user.click(screen.getByRole("button", {name: DEFAULT_COLLAPSED_ITEMS_ARIA_LABEL}));

        expect(screen.getByText(breadcrumbItems[1].title)).toBeInTheDocument();
        expect(screen.getByText(breadcrumbItems[1].title).closest("a")).toHaveAttribute(
            "href",
            breadcrumbItems[1].href,
        );
    });

    test("collapsed menu can have a custom aria label", () => {
        const collapsedItemsAriaLabel = "and way down we go, go, go";
        const lastItem = {title: "Last item", href: "lasthref"};
        render({
            collapsedItemsAriaLabel,
            items: [...breadcrumbItems, lastItem],
        });

        expect(screen.queryByRole("button", {name: DEFAULT_COLLAPSED_ITEMS_ARIA_LABEL})).not.toBeInTheDocument();
        expect(screen.getByRole("button", {name: collapsedItemsAriaLabel})).toBeInTheDocument();
    });

    test("renders custom separator", () => {
        render({separator: customSeparator, items: [breadcrumbItems[0], breadcrumbItems[1]]});
        expect(screen.getByText(customSeparatorText)).toBeInTheDocument();
    });

    test("renders no separator for single item", () => {
        render({separator: customSeparator, items: [breadcrumbItems[0]]});
        expect(screen.queryByText(customSeparatorText)).not.toBeInTheDocument();
    });

    test("hides separators for screen readers", () => {
        render({separator: customSeparator, items: [breadcrumbItems[0], breadcrumbItems[1]]});
        expect(screen.getByText(customSeparatorText).closest("li")).toHaveAttribute("aria-hidden");
    });

    test("renders proper aria-label", () => {
        const ariaLabel = "Amazing breadcrumb";
        render({
            "aria-label": ariaLabel,
            items: breadcrumbItems,
        });
        expect(screen.getByRole("navigation")).toHaveAttribute("aria-label", ariaLabel);
    });

    test("onClick handler is working", async () => {
        const onClick = vi.fn();

        const items = breadcrumbItems.map((item) => ({...item, onClick, href: undefined}));

        render({
            items,
        });

        await userEvent.click(screen.getByText(items[0].title));
        expect(onClick).toHaveBeenCalledTimes(1);
    });
});
