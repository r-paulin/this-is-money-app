import * as React from "react";

import {cx} from "@/helpers/utils/cx";

export interface LinkProps extends Omit<React.HTMLProps<HTMLAnchorElement>, "className"> {
    overrideClassName?: string;
}

function InternalLink({children, overrideClassName, target, ...props}: LinkProps, ref: any) {
    const rel = props.rel === undefined && target === "_blank" ? "noreferrer" : props.rel;

    return (
        <a
            className={cx(
                `
                  text-link-primary
                  visited:text-active-link-primary
                  hover:text-active-link-primary
                `,
                `
                  no-underline
                  hover:underline
                `,
                target === "_blank" && `
                  after:content-['_↗']
                  rtl:after:content-['']
                `,
                overrideClassName,
            )}
            target={target}
            rel={rel}
            ref={ref}
            {...props}
        >
            {children}
        </a>
    );
}

export const Link = React.forwardRef<HTMLAnchorElement, LinkProps>(InternalLink);
