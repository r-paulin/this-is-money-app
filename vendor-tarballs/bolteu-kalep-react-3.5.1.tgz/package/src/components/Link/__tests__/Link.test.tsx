import * as React from "react";

import {render, screen} from "@testing-library/react";

import {Link} from "../index";

describe("Link test suite", () => {
    test("renders to document with proper link href", () => {
        const testLabel = "Foo";
        const testLink = "link";
        render(<Link href={testLink}>{testLabel}</Link>);
        expect(screen.getByText(testLabel)).toBeInTheDocument();
        expect(screen.getByText(testLabel)).toHaveAttribute("href", testLink);
    });

    test.skip("renders external link suffix if target is blank", () => {
        const testLabel = "Foo";
        const testLink = "link";
        const externalSuffix = "↗";
        render(
            <Link href={testLink} target="_blank">
                {testLabel}
            </Link>,
        );
        expect(screen.getByText(testLabel)).toBeInTheDocument();

        expect(screen.getByText(externalSuffix)).toBeInTheDocument();
        expect(screen.getByText(testLabel)).toHaveAttribute("href", testLink);
        expect(screen.getByText(testLabel)).toHaveAttribute("target", "_blank");
    });
});
