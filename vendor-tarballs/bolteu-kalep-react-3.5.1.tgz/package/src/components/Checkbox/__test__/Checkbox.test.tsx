import * as React from "react";

import {vi} from "vitest";
import {render as testingLibraryRender, screen} from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import type {CheckboxProps} from "../index";
import {Checkbox} from "../index";

function render(props: CheckboxProps = {}) {
    const {rerender} = testingLibraryRender(<Checkbox {...props} />);
    return (propsOverride: Partial<CheckboxProps>) => rerender(<Checkbox {...props} {...propsOverride} />);
}

describe("Checkbox test suite", () => {
    const testLabel = "foo-bar-baz";
    const id = "input-field-id";

    test("Checkbox renders into document", () => {
        render({"aria-label": testLabel});

        expect(screen.getByLabelText(testLabel, {selector: "input"})).toHaveAttribute("type", "checkbox");
        expect(screen.getByLabelText(testLabel, {selector: "input"})).toHaveAttribute("aria-invalid", "false");
    });

    test("Checkbox can have an id", () => {
        render({label: testLabel, id});

        expect(screen.getByLabelText(testLabel)).toHaveAttribute("id", id);
    });

    test("defaultChecked=true sets checkbox state to checked", () => {
        render({label: testLabel, defaultChecked: true});

        expect(screen.getByLabelText(testLabel)).toBeChecked();
    });

    test("checked prop controls checkbox state", () => {
        const rerender = render({label: testLabel, checked: false, readOnly: true});

        expect(screen.getByLabelText(testLabel)).not.toBeChecked();
        rerender({checked: true});
        expect(screen.getByLabelText(testLabel)).toBeChecked();
        rerender({checked: false});
        expect(screen.getByLabelText(testLabel)).not.toBeChecked();
    });

    test("uncontrolled checkbox changes checked status on click", async () => {
        render({label: testLabel, defaultChecked: false});

        await userEvent.click(screen.getByLabelText(testLabel));
        expect(screen.getByLabelText(testLabel)).toBeChecked();
    });

    test("disabled prop blocks checkbox", async () => {
        render({label: testLabel, disabled: true, defaultChecked: false});

        await userEvent.click(screen.getByLabelText(testLabel));
        expect(screen.getByLabelText(testLabel)).not.toBeChecked();
    });

    test("onChange prop is triggered on controlled checkbox changes", async () => {
        const onChange = vi.fn();
        const isChecked = false;

        render({label: testLabel, onChange, checked: isChecked});
        await userEvent.click(screen.getByLabelText(testLabel));
        expect(onChange).toHaveBeenCalledTimes(1);
        expect(onChange.mock.calls[0][0].target.checked).toBe(isChecked);
    });

    test("onChange prop is triggered on uncontrolled checkbox changes", async () => {
        const onChange = vi.fn();

        render({label: testLabel, defaultChecked: false, onChange});
        await userEvent.click(screen.getByLabelText(testLabel));
        expect(onChange).toHaveBeenCalledTimes(1);
        expect(onChange.mock.calls[0][0].target.checked).toBe(true);
    });

    test("indeterminate prop sets the checkbox to indeterminate state", () => {
        const rerender = render({label: testLabel, indeterminate: false});
        expect(screen.getByLabelText(testLabel)).not.toBePartiallyChecked();
        rerender({indeterminate: true});
        expect(screen.getByLabelText(testLabel)).toBePartiallyChecked();
    });

    test("can be in an invalid state", () => {
        render({label: testLabel, error: true});

        expect(screen.getByLabelText(testLabel)).toBeInvalid();
    });
});
