import type * as React from "react";

export interface BaseModalProps {
    isOpen: boolean;
    /**
     * Default value is true - BaseModal acts as a true modal, blocking content below.
     *
     * BaseModal can be shown in 2 modes, one that blocks interaction with the
     * rest of the page below it and one that does not.
     * Setting this to false means you have to decide placement manually and might encounter z-index issues.
     */
    isModal?: boolean;
    /**
     * Default value true
     *
     * Setting hasBackdrop to false sets the ::backdrop style to display:none;
     * This is only visual, with no other effect.
     */
    hasBackdrop?: boolean;
    onRequestClose: (requester?: string) => void;
    allowCloseOnOutsideClick?: boolean;
    /**
     * String of tailwind classes. Defaults to fade-in & fade-out
     * Refer to documentation in Storybook to see how to create a custom animation */
    animation?: string;
    /**
     * Placement of modal on screen. Accepts tailwind classes.
     * It defaults to center of screen with user-agent (browser) styling. */
    placement?: string;
    /**
     * Defines shadow, border & border-radius. Accepts tailwind classes. */
    shape?: string;
    children: React.ReactNode;
    "aria-labelledby"?: string;
    "aria-label"?: string;
    role?: string;
}
