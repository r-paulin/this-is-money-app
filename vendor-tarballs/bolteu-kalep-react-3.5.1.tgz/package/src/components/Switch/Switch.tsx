import * as React from "react";

import {cx} from "@/helpers/utils/cx";
import {mergeRefs} from "@/helpers/utils/mergeRefs";

export interface SwitchProps extends Omit<React.ComponentPropsWithoutRef<"input">, "className"> {
    /**
     * Default checked value for uncontrolled component.
     * Has no effect if checked prop is provided.
     */
    defaultChecked?: boolean;
    /**
     * Setting a value for checked makes the component controlled.
     */
    checked?: boolean;
    /**
     * When label prop is set the switch will be wrapped in a <label> element
     */
    label?: string;
    /**
     * Disable or enable the switch control.
     */
    disabled?: boolean;
    /**
     * If Switch does not have an associated label or labelledby link provide
     * an accessible label in aria-label.
     */
    "aria-label"?: string;
}

export const Switch = React.forwardRef<HTMLInputElement, SwitchProps>((props, forwardedRef) => {
    const internalRef = React.createRef<HTMLInputElement>();

    const {checked, disabled = false, defaultChecked, label, onChange, ...rest} = props;

    const handleKeyDown = React.useCallback((e: React.KeyboardEvent) => {
        if (e.key === "Enter") {
            const event = new MouseEvent("click", {
                bubbles: true,
                cancelable: true,
            });
            e.target.dispatchEvent(event);
        }
    }, []);

    const switchElement = (
        <span className={cx("relative inline-block h-8 w-12 shrink-0")}>
            <input
                type="checkbox"
                role="switch"
                checked={checked}
                defaultChecked={defaultChecked}
                disabled={disabled}
                onChange={onChange}
                onKeyPress={handleKeyDown}
                ref={mergeRefs([internalRef, forwardedRef])}
                {...rest}
                className={cx("peer", [
                    `
                      m-0 h-full w-full cursor-pointer appearance-none rounded-full bg-transparent
                      disabled:cursor-default
                    `,
                ])}
            />
            <span
                className={cx(
                    "absolute inset-0 rounded-full",
                    "transition-colors duration-200 ease-linear",
                    "pointer-events-none",
                    "bg-neutral-secondary-hard",
                    "peer-hover:bg-active-neutral-secondary-hard",
                    "peer-checked:bg-action-primary",
                    "peer-checked:peer-disabled:bg-active-action-secondary",
                    "peer-checked:peer-disabled:peer-hover:bg-active-action-secondary",
                    "peer-checked:peer-hover:bg-active-action-primary",
                    "peer-disabled:bg-special-disabled",
                    "peer-disabled:peer-hover:bg-special-disabled",
                )}
            />
            <span
                className={cx(
                    "absolute inset-1 h-6 w-6 rounded-full",
                    "bg-static-key-light shadow-md",
                    "peer-disabled:shadow-none",
                    "pointer-events-none",
                    "transform duration-200 ease-in-out",
                    `
                      peer-checked:translate-x-4
                      rtl:peer-checked:-translate-x-4
                    `,
                )}
            />
        </span>
    );

    if (label) {
        return (
            <label
                className={cx(
                    "bolt-font-body-m-regular inline-flex cursor-pointer gap-2 leading-loose text-primary",
                    disabled && "cursor-default text-secondary",
                )}
            >
                {switchElement}
                {label}
            </label>
        );
    }

    return switchElement;
});
Switch.displayName = "Switch";
