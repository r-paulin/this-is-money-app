import * as React from "react";

import {enUS} from "date-fns/locale";
import {vi} from "vitest";
import {render, screen} from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import {DatePicker, registerLocale} from "../index";

const getDayByText = (text: string) => {
    return screen.getByText(text).closest(".react-datepicker__day");
};

const getInputByLabel = (label: string) => {
    return screen.getByRole("textbox", {name: label});
};

beforeAll(() => {
    registerLocale("en-US", enUS);
});

describe("Datepicker test suite", () => {
    test("renders datepicker input to the document", () => {
        const label = "Foo";

        render(<DatePicker label={label} />);
        expect(getInputByLabel(label)).toBeInTheDocument();
    });

    test("sets datepicker input value and formats it properly", () => {
        const label = "Foo";
        const value = new Date("2022-09-23T10:00:00Z");
        const format = "dd.MM.yyyy";
        const valueString = "23.09.2022";

        render(<DatePicker label={label} value={value} format={format} />);
        expect(getInputByLabel(label)).toHaveValue(valueString);
    });

    test("sets datepicker input value and formats it properly for range picker", () => {
        const label = "Foo";
        const format = "dd.MM.yyyy";
        const startValue = new Date("2022-09-23T10:00:00Z");
        const endValue = new Date("2022-09-25T10:00:00Z");
        const startValueString = "23.09.2022";
        const endValueString = "25.09.2022";

        render(<DatePicker label={label} format={format} startValue={startValue} endValue={endValue} isRange />);
        expect(getInputByLabel(label)).toHaveValue(`${startValueString} - ${endValueString}`);
    });

    test("renders custom start and end slots for the datepicker", () => {
        const format = "dd.MM.yyyy";
        const startSlotString = "whoa";
        const endSlotString = "boom";
        const renderStartSlot = () => <div>{startSlotString}</div>;
        const renderEndSlot = () => <div>{endSlotString}</div>;

        render(<DatePicker format={format} renderStartSlot={renderStartSlot} renderEndSlot={renderEndSlot} />);
        expect(screen.getByText(startSlotString)).toBeInTheDocument();
        expect(screen.getByText(endSlotString)).toBeInTheDocument();
    });

    test("predefinedRanges renders a chip for given range", async () => {
        const label = "Foo";
        const format = "dd.MM.yyyy";
        const expectedLabel = "Last 7 days";

        render(
            <DatePicker label={label} format={format} isRange predefinedRanges={["KALEP_DATE_RANGE_LAST_7_DAYS"]} />,
        );

        const user = userEvent.setup();
        await user.tab();

        expect(screen.getByText(expectedLabel)).toBeInTheDocument();
    });

    test("predefinedRanges renders a chip for given custom range definition", async () => {
        const label = "Foo";
        const format = "dd.MM.yyyy";
        const expectedLabel = "Funky-label";

        const range = {key: "test-range", label: expectedLabel, startDate: new Date(), endDate: new Date()};

        render(
            <DatePicker
                label={label}
                format={format}
                isRange
                predefinedRanges={[range, "KALEP_DATE_RANGE_LAST_7_DAYS"]}
            />,
        );

        const user = userEvent.setup();
        await user.tab();

        expect(screen.getByText(expectedLabel)).toBeInTheDocument();
    });

    test("renders label, helptext and placeholder", () => {
        const label = "Foo";
        const helpText = "Bar";
        const placeholder = "Baz";

        render(<DatePicker label={label} helperText={helpText} placeholder={placeholder} />);

        expect(screen.getByText(label)).toBeInTheDocument();
        expect(screen.getByText(helpText)).toBeInTheDocument();
        expect(getInputByLabel(label)).toHaveAttribute("placeholder", placeholder);
    });

    test("disables input with isDisabled prop", async () => {
        const label = "Foo";

        render(<DatePicker isDisabled label={label} />);

        expect(getInputByLabel(label)).toBeDisabled();

        const user = userEvent.setup();
        await user.tab();

        expect(getInputByLabel(label)).not.toHaveFocus();
    });

    test("renders invalid input if isError passed", async () => {
        const label = "Foo";

        render(<DatePicker isError label={label} />);
        expect(getInputByLabel(label)).toBeInvalid();
    });

    test("renders datepicker closed", async () => {
        const nextMonthLabel = "Foo";
        const prevMonthLabel = "Bar";

        render(<DatePicker nextMonthAriaLabel={nextMonthLabel} previousMonthAriaLabel={prevMonthLabel} />);

        expect(screen.queryByText(nextMonthLabel)).not.toBeInTheDocument();
        expect(screen.queryByText(prevMonthLabel)).not.toBeInTheDocument();
    });

    test("opens datepicker on focus", async () => {
        const nextMonthLabel = "Foo";
        const prevMonthLabel = "Bar";

        render(<DatePicker nextMonthAriaLabel={nextMonthLabel} previousMonthAriaLabel={prevMonthLabel} />);

        const user = userEvent.setup();
        await user.tab();

        expect(screen.getByLabelText(nextMonthLabel)).toBeInTheDocument();
        expect(screen.getByLabelText(prevMonthLabel)).toBeInTheDocument();
    });

    test("focuses current day after opening datepicker", async () => {
        render(<DatePicker />);

        const user = userEvent.setup();
        await user.tab();
        await user.keyboard("[ArrowDown]");

        expect(screen.getByRole("option", {current: "date"})).toHaveFocus();
    });

    test("focuses selected day after opening datepicker", async () => {
        const value = new Date("2022-09-23T10:00:00Z");
        const dayLabel = "23";

        render(<DatePicker value={value} />);

        const user = userEvent.setup();
        await user.tab();
        await user.keyboard("[ArrowDown]");

        expect(screen.getByRole("option", {selected: true})).toHaveFocus();
        expect(screen.getByRole("option", {selected: true}).firstChild).toHaveTextContent(dayLabel);
    });

    test("focuses previous and next month buttons properly", async () => {
        const nextMonthLabel = "Foo";
        const prevMonthLabel = "Bar";

        render(<DatePicker nextMonthAriaLabel={nextMonthLabel} previousMonthAriaLabel={prevMonthLabel} />);

        const user = userEvent.setup();
        await user.tab();
        await user.keyboard("[ArrowDown]");

        await user.tab({shift: true});
        expect(screen.getByLabelText(nextMonthLabel)).toHaveFocus();

        await user.tab({shift: true});
        expect(screen.getByLabelText(prevMonthLabel)).toHaveFocus();
    });

    test("calls onChange on clicking new date", async () => {
        const value = new Date("2022-09-23T10:00:00Z");
        const newValue = new Date("2022-09-24T10:00:00Z");
        const newDayLabel = "24";

        const onChange = vi.fn();

        render(<DatePicker value={value} onChange={onChange} />);

        const user = userEvent.setup();
        await user.tab();

        const newDay = getDayByText(newDayLabel);
        if (newDay) {
            await user.click(newDay);
        }

        expect(onChange).toHaveBeenCalledTimes(1);
        expect(onChange).toHaveBeenCalledWith(newValue);
    });

    test("allows using arrows for day selection", async () => {
        const value = new Date("2022-09-15T10:00:00Z");

        render(<DatePicker value={value} />);

        const user = userEvent.setup();
        await user.tab();
        await user.keyboard("[ArrowDown]");

        await user.keyboard("[ArrowLeft]");
        expect(getDayByText("14")).toHaveFocus();

        await user.keyboard("[ArrowRight]");
        expect(getDayByText("15")).toHaveFocus();

        await user.keyboard("[ArrowDown]");
        expect(getDayByText("22")).toHaveFocus();

        await user.keyboard("[ArrowUp]");
        expect(getDayByText("15")).toHaveFocus();
    });

    test("limits date selection with min and max date", async () => {
        const value = new Date("2022-09-15T10:00:00Z");
        const min = new Date("2022-09-14T10:00:00Z");
        const max = new Date("2022-09-16T10:00:00Z");

        render(<DatePicker value={value} minDate={min} maxDate={max} />);

        const user = userEvent.setup();
        await user.tab();

        expect(getDayByText("13")).toHaveAttribute("aria-disabled", "true");
        expect(getDayByText("14")).toHaveAttribute("aria-disabled", "false");
        expect(getDayByText("15")).toHaveAttribute("aria-disabled", "false");
        expect(getDayByText("16")).toHaveAttribute("aria-disabled", "false");
        expect(getDayByText("17")).toHaveAttribute("aria-disabled", "true");
    });
});
