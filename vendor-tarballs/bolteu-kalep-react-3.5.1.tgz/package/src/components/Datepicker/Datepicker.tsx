import React, {useState} from "react";
import ReactDatePicker from "react-datepicker";

import Calendar from "@bolteu/kalep-react-icons/dist/Calendar";
import ChevronLeft from "@bolteu/kalep-react-icons/dist/ChevronLeft";
import ChevronRight from "@bolteu/kalep-react-icons/dist/ChevronRight";
import Time from "@bolteu/kalep-react-icons/dist/Time";

import {IconButton} from "@/components/IconButton";
import type {TextFieldProps, TextFieldRenderProps} from "@/components/TextField";
import {TextField} from "@/components/TextField";
import {type RenderFunction, useControlledValueWarning} from "@/helpers";
import {cx} from "@/helpers/utils/cx";

import type {Size} from "../TextField/TextField.types";
import type {RequestedDateRanges} from "./PredefinedRanges";
import {PredefinedRanges} from "./PredefinedRanges";

const DEFAULT_LOCALE = "en-US";
const DEFAULT_FORMAT = "dd/MM/yyyy";
const DEFAULT_TIME_FORMAT = "HH:mm";
const DEFAULT_START_DAY = 1;
const DEFAULT_ARIA_LABELS = {
    previousMonth: "Previous month",
    nextMonth: "Next month",
};

interface DatePickerHeaderProps {
    date: Date;
    locale: string;
    decreaseMonth: () => void;
    increaseMonth: () => void;
    prevMonthButtonDisabled: boolean;
    nextMonthButtonDisabled: boolean;
    previousMonthAriaLabel?: string;
    nextMonthAriaLabel?: string;
    predefinedRanges?: RequestedDateRanges;
    onRangeSelected?: (range: [Date, Date]) => void;
}

function DatePickerHeader({
    date,
    locale,
    decreaseMonth,
    increaseMonth,
    prevMonthButtonDisabled,
    nextMonthButtonDisabled,
    previousMonthAriaLabel,
    nextMonthAriaLabel,
    predefinedRanges,
    onRangeSelected,
}: DatePickerHeaderProps) {
    const showPredefinedRangePicker = predefinedRanges && onRangeSelected;

    return (
        <div>
            {showPredefinedRangePicker ? (
                <PredefinedRanges onRangeSelected={onRangeSelected} ranges={predefinedRanges} />
            ) : null}
            <div className={cx("flex items-center justify-between px-2 py-2")}>
                <span className={cx("bolt-font-body-l-accent capitalize text-primary")}>
                    {`${date.toLocaleDateString(locale, {
                        year: "numeric",
                        month: "short",
                    })}`}
                </span>

                <div className={cx("flex gap-2")}>
                    <IconButton
                        onClick={decreaseMonth}
                        disabled={prevMonthButtonDisabled}
                        size="sm"
                        variant="secondary"
                        icon={<ChevronLeft className={cx("rtl:rotate-180")} />}
                        aria-label={previousMonthAriaLabel ?? DEFAULT_ARIA_LABELS.previousMonth}
                    />
                    <IconButton
                        onClick={increaseMonth}
                        disabled={nextMonthButtonDisabled}
                        size="sm"
                        variant="secondary"
                        icon={<ChevronRight className={cx("rtl:rotate-180")} />}
                        aria-label={nextMonthAriaLabel ?? DEFAULT_ARIA_LABELS.nextMonth}
                    />
                </div>
            </div>
        </div>
    );
}

const renderDay = (day: number) => {
    return <div className={cx("react-datepicker__day--internal")}>{day}</div>;
};

const renderCalendarInputEndSlot = (props: TextFieldProps) => {
    return (
        <Calendar
            className={cx(props.disabled ? "text-tertiary" : "cursor-pointer text-primary")}
            size={props.size === "sm" ? "sm" : "lg"}
        />
    );
};

const renderTimeInputEndSlot = (props: TextFieldProps) => {
    return (
        <Time
            className={cx(props.disabled ? "text-tertiary" : "cursor-pointer text-primary")}
            size={props.size === "sm" ? "sm" : "lg"}
        />
    );
};

const DatePickerInput = React.forwardRef<HTMLInputElement, TextFieldProps>(
    (
        {
            value,
            label,
            placeholder,
            required,
            helperText,
            disabled,
            error,
            onClick,
            onChange,
            onFocus,
            onBlur,
            onKeyDown,
            tabIndex,
            fullWidth,
            size,
            renderEndSlot,
            renderStartSlot,
        },
        ref,
    ) => {
        // We're manually passing through all the necessary props, because react-datepicker manages to pass on some kind of garbage
        // if we just spread all the props
        return (
            <TextField
                ref={ref}
                tabIndex={tabIndex}
                value={value}
                label={label}
                disabled={disabled}
                error={error}
                onClick={onClick}
                onChange={onChange}
                onFocus={onFocus}
                onBlur={onBlur}
                onKeyDown={onKeyDown}
                placeholder={placeholder}
                required={required}
                helperText={helperText}
                renderStartSlot={renderStartSlot}
                renderEndSlot={renderEndSlot ?? renderCalendarInputEndSlot}
                fullWidth={fullWidth}
                size={size}
            />
        );
    },
);
DatePickerInput.displayName = "DatePickerInput";

export type PopperPlacement =
    | "top"
    | "top-start"
    | "top-end"
    | "bottom"
    | "bottom-start"
    | "bottom-end"
    | "right"
    | "right-start"
    | "right-end"
    | "left"
    | "left-start"
    | "left-end"
    | "auto"
    | "auto-start"
    | "auto-end";

export interface DatePickerProps {
    onChange?: (value: Date | Date[] | null) => void;
    value?: Date | null;
    name?: string;
    startValue?: Date | null;
    endValue?: Date | null;
    label?: string;
    helperText?: string;
    placeholder?: string;
    required?: boolean;
    locale?: string;
    format?: string;
    timeFormat?: string;
    startDay?: number;
    minDate?: Date;
    maxDate?: Date;
    minTime?: Date;
    maxTime?: Date;
    isDisabled?: boolean;
    isError?: boolean;
    isRange?: boolean;
    previousMonthAriaLabel?: string;
    nextMonthAriaLabel?: string;
    fullWidth?: boolean;
    size?: Size;
    hasTimeSelect?: boolean;
    hasTimeSelectOnly?: boolean;
    injectTimes?: Date[];
    predefinedRanges?: RequestedDateRanges;
    popperPlacement?: PopperPlacement;
    popperModifiers?: Record<string, any>[];
    renderStartSlot?: RenderFunction<TextFieldRenderProps>;
    renderEndSlot?: RenderFunction<TextFieldRenderProps>;
    customInput?: React.ReactNode;
}

export function DatePicker(props: DatePickerProps) {
    const {
        onChange,
        value,
        name,
        startValue,
        endValue,
        label,
        helperText,
        placeholder,
        required,
        locale,
        format,
        timeFormat,
        startDay,
        minDate,
        maxDate,
        minTime,
        maxTime,
        isDisabled,
        isError,
        isRange,
        previousMonthAriaLabel,
        nextMonthAriaLabel,
        fullWidth,
        size,
        hasTimeSelect,
        hasTimeSelectOnly,
        injectTimes,
        predefinedRanges,
        popperPlacement,
        popperModifiers,
        renderStartSlot,
        renderEndSlot,
        customInput,
    } = props;
    let hasTimeSelectInternal = hasTimeSelect;
    if (hasTimeSelect && isRange) {
        hasTimeSelectInternal = false;

        console.warn(
            "Kalep warning: Datepicker does not support time selection in a ranged Datepicker. 'hasTimeSelect' is ignored.",
        );
    }

    const inputRef = React.useRef<HTMLInputElement>(null);

    const [internalDate, setInternalDate] = useState<Date | null>(null);
    const [internalStartDate, setInternalStartDate] = useState<Date | null>(null);
    const [internalEndDate, setInternalEndDate] = useState<Date | null>(null);

    const isControlled = React.useMemo(() => {
        return "value" in props || "startValue" in props || "endValue" in props;
    }, [props]);

    useControlledValueWarning(isControlled);

    const dateToUse = isControlled ? value : internalDate;
    const startDateToUse = isControlled ? startValue : internalStartDate;
    const endDateToUse = isControlled ? endValue : internalEndDate;

    const localeToUse = locale ?? DEFAULT_LOCALE;
    const formatToUse = format ?? DEFAULT_FORMAT;
    const timeFormatToUse = timeFormat ?? DEFAULT_TIME_FORMAT;
    const startDayToUse = startDay ?? DEFAULT_START_DAY;
    const placeholderToUse = placeholder ?? (isRange ? `${formatToUse} - ${formatToUse}` : formatToUse);
    const popperPlacementToUse = popperPlacement ?? "bottom-start";

    const handleChange = React.useCallback(
        (newValue: any) => {
            if (isControlled) {
                onChange?.(newValue);
            } else if (!isRange) {
                setInternalDate(newValue);
            } else {
                const [start, end] = newValue;
                setInternalStartDate(start);
                setInternalEndDate(end);
            }
        },
        [isControlled, isRange, onChange],
    );

    /** Consider: perhaps we only need handleChange? */
    const handlePredefinedRangeSelected = React.useCallback(
        (range: [Date, Date]) => {
            if (!isRange) {
                return;
            }

            if (isControlled) {
                onChange?.(range);
                return;
            }

            setInternalStartDate(range[0]);
            setInternalEndDate(range[1]);
        },
        [isControlled, isRange, onChange],
    );

    const endSlot = renderEndSlot ?? (hasTimeSelectOnly ? renderTimeInputEndSlot : undefined);
    const customInputProp = customInput ?? (
        <DatePickerInput
            ref={inputRef}
            label={label}
            helperText={helperText}
            error={isError}
            disabled={isDisabled}
            required={required}
            fullWidth={fullWidth}
            size={size}
            renderStartSlot={renderStartSlot}
            renderEndSlot={endSlot}
        />
    );
    return (
        <div className={cx(fullWidth ? "w-full" : "w-96")}>
            <ReactDatePicker
                name={name}
                customInputRef={inputRef as unknown as string}
                onChange={handleChange}
                selected={isRange ? undefined : dateToUse}
                startDate={isRange ? startDateToUse : undefined}
                endDate={isRange ? endDateToUse : undefined}
                selectsRange={isRange}
                disabled={isDisabled}
                minDate={minDate}
                maxDate={maxDate}
                minTime={minTime}
                maxTime={maxTime}
                fixedHeight
                showPopperArrow={false}
                showTimeSelect={hasTimeSelectInternal}
                showTimeSelectOnly={hasTimeSelectOnly}
                injectTimes={injectTimes}
                calendarStartDay={startDayToUse}
                dateFormat={formatToUse}
                timeFormat={timeFormatToUse}
                placeholderText={placeholderToUse}
                wrapperClassName="kalep-datepicker"
                popperClassName="kalep-datepicker"
                popperPlacement={popperPlacementToUse}
                popperModifiers={popperModifiers}
                customInput={customInputProp}
                locale={localeToUse}
                required={required}
                renderDayContents={renderDay}
                renderCustomHeader={({
                    date,
                    decreaseMonth,
                    increaseMonth,
                    prevMonthButtonDisabled,
                    nextMonthButtonDisabled,
                }) => (
                    <DatePickerHeader
                        date={date}
                        locale={localeToUse}
                        increaseMonth={increaseMonth}
                        decreaseMonth={decreaseMonth}
                        prevMonthButtonDisabled={prevMonthButtonDisabled}
                        nextMonthButtonDisabled={nextMonthButtonDisabled}
                        previousMonthAriaLabel={previousMonthAriaLabel}
                        nextMonthAriaLabel={nextMonthAriaLabel}
                        predefinedRanges={isRange ? predefinedRanges : undefined}
                        onRangeSelected={handlePredefinedRangeSelected}
                    />
                )}
            />
        </div>
    );
}
