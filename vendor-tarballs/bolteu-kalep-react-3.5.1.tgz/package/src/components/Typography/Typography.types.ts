import type * as React from "react";

// TODO: automate pulling this list from tokens.
/**
 * Font styles coming from design system tokens.
 */
export type BoltFontStyles =
    | "heading-l-accent"
    | "heading-m-accent"
    | "heading-s-accent"
    | "heading-xs-accent"
    | "heading-xs-regular"
    | "body-l-regular"
    | "body-l-accent"
    | "body-l-compact-regular"
    | "body-l-compact-accent"
    | "body-m-regular"
    | "body-m-accent"
    | "body-m-compact-regular"
    | "body-m-compact-accent"
    | "body-s-regular"
    | "body-s-accent"
    | "body-s-compact-regular"
    | "body-s-compact-accent"
    | "body-xs-regular"
    | "body-xs-accent"
    | "body-xs-compact-regular"
    | "body-xs-compact-accent"
    | "body-tabular-l-regular"
    | "body-tabular-l-accent"
    | "body-tabular-l-compact-regular"
    | "body-tabular-l-compact-accent"
    | "body-tabular-m-regular"
    | "body-tabular-m-accent"
    | "body-tabular-m-compact-regular"
    | "body-tabular-m-compact-accent"
    | "body-tabular-s-regular"
    | "body-tabular-s-accent"
    | "body-tabular-s-compact-regular"
    | "body-tabular-s-compact-accent"
    | "body-tabular-xs-regular"
    | "body-tabular-xs-accent"
    | "body-tabular-xs-compact-regular"
    | "body-tabular-xs-compact-accent"
    | "caps-l-accent"
    | "caps-m-accent"
    | "caps-s-accent"
    | "display-m-regular";

export type TypographyAlignment = "start" | "end" | "center" | "justify";

export type TypographySize =
    | "text-xs"
    | "text-sm"
    | "text-base"
    | "text-md"
    | "text-lg"
    | "text-xl"
    | "text-2xl"
    | "text-3xl"
    | "text-4xl"
    | "text-5xl"
    | "text-6xl";

export type TypographyColor =
    | "primary"
    | "secondary"
    | "tertiary"
    | "action-primary"
    | "action-secondary"
    | "danger-primary"
    | "danger-secondary"
    | "warning-primary"
    | "warning-secondary"
    | "positive-primary"
    | "positive-secondary"
    | "promo-primary"
    | "promo-secondary"
    | "link-primary"
    | "active-link-primary"
    | "link-secondary"
    | "primary-inverted";

export type TypographyLineClampValues = 1 | 2 | 3 | 4 | "none";

export type SpacingValue =
    | 0
    | 0.5
    | 1
    | 1.5
    | 2
    | 3
    | 4
    | 5
    | 6
    | 7
    | 8
    | 9
    | 10
    | 11
    | 12
    | 14
    | 16
    | 20
    | 24
    | 28
    | 32
    | 36
    | 40
    | 44
    | 48
    | 52
    | 56
    | 60
    | 64
    | 72
    | 80
    | 96;

export type TypographyProps = {
    /**
     * @default "body-m-regular"
     *
     */
    variant?: BoltFontStyles;
    /**
     * Sizes are given as valid tailwind classes.
     * If you need to define size differently, use inlineStyle prop instead.
     */
    fontSize?: TypographySize;
    /**
     * Default is not defined, so it will inherit a value from the parent.
     * Alignments are defined as logical values. I.e start instead of left. This is to support RTL languages.
     */
    align?: TypographyAlignment;
    /**
     * HTML element to use as the root node.
     */
    as?: React.ElementType;
    /**
     * The text content. It allows React.ReactNode to support localisation components and simpler icon usages.
     * However you should refrain from putting very complex components here.
     */
    children: React.ReactNode;
    /**
     * Sets "display: inline" on the root element.
     */
    inline?: boolean;
    /**
     * Blocks the text from wrapping. Sets text-overflow to ellipsis.
     */
    noWrap?: boolean;
    /**
     * Passed to the root element as inline styles.
     * NB: be careful with overriding default font style settings. For example Bolt font
     * styles have default font-feature-settings that should not be overridden.
     * If you need to apply the same properties, please make sure that you include the default values.
     */
    inlineStyle?: React.CSSProperties;
    /**
     * Spacing scale steps are allowed as value.
     * The calculation is done by multiplying the value with 0.25rem.
     */
    paddingTop?: SpacingValue;
    /**
     * Spacing scale steps are allowed as value.
     * The calculation is done by multiplying the value with 0.25rem.
     */
    paddingBottom?: SpacingValue;
    /**
     * Color values from the functional color palette are allowed as value.
     * If you need to define color differently, use inlineStyle prop instead.
     */
    color?: TypographyColor;
    /**
     * Text will be clamped to this number of lines and will be truncated with ellipsis.
     */
    lines?: TypographyLineClampValues;
};
