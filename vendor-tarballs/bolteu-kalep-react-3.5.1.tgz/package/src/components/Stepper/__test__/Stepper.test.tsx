import * as React from "react";

import {render, screen} from "@testing-library/react";

import {Stepper} from "../index";

describe("Stepper test suite", () => {
    test("renders progress stepper", () => {
        const steps = 4;
        const value = 2;

        render(<Stepper steps={steps} value={value} />);

        const stepper = screen.getByRole("progressbar");

        expect(stepper).toHaveAttribute("aria-valuenow", `${value}`);
        expect(stepper).toHaveAttribute("aria-busy", "true");
        expect(stepper?.childElementCount).toBe(steps);
        expect(stepper?.children.item(value)).toHaveClass("bg-active-action-secondary");
    });

    test("renders completed progress stepper", () => {
        const steps = 4;
        const value = 4;

        render(<Stepper steps={steps} value={value} />);

        const stepper = screen.getByRole("progressbar");

        expect(stepper).toHaveAttribute("aria-valuenow", `${value}`);
        expect(stepper).toHaveAttribute("aria-busy", "false");
        expect(stepper?.childElementCount).toBe(steps);
    });

    test("renders stepper caption", () => {
        const steps = 4;
        const value = 2;
        const caption = "Let's go through some steps";

        render(<Stepper steps={steps} value={value} caption={caption} />);

        expect(screen.getByRole("progressbar", {name: caption})).toBeInTheDocument();
        expect(screen.getByText(caption)).toBeInTheDocument();
    });
});
