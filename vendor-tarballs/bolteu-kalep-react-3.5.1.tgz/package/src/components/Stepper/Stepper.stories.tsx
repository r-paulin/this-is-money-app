import * as React from "react";

import type {Meta, StoryFn} from "@storybook/react-webpack5";

import {Button} from "@/components/Button";

import {Stepper} from "./Stepper";
import type {StepperProps} from "./Stepper.types";

export default {
    title: "Navigation/Stepper",
    component: Stepper,
    tags: ["autodocs"],
} as Meta<typeof Stepper>;

const ProgressStory: StoryFn<typeof Stepper> = (args: StepperProps) => {
    const {steps} = args;
    const [value, setValue] = React.useState(0);
    const caption = value < steps ? `Step ${value + 1}` : "Done";

    const stepForward = React.useCallback(() => {
        if (value <= steps) {
            setValue(value + 1);
        }
    }, [steps, value]);

    return (
        <div className="flex flex-col items-start gap-6">
            <Stepper {...args} value={value} caption={caption} />
            <Button onClick={stepForward} disabled={value === steps}>
                Next step
            </Button>
        </div>
    );
};

export const Progress = ProgressStory.bind({});
Progress.args = {
    steps: 8,
};
