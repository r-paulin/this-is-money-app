import type * as React from "react";

import type {RenderFunction} from "@/helpers";

export type State = "disabled" | "idle" | "selected";
export type PageType = "previous" | "next" | "page";

export interface PaginationProps {
    count: number;
    /* Provide an accessible label for navigation component */
    "aria-label": string;
    currentPage?: number;
    getItemAriaLabel?: (type: PageType, pageNumber: number) => string;
    onClick?: (page: number) => void;
    overrideClassName?: string;
    disabled?: boolean;
}

export interface PaginationItemProps {
    children: React.ReactNode;
    "aria-label": string;
    selected?: boolean;
    disabled?: boolean;
    onClick?: () => void;
}

export interface PaginationOptionsProps {
    value: number;
    options: Array<number>;
    onChange: (option: number) => void;
    label?: string | (() => string);
}

export type PaginationTotalLabelProps = {
    currentPage: number;
    rowsPerPage: number;
    totalItems: number;
};
export interface PaginationTotalCountProps {
    currentPage?: number;
    rowsPerPage?: number;
    totalItems?: number;
    renderLabel?: RenderFunction<PaginationTotalLabelProps>;
}
