import * as React from "react";

import ChevronLeft from "@bolteu/kalep-react-icons/dist/ChevronLeft";
import ChevronRight from "@bolteu/kalep-react-icons/dist/ChevronRight";

import {cx} from "@/helpers/utils/cx";

import {IconButton} from "../IconButton";
import type {PageType, PaginationItemProps, PaginationProps, State} from "./Pagination.types";

export const MAX_DISPLAYED_PAGES = 7;
export const MIN_PAGES_FROM_EDGE = 5;
export const defaultGetItemAriaLabel = (type: PageType, pageNumber: number) => {
    if (type === "previous") {
        return "Go to the previous page";
    }

    if (type === "next") {
        return "Go to the next page";
    }

    return `Go to page ${pageNumber + 1}`;
};

const paginationItemStyle =
    "bg-special-nulled h-9 min-w-9 p-2 text-primary rounded-md border border-transparent bolt-font-body-s-regular text-center";
const states: Record<State, string> = {
    selected: "bg-neutral-secondary border-special-nulled cursor-default font-semibold",
    disabled: "text-tertiary cursor-not-allowed",
    idle: "hover:border-separator cursor-pointer",
};

/**
 * Returns a list of non-truncated pages
 * For example for count = 10; currentPage = 2 the following output will be returned:
 * [0, 1, 2, 3, 4, 9]
 */
const getDisplayedPages = (currentPage: number, count: number, allPages: number[]) => {
    const isCurrentPageNearStart = currentPage < MIN_PAGES_FROM_EDGE - 1;
    const isCurrentPageNearEnd = currentPage > count - MIN_PAGES_FROM_EDGE;

    if (count <= MAX_DISPLAYED_PAGES) {
        return allPages;
    }

    return [
        ...new Set([
            0,
            count - 1,
            currentPage,
            currentPage - 1,
            currentPage + 1,
            ...(isCurrentPageNearStart ? [...Array(MIN_PAGES_FROM_EDGE).keys()] : []),
            ...(isCurrentPageNearEnd ? [...Array(count).keys()].slice(count - MIN_PAGES_FROM_EDGE) : []),
        ]),
    ]
        .filter((value) => value >= 0 && value < count)
        .sort((a, b) => a - b);
};

/* renders previous and next arrows, displayed pages and ellipses */
const renderPages = (
    currentPage: number,
    count: number,
    allPages: number[],
    onClick: (goToPage: number) => (() => void) | undefined,
    disabled: boolean,
    getItemAriaLabel: PaginationProps["getItemAriaLabel"] = defaultGetItemAriaLabel,
) => {
    const displayedPages = getDisplayedPages(currentPage, count, allPages);

    return allPages.map((pageNumber, index) => {
        if (displayedPages.includes(pageNumber)) {
            return (
                <PaginationItem
                    key={pageNumber}
                    aria-label={getItemAriaLabel("page", pageNumber)}
                    selected={currentPage === pageNumber}
                    onClick={onClick(pageNumber)}
                    disabled={disabled}
                >
                    {pageNumber + 1}
                </PaginationItem>
            );
        }

        const previousPage = allPages[index - 1];

        if (displayedPages.includes(previousPage)) {
            return (
                <li key={pageNumber} data-testid="ellipsis" className={cx(paginationItemStyle, "text-secondary")}>
                    ...
                </li>
            );
        }

        return null;
    });
};

export function Pagination({
    count = 1,
    currentPage = 0,
    onClick,
    getItemAriaLabel = defaultGetItemAriaLabel,
    overrideClassName,
    disabled = false,
    "aria-label": ariaLabel,
}: PaginationProps) {
    const handleClick = React.useCallback(
        (goToPage: number) => {
            if (typeof onClick === "function") {
                return () => onClick(goToPage);
            }

            return undefined;
        },
        [onClick],
    );

    const allPages = React.useMemo(() => [...Array(count).keys()], [count]);
    const renderedPages = React.useMemo(
        () => renderPages(currentPage, count, allPages, handleClick, disabled, getItemAriaLabel),
        [currentPage, count, allPages, handleClick, disabled, getItemAriaLabel],
    );

    return (
        <nav role="navigation" aria-label={ariaLabel} className={cx("flex w-full justify-center", overrideClassName)}>
            <ul className={cx("m-0 flex list-none gap-1 px-0 text-primary")}>
                <li>
                    <IconButton
                        aria-label={getItemAriaLabel("previous", currentPage - 1)}
                        shape="square"
                        variant="ghost"
                        icon={<ChevronLeft size="sm" className={cx("rtl:rotate-180")} />}
                        size="sm"
                        onClick={handleClick(currentPage - 1)}
                        disabled={disabled || currentPage === 0}
                    />
                </li>
                {renderedPages}
                <li>
                    <IconButton
                        aria-label={getItemAriaLabel("next", currentPage + 1)}
                        shape="square"
                        variant="ghost"
                        icon={<ChevronRight size="sm" className={cx("rtl:rotate-180")} />}
                        size="sm"
                        onClick={handleClick(currentPage + 1)}
                        disabled={disabled || currentPage === count - 1}
                    />
                </li>
            </ul>
        </nav>
    );
}

function PaginationItem({
    children,
    selected = false,
    disabled = false,
    onClick,
    "aria-label": ariaLabel,
}: PaginationItemProps) {
    return (
        <li>
            <button
                type="button"
                disabled={disabled}
                aria-current={selected}
                aria-label={ariaLabel}
                className={cx(
                    paginationItemStyle,
                    selected && states.selected,
                    disabled && states.disabled,
                    !disabled && !selected && states.idle,
                )}
                onClick={onClick}
            >
                {children}
            </button>
        </li>
    );
}
