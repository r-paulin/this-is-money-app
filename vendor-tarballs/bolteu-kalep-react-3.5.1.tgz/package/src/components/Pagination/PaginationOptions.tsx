import * as React from "react";

import type {SelectOption} from "@/components/_internal/Option";
import {Select} from "@/components/Select";
import {useId} from "@/helpers";
import {cx} from "@/helpers/utils/cx";

import type {PaginationOptionsProps} from "./Pagination.types";

function valueToSelectOption(value: number): SelectOption {
    return {value, title: String(value)};
}

export function PaginationOptions({options, value, onChange, label = "Per page:"}: PaginationOptionsProps) {
    const selectId = useId();
    const selectOptions = React.useMemo(() => options.map(valueToSelectOption), [options]);
    const selectedOption = React.useMemo(() => valueToSelectOption(value), [value]);

    const onSelectChange = React.useCallback(
        (option: SelectOption | SelectOption[] | null) => {
            if (!Array.isArray(option)) {
                onChange(option?.value as number);
            }
        },
        [onChange],
    );

    return (
        <div className={cx("flex items-center gap-3", "text-primary")}>
            <label htmlFor={selectId} className={cx("bolt-font-body-s-regular text-secondary")}>
                {typeof label === "function" ? label() : label}
            </label>
            <div className={cx("min-w-20")}>
                <Select
                    id={selectId}
                    options={selectOptions}
                    value={selectedOption}
                    onChange={onSelectChange}
                    fullWidth
                    size="sm"
                    clearable={false}
                />
            </div>
        </div>
    );
}
