import * as React from "react";

import {render, screen} from "@testing-library/react";

import {Pagination} from "../index";
import {defaultGetItemAriaLabel, MAX_DISPLAYED_PAGES, MIN_PAGES_FROM_EDGE} from "../Pagination";
import type {PageType} from "../Pagination.types";

describe("Pagination test suite", () => {
    test("pagination items can have custom aria label", () => {
        const previousAriaLabel = "go back";
        const nextAriaLabel = "do not go back";
        const numberAriaLabel = "lucky number";

        const getItemAriaLabel = (type: PageType, number: number) => {
            if (type === "previous") {
                return previousAriaLabel;
            }

            if (type === "next") {
                return nextAriaLabel;
            }

            return `${numberAriaLabel} ${number + 1}`;
        };

        render(<Pagination aria-label="pagination" count={2} getItemAriaLabel={getItemAriaLabel} />);

        expect(screen.getByRole("button", {name: previousAriaLabel})).toBeInTheDocument();
        expect(screen.getByRole("button", {name: nextAriaLabel})).toBeInTheDocument();
        expect(screen.getByRole("button", {name: `${numberAriaLabel} ${1}`})).toBeInTheDocument();
        expect(screen.getByRole("button", {name: `${numberAriaLabel} ${2}`})).toBeInTheDocument();
    });

    test("renders short pagination", () => {
        const count = 7;
        let currentPage = 0;

        const {rerender} = render(<Pagination aria-label="pagination" count={count} currentPage={currentPage} />);

        const pagination = screen.getByRole("navigation");
        const selectedPage = screen.getByText(currentPage + 1);
        const pages = screen.getAllByRole("listitem");
        const arrowLeft = pages[0]?.getElementsByTagName("button").item(0);
        const arrowRight = pages[pages.length - 1]?.getElementsByTagName("button").item(0);

        expect(pagination?.getElementsByTagName("ul").length).toBe(1);
        expect(pages).toHaveLength(count + 2);
        expect(selectedPage).toHaveAttribute("aria-current", "true");
        expect(arrowLeft).toHaveAttribute("aria-label", defaultGetItemAriaLabel("previous", currentPage - 1));
        expect(arrowLeft).toBeDisabled();
        expect(arrowRight).toBeEnabled();
        expect(arrowRight).toHaveAttribute("aria-label", defaultGetItemAriaLabel("next", currentPage + 1));

        currentPage = 2;
        rerender(<Pagination aria-label="pagination" count={count} currentPage={currentPage} />);

        expect(arrowLeft).toBeEnabled();
        expect(arrowRight).toBeEnabled();

        currentPage = count - 1;
        rerender(<Pagination aria-label="pagination" count={count} currentPage={currentPage} />);

        expect(arrowLeft).toBeEnabled();
        expect(arrowRight).toBeDisabled();
    });

    test("renders truncated pagination", () => {
        const count = 10;
        let currentPage = 0;

        const {rerender} = render(<Pagination aria-label="pagination" count={count} currentPage={currentPage} />);

        let pages = screen.getAllByRole("listitem");
        let ellipses = screen.getAllByTestId("ellipsis");

        expect(pages).toHaveLength(MAX_DISPLAYED_PAGES + 2);
        expect(ellipses).toHaveLength(1);
        expect(pages[MIN_PAGES_FROM_EDGE + 1]).toHaveTextContent("...");

        currentPage = 5;
        rerender(<Pagination aria-label="pagination" count={count} currentPage={currentPage} />);
        pages = screen.getAllByRole("listitem");
        ellipses = screen.getAllByTestId("ellipsis");
        expect(pages).toHaveLength(MAX_DISPLAYED_PAGES + 2);
        expect(ellipses).toHaveLength(2);
        expect(pages[2]).toHaveTextContent("...");
        expect(pages[pages.length - 3]).toHaveTextContent("...");

        currentPage = 9;
        rerender(<Pagination aria-label="pagination" count={count} currentPage={currentPage} />);
        pages = screen.getAllByRole("listitem");
        ellipses = screen.getAllByTestId("ellipsis");
        expect(pages).toHaveLength(MAX_DISPLAYED_PAGES + 2);
        expect(ellipses).toHaveLength(1);
        expect(pages[pages.length - MIN_PAGES_FROM_EDGE - 2]).toHaveTextContent("...");
    });
});
