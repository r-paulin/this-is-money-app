import * as React from "react";

import {cx} from "@/helpers/utils/cx";

import {Typography} from "../Typography";
import type {PaginationTotalCountProps, PaginationTotalLabelProps} from "./Pagination.types";

const clamp = (min: number, num: number, max: number) => Math.min(Math.max(num, min), max);

function renderDefaultLabel(props: PaginationTotalLabelProps) {
    const {currentPage, rowsPerPage, totalItems} = props;

    const start = rowsPerPage * currentPage + 1;

    const end = clamp(0, rowsPerPage * currentPage + rowsPerPage, totalItems);

    return (
        <Typography variant="body-m-regular" fontSize="text-sm">
            {start}-{end} of {totalItems}
        </Typography>
    );
}

export function PaginationTotalCount({
    currentPage = 0,
    rowsPerPage,
    totalItems,
    renderLabel = renderDefaultLabel,
}: PaginationTotalCountProps) {
    if (!(rowsPerPage && totalItems)) {
        return null;
    }

    return (
        <div className={cx(`
          flex
          sm:flex-1 sm:justify-end
        `)}>
            {renderLabel({currentPage, rowsPerPage, totalItems}, renderDefaultLabel)}
        </div>
    );
}
