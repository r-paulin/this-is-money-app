import * as React from "react";

import type {Meta, StoryFn} from "@storybook/react-webpack5";

import {Pagination} from "./Pagination";
import type {PaginationProps} from "./Pagination.types";
import {PaginationOptions} from "./PaginationOptions";
import {PaginationTotalCount} from "./PaginationTotalCount";

export default {
    title: "Navigation/Pagination",
    component: Pagination,
    tags: ["autodocs"],
    // Downshift uses role="combobox" on Select trigger button and a11y plugin complains about it
    parameters: {
        a11y: {
            config: {
                rules: [
                    {
                        id: "aria-allowed-role",
                        enabled: false,
                    },
                    {
                        id: "button-name",
                        enabled: false,
                    },
                ],
            },
        },
    },
} as Meta<typeof Pagination>;

const content = [
    "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas tincidunt porttitor urna, et iaculis dolor sagittis id. Fusce lacus neque, tristique sagittis libero ut, finibus dapibus velit. Phasellus id arcu in ante sagittis egestas id a mi. Etiam non vehicula leo. Etiam iaculis maximus ante, eu pulvinar ligula imperdiet sed. Maecenas maximus, libero a eleifend dapibus, magna orci dignissim mi, non fermentum tellus orci non odio. Proin sodales lacus vel tempor congue. Donec et rhoncus risus, vitae posuere tellus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla orci lectus, tempor nec ultricies non, gravida id sapien. Mauris elementum egestas gravida. Vestibulum a velit eget lorem accumsan auctor eu nec nibh.",
    "Morbi lobortis aliquam iaculis. Vestibulum augue ante, molestie in ligula at, placerat laoreet arcu. Duis finibus varius massa, ac viverra sem vulputate nec. Nulla euismod sollicitudin felis ac efficitur. Suspendisse tristique, nulla a laoreet finibus, eros lacus fringilla metus, sit amet lacinia elit diam nec nibh. Donec quis tempor nibh. Quisque ut efficitur lorem. Proin nec velit non tellus faucibus facilisis in non justo. Proin ac ex quis urna facilisis pharetra. Sed non tellus vitae massa rhoncus pellentesque et eu neque. Curabitur elementum consequat ipsum eu vulputate.",
    "Quisque turpis risus, semper ac ex in, elementum elementum nunc. Morbi hendrerit euismod hendrerit. Curabitur lacinia ornare quam, non tempus ligula tempus eget. Aenean posuere, tortor ut ullamcorper lobortis, ante metus ornare augue, quis tincidunt magna orci pharetra dolor. Praesent imperdiet gravida quam, eu mollis urna feugiat sit amet. Ut hendrerit lectus eu lacus ultricies, eget mattis augue bibendum. Donec nec posuere ligula. In lorem erat, volutpat nec pulvinar id, finibus at metus. Nam feugiat, eros a consectetur luctus, velit nisi scelerisque urna, a dapibus nisi mi in magna. Nunc venenatis turpis massa, non egestas mauris consectetur sit amet. Morbi nisl diam, convallis id enim quis, varius gravida augue. Integer sodales velit vel quam porttitor aliquam. Ut ornare neque et arcu scelerisque, a pretium felis posuere.",
    "Quisque tincidunt et magna in volutpat. Sed aliquam condimentum nisi nec feugiat. Sed posuere libero ac neque consectetur, sed sagittis orci suscipit. Maecenas rhoncus lectus lorem, id sagittis purus facilisis quis. Ut ac felis laoreet, pulvinar purus ut, scelerisque quam. In a mi auctor, cursus ligula vel, commodo ante. Nunc dictum congue tortor a tristique. Nulla facilisi. Donec scelerisque, ante a aliquam mattis, mauris sem rutrum eros, ut hendrerit lectus turpis nec orci. Ut et consequat felis. Sed nec orci risus. Nulla dolor lacus, sagittis at vulputate elementum, porttitor vitae purus. Etiam et risus et odio gravida fringilla. Aliquam sodales risus ligula, a sollicitudin metus rhoncus sit amet. Phasellus lobortis elementum feugiat.",
    "Pellentesque sit amet eleifend nibh. Curabitur convallis eros eget aliquet condimentum. Pellentesque id luctus nibh. Donec vitae urna sit amet lacus congue egestas. Morbi rhoncus nec lacus eget luctus. Nulla vel aliquet eros, sit amet aliquam justo. Etiam pellentesque purus eu tellus malesuada ultricies. Etiam libero elit, imperdiet et mollis at, ultrices sed mauris.",
];

const PaginationStory: StoryFn<typeof Pagination> = (args: PaginationProps) => {
    const [currentPage, setCurrentPage] = React.useState(args.currentPage ?? 0);

    const handlePageChange = React.useCallback(
        (newPage: number) => {
            setCurrentPage(newPage);
        },
        [setCurrentPage],
    );

    return (
        <div>
            <div className="h-[240px] p-3 text-primary">{content[currentPage % content.length]}</div>
            <Pagination {...args} aria-label="Main pagination" currentPage={currentPage} onClick={handlePageChange} />
        </div>
    );
};

export const DefaultPagination = PaginationStory.bind({});
DefaultPagination.args = {
    count: 7,
};

const rowsPerPageOptions = [25, 50, 100, 500];
const clamp = (min: number, num: number, max: number) => Math.min(Math.max(num, min), max);

export const PerPageOptions = () => {
    const totalItems = 3458;
    const [currentPage, setCurrentPage] = React.useState(0);
    const [rowsPerPage, setRowsPerPage] = React.useState(rowsPerPageOptions[0]);

    const onPaginationClick = React.useCallback((page: number) => {
        setCurrentPage(page);
    }, []);

    const onRowsPerPageChange = React.useCallback((rpp: number) => {
        // Reset to the first page to avoid invalid state, because the current page might be out of bounds.
        setCurrentPage(0);
        setRowsPerPage(rpp);
    }, []);

    return (
        <div className="flex flex-col items-center justify-center gap-8">
            <div className="grid w-full place-items-center bg-neutral-secondary p-6 text-primary">
                <span>{`Showing ${rowsPerPage * currentPage + 1}...${clamp(
                    0,
                    rowsPerPage * currentPage + rowsPerPage,
                    totalItems,
                )} of ${totalItems} rows.`}</span>
                <br />
                <span>{`You are on page ${currentPage + 1} of ${Math.ceil(totalItems / rowsPerPage)} pages.`}</span>
            </div>
            <footer className={`
              mb-8 flex w-full flex-wrap items-center justify-center gap-6
              sm:flex-row-reverse sm:justify-between sm:[&>*]:w-auto
            `}>
                <Pagination
                    aria-label="Pagination for the imaginary table content above"
                    count={Math.ceil(totalItems / rowsPerPage)}
                    currentPage={currentPage}
                    onClick={onPaginationClick}
                />
                <PaginationTotalCount currentPage={currentPage} rowsPerPage={rowsPerPage} totalItems={totalItems} />
                <PaginationOptions value={rowsPerPage} options={rowsPerPageOptions} onChange={onRowsPerPageChange} />
            </footer>
        </div>
    );
};
