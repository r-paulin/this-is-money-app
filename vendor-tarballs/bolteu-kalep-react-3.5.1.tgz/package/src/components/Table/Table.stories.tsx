import * as React from "react";

import type {Meta, StoryFn} from "@storybook/react-webpack5";

import {Dragging} from "@bolteu/kalep-react-icons";

import {Island} from "../Island";
import type {TableProps} from "./index";
import {Table} from "./index";

export default {
    title: "Tables/Simple Table",
    component: Table,
    tags: ["autodocs"],
    parameters: {
        docs: {
            description: {
                component:
                    "Simple Table is a primitive composable Table component to cover the most basic data display needs. 🏋️‍♀️ If you are looking for a more comprehensive Table then check out Table component from the `kalep-table-react` package.",
            },
        },
    },
} as Meta<typeof Table>;

const tableData = [
    {
        sku: 5510,
        productName: "Tomatoes, 1kg",
        sold: 1000,
    },
    {
        sku: 1000,
        productName: "Garlic",
        sold: 200,
    },
    {
        sku: 5520,
        productName: "Apples, 1kg",
        sold: 43,
    },
    {
        sku: 1100,
        productName: "Yellow onion",
        sold: 15,
    },
    {
        sku: 7510,
        productName: "Olive oil, 1l",
        sold: 3,
    },
    {
        sku: 9000,
        productName: "Tofu, 200g",
        sold: 666,
    },
];

const Template: StoryFn<typeof Table> = (args: TableProps) => {
    const draggedItem = React.useRef<number | null>(null);
    const draggedOverItem = React.useRef<number | null>(null);

    const [items, setItems] = React.useState(tableData);

    const handleDragStart = React.useCallback((e) => {
        draggedItem.current = Number(e.target.dataset.index);
    }, []);
    const handleDragEnter = React.useCallback((e) => {
        draggedOverItem.current = Number(e.currentTarget.dataset.index);
    }, []);
    const handleDragEnd = React.useCallback(() => {
        if (draggedItem.current === null || draggedOverItem.current === null) {
            return;
        }

        const itemsCopy = [...items];
        const draggedItemContent = itemsCopy[draggedItem.current];

        itemsCopy.splice(draggedItem.current, 1);
        itemsCopy.splice(draggedOverItem.current!, 0, draggedItemContent);
        draggedItem.current = null;
        draggedOverItem.current = null;
        setItems(itemsCopy);
    }, [items]);

    return (
        <Island>
            <Table {...args}>
                <Table.Header>
                    <Table.HeaderRow>
                        <Table.HeaderCell />
                        <Table.HeaderCell>Sku</Table.HeaderCell>
                        <Table.HeaderCell>Product name</Table.HeaderCell>
                        <Table.HeaderCell align="right">Units sold</Table.HeaderCell>
                    </Table.HeaderRow>
                </Table.Header>
                <Table.Body>
                    {items.map((row, index) => (
                        <Table.Row
                            key={row.sku}
                            data-index={index}
                            draggable
                            onDragStart={handleDragStart}
                            onDragEnter={handleDragEnter}
                            onDragEnd={handleDragEnd}
                        >
                            <Table.Cell>
                                <div className={`
                                  flex text-tertiary
                                  hover:text-secondary
                                `}>
                                    <Dragging size="sm" />
                                </div>
                            </Table.Cell>
                            <Table.Cell>{row.sku}</Table.Cell>
                            <Table.Cell>{row.productName}</Table.Cell>
                            <Table.Cell align="right">{row.sold}</Table.Cell>
                        </Table.Row>
                    ))}
                </Table.Body>
            </Table>
        </Island>
    );
};

export const DraggableRows = Template.bind({});
DraggableRows.args = {
    compact: true,
    striped: true,
};

export const MassiveHeaders = () => (
    <div className="max-w-60">
        <Table>
            <Table.Header>
                <Table.HeaderRow>
                    <Table.HeaderCell>SKU</Table.HeaderCell>
                    <Table.HeaderCell>Total Acceptance</Table.HeaderCell>
                    <Table.HeaderCell>Acceptance rate, % (non-optional orders)</Table.HeaderCell>
                    <Table.HeaderCell>Product name</Table.HeaderCell>
                </Table.HeaderRow>
            </Table.Header>
            <Table.Body>
                {tableData.map((row) => (
                    <Table.Row key={row.sku}>
                        <Table.Cell>{row.sku}</Table.Cell>
                        <Table.Cell>{row.productName}</Table.Cell>
                        <Table.Cell>{row.productName}</Table.Cell>
                        <Table.Cell>{row.productName}</Table.Cell>
                    </Table.Row>
                ))}
            </Table.Body>
        </Table>
    </div>
);
