import React from "react";

import {toast, Toaster} from "sonner";

import {Snackbar} from "./Snackbar";
import type {SnackbarContent, SnackbarProviderProps, SnackbarState} from "./Snackbar.types";

const SnackbarContext = React.createContext<SnackbarState | null>(null);

export function useSnackbar() {
    return React.useContext(SnackbarContext) as SnackbarState;
}

export function SnackbarProvider({
    children,
    maxVisibleSnackbars = 3,
    placement = "bottom-left",
    expand = false,
}: SnackbarProviderProps) {
    const memoizedState = React.useMemo<SnackbarState>(
        () => ({
            add: (content: SnackbarContent) => {
                return toast.custom((t) => <Snackbar id={t} content={content} />, {
                    dismissible: true,
                    duration: content.timeout || Infinity,
                });
            },
            remove: (id: number) => {
                toast.dismiss(id);
            },
        }),
        [],
    );

    return (
        <SnackbarContext.Provider value={memoizedState}>
            <Toaster visibleToasts={maxVisibleSnackbars} position={placement} expand={expand} />
            {children}
        </SnackbarContext.Provider>
    );
}
