export interface SnackbarContent {
    /** (optional) Represents the title of the snackbar content. */
    title?: string;
    /** (required) Represents the main description of the snackbar content. Can be a multiline text. */
    description: string;
    /** (optional) Represents an array of actions available for the snackbar content.
     * `onClick` callback hides the toast, so you can hide the the default close button by setting `dismissible` to false.
     * Please keep at most 2 actions.
     */
    actions?: Array<{
        /** A callback that will be executed when the action is clicked. Hides the toast by default. */
        onClick: () => void;
        /**  The label or text for the action. Keep it short. */
        label: string;
    }>;
    /** (optional) Set true or false to show/hide a close button. The default is true.  */
    dismissible?: boolean;
    /** (optional) Time in milliseconds that should elapse before automatically closing the snackbar.  */
    timeout?: number;
}

export interface SnackbarState {
    add: (content: SnackbarContent) => number | string;
    remove: (id: number) => void;
}

type SnackbarPlacement = "bottom-left" | "bottom-right" | "bottom-center" | "top-left" | "top-right" | "top-center";

export interface SnackbarProviderProps {
    children: React.ReactNode;
    /** (optional) Configures the placement of the snackbars. Default is "bottom-left". */
    placement?: SnackbarPlacement;
    /** (optional) Maximum of simultaneously visible snackbars. Default is 3. */
    maxVisibleSnackbars?: number;
    /** (optional) Expand snackbar stack by default. */
    expand?: boolean;
}

export interface SnackbarProps {
    id: string | number;
    content: SnackbarContent;
}
