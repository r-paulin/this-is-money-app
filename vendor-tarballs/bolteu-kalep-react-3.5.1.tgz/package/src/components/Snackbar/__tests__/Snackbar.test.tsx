import * as React from "react";

import {vi} from "vitest";
import {act, render, waitFor, waitForElementToBeRemoved} from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import {SnackbarProvider, useSnackbar} from "../index";

console.error = vi.fn(); // Suppress the errors for "The current testing environment is not configured to support act(...)"

describe("Snackbar", () => {
    test("renders snackbar with title and description", async () => {
        function TestComponent() {
            const snackbar = useSnackbar();

            React.useEffect(() => {
                snackbar.add({
                    title: "Test Title",
                    description: "Test Description",
                });
            }, [snackbar]);

            return <div>Hello</div>;
        }

        const {getByText} = render(
            <SnackbarProvider>
                <TestComponent />
            </SnackbarProvider>,
        );

        await act(async () => {
            await waitFor(() => {}); // TODO: For some reason test env needs another tick to render the snackbar
        });

        expect(getByText("Test Title")).toBeInTheDocument();
        expect(getByText("Test Description")).toBeInTheDocument();
    });

    test("render snackbar by clicking on a button", async () => {
        const user = userEvent.setup({delay: null});

        function TestComponent() {
            const snackbar = useSnackbar();

            return (
                <button
                    type="button"
                    onClick={() => {
                        snackbar.add({
                            title: "Test Title",
                            description: "Test Description",
                        });
                    }}
                >
                    Click me
                </button>
            );
        }

        const {queryByText, getByText, getByRole} = render(
            <SnackbarProvider>
                <TestComponent />
            </SnackbarProvider>,
        );

        expect(queryByText("Test Title")).not.toBeInTheDocument();
        expect(queryByText("Test Description")).not.toBeInTheDocument();

        await act(async () => {
            await user.click(getByRole("button", {name: "Click me"}));
        });

        expect(getByText("Test Title")).toBeInTheDocument();
        expect(getByText("Test Description")).toBeInTheDocument();
    });

    test("renders snackbar with actions", async () => {
        function TestComponent() {
            const snackbar = useSnackbar();

            React.useEffect(() => {
                snackbar.add({
                    title: "Test Title",
                    description: "Test Description",
                    actions: [
                        {
                            onClick: () => {},
                            label: "Action 1",
                        },
                        {
                            onClick: () => {},
                            label: "Action 2",
                        },
                    ],
                });
            }, []);

            return null;
        }

        const {getByText} = render(
            <SnackbarProvider>
                <TestComponent />
            </SnackbarProvider>,
        );

        await act(async () => {
            await waitFor(() => {}); // TODO: For some reason test env needs another tick to render the snackbar
        });

        expect(getByText("Action 1")).toBeInTheDocument();
        expect(getByText("Action 2")).toBeInTheDocument();
    });

    test("dismisses snackbar when the close button is clicked", async () => {
        const user = userEvent.setup({delay: null});

        function TestComponent() {
            const snackbar = useSnackbar();

            React.useEffect(() => {
                snackbar.add({
                    title: "Test Title",
                    description: "Test Description",
                    dismissible: true,
                });
            }, []);

            return null;
        }

        const {getByText, queryByText, getByTestId} = render(
            <SnackbarProvider>
                <TestComponent />
            </SnackbarProvider>,
        );

        await act(async () => {
            await waitFor(() => {}); // TODO: For some reason test env needs another tick to render the snackbar
        });

        expect(getByText("Test Title")).toBeInTheDocument();
        expect(getByText("Test Description")).toBeInTheDocument();

        await act(async () => {
            await user.click(getByTestId("snackbar-close-button"));
        });

        await waitForElementToBeRemoved(() => queryByText("Test Title"));
    });

    test("dismisses snackbar when an action is clicked", async () => {
        const user = userEvent.setup({delay: null});

        function TestComponent() {
            const snackbar = useSnackbar();

            React.useEffect(() => {
                snackbar.add({
                    title: "Test Title",
                    description: "Test Description",
                    dismissible: false,
                    actions: [
                        {
                            onClick: () => {},
                            label: "Action 1",
                        },
                    ],
                });
            }, []);

            return null;
        }

        const {getByText, queryByText} = render(
            <SnackbarProvider>
                <TestComponent />
            </SnackbarProvider>,
        );

        await act(async () => {
            await waitFor(() => {}); // TODO: For some reason test env needs another tick to render the snackbar
        });

        expect(getByText("Test Title")).toBeInTheDocument();
        expect(getByText("Test Description")).toBeInTheDocument();

        await act(async () => {
            await user.click(getByText("Action 1"));
        });

        await waitForElementToBeRemoved(() => queryByText("Test Title"));
    });

    test("dismisses snackbar after a timeout", async () => {
        function TestComponent() {
            const snackbar = useSnackbar();

            React.useEffect(() => {
                snackbar.add({
                    title: "Test Title",
                    description: "Test Description",
                    timeout: 1000, // Use shorter timeout for test
                });
            }, []);

            return null;
        }

        const {getByText, queryByText} = render(
            <SnackbarProvider>
                <TestComponent />
            </SnackbarProvider>,
        );

        await act(async () => {
            await waitFor(() => {}); // TODO: For some reason test env needs another tick to render the snackbar
        });

        expect(getByText("Test Title")).toBeInTheDocument();
        expect(getByText("Test Description")).toBeInTheDocument();

        await waitForElementToBeRemoved(() => queryByText("Test Title"), {timeout: 3000});
    });

    test("closes snackbar programmatically", async () => {
        const user = userEvent.setup({delay: null});

        function TestComponent() {
            const snackbar = useSnackbar();
            const [key, setKey] = React.useState<number>(0);

            React.useEffect(() => {
                const msgkey = snackbar.add({
                    title: "Test Title",
                    description: "Test Description",
                });

                setKey(msgkey as number);
            }, []);

            return (
                <button
                    type="button"
                    data-testid="snackbar-close-programmatically-button"
                    onClick={() => {
                        snackbar.remove(key);
                    }}
                >
                    Button
                </button>
            );
        }

        const {getByText, queryByText, getByTestId} = render(
            <SnackbarProvider>
                <TestComponent />
            </SnackbarProvider>,
        );

        await act(async () => {
            await waitFor(() => {}); // TODO: For some reason test env needs another tick to render the snackbar
        });

        expect(getByText("Test Title")).toBeInTheDocument();
        expect(getByText("Test Description")).toBeInTheDocument();

        await act(async () => {
            await user.click(getByTestId("snackbar-close-programmatically-button"));
        });

        await waitForElementToBeRemoved(() => queryByText("Test Title"));
    });

    test("hides the close button if dismissible is false", async () => {
        function TestComponent() {
            const snackbar = useSnackbar();

            React.useEffect(() => {
                snackbar.add({
                    title: "Test Title",
                    description: "Test Description",
                    dismissible: false,
                });
            }, []);

            return null;
        }

        const {getByText, queryByTestId} = render(
            <SnackbarProvider>
                <TestComponent />
            </SnackbarProvider>,
        );

        await act(async () => {
            await waitFor(() => {}); // TODO: For some reason test env needs another tick to render the snackbar
        });

        expect(getByText("Test Title")).toBeInTheDocument();
        expect(getByText("Test Description")).toBeInTheDocument();
        expect(queryByTestId("snackbar-close-button")).not.toBeInTheDocument();
    });
});
