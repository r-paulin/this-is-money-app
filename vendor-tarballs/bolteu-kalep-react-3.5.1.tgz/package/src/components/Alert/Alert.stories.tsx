import * as React from "react";

import type {Meta, StoryFn, StoryObj} from "@storybook/react-webpack5";

import SvgAlert from "@bolteu/kalep-react-icons/dist/Alert";
import SvgLock from "@bolteu/kalep-react-icons/dist/Lock";
import SvgRideStart from "@bolteu/kalep-react-icons/dist/RideStart";

import {cx} from "@/helpers/utils/cx";

import type {AlertProps} from "./index";
import {Alert} from "./index";

export default {
    title: "Feedback/Alert",
    component: Alert,
    tags: ["autodocs"],
    argTypes: {
        icon: {
            options: ["None", "Lock", "Alert", "RideStart"],
            mapping: {
                None: undefined,
                Lock: <SvgLock />,
                Alert: <SvgAlert />,
                Ride: <SvgRideStart />,
            },
        },
    },
} as Meta<typeof Alert>;

export const Default: StoryObj<typeof Alert> = (args: AlertProps) => (
    <div className={cx("flex w-[592px] flex-col gap-3")}>
        <Alert {...args} />
        <Alert>You are a wonderful success story!</Alert>
        <Alert severity="error">Enter a correct username or password.</Alert>
        <Alert severity="info">Passwords should not be written on pieces of paper.</Alert>
        <Alert severity="warning">Be careful what you wish, you just might get it!</Alert>
        <Alert severity="promotion">Experience the ride of your life, for only $9.99.</Alert>
    </div>
);
Default.args = {
    children: "Change this alert!",
    onClose: null as any, // remove the close icon
};

const Template: StoryFn<typeof Alert> = (args: AlertProps) => (
    <div className={cx("w-[592px]")}>
        <Alert {...args} />
    </div>
);

export const WithTitle = Template.bind({});
WithTitle.args = {
    ...Default.args,
    title: "Your Alert",
};

export const Dismissable = Template.bind({});
Dismissable.args = {
    ...Default.args,
    children: "Close this alert!",
    closeButtonAriaLabel: "close alert",
    onClose() {
        alert("Alert was closed!");
    },
};

export const WithAction = (args: AlertProps) => {
    const action = {
        onClick: () => {},
        label: "Stay",
    };

    return (
        <div className={cx("flex w-[592px] flex-col gap-2")}>
            <Alert {...args} action={action}>
                Should I stay or should I go?
            </Alert>
        </div>
    );
};
WithAction.args = {
    ...Default.args,
    closeButtonAriaLabel: "close alert",
    onClose() {
        alert("Alert was closed!");
    },
};
