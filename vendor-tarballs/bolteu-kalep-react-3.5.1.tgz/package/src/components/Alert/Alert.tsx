import * as React from "react";

import AlertIcon from "@bolteu/kalep-react-icons/dist/Alert";
import CheckCircleFill from "@bolteu/kalep-react-icons/dist/CheckCircle";
import Cross from "@bolteu/kalep-react-icons/dist/Cross";
import InfoCircle from "@bolteu/kalep-react-icons/dist/InfoCircle";
import Offer from "@bolteu/kalep-react-icons/dist/Offer";
import type {KalepIcon, KalepIconElement} from "@bolteu/kalep-react-icons/dist/types";

import {GhostButton} from "@/components/GhostButton";
import {useId} from "@/helpers";
import {cx} from "@/helpers/utils/cx";

import type {AlertIconProps, AlertProps, Severity} from "./Alert.types";

const severities: Record<Severity, string> = {
    error: "bg-danger-secondary",
    info: "bg-promo-secondary",
    promotion: "bg-layer-floor-1 border-separator",
    success: "bg-positive-secondary",
    warning: "bg-warning-secondary",
};
const actionColors: Record<Severity, string> = {
    error: "text-danger-primary",
    info: "text-promo-primary",
    promotion: "text-action-primary",
    success: "text-positive-primary",
    warning: "text-primary",
};

export const DEFAULT_CLOSE_BUTTON_ARIA_LABEL = "close notification";

export const Alert = React.forwardRef<HTMLDivElement, AlertProps>(function AlertComponent(
    {
        children,
        action,
        closeButtonAriaLabel = DEFAULT_CLOSE_BUTTON_ARIA_LABEL,
        icon,
        onClose,
        overrideClassName,
        severity = "success",
        title,
    },
    ref,
): JSX.Element {
    const isError = severity === "error";
    const generatedId = useId();
    const contentId = `kalep-alert-content-${generatedId}`;
    const titleId = `kalep-alert-title-${generatedId}`;
    const actionButton = action ? (
        <GhostButton
            overrideClassName={cx("mt-4", "bolt-font-body-m-accent", actionColors[severity])}
            onClick={action.onClick}
        >
            {action.label}
        </GhostButton>
    ) : null;

    return (
        <div
            className={cx(
                "flex w-full gap-4 p-4",
                "rounded-md border border-solid border-transparent" /* transparent border by default for unified look */,
                "items-center",
                "bolt-font-body-s-regular",
                severities[severity],
                overrideClassName,
            )}
            role="region"
            aria-labelledby={cx(title && titleId, contentId)}
            ref={ref}
        >
            <AlertIconWrap icon={icon} severity={severity} />
            <div
                className={cx("flex w-full flex-col items-start gap-2")}
                role={isError ? "alert" : "status"}
                aria-live={isError ? "assertive" : "polite"}
            >
                {title && (
                    <div id={titleId} className={cx("font-semibold text-primary")}>
                        {title}
                    </div>
                )}
                <div id={contentId} className={cx(title ? "text-secondary" : "text-primary")}>
                    {children}
                </div>
                {actionButton}
            </div>
            {onClose && (
                <button
                    className={cx(/* resets */ "cursor-pointer border-none bg-transparent", "mb-auto p-1")}
                    type="button"
                    aria-label={closeButtonAriaLabel}
                    onClick={onClose}
                >
                    <Cross size="xs" className={cx("block")} />
                </button>
            )}
        </div>
    );
});

const iconColors: Record<Severity, string> = {
    error: "text-danger-secondary",
    info: "text-promo-secondary",
    promotion: "text-primary",
    success: "text-action-secondary",
    warning: "text-warning-secondary",
};

function AlertIconWrap({icon: iconProp, severity}: AlertIconProps): KalepIconElement | null {
    if (iconProp === false) {
        return null;
    }

    const commonProps: KalepIcon = {
        "aria-hidden": "true",
        className: "block",
        size: "lg",
    };
    let icon = iconProp;

    if (!icon) {
        switch (severity) {
            case "error":
                icon = <AlertIcon data-testid="alert-error-icon" {...commonProps} />;
                break;
            case "info":
                icon = <InfoCircle data-testid="alert-info-icon" {...commonProps} />;
                break;
            case "success":
                icon = <CheckCircleFill data-testid="alert-success-icon" {...commonProps} />;
                break;
            case "promotion":
                icon = <Offer data-testid="alert-promotion-icon" {...commonProps} />;
                break;
            case "warning":
                icon = <AlertIcon data-testid="alert-warning-icon" {...commonProps} />;
                break;
            default:
                return null;
        }
    }

    return <div className={cx("self-start", iconColors[severity])}>{icon}</div>;
}
