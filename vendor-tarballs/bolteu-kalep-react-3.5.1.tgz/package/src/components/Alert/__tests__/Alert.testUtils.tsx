import * as React from "react";

import type {RenderResult} from "@testing-library/react";
import {render, screen} from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import {Alert} from "../Alert";
import type {AlertProps} from "../Alert.types";

export * from "@testing-library/react";
export {userEvent};

export const defaultProps = {
    children: "You deserve success in your life.",
};

export function renderAlert(
    props: Partial<AlertProps> = {},
): Omit<RenderResult, "rerender"> & {rerender: (newProps?: Partial<AlertProps>) => void} {
    const utils = render(<Alert {...defaultProps} {...props} />);

    function rerender(newProps?: Partial<AlertProps>): void {
        utils.rerender(<Alert {...defaultProps} {...newProps} />);
    }

    return {...utils, rerender};
}

export function getAlert(textContent = defaultProps.children): HTMLElement {
    return screen.getByRole("alert", {name: textContent});
}

export function getStatus(textContent = defaultProps.children): HTMLElement {
    return screen.getByRole("status", {name: textContent});
}
