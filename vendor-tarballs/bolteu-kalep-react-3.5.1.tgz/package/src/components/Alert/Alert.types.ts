import type {KalepIconElement} from "@bolteu/kalep-react-icons/dist/types";

export type Severity = "error" | "warning" | "promotion" | "success" | "info";

export interface AlertProps {
    children: React.ReactNode;
    action?: {
        onClick: () => void;
        label: string;
    };
    closeButtonAriaLabel?: string;
    icon?: KalepIconElement | false;
    onClose?: () => void;
    overrideClassName?: string;
    severity?: Severity;
    title?: string;
}

export interface AlertIconProps {
    icon?: KalepIconElement | false;
    severity: Severity;
}
