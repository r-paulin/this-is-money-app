import * as React from "react";

import {expect} from "storybook/test";

export default {
    title: "Tests/TailwindIntegration",
    tags: ["autodocs"],
};

function sleep(ms: number) {
    return new Promise((resolve) => {
        setTimeout((args) => {
            resolve(args);
        }, ms);
    });
}

/**
 * Helper for creating DOM elements in tests.
 * @param element - e.g "div"
 * @param classList - "flex gap-4"
 * @param attributes - [["type", "button"]]
 * @param innerText - "click here"
 */
function createElement(
    element: string,
    classList: string = "",
    attributes: Array<[string, string]> = [],
    innerText: string = "",
): HTMLElement {
    const el = document.createElement(element);

    if (classList) {
        el.classList.add(...classList.split(" "));
    }

    attributes.forEach(([attr, value]) => el.setAttribute(attr, value));

    if (innerText) {
        el.innerText = innerText;
    }

    return el;
}

const element = document.createElement("div");
element.classList.add("bg-active-action-secondary");
element.innerText = "TEST IN A SHADOW ROOT";

const PREBUILT_KALEP_STYLES = createElement("link", undefined, [
    ["rel", "stylesheet"],
    ["href", "kalep.css"],
]);
const RGB_HOTPINK = "rgb(255, 105, 180)";

// create a "mui-like button"
// load its styles first and then kalep styles.
// expect to break without layers.
export const ResetInLayer = () => {
    const rootRef = React.useRef<HTMLDivElement>(null);

    React.useEffect(() => {
        const shadowRoot = rootRef.current?.attachShadow({mode: "open"});
        shadowRoot?.appendChild(
            createElement("style", undefined, undefined, `.button-style {background: ${RGB_HOTPINK};}`),
        );
        shadowRoot?.appendChild(PREBUILT_KALEP_STYLES);
        shadowRoot?.appendChild(
            createElement("button", "button-style", [["type", "button"]], "This button should have a pink background"),
        );
    }, []);

    return (
        <div>
            This test will fail if the prebuilt <code>kalep.css</code> file does not have the reset styles wrapped in a
            layer.
            <main id="TEST-ResetInLayer" ref={rootRef} />
        </div>
    );
};

ResetInLayer.play = async () => {
    await sleep(1000);

    const host = document.getElementById("TEST-ResetInLayer");
    const button = host?.shadowRoot?.querySelector("button");

    if (button) {
        const backgroundColor = window.getComputedStyle(button).getPropertyValue("background-color");
        await expect(backgroundColor).toBe(RGB_HOTPINK);
    } else {
        // A bit of a silly hack to make it report failure.
        await expect("Not found").toBe("found");
    }
};
