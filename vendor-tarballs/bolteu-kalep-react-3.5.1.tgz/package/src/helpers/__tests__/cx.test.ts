import {vi} from "vitest";

import type * as CxModuleType from '../utils/cx';

type CxModule = typeof CxModuleType;

const originalVersion = process.env.KALEP_VERSION;

async function loadCxModule(options: {version?: string | null} = {}): Promise<CxModule> {
  const {version = null} = options;

  vi.resetModules();

  if (version === null) {
    delete process.env.KALEP_VERSION;
  } else {
    process.env.KALEP_VERSION = version;
  }

  return import('../utils/cx');
}

const customMergeScenarios: Array<[string, string, string]> = [
  ['text colors', 'text-primary', 'text-secondary'],
  ['background colors', 'bg-action-primary', 'bg-active-action-primary'],
  ['border colors', 'border-neutral-primary', 'border-danger-primary'],
  ['font variants', 'bolt-font-heading-l-accent', 'bolt-font-body-s-accent'],
  ['font sizes', 'text-size-inherit', 'text-m'],
  ['letter spacing', 'tracking-body-xs', 'tracking-body-l'],
  ['icon sizes', 'size-icon-s', 'size-icon-m'],
  ['padding (p)', 'p-comp-vr-padding-s', 'p-comp-vr-padding-l'],
  ['padding (px)', 'px-comp-vr-padding-s', 'px-comp-vr-padding-l'],
  ['padding (py)', 'py-comp-vr-padding-s', 'py-comp-vr-padding-l'],
  ['padding (pt)', 'pt-comp-vr-padding-s', 'pt-comp-vr-padding-l'],
  ['padding (pr)', 'pr-comp-vr-padding-s', 'pr-comp-vr-padding-l'],
  ['padding (pb)', 'pb-comp-vr-padding-s', 'pb-comp-vr-padding-l'],
  ['padding (pl)', 'pl-comp-vr-padding-s', 'pl-comp-vr-padding-l'],
  ['min height tokens', 'min-h-comp-s', 'min-h-comp-l'],
  ['z-index tokens', 'z-base', 'z-modal'],
  ['scale tokens', 'scale-100', 'scale-975'],
  ['animation tokens', 'animate-fade-in', 'animate-fade-out'],
];

afterEach(() => {
  vi.resetModules();

  if (originalVersion === undefined) {
    delete process.env.KALEP_VERSION;
  } else {
    process.env.KALEP_VERSION = originalVersion;
  }
});

describe('cx', () => {
  test('always adds the scoping class even when no version is available', async () => {
    const {cx} = await loadCxModule({version: null});

    expect(cx('text-primary')).toBe('__kalep text-primary');
  });

  test('adds a version specific scope when KALEP_VERSION is provided', async () => {
    const version = '5.4.3';
    const versionClass = '__kalep_5_4_3';
    const {cx} = await loadCxModule({version});

    expect(cx('text-primary')).toBe(`__kalep ${versionClass} text-primary`);
  });

  test.each(customMergeScenarios)(
    'prefers the last declaration for %s',
    async (_description, firstClass, secondClass) => {
      const {cx} = await loadCxModule({version: null});

      expect(cx(firstClass, secondClass)).toBe(`__kalep ${secondClass}`);
    },
  );

  test('keeps classes from unrelated groups untouched', async () => {
    const {cx} = await loadCxModule({version: null});

    expect(cx('text-primary', 'bg-action-primary')).toBe('__kalep text-primary bg-action-primary');
  });

  test('only removes the conflicting class while keeping unrelated tokens in order', async () => {
    const {cx} = await loadCxModule({version: null});

    expect(cx('text-primary', 'bg-action-primary', 'text-secondary')).toBe(
      '__kalep bg-action-primary text-secondary',
    );
  });
});
