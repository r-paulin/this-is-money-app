import type {ChangeEvent} from "react";

import {vi} from "vitest";
import {act, renderHook} from "@testing-library/react";

import {useControlledValue} from "..";

afterEach(vi.restoreAllMocks);

test("uses defaultValue when uncontrolled", function initialValue() {
    const defaultValue = "foo";
    const {result} = renderHook(() =>
        useControlledValue({defaultValue, isControlled: false, controlledValue: undefined}),
    );

    expect(result.current.value).toEqual(defaultValue);
});

test("uses controlledValue when controlled", function initialValue() {
    const defaultValue = "foo";
    const controlledValue = "bar";
    const {result} = renderHook(() => useControlledValue({defaultValue, isControlled: true, controlledValue}));

    expect(result.current.value).toEqual(controlledValue);
});

test("value can be changed via setInternalValue when uncontrolled", function changeBySetValue() {
    const defaultValue = "foo";
    const newValue = "bar";
    const {result} = renderHook(() =>
        useControlledValue({defaultValue, isControlled: false, controlledValue: undefined}),
    );

    act(() => result.current.setInternalValue(newValue));

    expect(result.current.value).toEqual(newValue);
});

test("input onChange is propagated when controlled", function changeByOnChange() {
    const defaultValue = "foo";
    const controlledValue = "bar";
    const onChange = vi.fn();
    const changeEvent = {target: {value: "baz"}} as ChangeEvent<HTMLInputElement>;

    const {result} = renderHook(() =>
        useControlledValue({
            defaultValue,
            controlledValue,
            onChange,
            isControlled: true,
        }),
    );

    act(() => result.current.onChange(changeEvent));

    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith(changeEvent);
});

test("show warning when switching from controlled to uncontrolled", function controlledUncontrolledError() {
    const consoleWarnSpy = vi.spyOn(console, "warn").mockImplementation(() => {});

    const {rerender} = renderHook((props) => useControlledValue({...props}), {
        initialProps: {controlledValue: "", defaultValue: "", isControlled: true},
    });

    rerender({controlledValue: "", defaultValue: "", isControlled: false});

    expect(consoleWarnSpy).toHaveBeenCalledTimes(1);
    expect(consoleWarnSpy).toHaveBeenCalledWith(
        "Warning: A component is changing from controlled to uncontrolled state. This is likely caused by the value property being set and unset dynamically, which should not happen. Decide between using a controlled or uncontrolled state for the lifetime of the component.",
    );
});

test("show warning when switching from uncontrolled to controlled", function controlledUncontrolledError() {
    const consoleWarnSpy = vi.spyOn(console, "warn").mockImplementation(() => {});

    const {rerender} = renderHook((props) => useControlledValue({...props}), {
        initialProps: {controlledValue: "", defaultValue: "", isControlled: false},
    });

    rerender({controlledValue: "", defaultValue: "", isControlled: true});

    expect(consoleWarnSpy).toHaveBeenCalledTimes(1);
    expect(consoleWarnSpy).toHaveBeenCalledWith(
        "Warning: A component is changing from uncontrolled to controlled state. This is likely caused by the value property being set and unset dynamically, which should not happen. Decide between using a controlled or uncontrolled state for the lifetime of the component.",
    );
});
