import {filterDataAttributes} from "../utils/props";

test("filterDataAttributes utility should filter data attributes", function call() {
    const props = {
        label: "Foo",
        value: 123,
        "data-x": "x",
        "data-y": 456,
    };

    const result = filterDataAttributes(props);

    expect(result).toStrictEqual({
        "data-x": "x",
        "data-y": 456,
    });
});

test("filterDataAttributes utility should work with empty object", function call() {
    expect(filterDataAttributes({})).toStrictEqual({});
});

test("filterDataAttributes utility should work with no data attributes", function call() {
    const props = {
        label: "Foo",
        value: 123,
    };

    expect(filterDataAttributes(props)).toStrictEqual({});
});

test("filterDataAttributes utility should work with only data attributes", function call() {
    const props = {
        "data-x": "x",
        "data-y": 456,
    };
    expect(filterDataAttributes(props)).toStrictEqual(props);
});
