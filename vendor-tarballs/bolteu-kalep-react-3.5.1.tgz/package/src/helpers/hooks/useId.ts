import {useId as useIdAria} from "@react-aria/utils";

const DEFAULT_ID_PREFIX = "kalep_id__";

export const useId = (prefix: string = DEFAULT_ID_PREFIX) => {
    // TODO: Drop this when we do not want to support React 17 any more
    const id = useIdAria();
    return `${prefix}${id}`;
};
