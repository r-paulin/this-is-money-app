import * as React from "react";

type OnChangeType<T> = (e: React.ChangeEvent<T>) => void;

type UseControlledValueProps<T, R> = {
    isControlled: boolean;
    defaultValue: R;
    controlledValue: R;
    onChange?: OnChangeType<T>;
};

type UseControlledValueResult<T, R> = {
    value: R;
    onChange: OnChangeType<T>;
    setInternalValue: React.Dispatch<React.SetStateAction<R>>;
};

export const useControlledValueWarning = (isControlled: boolean) => {
    const wasControlled = React.useRef<boolean>(isControlled);

    React.useEffect(() => {
        if (wasControlled.current !== isControlled) {
            console.warn(
                isControlled
                    ? "Warning: A component is changing from uncontrolled to controlled state. This is likely caused by the value property being set and unset dynamically, which should not happen. Decide between using a controlled or uncontrolled state for the lifetime of the component."
                    : "Warning: A component is changing from controlled to uncontrolled state. This is likely caused by the value property being set and unset dynamically, which should not happen. Decide between using a controlled or uncontrolled state for the lifetime of the component.",
            );
        }
    }, [isControlled]);
};

export function useControlledValue<T extends HTMLInputElement | HTMLTextAreaElement, R>({
    isControlled,
    controlledValue,
    defaultValue,
    onChange,
}: UseControlledValueProps<T, R>): UseControlledValueResult<T, R> {
    const [stateValue, setValue] = React.useState<R>(defaultValue);
    const value = isControlled ? controlledValue : stateValue;
    useControlledValueWarning(isControlled);

    const handleChange = React.useCallback(
        (e: React.ChangeEvent<T>): void => {
            if (!isControlled) {
                setValue(
                    (typeof value === "boolean"
                        ? (e.target as unknown as HTMLInputElement)?.checked
                        : e.target.value) as unknown as R,
                );
            }

            onChange?.(e);
        },
        [isControlled, onChange, value],
    );

    return {value, onChange: handleChange, setInternalValue: setValue};
}
