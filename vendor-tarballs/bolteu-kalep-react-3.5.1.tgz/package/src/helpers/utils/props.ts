export const filterDataAttributes = (props: Record<string, any>) => {
    return Object.keys(props)
        .filter((key) => key.startsWith("data-"))
        .reduce((accumulator: Record<string, any>, key) => {
            accumulator[key] = props[key];
            return accumulator;
        }, {});
};
