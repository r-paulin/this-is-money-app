/**
 * These modified functions are taken from chroma.js
 * Copyright Gregor Aisch. Licensed under BSD-3-Clause AND Apache-2.0
 * See license text at https://github.com/gka/chroma.js/blob/main/LICENSE
 */

// https://github.com/gka/chroma.js/blob/main/src/io/hex/hex2rgb.js

const RE_HEX = /^#?([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/;
const RE_HEXA = /^#?([A-Fa-f0-9]{8}|[A-Fa-f0-9]{4})$/;

export const hex2rgb = (hex: any): {r: number; g: number; b: number; a: number} => {
    if (hex.match(RE_HEX)) {
        // remove optional leading #
        if (hex.length === 4 || hex.length === 7) {
            hex = hex.substr(1);
        }
        // expand short-notation to full six-digit
        if (hex.length === 3) {
            hex = hex.split("");
            hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
        }
        const u = parseInt(hex, 16);
        const r = u >> 16;
        const g = (u >> 8) & 0xff;
        const b = u & 0xff;
        return {r, g, b, a: 1};
    }

    // match rgba hex format, eg #FF000077
    if (hex.match(RE_HEXA)) {
        if (hex.length === 5 || hex.length === 9) {
            // remove optional leading #
            hex = hex.substr(1);
        }
        // expand short-notation to full eight-digit
        if (hex.length === 4) {
            hex = hex.split("");
            hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2] + hex[3] + hex[3];
        }
        const u = parseInt(hex, 16);
        const r = (u >> 24) & 0xff;
        const g = (u >> 16) & 0xff;
        const b = (u >> 8) & 0xff;
        const a = Math.round(((u & 0xff) / 0xff) * 100) / 100;
        return {r, g, b, a};
    }

    throw new Error(`failed to convert color from hex to rgb: unknown hex color: ${hex}`);
};

// https://github.com/gka/chroma.js/blob/main/src/io/hsl/rgb2hsl.js

export const rgb2hsl = (...args: any[]) => {
    let rgbArr;
    // if not an array, should be object {r, g, b, a?}
    if (Array.isArray(args[0])) {
        [rgbArr] = args;
    } else {
        rgbArr = "rgba"
            .split("")
            .filter((k) => args[0][k] !== undefined)
            .map((k) => args[0][k]);
    }

    let [r, g, b] = rgbArr;

    r /= 255;
    g /= 255;
    b /= 255;

    const min = Math.min(r, g, b);
    const max = Math.max(r, g, b);

    const l = (max + min) / 2;
    let s;
    let h;

    if (max === min) {
        s = 0;
        h = Number.NaN;
    } else {
        s = l < 0.5 ? (max - min) / (max + min) : (max - min) / (2 - max - min);
    }

    if (r === max) {
        h = (g - b) / (max - min);
    } else if (g === max) {
        h = 2 + (b - r) / (max - min);
    } else if (b === max) {
        h = 4 + (r - g) / (max - min);
    }

    if (max === min) {
        h = 0;
    }

    (h as number) *= 60;
    if ((h as number) < 0) {
        (h as number) += 360;
    }
    if (rgbArr.length > 3 && rgbArr[3] !== undefined) {
        return {h, s: s * 100, l: l * 100, a: rgbArr[3]};
    }
    return {h, s: s * 100, l: l * 100};
};
