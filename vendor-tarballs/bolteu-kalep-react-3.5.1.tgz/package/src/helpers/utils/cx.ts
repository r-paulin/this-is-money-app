import clsx from "clsx";
import {extendTailwindMerge} from "tailwind-merge";

const version = process.env.KALEP_VERSION || "";
const versionString = version.split(".").join("_");

// This is referenced in bundled (scoped) CSS file (check: config/scoped/postcss.config.js)
export const scopingClass = ["__kalep", versionString && `__kalep_${versionString}`];

interface ClassDictionary {
    [id: string]: any;
}

interface ClassArray extends Array<ClassValue> {}

export type ClassValue = ClassArray | ClassDictionary | string | number | null | boolean | undefined;

const customTwMerge = extendTailwindMerge({
    extend: {
        classGroups: {
            "text-color": [
                {
                    text: [
                        "tertiary",
                        "static-key-light",
                        "primary",
                        "secondary",
                        "action-primary",
                        "action-secondary",
                        "danger-primary",
                        "danger-secondary",
                        "warning-primary",
                        "warning-secondary",
                        "positive-primary",
                        "positive-secondary",
                        "promo-primary",
                        "promo-secondary",
                        "link-primary",
                        "active-link-primary",
                        "link-secondary",
                        "primary-inverted",
                    ],
                },
            ],
            "bg-color": [
                {
                    bg: [
                        "action-primary",
                        "active-action-primary",
                        "danger-primary",
                        "active-danger-primary",
                        "special-nulled",
                        "special-disabled",
                    ],
                },
            ],
            "border-color": [
                {
                    border: ["neutral-primary", "danger-primary"],
                },
            ],
            // @ts-expect-error FIXME: Tailwind Merge types are not correct
            "font-variant": [
                {
                    "bolt-font": [
                        "heading-l-accent",
                        "heading-m-accent",
                        "heading-s-accent",
                        "heading-xs-accent",
                        "heading-xs-regular",
                        "body-l-regular",
                        "body-l-accent",
                        "body-l-compact-regular",
                        "body-l-compact-accent",
                        "body-m-regular",
                        "body-m-accent",
                        "body-m-compact-regular",
                        "body-m-compact-accent",
                        "body-s-regular",
                        "body-s-accent",
                        "body-s-compact-regular",
                        "body-s-compact-accent",
                        "body-xs-regular",
                        "body-xs-accent",
                        "body-xs-compact-regular",
                        "body-xs-compact-accent",
                        "body-tabular-l-regular",
                        "body-tabular-l-accent",
                        "body-tabular-l-compact-regular",
                        "body-tabular-l-compact-accent",
                        "body-tabular-m-regular",
                        "body-tabular-m-accent",
                        "body-tabular-m-compact-regular",
                        "body-tabular-m-compact-accent",
                        "body-tabular-s-regular",
                        "body-tabular-s-accent",
                        "body-tabular-s-compact-regular",
                        "body-tabular-s-compact-accent",
                        "body-tabular-xs-regular",
                        "body-tabular-xs-accent",
                        "body-tabular-xs-compact-regular",
                        "body-tabular-xs-compact-accent",
                        "caps-l-accent",
                        "caps-m-accent",
                        "caps-s-accent",
                        "display-m-regular",
                    ],
                },
            ],
            "font-size": [
                {
                    text: [
                        "size-inherit",
                        "xs",
                        "xs-compact",
                        "sm",
                        "sm-compact",
                        "base",
                        "m",
                        "m-compact",
                        "lg",
                        "lg-compact",
                        "xl",
                        "2xl",
                        "3xl",
                        "4xl",
                        "5xl",
                        "6xl",
                    ],
                },
            ],
            tracking: [
                {
                    tracking: [
                        "body-xs",
                        "body-xs-tabular",
                        "body-s",
                        "body-s-tabular",
                        "body-m",
                        "body-m-tabular",
                        "body-l",
                        "body-l-tabular",
                    ],
                },
            ],
            size: [
                {
                    size: ["icon-xs", "icon-s", "icon-m"],
                },
            ],
            p: [
                {
                    p: ["comp-vr-padding-s", "comp-vr-padding-m", "comp-vr-padding-l"],
                },
            ],
            px: [
                {
                    px: ["comp-vr-padding-s", "comp-vr-padding-m", "comp-vr-padding-l"],
                },
            ],
            py: [
                {
                    py: ["comp-vr-padding-s", "comp-vr-padding-m", "comp-vr-padding-l"],
                },
            ],
            pt: [
                {
                    pt: ["comp-vr-padding-s", "comp-vr-padding-m", "comp-vr-padding-l"],
                },
            ],
            pr: [
                {
                    pr: ["comp-vr-padding-s", "comp-vr-padding-m", "comp-vr-padding-l"],
                },
            ],
            pb: [
                {
                    pb: ["comp-vr-padding-s", "comp-vr-padding-m", "comp-vr-padding-l"],
                },
            ],
            pl: [
                {
                    pl: ["comp-vr-padding-s", "comp-vr-padding-m", "comp-vr-padding-l"],
                },
            ],
            "min-h": [
                {
                    "min-h": ["comp-s", "comp-m", "comp-l"],
                },
            ],
            z: [
                {
                    z: ["base", "dropdown", "modalOverlay", "modal", "tooltip", "snackbar"],
                },
            ],
            scale: [
                {
                    scale: ["975"],
                },
            ],
            animate: [
                {
                    animate: [
                        "indeterminateProgress",
                        "fade-in",
                        "fade-out",
                        "snackbar",
                        "overlayShow",
                        "overlayHide",
                        "contentShow",
                        "slideInRight",
                        "slideOutRight",
                    ],
                },
            ],
        },
    },
});

export function cx(...classes: ClassValue[]): string {
    return customTwMerge(clsx(scopingClass, classes));
}
