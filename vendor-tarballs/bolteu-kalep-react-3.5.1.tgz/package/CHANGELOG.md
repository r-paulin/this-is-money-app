# @bolteu/kalep-react

## 3.5.1

### Patch Changes

- [#2135](https://github.com/bolteu/kalep/pull/2135) [`06f3f6e`](https://github.com/bolteu/kalep/commit/06f3f6ef0cbda8078d17ae780b22935ecee03682) Thanks [@runewizard](https://github.com/runewizard)! - Add CheckboxIndicator to Combobox component

- [#2134](https://github.com/bolteu/kalep/pull/2134) [`5240c68`](https://github.com/bolteu/kalep/commit/5240c68e0702e2e7073e239455349bc7cc9bbb18) Thanks [@KoitsaluR](https://github.com/KoitsaluR)! - Fix Legacy IconButton Icon sizing

## 3.5.0

### Minor Changes

- [#2108](https://github.com/bolteu/kalep/pull/2108) [`499ffb2`](https://github.com/bolteu/kalep/commit/499ffb255f2926f09d486f36f5e43ed71cdf5245) Thanks [@arturluik](https://github.com/arturluik)! - Add `Autocomplete` component.

  A free-form text input with suggestion support, following the same structure and conventions as `Combobox`. Unlike Combobox, Autocomplete manages a plain string value — there is no selection state, chips, or multi-select.

## 3.4.3

### Patch Changes

- [#2130](https://github.com/bolteu/kalep/pull/2130) [`c99cbee`](https://github.com/bolteu/kalep/commit/c99cbeef682fe2f743315c08ebe97820c346be98) Thanks [@edvardsr](https://github.com/edvardsr)! - Add correct handling for dark icon color replacement

- Updated dependencies [[`c99cbee`](https://github.com/bolteu/kalep/commit/c99cbeef682fe2f743315c08ebe97820c346be98)]:
  - @bolteu/kalep-react-icons@2.6.2

## 3.4.2

### Patch Changes

- [#2124](https://github.com/bolteu/kalep/pull/2124) [`5b83e32`](https://github.com/bolteu/kalep/commit/5b83e32e5ee389aea8f8dc5f75e8edf22647bd5d) Thanks [@edvardsr](https://github.com/edvardsr)! - Fixed the SearchExtra icon

- Updated dependencies [[`5b83e32`](https://github.com/bolteu/kalep/commit/5b83e32e5ee389aea8f8dc5f75e8edf22647bd5d)]:
  - @bolteu/kalep-react-icons@2.6.1

## 3.4.1

### Patch Changes

- [#2123](https://github.com/bolteu/kalep/pull/2123) [`bb38023`](https://github.com/bolteu/kalep/commit/bb38023a8bac03897ef032450c57914cd24331e1) Thanks [@edvardsr](https://github.com/edvardsr)! - Updated icons, added deprecation notices to outdated icons

- Updated dependencies [[`bb38023`](https://github.com/bolteu/kalep/commit/bb38023a8bac03897ef032450c57914cd24331e1)]:
  - @bolteu/kalep-react-icons@2.6.0

## 3.4.0

### Minor Changes

- [#2118](https://github.com/bolteu/kalep/pull/2118) [`2cfc6ed`](https://github.com/bolteu/kalep/commit/2cfc6edb4884b926b06b30118b77d8241f48ea29) Thanks [@runewizard](https://github.com/runewizard)! - Add `multiple` and `readonly` support for Select component

- [#2101](https://github.com/bolteu/kalep/pull/2101) [`5ce85de`](https://github.com/bolteu/kalep/commit/5ce85de96a191ee97976179ec8b912f6168354ca) Thanks [@KoitsaluR](https://github.com/KoitsaluR)! - Implement PasswordInput component

### Patch Changes

- Updated dependencies [[`ef6842c`](https://github.com/bolteu/kalep/commit/ef6842caeed0c6ddf4bb40748accf963569f41e2)]:
  - @bolteu/kalep-tailwind@3.2.0

## 3.3.2

### Patch Changes

- [#2097](https://github.com/bolteu/kalep/pull/2097) [`de47a54`](https://github.com/bolteu/kalep/commit/de47a542eb3ec3fc12c3aec1012e1e5cbecddfd3) Thanks [@libahipi](https://github.com/libahipi)! - Add new heading/display font styles (update design-tokens 2.1.0->2.1.1) - WAVE-280

- Updated dependencies [[`de47a54`](https://github.com/bolteu/kalep/commit/de47a542eb3ec3fc12c3aec1012e1e5cbecddfd3)]:
  - @bolteu/kalep-tailwind@3.1.1

## 3.3.1

### Patch Changes

- [#2087](https://github.com/bolteu/kalep/pull/2087) [`60005d3`](https://github.com/bolteu/kalep/commit/60005d3e10e32fe6dc8e94943377622a2f987ee5) Thanks [@KoitsaluR](https://github.com/KoitsaluR)! - Fix IconButton icon sizing issue.

## 3.3.0

### Minor Changes

- [#2083](https://github.com/bolteu/kalep/pull/2083) [`785f3ae`](https://github.com/bolteu/kalep/commit/785f3aeb578540080682ca774b2e88302f3b26b0) Thanks [@runewizard](https://github.com/runewizard)! - BREAKING CHANGE: `SpinnerIcon` is now internal and no longer exported.
  Refactor direct spinner SVG usage to the internal `SpinnerIcon` component.

### Patch Changes

- [#2085](https://github.com/bolteu/kalep/pull/2085) [`a3563ce`](https://github.com/bolteu/kalep/commit/a3563ce8bbdbc436d32691bfe396dcb0bdd7ed71) Thanks [@runewizard](https://github.com/runewizard)! - Expand Spinner sizes list

## 3.2.4

### Patch Changes

- [#2080](https://github.com/bolteu/kalep/pull/2080) [`7c2a3f2`](https://github.com/bolteu/kalep/commit/7c2a3f2e4abf98ef3601fc8f0d69223559c05248) Thanks [@runewizard](https://github.com/runewizard)! - Fix overlapping Snackbar.Viewport

## 3.2.3

### Patch Changes

- [#2077](https://github.com/bolteu/kalep/pull/2077) [`c7df255`](https://github.com/bolteu/kalep/commit/c7df255e42136de768b2e48e1f8ff00289cdda60) Thanks [@runewizard](https://github.com/runewizard)! - Snackbar fixes

## 3.2.2

### Patch Changes

- [#2071](https://github.com/bolteu/kalep/pull/2071) [`fda7c71`](https://github.com/bolteu/kalep/commit/fda7c71bc6b874c27fb4436d91d5a6699bdcfb23) Thanks [@runewizard](https://github.com/runewizard)! - Accordion disabled item behaviour

- [#2052](https://github.com/bolteu/kalep/pull/2052) [`d13d765`](https://github.com/bolteu/kalep/commit/d13d765de9c3e159e8d99031d9e2fb2ba738dea2) Thanks [@edvardsr](https://github.com/edvardsr)! - Adjust top margin for Alert action button

## 3.2.1

### Patch Changes

- [#2066](https://github.com/bolteu/kalep/pull/2066) [`fdf372d`](https://github.com/bolteu/kalep/commit/fdf372d226a338621a8f17d2f0d1507cea6a1675) Thanks [@runewizard](https://github.com/runewizard)! - Update problematic tw css expression for old version of postcss

## 3.2.0

### Minor Changes

- [#2065](https://github.com/bolteu/kalep/pull/2065) [`dbe01e9`](https://github.com/bolteu/kalep/commit/dbe01e9cbb6afc2cc24cd482f96492152b4b1ecf) Thanks [@runewizard](https://github.com/runewizard)! - Supress downshift issue with refs

- [#2063](https://github.com/bolteu/kalep/pull/2063) [`200bb99`](https://github.com/bolteu/kalep/commit/200bb9952c3b879146b740fa644a5ae88ccd151a) Thanks [@runewizard](https://github.com/runewizard)! - Fix for Combobox render loop

### Patch Changes

- [#2055](https://github.com/bolteu/kalep/pull/2055) [`dfd8644`](https://github.com/bolteu/kalep/commit/dfd8644b9573101bd8bead2db622f9254f588881) Thanks [@arturluik](https://github.com/arturluik)! - WAVE-179: Chip component

## 3.1.0

### Minor Changes

- [#2049](https://github.com/bolteu/kalep/pull/2049) [`85f0c2e`](https://github.com/bolteu/kalep/commit/85f0c2eb1b6222981f8cb1ed770df853b10d605e) Thanks [@runewizard](https://github.com/runewizard)! - Add bunch of BaseUI-based components

## 3.0.2

### Patch Changes

- [#2029](https://github.com/bolteu/kalep/pull/2029) [`bdac16f`](https://github.com/bolteu/kalep/commit/bdac16fe5a00c40baf18be93c84a777f511aceee) Thanks [@KoitsaluR](https://github.com/KoitsaluR)! - Include non-scoped css file to the build

- [#2022](https://github.com/bolteu/kalep/pull/2022) [`a6f5575`](https://github.com/bolteu/kalep/commit/a6f557503c78bdc0a92592563ae349b7ab9f0a32) Thanks [@arturluik](https://github.com/arturluik)! - WAVE-170: Kalep to latest Eslint

- Updated dependencies [[`a6f5575`](https://github.com/bolteu/kalep/commit/a6f557503c78bdc0a92592563ae349b7ab9f0a32)]:
  - @bolteu/kalep-react-icons@2.5.2

## 3.0.1

### Patch Changes

- Updated dependencies [[`8cb1e3f`](https://github.com/bolteu/kalep/commit/8cb1e3f4d3ee1eecd6d287004c95e486b0ed640c), [`ad95b64`](https://github.com/bolteu/kalep/commit/ad95b64dba4eb5b0c22a528bf3b1af58e5fd0f45)]:
  - @bolteu/kalep-tailwind@3.1.0

## 3.0.0

### Major Changes

- [#1985](https://github.com/bolteu/kalep/pull/1985) [`19b356e`](https://github.com/bolteu/kalep/commit/19b356e60aca3d469b3cec836f9bad2821789e03) Thanks [@libahipi](https://github.com/libahipi)! - Updates design-tokens to v2 - setting accessible color theme as the default
  - There is no more "Accessible colors" / "a11y" theme - these are now defaults.
  - The old colorscheme (named Default2024) can be used if needed, but please reach out to #dev-design-system-web-support for help. It is not included by default to save on file size.
  - Bolt Plus no longer exists as a separate theme - Bolt Plus specific tokens are included in the base set.
  - Only semantic colors are available. The new accessible primitive colors palette is not directly available via Tailwind.

  For any web specific questions please reach out to #dev-design-system-web-support
  If you have questiosn about specific color values and/or design-tokens please reach out to #design-system-general

### Patch Changes

- Updated dependencies [[`c3c5c7d`](https://github.com/bolteu/kalep/commit/c3c5c7da4559970ca26aba181a022ece63cfbe7a)]:
  - @bolteu/kalep-tailwind@3.0.0

## 2.1.5

### Patch Changes

- [#1978](https://github.com/bolteu/kalep/pull/1978) [`3e7fa64`](https://github.com/bolteu/kalep/commit/3e7fa646496d161c925608d0df222eb0a9e14fc1) Thanks [@libahipi](https://github.com/libahipi)! - fix: Checked & Disabled Switch should have bg-active-action-secondary background - WAVE-86

## 2.1.4

### Patch Changes

- Updated dependencies [[`6b1f6c2`](https://github.com/bolteu/kalep/commit/6b1f6c2bf1459dc0275d3a4b62b6d0933cde9b13)]:
  - @bolteu/kalep-tailwind@2.2.5

## 2.1.3

### Patch Changes

- [#1966](https://github.com/bolteu/kalep/pull/1966) [`4446e2d`](https://github.com/bolteu/kalep/commit/4446e2d04e06395bfd4c97e9620d02540f60562e) Thanks [@oleksiistavriianov](https://github.com/oleksiistavriianov)! - Allow replacing rendered input area in DatePicker component.

  The customInput allows a custom React component to replace the default input element, enabling complete control over the date field’s appearance and behavior.

  This prop maps directly to the underlying react-datepicker customInput property. Internally react-datepicker will clone the element that you pass here and add a bunch of props to make it work. Check how Kalep's DatePickerInput component works (in Datepicker.tsx).

  What props are passed from react-datepicker: https://github.com/Hacker0x01/react-datepicker/blob/db67a58de2b05d2681bdf0a4977b606095d514c4/src/index.tsx#L1396
  Note that per testing some garbage is passed through as well, so you'll need to intentionally pick props.

## 2.1.2

### Patch Changes

- Updated dependencies [[`95525ea`](https://github.com/bolteu/kalep/commit/95525eae8ae528370d7e2511012160dd43da21e7)]:
  - @bolteu/kalep-react-icons@2.5.1

## 2.1.1

### Patch Changes

- [#1944](https://github.com/bolteu/kalep/pull/1944) [`ab43341`](https://github.com/bolteu/kalep/commit/ab433414537f5d9021c799beaea3971ab2628d73) Thanks [@palgij](https://github.com/palgij)! - Expose BottomSheetProps through Dialog/Drawer components for when useBottomSheet prop is used.
  Also fixed height to display full-height bottom sheets

## 2.1.0

### Minor Changes

- [#1945](https://github.com/bolteu/kalep/pull/1945) [`54a77fe`](https://github.com/bolteu/kalep/commit/54a77fef503c8695cc5222b89173f51a92359e8d) Thanks [@raido](https://github.com/raido)! - Remove PaymentCardField component to avoid falling under PCI-DSS scope.

  Currently this component doesn't seem to be used (based on code search) but in general
  we don't want to have UI components library under PCI-DSS scope as this brings many new requirements.

## 2.0.11

### Patch Changes

- [#1942](https://github.com/bolteu/kalep/pull/1942) [`cd0f631`](https://github.com/bolteu/kalep/commit/cd0f631db749d8a476007241ff7cfdcc55efc1e6) Thanks [@palgij](https://github.com/palgij)! - Fix Dialog alert variant for radix AlertDialogTitle crash

## 2.0.10

### Patch Changes

- [#1938](https://github.com/bolteu/kalep/pull/1938) [`b82ec37`](https://github.com/bolteu/kalep/commit/b82ec370c5da036a47768313cef8f4116c03ec7e) Thanks [@palgij](https://github.com/palgij)! - Fix Dialog/Drawer radix DialogTitle console error and DialogContent warning

## 2.0.9

### Patch Changes

- [#1933](https://github.com/bolteu/kalep/pull/1933) [`c14c5df`](https://github.com/bolteu/kalep/commit/c14c5dff53ec03a0ae9d6ffddf56bb5d2a686d1f) Thanks [@lelumees](https://github.com/lelumees)! - Controlled Menu

## 2.0.8

### Patch Changes

- [#1930](https://github.com/bolteu/kalep/pull/1930) [`88b9580`](https://github.com/bolteu/kalep/commit/88b9580a6420a0a7813ea95a97431f903b45fbd0) Thanks [@libahipi](https://github.com/libahipi)! - fix: remove basic Combobox disabled state bypass - KALEP-842

## 2.0.7

### Patch Changes

- [#1926](https://github.com/bolteu/kalep/pull/1926) [`47fd1c1`](https://github.com/bolteu/kalep/commit/47fd1c1cb6d72ecbeb8cf8c57b55f292f112dffa) Thanks [@libahipi](https://github.com/libahipi)! - fix: add missing heading-l-accent style to Typography component - KALEP-840

## 2.0.6

### Patch Changes

- [#1921](https://github.com/bolteu/kalep/pull/1921) [`55d6ebf`](https://github.com/bolteu/kalep/commit/55d6ebf59c6d14af8b6112f9f1d2ee8d723affc5) Thanks [@lelumees](https://github.com/lelumees)! - Implement exclusive accordion

## 2.0.5

### Patch Changes

- [#1919](https://github.com/bolteu/kalep/pull/1919) [`9c03308`](https://github.com/bolteu/kalep/commit/9c03308e22c7f8dc11ebf7b259cc650f8abd4dd8) Thanks [@lelumees](https://github.com/lelumees)! - Badge: pass through unknown props to the wrapped component. Supports flows where a Badge-wrapped component is given as a custom button to other components. Requested here: https://taxify.slack.com/archives/C034P1EFKDF/p1744637106581869

## 2.0.4

### Patch Changes

- [#1912](https://github.com/bolteu/kalep/pull/1912) [`cc2b6ed`](https://github.com/bolteu/kalep/commit/cc2b6ed98bfac01fdc6350a3ff0e5a4eeaeda71e) Thanks [@lelumees](https://github.com/lelumees)! - Apply hover styles only when hover is supported

## 2.0.3

### Patch Changes

- [#1908](https://github.com/bolteu/kalep/pull/1908) [`6665223`](https://github.com/bolteu/kalep/commit/66652234fff54fddf7e0ca5132295332d08c94d4) Thanks [@lelumees](https://github.com/lelumees)! - Expose portalContainer for Dialog and Drawer to allow nesting them

## 2.0.2

### Patch Changes

- [#1903](https://github.com/bolteu/kalep/pull/1903) [`4f0683f`](https://github.com/bolteu/kalep/commit/4f0683f50702140d00eb6b076e94c92fed081588) Thanks [@palgij](https://github.com/palgij)! - Remove console error for passing menuButton prop for InnerControlledMenu

- [#1901](https://github.com/bolteu/kalep/pull/1901) [`9cdcdc0`](https://github.com/bolteu/kalep/commit/9cdcdc00c548fb99bf4b1b29341574d97f46d34b) Thanks [@libahipi](https://github.com/libahipi)! - feature: allow Simple Table HeaderRow height to grow with content - KALEP-833

- Updated dependencies [[`6b7fd2a`](https://github.com/bolteu/kalep/commit/6b7fd2ac3e3208b39ccde99da0a091e73f60eea5)]:
  - @bolteu/kalep-react-icons@2.5.0

## 2.0.1

### Patch Changes

- [#1899](https://github.com/bolteu/kalep/pull/1899) [`4343d18`](https://github.com/bolteu/kalep/commit/4343d18081663af19a87e26d944e1e4a64a32efe) Thanks [@lelumees](https://github.com/lelumees)! - Fix Pagination per page option select width

## 2.0.0

### Major Changes

- [#1825](https://github.com/bolteu/kalep/pull/1825) [`b5eb74b`](https://github.com/bolteu/kalep/commit/b5eb74b28925c076bb38e506bc10d6a015b2416b) Thanks [@lelumees](https://github.com/lelumees)! - Kalep React version 2
  - Accessible color theme
  - Rehauled floating components with appropriate stacking (z-indexing)
  - Rewritten components - Dialog, Drawer, Tooltip and Snackbar
  - Internal quality improvements and much more

  Note that this release brings breaking changes! ❌ Follow the [migration guide](https://github.com/bolteu/kalep/blob/main/packages/kalep-react/docs/migrations.md#1---2) to ease the upgrading experience.

### Patch Changes

- Updated dependencies [[`eec444d`](https://github.com/bolteu/kalep/commit/eec444d1023c18c7af2c49e756350e516e5febdb)]:
  - @bolteu/kalep-tailwind@2.2.4

## 1.8.22

### Patch Changes

- [#1876](https://github.com/bolteu/kalep/pull/1876) [`3ff8684`](https://github.com/bolteu/kalep/commit/3ff8684332b06153a57f4b78f005b637a53de3bd) Thanks [@caroliina](https://github.com/caroliina)! - Implement borderless Accordion using showSeparator prop

## 1.8.21

### Patch Changes

- Updated dependencies [[`b68f287`](https://github.com/bolteu/kalep/commit/b68f287ddba683bc458aee9ca5ac93aa8ef736ce)]:
  - @bolteu/kalep-tailwind@2.2.3

## 1.8.20

### Patch Changes

- [#1870](https://github.com/bolteu/kalep/pull/1870) [`26909e1`](https://github.com/bolteu/kalep/commit/26909e1cbdbea590592d3d7c0e0d0b4b0f0eeacd) Thanks [@palgij](https://github.com/palgij)! - Use hoverable menu with 0 closing delay.

## 1.8.19

### Patch Changes

- [#1866](https://github.com/bolteu/kalep/pull/1866) [`31f9b4f`](https://github.com/bolteu/kalep/commit/31f9b4ffe69c3e6f55a2c3181c9d3891752027c4) Thanks [@lelumees](https://github.com/lelumees)! - Simplify clear button logic in SearchTextField.

## 1.8.18

### Patch Changes

- [#1852](https://github.com/bolteu/kalep/pull/1852) [`5090934`](https://github.com/bolteu/kalep/commit/5090934a13350ef15da66a7156c864a4b4a5069a) Thanks [@palgij](https://github.com/palgij)! - Fix: Add missing className prop to hoverable menu, which is used for non hoverable menu

## 1.8.17

### Patch Changes

- [#1846](https://github.com/bolteu/kalep/pull/1846) [`dbe64a5`](https://github.com/bolteu/kalep/commit/dbe64a5986ba61150989b0a929a015c49f9c08b1) Thanks [@palgij](https://github.com/palgij)! - New: Menu openOnHover prop to open menu when hovering over menu button.

  as a user i would like to open a menu when hovering with a mouse

## 1.8.16

### Patch Changes

- [#1844](https://github.com/bolteu/kalep/pull/1844) [`2215600`](https://github.com/bolteu/kalep/commit/221560092ba30957a4d723b193438ae17baed96d) Thanks [@libahipi](https://github.com/libahipi)! - fix: correctly color Checkbox SVG graphic with content-tertiary when in disabled state - KALEP-825

## 1.8.15

### Patch Changes

- [#1832](https://github.com/bolteu/kalep/pull/1832) [`d7c2ba1`](https://github.com/bolteu/kalep/commit/d7c2ba1b179feda906e48819f3f2cd2d2216fd30) Thanks [@lelumees](https://github.com/lelumees)! - Improve focus outlines

## 1.8.14

### Patch Changes

- [#1820](https://github.com/bolteu/kalep/pull/1820) [`cfe9be1`](https://github.com/bolteu/kalep/commit/cfe9be1f4648b0a5ba948f7bd83bfd48603c6d0b) Thanks [@lelumees](https://github.com/lelumees)! - Fix Switch BG being black when disabled on mobile devices

## 1.8.13

### Patch Changes

- Updated dependencies [[`7940f23`](https://github.com/bolteu/kalep/commit/7940f23b5ebda1e3bc41d5b4e436825b6be2a896)]:
  - @bolteu/kalep-react-icons@2.4.2

## 1.8.12

### Patch Changes

- [#1813](https://github.com/bolteu/kalep/pull/1813) [`4c40542`](https://github.com/bolteu/kalep/commit/4c40542e33588a4a6eb020f330652b0b56ec1594) Thanks [@lelumees](https://github.com/lelumees)! - Fix: Snackbar state.add and state.remove are now stable

## 1.8.11

### Patch Changes

- [#1812](https://github.com/bolteu/kalep/pull/1812) [`19120d6`](https://github.com/bolteu/kalep/commit/19120d6fc9bc88779b1ba2a752670855d3bf24b8) Thanks [@lelumees](https://github.com/lelumees)! - Responsive Dialog using BottomSheet

- [#1810](https://github.com/bolteu/kalep/pull/1810) [`e0144c6`](https://github.com/bolteu/kalep/commit/e0144c604c7c2f9404dd101cb15dc89df0705959) Thanks [@lelumees](https://github.com/lelumees)! - Responsive Drawer

## 1.8.10

### Patch Changes

- [#1808](https://github.com/bolteu/kalep/pull/1808) [`7a87be7`](https://github.com/bolteu/kalep/commit/7a87be7f842196f16f7b937885e98275f00e7a29) Thanks [@lelumees](https://github.com/lelumees)! - Fix BottomSheet height calculation on mobile

## 1.8.9

### Patch Changes

- [#1805](https://github.com/bolteu/kalep/pull/1805) [`bae389b`](https://github.com/bolteu/kalep/commit/bae389b1e6eb3d40da3f6818b9cd89491b5a4f8e) Thanks [@lelumees](https://github.com/lelumees)! - Fix BottomSheet overflow issue

## 1.8.8

### Patch Changes

- [#1799](https://github.com/bolteu/kalep/pull/1799) [`1982f93`](https://github.com/bolteu/kalep/commit/1982f93eb0b948fd3c08234bf2ae5134a8192deb) Thanks [@lelumees](https://github.com/lelumees)! - Expose new BottomSheet component

## 1.8.7

### Patch Changes

- [#1786](https://github.com/bolteu/kalep/pull/1786) [`9da3b8f`](https://github.com/bolteu/kalep/commit/9da3b8f2779299582029e22a2ea29a0162ccec2d) Thanks [@lelumees](https://github.com/lelumees)! - BottomSheet component implementation

- [#1790](https://github.com/bolteu/kalep/pull/1790) [`14e98b3`](https://github.com/bolteu/kalep/commit/14e98b33ccd9fc875e3f1433ff4c85782dc75c9a) Thanks [@kkirss](https://github.com/kkirss)! - Fix Drawer close button going off-screen when title has a long word

## 1.8.6

### Patch Changes

- [#1787](https://github.com/bolteu/kalep/pull/1787) [`6fd315a`](https://github.com/bolteu/kalep/commit/6fd315aa01dacc99184c6448973467c0c1a323bc) Thanks [@lelumees](https://github.com/lelumees)! - Remove redundant dependencies and unused virtualised table

- [#1768](https://github.com/bolteu/kalep/pull/1768) [`edeb073`](https://github.com/bolteu/kalep/commit/edeb073e418f184530153a80bfc1e24afe157cf2) Thanks [@lelumees](https://github.com/lelumees)! - Fix multiselect Combobox swallowing the first typed character when open after selecting a value

## 1.8.5

### Patch Changes

- Updated dependencies [[`34b9171`](https://github.com/bolteu/kalep/commit/34b91714a7b28627c9189991ab1c51f668aaa254)]:
  - @bolteu/kalep-react-icons@2.4.1

## 1.8.4

### Patch Changes

- [#1761](https://github.com/bolteu/kalep/pull/1761) [`03e1957`](https://github.com/bolteu/kalep/commit/03e195779053dc883a70ef096bb1160d8267aad8) Thanks [@lelumees](https://github.com/lelumees)! - Multiline multiple Combobox

- [#1757](https://github.com/bolteu/kalep/pull/1757) [`98fbb54`](https://github.com/bolteu/kalep/commit/98fbb54c2cf3dd9b5574691794b7eb91a5838cfb) Thanks [@lelumees](https://github.com/lelumees)! - Smaller updates - time limitations for Datepicker and updated typings, Menu divider color update

## 1.8.3

### Patch Changes

- [#1747](https://github.com/bolteu/kalep/pull/1747) [`8e7b2fb`](https://github.com/bolteu/kalep/commit/8e7b2fbda24d4c8184f1874205520f0a50a5d8cc) Thanks [@abhishek97](https://github.com/abhishek97)! - Aria label for ListItemLayout

## 1.8.2

### Patch Changes

- [#1743](https://github.com/bolteu/kalep/pull/1743) [`0cabaf2`](https://github.com/bolteu/kalep/commit/0cabaf2cf30674107d65928d11e38e325a20ad2c) Thanks [@lelumees](https://github.com/lelumees)! - Fix broken internal dependencies

## 1.8.1

### Patch Changes

- [#1741](https://github.com/bolteu/kalep/pull/1741) [`d5263b8`](https://github.com/bolteu/kalep/commit/d5263b85ab0318ecbef897874872cdc326021438) Thanks [@kkirss](https://github.com/kkirss)! - Reorganise Table stories

## 1.8.0

### Minor Changes

- [#1734](https://github.com/bolteu/kalep/pull/1734) [`9fd4bd0`](https://github.com/bolteu/kalep/commit/9fd4bd006e78d939c9f9c6565625ac69cb347790) Thanks [@lelumees](https://github.com/lelumees)! - Roll back bad dependency upgrades

## 1.7.1

### Patch Changes

- [#1719](https://github.com/bolteu/kalep/pull/1719) [`71e45a5`](https://github.com/bolteu/kalep/commit/71e45a5cbefd4b0ce84e21118610fc176fd11375) Thanks [@marekpagel](https://github.com/marekpagel)! - Add xs size support for Chip

## 1.7.0

### Minor Changes

- [#1715](https://github.com/bolteu/kalep/pull/1715) [`08709aa`](https://github.com/bolteu/kalep/commit/08709aab75a782165f6973d23692dfab08e7bbe0) Thanks [@lelumees](https://github.com/lelumees)! - Dependency upgrades

## 1.6.15

### Patch Changes

- [#1711](https://github.com/bolteu/kalep/pull/1711) [`ee95f58`](https://github.com/bolteu/kalep/commit/ee95f58cef7638d4e6a6d38a15e0abcfc2ac04ee) Thanks [@lelumees](https://github.com/lelumees)! - Update neutral border color for Radio and Checkbox

## 1.6.14

### Patch Changes

- [#1712](https://github.com/bolteu/kalep/pull/1712) [`ad21148`](https://github.com/bolteu/kalep/commit/ad211489ade460823db17ffdc6b27ba81d726d43) Thanks [@lelumees](https://github.com/lelumees)! - Internal refactoring

## 1.6.13

### Patch Changes

- [#1705](https://github.com/bolteu/kalep/pull/1705) [`3edbeaf`](https://github.com/bolteu/kalep/commit/3edbeaf4d8ce6f7eeaf786427bef001e97e0cf5e) Thanks [@palgij](https://github.com/palgij)! - Add renderEndSlot prop to Combobox props

## 1.6.12

### Patch Changes

- [#1698](https://github.com/bolteu/kalep/pull/1698) [`96cbd0a`](https://github.com/bolteu/kalep/commit/96cbd0a6632df9ce7d65deef811f69abede6164d) Thanks [@lelumees](https://github.com/lelumees)! - Mixpanel for Kalep React

## 1.6.11

### Patch Changes

- [#1696](https://github.com/bolteu/kalep/pull/1696) [`f453329`](https://github.com/bolteu/kalep/commit/f4533293494c5a379686eddc6b30845730f67191) Thanks [@lelumees](https://github.com/lelumees)! - Add GA to kalep-react

## 1.6.10

### Patch Changes

- [#1691](https://github.com/bolteu/kalep/pull/1691) [`51fd3ea`](https://github.com/bolteu/kalep/commit/51fd3ea296618eac57d883581dd306b1125cb02f) Thanks [@lelumees](https://github.com/lelumees)! - Fix combobox select overlay issue

## 1.6.9

### Patch Changes

- [#1684](https://github.com/bolteu/kalep/pull/1684) [`c80c58a`](https://github.com/bolteu/kalep/commit/c80c58ac8c09d19b04fa9f22fbd81ecb102fcf35) Thanks [@lelumees](https://github.com/lelumees)! - Fix Combobox and Select overlay width and Combobox input delete problems

## 1.6.8

### Patch Changes

- [#1668](https://github.com/bolteu/kalep/pull/1668) [`77fdeb5`](https://github.com/bolteu/kalep/commit/77fdeb51cec49e2680cbf137f6584483c6d6e11f) Thanks [@kmeshavkin](https://github.com/kmeshavkin)! - Fix class for Drawer header font size

## 1.6.7

### Patch Changes

- [#1661](https://github.com/bolteu/kalep/pull/1661) [`99e290a`](https://github.com/bolteu/kalep/commit/99e290af27d3199e39a74f60cc1900be7cf13135) Thanks [@libahipi](https://github.com/libahipi)! - feature: add support for mirroring supported icons in RTL mode

- Updated dependencies [[`9e84051`](https://github.com/bolteu/kalep/commit/9e84051448b37affaa84c1e39a530144aa46399f), [`099e015`](https://github.com/bolteu/kalep/commit/099e015df14557f956619944b6dcbe33c72a291e)]:
  - @bolteu/kalep-react-icons@2.4.0
  - @bolteu/kalep-tailwind@2.2.2

## 1.6.6

### Patch Changes

- [#1657](https://github.com/bolteu/kalep/pull/1657) [`93c5e3b`](https://github.com/bolteu/kalep/commit/93c5e3b308fa061ce710b322c6688c94e63c4aeb) Thanks [@lelumees](https://github.com/lelumees)! - Fix Link in RTL (make it inline again)

## 1.6.5

### Patch Changes

- [#1655](https://github.com/bolteu/kalep/pull/1655) [`da2dbce`](https://github.com/bolteu/kalep/commit/da2dbceecf69beba122a3eeb7845eabf0f3d8c7d) Thanks [@lelumees](https://github.com/lelumees)! - Fix forwarded ref fallbacks in all kalep react components

## 1.6.4

### Patch Changes

- [#1651](https://github.com/bolteu/kalep/pull/1651) [`b55aee4`](https://github.com/bolteu/kalep/commit/b55aee4e0544f210cf4d6481d5b8c6c2a0c1cfac) Thanks [@caroliina](https://github.com/caroliina)! - Datepicker supports custom renderers for input start and end slots

## 1.6.3

### Patch Changes

- [#1647](https://github.com/bolteu/kalep/pull/1647) [`6ec47ae`](https://github.com/bolteu/kalep/commit/6ec47ae28e8f70a2b61e48be51284b9affaf713e) Thanks [@lelumees](https://github.com/lelumees)! - RTL support (fixes) for the most used components

## 1.6.2

### Patch Changes

- [#1643](https://github.com/bolteu/kalep/pull/1643) [`b410f6b`](https://github.com/bolteu/kalep/commit/b410f6bdf7fc87240681e833023a3515a707afea) Thanks [@lelumees](https://github.com/lelumees)! - Change GhostButton overrideClassName priority to fix issues in Combobox

## 1.6.1

### Patch Changes

- [#1639](https://github.com/bolteu/kalep/pull/1639) [`fc9061e`](https://github.com/bolteu/kalep/commit/fc9061e61b1887f3d7c27f63d0f5428aa761b49f) Thanks [@lelumees](https://github.com/lelumees)! - Make Snackbar responsive

## 1.6.0

### Minor Changes

- [#1594](https://github.com/bolteu/kalep/pull/1594) [`173d160`](https://github.com/bolteu/kalep/commit/173d1605acad237368b9acd889b290100190fd1a) Thanks [@libahipi](https://github.com/libahipi)! - feature: Customizable width for Drawer and Dialog

  Drawer `size` prop has been expanded with "custom" value, for Dialog a new optional prop `size` with a single allowed value "custom".
  In both components passing `size="custom"` has the effect of the component not enforcing a width on its own (up to max-width of `calc(100vw - 1rem)`).
  This enables you to define the desired width on the content area, if there's enough room, the component will respect this width. If not the component will visually take as much as possible and content area starts scrolling horizontally.

  It is still advised to stick with the default sizings.
  You can observe these custom width scenarios in Storybook for both Dialog and Drawer in their respective stories.

  ***

  Additionally this version drops the previously deprecated prop `experimentalOverflowVisible` from Dialog.

### Patch Changes

- Updated dependencies [[`7b747e8`](https://github.com/bolteu/kalep/commit/7b747e8e7d6421ac0cd394379477d7033b51605e)]:
  - @bolteu/kalep-tailwind@2.2.1

## 1.5.2

### Patch Changes

- [#1618](https://github.com/bolteu/kalep/pull/1618) [`104aa37`](https://github.com/bolteu/kalep/commit/104aa37f198600c544e3ed24eab3fe5cf12d0e82) Thanks [@lelumees](https://github.com/lelumees)! - Updated and fixed Snackbar

## 1.5.1

### Patch Changes

- [#1605](https://github.com/bolteu/kalep/pull/1605) [`06de1da9828648a194ad65612bd7753fd2a2af2d`](https://github.com/bolteu/kalep/commit/06de1da9828648a194ad65612bd7753fd2a2af2d) Thanks [@libahipi](https://github.com/libahipi)! - feature: add className prop support to Island component

- [#1609](https://github.com/bolteu/kalep/pull/1609) [`8faad98ea90b8edf9d2720752b5ca5476d62e354`](https://github.com/bolteu/kalep/commit/8faad98ea90b8edf9d2720752b5ca5476d62e354) Thanks [@libahipi](https://github.com/libahipi)! - fix: static-light button variant disabled referenced incorrect tailwind text color class - KALEP-711

- Updated dependencies [[`dbf9e5f4d58f3ad678edbab1c38a309409889706`](https://github.com/bolteu/kalep/commit/dbf9e5f4d58f3ad678edbab1c38a309409889706)]:
  - @bolteu/kalep-react-icons@2.3.0

## 1.5.0

### Minor Changes

- [#1596](https://github.com/bolteu/kalep/pull/1596) [`715c3a59b58d30169c9a6df456ac05def9f34e71`](https://github.com/bolteu/kalep/commit/715c3a59b58d30169c9a6df456ac05def9f34e71) Thanks [@libahipi](https://github.com/libahipi)! - feature: Change font styles heading-{size} to heading-{size}-accent

### Patch Changes

- [#1590](https://github.com/bolteu/kalep/pull/1590) [`e9ca60f0bf9e4a626857933fe4c35f7186b335ac`](https://github.com/bolteu/kalep/commit/e9ca60f0bf9e4a626857933fe4c35f7186b335ac) Thanks [@ch-ms](https://github.com/ch-ms)! - Xl drawer width added (736px)

- [#1596](https://github.com/bolteu/kalep/pull/1596) [`beed7aabe77a99a0814052a9181eaa36196a9b59`](https://github.com/bolteu/kalep/commit/beed7aabe77a99a0814052a9181eaa36196a9b59) Thanks [@libahipi](https://github.com/libahipi)! - feature: add caps font styles to Typography component - UI-168

- Updated dependencies [[`a21526e8b2d27e095b560d1dcc7a68076d525ab7`](https://github.com/bolteu/kalep/commit/a21526e8b2d27e095b560d1dcc7a68076d525ab7)]:
  - @bolteu/kalep-tailwind@2.2.0

## 1.4.3

### Patch Changes

- [#1589](https://github.com/bolteu/kalep/pull/1589) [`abb056ba6166fc9b1d60e47309e5ec1ea4532b99`](https://github.com/bolteu/kalep/commit/abb056ba6166fc9b1d60e47309e5ec1ea4532b99) Thanks [@libahipi](https://github.com/libahipi)! - fix: Apply minimum width to Grid columns, avoid issues with it being set to min-content automatically

## 1.4.2

### Patch Changes

- [#1533](https://github.com/bolteu/kalep/pull/1533) [`71617375a889c9702fe761fd77b6815977a20e81`](https://github.com/bolteu/kalep/commit/71617375a889c9702fe761fd77b6815977a20e81) Thanks [@flygerian](https://github.com/flygerian)! - Exposing the Table component, so it it's primitives can be used downstream

## 1.4.1

### Patch Changes

- [#1523](https://github.com/bolteu/kalep/pull/1523) [`fb20488de3373ad9b7e939ebc7f8cd6f72727979`](https://github.com/bolteu/kalep/commit/fb20488de3373ad9b7e939ebc7f8cd6f72727979) Thanks [@CountryTk](https://github.com/CountryTk)! - Fix z-index issue in combobox clear button

## 1.4.0

### Minor Changes

- [#1491](https://github.com/bolteu/kalep/pull/1491) [`027346aa62539d96f90142628a33e6dd2cb8bdc8`](https://github.com/bolteu/kalep/commit/027346aa62539d96f90142628a33e6dd2cb8bdc8) Thanks [@libahipi](https://github.com/libahipi)! - feature: new font: Inter, new font styles from design system

  Fully leverage UI Foundation / Fonts - https://www.figma.com/design/gM8bsTnkACiIWiuAsFTdyI/UI-Foundation---Fonts?node-id=9183-0&t=isUbiobaVKaUby5t-0
  All the styles from there are available as tailwind classes and nearly all text styling should be done with them.

  Typography component supports all the described styles in its variant prop.

### Patch Changes

- Updated dependencies [[`96a8798e8ea4acfdab06dd6322882f53c3f5efac`](https://github.com/bolteu/kalep/commit/96a8798e8ea4acfdab06dd6322882f53c3f5efac)]:
  - @bolteu/kalep-tailwind@2.1.0

## 1.3.1

### Patch Changes

- [#1512](https://github.com/bolteu/kalep/pull/1512) [`2d6a25a3a1b6e44441364aec6adb83d8bfc21044`](https://github.com/bolteu/kalep/commit/2d6a25a3a1b6e44441364aec6adb83d8bfc21044) Thanks [@libahipi](https://github.com/libahipi)! - fix: Apply bg-floor-3 to Select and Combobox dropdowns - KALEP-704

- [#1512](https://github.com/bolteu/kalep/pull/1512) [`4204b5b3668a256f25bc10d736559e1305f36a74`](https://github.com/bolteu/kalep/commit/4204b5b3668a256f25bc10d736559e1305f36a74) Thanks [@libahipi](https://github.com/libahipi)! - fix: measure Select and Combobox width inside Dialog for correct dropdown sizing - KALEP-703

## 1.3.0

### Minor Changes

- [#1478](https://github.com/bolteu/kalep/pull/1478) [`9ae1e0df4cf8bbd728a81ca6caef9b2c0650cc30`](https://github.com/bolteu/kalep/commit/9ae1e0df4cf8bbd728a81ca6caef9b2c0650cc30) Thanks [@KoitsaluR](https://github.com/KoitsaluR)! - React 18, Storybook 8 upgrade

### Patch Changes

- Updated dependencies [[`9ae1e0df4cf8bbd728a81ca6caef9b2c0650cc30`](https://github.com/bolteu/kalep/commit/9ae1e0df4cf8bbd728a81ca6caef9b2c0650cc30)]:
  - @bolteu/kalep-react-icons@2.2.1

## 1.2.10

### Patch Changes

- [#1421](https://github.com/bolteu/kalep/pull/1421) [`ce81c73b`](https://github.com/bolteu/kalep/commit/ce81c73b61f62ea0795483d9350c7fe86b21fe5d) Thanks [@libahipi](https://github.com/libahipi)! - fix: remove background clipping and vertical paddings from MultipleCombobox trigger

## 1.2.9

### Patch Changes

- [#1415](https://github.com/bolteu/kalep/pull/1415) [`b738ef1b`](https://github.com/bolteu/kalep/commit/b738ef1b42ad830b6b1a4229eecae31db33daa97) Thanks [@libahipi](https://github.com/libahipi)! - fix: multiple selection Combobox selection chips handling in small sizes - KALEP-697

* [#1415](https://github.com/bolteu/kalep/pull/1415) [`78248b5a`](https://github.com/bolteu/kalep/commit/78248b5acab9d1b19a4bae2043c2677b070cbce3) Thanks [@libahipi](https://github.com/libahipi)! - fix: Align Select horizontal paddings for small size with others

## 1.2.8

### Patch Changes

- [#1394](https://github.com/bolteu/kalep/pull/1394) [`1b5a0693`](https://github.com/bolteu/kalep/commit/1b5a0693d76c000662e6fce741fee45f897738d8) Thanks [@libahipi](https://github.com/libahipi)! - fix: show background color under border in Select

## 1.2.7

### Patch Changes

- [#1387](https://github.com/bolteu/kalep/pull/1387) [`b1483e42`](https://github.com/bolteu/kalep/commit/b1483e429d6aaf060c65c1729f238c508afb1aa9) Thanks [@Zip753](https://github.com/Zip753)! - Add secondary text to SelectOption and its usages

## 1.2.6

### Patch Changes

- [#1377](https://github.com/bolteu/kalep/pull/1377) [`17d3edad`](https://github.com/bolteu/kalep/commit/17d3edad8ab4ab9ae44e7c7837664db934e99b01) Thanks [@lelumees](https://github.com/lelumees)! - Testability improvements

* [#1388](https://github.com/bolteu/kalep/pull/1388) [`15677ae1`](https://github.com/bolteu/kalep/commit/15677ae178b3843006b55635d69b0f0632d1b5d7) Thanks [@lelumees](https://github.com/lelumees)! - Fix MultiSelect blur double selection issue on mobile devices

## 1.2.5

### Patch Changes

- [#1381](https://github.com/bolteu/kalep/pull/1381) [`78fc62a6`](https://github.com/bolteu/kalep/commit/78fc62a69a92e23728864fe0497f50df86f0cde6) Thanks [@lelumees](https://github.com/lelumees)! - Fix combobox scaling inside display grid

## 1.2.4

### Patch Changes

- Updated dependencies [[`3b7aeaf2`](https://github.com/bolteu/kalep/commit/3b7aeaf26388b0f915d2c37d6d9ebd316b355b18)]:
  - @bolteu/kalep-react-icons@2.2.0

## 1.2.3

### Patch Changes

- [#1375](https://github.com/bolteu/kalep/pull/1375) [`ef28e8b3`](https://github.com/bolteu/kalep/commit/ef28e8b36ec787456b741b95e90820f362add94c) Thanks [@CountryTk](https://github.com/CountryTk)! - Add maxWidth property to Select and Combobox and rename width to minWidth

## 1.2.2

### Patch Changes

- [#1368](https://github.com/bolteu/kalep/pull/1368) [`d99aa35a`](https://github.com/bolteu/kalep/commit/d99aa35af3dc5360963f21fb7082fd237cdfbfee) Thanks [@lelumees](https://github.com/lelumees)! - Select and Combobox fixes and improvements

* [#1371](https://github.com/bolteu/kalep/pull/1371) [`7d655c09`](https://github.com/bolteu/kalep/commit/7d655c09cddcfa4cc3a26a49d16a202259af650c) Thanks [@lelumees](https://github.com/lelumees)! - Fix overflow issue under combobox start slot

- [#1370](https://github.com/bolteu/kalep/pull/1370) [`a6a0d007`](https://github.com/bolteu/kalep/commit/a6a0d007f611519917c0ba024cd01a8bd8453ffd) Thanks [@lelumees](https://github.com/lelumees)! - Fix scroll position initialisation for select and combobox virtualised options

## 1.2.1

### Patch Changes

- [#1363](https://github.com/bolteu/kalep/pull/1363) [`460d09d5`](https://github.com/bolteu/kalep/commit/460d09d5f15b66c13e71afd0baefa95bc96f86cf) Thanks [@lelumees](https://github.com/lelumees)! - Fixes to Select and Combobox

## 1.2.0

### Minor Changes

- [#1277](https://github.com/bolteu/kalep/pull/1277) [`c93bf3f2`](https://github.com/bolteu/kalep/commit/c93bf3f2a973d450919d68a36d31961c99e9e57e) Thanks [@lelumees](https://github.com/lelumees)! - New Select
  - Multiline Select layout
  - Enhanced label
  - Added clear button
  - Read-only version
  - Selected value rendered as chips inside multiple select trigger
  - Redundant properties were dropped ❌ BREAKING ❌
  - Lots of internal improvements

  New Combobox
  - Enhanced label
  - Read-only version
  - Selected value rendered as chips inside multiple combobox trigger
  - Redundant properties were dropped ❌ BREAKING ❌
  - Lots of internal improvements

## 1.1.62

### Patch Changes

- Updated dependencies [[`3c528e3a`](https://github.com/bolteu/kalep/commit/3c528e3a6fae95f1d3ce0aec408086e5dae4e593)]:
  - @bolteu/kalep-tailwind@2.0.2

## 1.1.61

### Patch Changes

- Updated dependencies [[`1e558b6a`](https://github.com/bolteu/kalep/commit/1e558b6aa6ff44f4bd522e2b78d80827239ccaa5)]:
  - @bolteu/kalep-tailwind@2.0.1

## 1.1.60

### Patch Changes

- [#1346](https://github.com/bolteu/kalep/pull/1346) [`21ab1635`](https://github.com/bolteu/kalep/commit/21ab1635b9a72a0380006a03aaa1f33cdfc0992c) Thanks [@eugenekovaljov](https://github.com/eugenekovaljov)! - Drawer with responsive width

- Updated dependencies [[`e651bb3b`](https://github.com/bolteu/kalep/commit/e651bb3bac137f69e875dae2d526b7b8ecc9417f)]:
  - @bolteu/kalep-tailwind@2.0.0

## 1.1.59

### Patch Changes

- Updated dependencies [[`e7cdd42b`](https://github.com/bolteu/kalep/commit/e7cdd42b0fba3a1d5025de7fe1197283d2ca87d9)]:
  - @bolteu/kalep-react-icons@2.1.1

## 1.1.58

### Patch Changes

- Updated dependencies [[`01a100e4`](https://github.com/bolteu/kalep/commit/01a100e40962e7a3ba14806f0f12a0ae0c9eae12)]:
  - @bolteu/kalep-react-icons@2.1.0

## 1.1.57

### Patch Changes

- [#1331](https://github.com/bolteu/kalep/pull/1331) [`16c33ee5`](https://github.com/bolteu/kalep/commit/16c33ee5ee0db0733fd47db71fbd5254e53b9853) Thanks [@lelumees](https://github.com/lelumees)! - Borderless and static Chip, using new props: borderless, noHover

## 1.1.56

### Patch Changes

- [#1337](https://github.com/bolteu/kalep/pull/1337) [`f65df189`](https://github.com/bolteu/kalep/commit/f65df189fcec92a06cd73225b408a88d645bf856) Thanks [@lelumees](https://github.com/lelumees)! - Small Tabs

* [#1334](https://github.com/bolteu/kalep/pull/1334) [`dc8cbe47`](https://github.com/bolteu/kalep/commit/dc8cbe474fc33c8dc12f8db76ff00ccf8f4c2fa9) Thanks [@lelumees](https://github.com/lelumees)! - Helpertext for Radio Group

## 1.1.55

### Patch Changes

- [#1308](https://github.com/bolteu/kalep/pull/1308) [`dac7f6c1`](https://github.com/bolteu/kalep/commit/dac7f6c11d5cc25745c459f31fdc01d47c3417c4) Thanks [@CountryTk](https://github.com/CountryTk)! - Add new SpacingValue variant - 1.5

## 1.1.54

### Patch Changes

- [#1302](https://github.com/bolteu/kalep/pull/1302) [`dcb335df`](https://github.com/bolteu/kalep/commit/dcb335dfcf5bae6ea50106bae514f585117cae44) Thanks [@burakozdemir32](https://github.com/burakozdemir32)! - Kalep:
  - BaseModal Prevents Scroll When Visible

  WTK:
  - Update Navigation Components To Use BaseModal

## 1.1.53

### Patch Changes

- [#1289](https://github.com/bolteu/kalep/pull/1289) [`6e72ead1`](https://github.com/bolteu/kalep/commit/6e72ead16b9825435f475991be70e54b6b3feefc) Thanks [@lelumees](https://github.com/lelumees)! - Radio field types fix - number not allowed as value

## 1.1.52

### Patch Changes

- [#1280](https://github.com/bolteu/kalep/pull/1280) [`582e2b26`](https://github.com/bolteu/kalep/commit/582e2b266a1e5f3d462aca18811b582e29741e80) Thanks [@lelumees](https://github.com/lelumees)! - Update Tailwind

- Updated dependencies [[`582e2b26`](https://github.com/bolteu/kalep/commit/582e2b266a1e5f3d462aca18811b582e29741e80)]:
  - @bolteu/kalep-tailwind@1.1.0

## 1.1.51

### Patch Changes

- [#1275](https://github.com/bolteu/kalep/pull/1275) [`a2512334`](https://github.com/bolteu/kalep/commit/a2512334a7739892c6960c4ad22b6661cfad4d7e) Thanks [@burakozdemir32](https://github.com/burakozdemir32)! - Make Upload Area Labels Customisable

- Updated dependencies [[`b34cf862`](https://github.com/bolteu/kalep/commit/b34cf86226d290d8d01a2639da76837d0552132d)]:
  - @bolteu/kalep-react-icons@2.0.0

## 1.1.50

### Patch Changes

- [#1268](https://github.com/bolteu/kalep/pull/1268) [`482ae82a`](https://github.com/bolteu/kalep/commit/482ae82a9e6b60f7641fb95879f91d0dbbbf867f) Thanks [@CountryTk](https://github.com/CountryTk)! - Add a prop to control combobox dropdown conditionally

## 1.1.49

### Patch Changes

- [#1266](https://github.com/bolteu/kalep/pull/1266) [`03063aed`](https://github.com/bolteu/kalep/commit/03063aeddc8e473e6a26bad5fe23079fa957c578) Thanks [@CountryTk](https://github.com/CountryTk)! - Add extra customisation for combobox - add render start slot icon prop and make chevron render controlled by another prop

## 1.1.48

### Patch Changes

- [#1264](https://github.com/bolteu/kalep/pull/1264) [`045d9746`](https://github.com/bolteu/kalep/commit/045d97467be039df930424073ee634d0e2dc347e) Thanks [@lelumees](https://github.com/lelumees)! - Fix IconView color property when used w/o Tailwind

## 1.1.47

### Patch Changes

- [#1214](https://github.com/bolteu/kalep/pull/1214) [`a35b1f3f`](https://github.com/bolteu/kalep/commit/a35b1f3f96c286f8a2da05fc1b1e579ed8552600) Thanks [@lelumees](https://github.com/lelumees)! - Downshift upgrade - Select and Combobox internal updates

## 1.1.46

### Patch Changes

- Updated dependencies [[`4c0a87e3`](https://github.com/bolteu/kalep/commit/4c0a87e3d9c2049c077bfd2ece1dc0db22de2acf)]:
  - @bolteu/kalep-react-icons@1.2.1

## 1.1.45

### Patch Changes

- [#1253](https://github.com/bolteu/kalep/pull/1253) [`6ce11096`](https://github.com/bolteu/kalep/commit/6ce11096af13669f88e7042bca21bc37977c0c3b) Thanks [@CountryTk](https://github.com/CountryTk)! - Feature: Add overscroll: none behaviour to BaseSelect to improve UX

* [#1251](https://github.com/bolteu/kalep/pull/1251) [`858382a1`](https://github.com/bolteu/kalep/commit/858382a1c80edfb28e3dfe67a0f728de331ba2f1) Thanks [@libahipi](https://github.com/libahipi)! - fix: Long single word filenames will not break UploadAttachments UI any more - KALEP-656

## 1.1.44

### Patch Changes

- [#1208](https://github.com/bolteu/kalep/pull/1208) [`3c088588`](https://github.com/bolteu/kalep/commit/3c0885884911016c6e8eab9437a9f2d07ee77b40) Thanks [@lelumees](https://github.com/lelumees)! - Tooltip - complete rewrite to make it more reliable

  !!! BREAKING CHANGES to the API - closeOnActivation is removed, the default behaviour remains the same
  - Fixes various positioning issues, including the arrow mispositioning in Dialogs
  - Uses react-aria-components instead of react-aria hooks underneath

## 1.1.43

### Patch Changes

- Updated dependencies [[`600f1f94`](https://github.com/bolteu/kalep/commit/600f1f946723b073cf95a4ecbdfbb1ce9e6db747)]:
  - @bolteu/kalep-react-icons@1.2.0

## 1.1.42

### Patch Changes

- [#1173](https://github.com/bolteu/kalep/pull/1173) [`ba5b7cda`](https://github.com/bolteu/kalep/commit/ba5b7cdaa10fea1d663fe48a01fb22ab083deee8) Thanks [@libahipi](https://github.com/libahipi)! - fix: add ForwardRef to Link

* [#1173](https://github.com/bolteu/kalep/pull/1173) [`ba5b7cda`](https://github.com/bolteu/kalep/commit/ba5b7cdaa10fea1d663fe48a01fb22ab083deee8) Thanks [@libahipi](https://github.com/libahipi)! - Add Menu package re-exports from underlying library

## 1.1.41

### Patch Changes

- [#1138](https://github.com/bolteu/kalep/pull/1138) [`98741621`](https://github.com/bolteu/kalep/commit/98741621453b98db117f86f73194687fc0a421bb) Thanks [@lelumees](https://github.com/lelumees)! - Add default rel="noopener noreferrer" to external links

## 1.1.40

### Patch Changes

- [#1144](https://github.com/bolteu/kalep/pull/1144) [`ebe11659`](https://github.com/bolteu/kalep/commit/ebe11659c4aef2db4d4357bb543ffe2246424aa9) Thanks [@lelumees](https://github.com/lelumees)! - Make TextArea respect rows parameter

## 1.1.39

### Patch Changes

- [#1140](https://github.com/bolteu/kalep/pull/1140) [`50244395`](https://github.com/bolteu/kalep/commit/502443950fbff80f429ec08edbc7851a7ba0a74d) Thanks [@lelumees](https://github.com/lelumees)! - Allow TextArea to resize only vertically

## 1.1.38

### Patch Changes

- [#1110](https://github.com/bolteu/kalep/pull/1110) [`cfad4122`](https://github.com/bolteu/kalep/commit/cfad41227807ae9d1b141a1d4d2c1885a7e0baf2) Thanks [@lelumees](https://github.com/lelumees)! - Fix: Combobox scrolls to highlighted item when operated using arrows

* [#1124](https://github.com/bolteu/kalep/pull/1124) [`9f2a199b`](https://github.com/bolteu/kalep/commit/9f2a199b6bb7392f6fc220edd1fc2cc0207a697f) Thanks [@libahipi](https://github.com/libahipi)! - fix: ensure that up to date onRequestClose is used in cancel event handler in Dialog

  This allows onRequestClose to be dependent on other state. E.g a usecase of Dialog main action triggering
  an async action. Then consumer could make the button be in loading state and block closing the Dialog (via onRequestClose)
  while the async action is processing.

  NB! Consumer should _never_ rely on the user being unable to close the Dialog prematurely. This feature can be a nice to have
  but should not be relied on for important flows.

## 1.1.37

### Patch Changes

- [#1129](https://github.com/bolteu/kalep/pull/1129) [`66eaa34f`](https://github.com/bolteu/kalep/commit/66eaa34f21e8c002343aeb80d8864530b5550d50) Thanks [@lelumees](https://github.com/lelumees)! - Improved badge - fixes for positioning and stroke, optional stroke usage

## 1.1.36

### Patch Changes

- [#1091](https://github.com/bolteu/kalep/pull/1091) [`8c086d3b`](https://github.com/bolteu/kalep/commit/8c086d3b5a39c7df80e10509ae650c40a90362ac) Thanks [@CountryTk](https://github.com/CountryTk)! - Remove document.body from tooltip because it's included by default in react-aria library and it handles document not being defined for SSR usecases

## 1.1.35

### Patch Changes

- [#1089](https://github.com/bolteu/kalep/pull/1089) [`5669d727`](https://github.com/bolteu/kalep/commit/5669d727e91694fea959f2985680e576162d450e) Thanks [@libahipi](https://github.com/libahipi)! - fix: Add exports for predefined ranges types in Datepicker - KALEP-614

## 1.1.34

### Patch Changes

- [#1068](https://github.com/bolteu/kalep/pull/1068) [`d32702a8`](https://github.com/bolteu/kalep/commit/d32702a830875afc349039a3088f502428cc9ed1) Thanks [@libahipi](https://github.com/libahipi)! - fix: clarify behavior of required in Combobox - KALEP-612

  required is no longer directly applied to the underlying input element.
  Instead when required prop is set, the input field recieves `aria-required="true"` and
  setCustomValidity is used on the input field to set a custom error when value is empty

## 1.1.33

### Patch Changes

- [#1063](https://github.com/bolteu/kalep/pull/1063) [`f65e1334`](https://github.com/bolteu/kalep/commit/f65e13346ab6e14d0d50b523504da5abe9a0b34f) Thanks [@burakozdemir32](https://github.com/burakozdemir32)! - Fix Button `static-light` variant on dark mode

## 1.1.32

### Patch Changes

- [#1051](https://github.com/bolteu/kalep/pull/1051) [`99e45703`](https://github.com/bolteu/kalep/commit/99e4570368015b9df36c78fb43df45620b35d7ae) Thanks [@libahipi](https://github.com/libahipi)! - fix: Add .5rem top padding to Datepicker predefined ranges - KALEP-610

## 1.1.31

### Patch Changes

- [#1045](https://github.com/bolteu/kalep/pull/1045) [`2020db1e`](https://github.com/bolteu/kalep/commit/2020db1e89a29634e76ab6ef2cae13b7235894aa) Thanks [@libahipi](https://github.com/libahipi)! - feature: Datepicker predefined date ranges - KALEP-604

  Datepicker has a new prop: `predefinedRanges`, providing ranges adds shortcut buttons at the top of the calendar popup to select user defined date ranges.

  You can use library provided default options like this:

  ```
  predefinedRanges={["KALEP_DATE_RANGE_LAST_7_DAYS", "KALEP_DATE_RANGE_LAST_14_DAYS"]}
  ```

  The complete list of offered values is as follows:
  "KALEP_DATE_RANGE_LAST_3_DAYS"
  "KALEP_DATE_RANGE_LAST_7_DAYS"
  "KALEP_DATE_RANGE_LAST_14_DAYS"
  "KALEP_DATE_RANGE_LAST_30_DAYS"
  "KALEP_DATE_RANGE_NEXT_3_DAYS"
  "KALEP_DATE_RANGE_NEXT_7_DAYS"
  "KALEP_DATE_RANGE_NEXT_14_DAYS"

  You can also define a custom Date range like this:

  ```
  const today = new Date();
  /* ... */
  predefinedRanges = {[{
    key: "last-5-days",
    label: "Last 5 days",
    startDate: new Date(today.getFullYear(), today.getMonth(), today.getDate() - 4),
    endDate: today,
  }]}
  ```

  In practice you probably want to memoize the ranges array, or define it outside of the component, so its reference doesn't change.

## 1.1.30

### Patch Changes

- [#1043](https://github.com/bolteu/kalep/pull/1043) [`1506c2f2`](https://github.com/bolteu/kalep/commit/1506c2f29df3748dd4baee46e1db1b12e151623a) Thanks [@libahipi](https://github.com/libahipi)! - Optimise Tailwind configuration, skip Storybook files from parsed content in builds by default.

## 1.1.29

### Patch Changes

- [#1036](https://github.com/bolteu/kalep/pull/1036) [`8c657d0f`](https://github.com/bolteu/kalep/commit/8c657d0f0a83e38a172c01a912900edcb9b3d263) Thanks [@usetheplatform](https://github.com/usetheplatform)! - KALEP-490 Island: allow modifying paddings. Accepts a spacing token in `padding`. It's possible to control sides with `paddingLeft`, `paddingRight`, `paddingTop`, `paddingBottom`. The default value is `5`.

* [#1037](https://github.com/bolteu/kalep/pull/1037) [`c774af5c`](https://github.com/bolteu/kalep/commit/c774af5c6913e6f742b54f7cb3a6db9aadbc61a4) Thanks [@usetheplatform](https://github.com/usetheplatform)! - KALEP-535 IconView: change values for the `xs` size: container 24px -> 28px, content: 16px -> 20px

- [#1034](https://github.com/bolteu/kalep/pull/1034) [`93725afb`](https://github.com/bolteu/kalep/commit/93725afb001e4c3ab3255af01c6f2ba4fed8e7f1) Thanks [@usetheplatform](https://github.com/usetheplatform)! - KALEP-600 Select: fix options were not displayed properly if set to disabled

* [#1035](https://github.com/bolteu/kalep/pull/1035) [`125750b4`](https://github.com/bolteu/kalep/commit/125750b4f758b14d286fac60b171c9738e510ce4) Thanks [@usetheplatform](https://github.com/usetheplatform)! - Snackbar: Execute the exiting animation only if the parent element is available.

## 1.1.28

### Patch Changes

- [#1018](https://github.com/bolteu/kalep/pull/1018) [`0a22ba1b`](https://github.com/bolteu/kalep/commit/0a22ba1b388a1bb3792f9b6f80375d060241a6b8) Thanks [@libahipi](https://github.com/libahipi)! - Sync up react-aria dependency versions across kalep libraries to avoid duplications in final bundles

* [#1027](https://github.com/bolteu/kalep/pull/1027) [`67cf9902`](https://github.com/bolteu/kalep/commit/67cf99027ca73c0cda90805518989a8b1714ce09) Thanks [@usetheplatform](https://github.com/usetheplatform)! - Fix issue, when Snackbar components were not scoped to the kalep version

## 1.1.27

### Patch Changes

- [#1017](https://github.com/bolteu/kalep/pull/1017) [`801650b7`](https://github.com/bolteu/kalep/commit/801650b7268180858a4906aa3ebba15c979ccac1) Thanks [@libahipi](https://github.com/libahipi)! - chore: remove mistakenly added react-aria dependency

## 1.1.26

### Patch Changes

- [#1007](https://github.com/bolteu/kalep/pull/1007) [`017fa4e4`](https://github.com/bolteu/kalep/commit/017fa4e415901d3fd896e26fa6db2d1d33997fe9) Thanks [@libahipi](https://github.com/libahipi)! - fix: Clarify Upload component size units to KiB and MiB - KALEP-570

## 1.1.25

### Patch Changes

- [#1000](https://github.com/bolteu/kalep/pull/1000) [`8bf4fab9`](https://github.com/bolteu/kalep/commit/8bf4fab96520a66a3efecbb2cf44b036804a2b30) Thanks [@libahipi](https://github.com/libahipi)! - fix: make Breadcrumbs components React keys more resilient to input data

## 1.1.24

### Patch Changes

- [#986](https://github.com/bolteu/kalep/pull/986) [`5c3331a6`](https://github.com/bolteu/kalep/commit/5c3331a617a2400453aaa9f162a4a2681c7a4685) Thanks [@usetheplatform](https://github.com/usetheplatform)! - KALEP-551 Badge: add stroke

* [#986](https://github.com/bolteu/kalep/pull/986) [`5c3331a6`](https://github.com/bolteu/kalep/commit/5c3331a617a2400453aaa9f162a4a2681c7a4685) Thanks [@usetheplatform](https://github.com/usetheplatform)! - Select,MultiSelect: customize trigger rendering, by using three new render functions

  `renderTrigger`
  `renderLoader`
  `renderError`

  It's used internally in TableView to render in-column filters.

## 1.1.23

### Patch Changes

- [#988](https://github.com/bolteu/kalep/pull/988) [`d3525e8a`](https://github.com/bolteu/kalep/commit/d3525e8ab2a1646a8636a4bc7819a9b84efc829f) Thanks [@usetheplatform](https://github.com/usetheplatform)! - KALEP-552 ListItemLayout: Selector type

  ```tsx
  export const MyApp = () => (
    <ul>
      <li>
        <ListItemLayout primary="Selected item: solo-checkmark" selected={true} selectionMode="solo-checkmark" />
      </li>
      <li>
        <ListItemLayout primary="Selected item: solo-radio" selected={true} selectionMode="solo-radio" />
      </li>
      <li>
        <ListItemLayout primary="Selected item: multiple" selected={true} selectionMode="multiple" />
      </li>
      <li>
        <ListItemLayout primary="Selected item: switch" selected={true} selectionMode="switch" />
      </li>
    </ul>
  );
  ```

* [#991](https://github.com/bolteu/kalep/pull/991) [`f169f560`](https://github.com/bolteu/kalep/commit/f169f5609ffeb6fe0dc1fcf3938126739b9152d7) Thanks [@burakozdemir32](https://github.com/burakozdemir32)! - Fix ComboBox Click Issues

## 1.1.22

### Patch Changes

- [#989](https://github.com/bolteu/kalep/pull/989) [`2a167828`](https://github.com/bolteu/kalep/commit/2a167828a2dc13e4c5046fbcf1d2f53b25c9c381) Thanks [@usetheplatform](https://github.com/usetheplatform)! - Badge: fix issue with the neutral appearance, caused by https://github.com/bolteu/kalep/pull/954

## 1.1.21

### Patch Changes

- [#980](https://github.com/bolteu/kalep/pull/980) [`2dfc2dd2`](https://github.com/bolteu/kalep/commit/2dfc2dd22e407e18f9f3f409ff7a47ea7dd59595) Thanks [@CountryTk](https://github.com/CountryTk)! - Added an onClick handler on BaseTextField in BaseComboBox which calls openMenu to open
  the dropdown when user presses on INPUT tag.

## 1.1.20

### Patch Changes

- [#973](https://github.com/bolteu/kalep/pull/973) [`fe9e818c`](https://github.com/bolteu/kalep/commit/fe9e818cb509813e32b6f5f325da45fc63ca833c) Thanks [@usetheplatform](https://github.com/usetheplatform)! - Breadcrumbs: Fixes for BreadcrumbItem
  - expose a mouse event in `onClick`
  - add cursor-pointer
  - fix react key is missing issue

## 1.1.19

### Patch Changes

- [#968](https://github.com/bolteu/kalep/pull/968) [`1c2e89e6`](https://github.com/bolteu/kalep/commit/1c2e89e6aedc00ed68485ddbe542ebdc19a02761) Thanks [@usetheplatform](https://github.com/usetheplatform)! - KALEP-565 Breadcrumb: Allow onClick handlers to be used

  ```tsx
  const items: BreadcrumbItem[] = [
    {
      title: "Home",
      onClick: () => {
        console.log("Home clicked");
      },
    },
    {
      title: "Settings",
      onClick: () => {
        console.log("Settings clicked");
      },
    },
    {
      title: "Account",
      onClick: () => {
        console.log("Account clicked");
      },
    },
  ];

  export function MyApp() {
    return <Breadcrumb items={items} />;
  }
  ```

* [#967](https://github.com/bolteu/kalep/pull/967) [`20c3427e`](https://github.com/bolteu/kalep/commit/20c3427e39171260bf88a8d6dcb31f69b88c6472) Thanks [@usetheplatform](https://github.com/usetheplatform)! - KALEP-567 ListItemLayout: allow customizing of top-bottom paddings

## 1.1.18

### Patch Changes

- [#954](https://github.com/bolteu/kalep/pull/954) [`c4c4b516`](https://github.com/bolteu/kalep/commit/c4c4b516745a81e20b7968334f36d7b2188e82b2) Thanks [@usetheplatform](https://github.com/usetheplatform)! - Chip: Fix the color content css variable for the `neutral` appearance, from `--color-content-neutral-secondary` to `--color-content-secondary`.

## 1.1.17

### Patch Changes

- [#947](https://github.com/bolteu/kalep/pull/947) [`0fb1fad3`](https://github.com/bolteu/kalep/commit/0fb1fad3ea4884b70b03102469d3d6e49a884527) Thanks [@usetheplatform](https://github.com/usetheplatform)! - Accordion: add data-testid="kalep-accordion-expand-row-button" to tests to be able to select accordion buttons

## 1.1.16

### Patch Changes

- [#944](https://github.com/bolteu/kalep/pull/944) [`6fabffb9`](https://github.com/bolteu/kalep/commit/6fabffb9f7ac31af8c2c0b59c5a04b9f95b324ba) Thanks [@usetheplatform](https://github.com/usetheplatform)! - ListItemLayout: partially revert vertical paddings update for the sm variant in KALEP-545

## 1.1.15

### Patch Changes

- [#939](https://github.com/bolteu/kalep/pull/939) [`f9178f1e`](https://github.com/bolteu/kalep/commit/f9178f1ef5f5c2f441c103743ff3efed1b04d203) Thanks [@usetheplatform](https://github.com/usetheplatform)! - KALEP-557 Accordion & AccordionTable: Allow to customize horizontal paddings

## 1.1.14

### Patch Changes

- [#932](https://github.com/bolteu/kalep/pull/932) [`6e23d4dd`](https://github.com/bolteu/kalep/commit/6e23d4dd184dc2cdad387797d31972868df8b6d9) Thanks [@usetheplatform](https://github.com/usetheplatform)! - KALEP-555 Implement Accordion

  Examples:

  ### Basic example

  ```tsx
  import {Accordion, AccordionItem} from "@bolteu/kalep-react";

  export function App() {
    return (
      <div>
        <Accordion>
          {items.map((item) => (
            <AccordionItem
              key={item.id}
              id={item.id}
              title={{
                primary: item.title,
              }}
            >
              <div className="flex flex-col">
                <Skeleton variant="text" />
                <Skeleton variant="text" />
                <Skeleton variant="text" width="50%" />
              </div>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    );
  }
  ```

  ### Customize Accordion header

  ```tsx
  import {Accordion, AccordionItem} from "@bolteu/kalep-react";

  export function App() {
    return (
      <div>
        <Accordion>
          {items.map((item) => (
            <AccordionItem
              key={item.id}
              id={item.id}
              title={{
                primary: item.title,
                secondary: item.subtitle,
                secondaryTypographyProps: {
                  color: item.status === "In review" ? "danger-secondary" : "primary",
                },
                renderEndSlot: (props) => (item.status ? <Chip label={item.status} {...props} /> : null),
              }}
            >
              <div className="flex flex-col">
                <Skeleton variant="text" />
                <Skeleton variant="text" />
                <Skeleton variant="text" width="50%" />
              </div>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    );
  }
  ```

  ### Control state

  ```tsx
  import {Accordion, AccordionItem} from "@bolteu/kalep-react";

  export function App() {
    return (
      <div>
        <Accordion expandedKeys={[1]} disabledKeys={[2]} onExpandedChange={(keys) => console.log(keys)}>
          {items.map((item) => (
            <AccordionItem
              key={item.id}
              id={item.id}
              title={{
                primary: item.title,
              }}
            >
              <div className="flex flex-col">
                <Skeleton variant="text" />
                <Skeleton variant="text" />
                <Skeleton variant="text" width="50%" />
              </div>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    );
  }
  ```

## 1.1.13

### Patch Changes

- [#930](https://github.com/bolteu/kalep/pull/930) [`ffd5540f`](https://github.com/bolteu/kalep/commit/ffd5540f5c88c131fcb63748c1de583061b651a5) Thanks [@meikoudras](https://github.com/meikoudras)! - Update TextField min and max types to reflect input types

## 1.1.12

### Patch Changes

- [#931](https://github.com/bolteu/kalep/pull/931) [`231814d8`](https://github.com/bolteu/kalep/commit/231814d8055dfbb98b4803488e1a4e0fba70c756) Thanks [@kristerlooga-bolt](https://github.com/kristerlooga-bolt)! - Add option to disable virtualization auto scroll for select component.
  This option is added because we use custom margin in the select component options, that the virtualization does not take into account. This results in a jumpy behaviour when user is hovering over items.

## 1.1.11

### Patch Changes

- [#927](https://github.com/bolteu/kalep/pull/927) [`5c85b117`](https://github.com/bolteu/kalep/commit/5c85b11717f4a7e8a5d27648e104c84b7b966a98) Thanks [@usetheplatform](https://github.com/usetheplatform)! - KALEP-545 Update vertical paddings in ListItemLayout

* [#929](https://github.com/bolteu/kalep/pull/929) [`bcb52ec7`](https://github.com/bolteu/kalep/commit/bcb52ec737702e46f4fa5d89ff82892b5f50de9f) Thanks [@usetheplatform](https://github.com/usetheplatform)! - Make IconView a forwarded ref component.

- [#926](https://github.com/bolteu/kalep/pull/926) [`0a5da13a`](https://github.com/bolteu/kalep/commit/0a5da13a7e51e2f23897b1c7e2e8b06a3cd98bda) Thanks [@usetheplatform](https://github.com/usetheplatform)! - chore: Remove console.log from SnackbarProvider

* [#929](https://github.com/bolteu/kalep/pull/929) [`bcb52ec7`](https://github.com/bolteu/kalep/commit/bcb52ec737702e46f4fa5d89ff82892b5f50de9f) Thanks [@usetheplatform](https://github.com/usetheplatform)! - Fix Tooltip wasn't appearing, if it was used with IconView.

- [#921](https://github.com/bolteu/kalep/pull/921) [`51003f60`](https://github.com/bolteu/kalep/commit/51003f60e0cfdb5cd3f3d011fdec51d305f4b6ea) Thanks [@usetheplatform](https://github.com/usetheplatform)! - KALEP-533 Add new static-light variant for Button

  Usage

  Basic example

  ```jsx
  import {Button} from "@bolteu/kalep-react";

  export function App() {
    return <Button variant="static-light">My button</Button>;
  }
  ```

  Change content color

  > It's possible to change the content color of the static-light button.
  > The `contentColor` prop accepts either valid a CSS color expression (e.g. `#ffcc00`)
  > or a Kalep semantic color name (e.g. `text-danger-primary`)

  ```jsx
  import {Button} from "@bolteu/kalep-react";

  export function App() {
    return (
      <Button variant="static-light" contentColor="royalblue">
        My button
      </Button>
    );
  }
  ```

## 1.1.10

### Patch Changes

- Updated dependencies [[`5c69f9b0`](https://github.com/bolteu/kalep/commit/5c69f9b05d375a30035dbf952a10b54ae67519d4)]:
  - @bolteu/kalep-react-icons@1.1.0

## 1.1.9

### Patch Changes

- [#904](https://github.com/bolteu/kalep/pull/904) [`4f26ac66`](https://github.com/bolteu/kalep/commit/4f26ac666391e16aa5f725dcd13d425922490d98) Thanks [@usetheplatform](https://github.com/usetheplatform)! - KALEP-420 Add total count to Table Pagination

## 1.1.8

### Patch Changes

- [#863](https://github.com/bolteu/kalep/pull/863) [`3c9e4c6d`](https://github.com/bolteu/kalep/commit/3c9e4c6d054e003c7cc0e7990690a222d12e81c2) Thanks [@usetheplatform](https://github.com/usetheplatform)! - KALEP-528 Fix bug when Checkbox is shrinked if the label text is too long

## 1.1.7

### Patch Changes

- [#854](https://github.com/bolteu/kalep/pull/854) [`45fcd990`](https://github.com/bolteu/kalep/commit/45fcd9902f859c19c0cccd69d04727228e73566f) Thanks [@usetheplatform](https://github.com/usetheplatform)! - KALEP-512 Use ListItemLayout internally in ComboBox and Select. Mark ListItem as deprecated.

* [#854](https://github.com/bolteu/kalep/pull/854) [`45fcd990`](https://github.com/bolteu/kalep/commit/45fcd9902f859c19c0cccd69d04727228e73566f) Thanks [@usetheplatform](https://github.com/usetheplatform)! - KALEP-512 Expose `highlighted` prop in ListItemLayout to handle highlighting state.

- [#851](https://github.com/bolteu/kalep/pull/851) [`5edfd483`](https://github.com/bolteu/kalep/commit/5edfd48377da929f42fc784d922d19ce412d0b40) Thanks [@usetheplatform](https://github.com/usetheplatform)! - KALEP-521 Fix bug when disabled prop for Button doesn't work if it's wrapped in a Tooltip

## 1.1.6

### Patch Changes

- [#855](https://github.com/bolteu/kalep/pull/855) [`853b97aa`](https://github.com/bolteu/kalep/commit/853b97aa2cdafabee2476237ad50a181c51ca30e) Thanks [@libahipi](https://github.com/libahipi)! - fix: make IconButton display: inline-flex

## 1.1.5

### Patch Changes

- [#848](https://github.com/bolteu/kalep/pull/848) [`3525f8bc`](https://github.com/bolteu/kalep/commit/3525f8bc8170e58634b0a75cc9c55948e53f4d81) Thanks [@libahipi](https://github.com/libahipi)! - fix: change IconButton default variant to secondary (previously filled, visually same)

## 1.1.4

### Patch Changes

- [#840](https://github.com/bolteu/kalep/pull/840) [`04be52b3`](https://github.com/bolteu/kalep/commit/04be52b3b0e7877b27995c4af43a9f991ae6a11a) Thanks [@grasscut](https://github.com/grasscut)! - ## Changes to IconButton Component
  - Added new variants: `primary`, `danger`, `inverted`, `floating-inverted`.
  - Renamed variant `filled` to `secondary`.
  - Implemented label type `tooltip`.
  - Added `width` prop to set the width of the button.

  ### Usage Example

  ```jsx
  import { IconButton, Tooltip } from 'your-components-library';

  function MyComponent() {
    return (
      <div>
          <IconButton
              icon={<YourIconComponent />}
              variant="primary"
              size="md"
              shape="round"
              labelType="tooltip"
              "aria-label"="Add Item"
          >
              Add
          </IconButton>

          <IconButton
              icon={<YourIconComponent />}
              variant="danger"
              size="lg"
              shape="square"
              "aria-label"="Delete Item"
          >
              Delete
          </IconButton>

          <IconButton
              icon={<YourIconComponent />}
              variant="inverted"
              size="sm"
              shape="round"
              disabled
              "aria-label"="Edit Item"
          >
              Edit
          </IconButton>

          <IconButton
              icon={<YourIconComponent />}
              variant="floating-inverted"
              size="md"
              shape="round"
              labelType="tooltip"
              "aria-label"="Save Item"
          />

          <IconButton
              icon={<Heart />}
              aria-label="Like"
              width="100px"
          />
          <IconButton
              icon={<Heart />}
              aria-label="Like"
              width={120}
          />
      </div>
    );
  }

  ```

* [#844](https://github.com/bolteu/kalep/pull/844) [`274b4d4f`](https://github.com/bolteu/kalep/commit/274b4d4fc5dee4e125994ff5a85debfdfc0e6f27) Thanks [@libahipi](https://github.com/libahipi)! - fix: make color prop of Badge use appearance underneath - KALEP-519

- [#843](https://github.com/bolteu/kalep/pull/843) [`ceae2336`](https://github.com/bolteu/kalep/commit/ceae23361abd1bd3aa0f94b851e5dedb112420ea) Thanks [@usetheplatform](https://github.com/usetheplatform)! - KALEP-510 Support controlled state in Tooltip

* [#842](https://github.com/bolteu/kalep/pull/842) [`015529d6`](https://github.com/bolteu/kalep/commit/015529d60f91dca6d8be4404653e23606451d696) Thanks [@libahipi](https://github.com/libahipi)! - fix: make datepicker styles work even if original react-datepicker styles are loaded on page

## 1.1.3

### Patch Changes

- [#837](https://github.com/bolteu/kalep/pull/837) [`8a3fa118`](https://github.com/bolteu/kalep/commit/8a3fa11816ef9fc784b9c0a1a869c23536613dc3) Thanks [@usetheplatform](https://github.com/usetheplatform)! - Fix Tooltip alignment issue in right-aligned Table columns

## 1.1.2

### Patch Changes

- [#828](https://github.com/bolteu/kalep/pull/828) [`2aa98d55`](https://github.com/bolteu/kalep/commit/2aa98d557eea4cf2f24f69706af758a042494e13) Thanks [@grasscut](https://github.com/grasscut)! - # Added new spacing value
  - Added a new spacing value `1.5` with the corresponding size of `0.375rem` to the Tailwind CSS configuration file.

  # Added new variant for Badge
  - Added a new variant `s-dot` for the Badge component, intended to be used with small icons (24x24px). This variant can be applied to the Badge component to style it specifically for small icons.

  # Fixed paddings in Badge
  - Fixed the paddings in the Badge component to ensure consistent and appropriate spacing. Adjustments were made to align the padding values with the desired design and visual requirements.

  # Added font feature settings
  - Added `font-feature-settings: 'tnum' on;` to the global CSS rules or specific stylesheets to enable tabular numbers (tnum) font feature settings. This allows for consistent alignment of numbers in tables and tabular data.

* [#829](https://github.com/bolteu/kalep/pull/829) [`96476d07`](https://github.com/bolteu/kalep/commit/96476d0715985c64e33dd88ea72e1ba87488299b) Thanks [@libahipi](https://github.com/libahipi)! - fix: require MultipleSelect & MultipleCombobox value & defaultValue to be arrays - KALEP-513

## 1.1.1

### Patch Changes

- [#824](https://github.com/bolteu/kalep/pull/824) [`5d5d3543`](https://github.com/bolteu/kalep/commit/5d5d354350627b99ab89fab96d0818a5bc60c507) Thanks [@burakozdemir32](https://github.com/burakozdemir32)! - Use Default Import for Icons

## 1.1.0

### Minor Changes

- [#822](https://github.com/bolteu/kalep/pull/822) [`ad1e5b39`](https://github.com/bolteu/kalep/commit/ad1e5b395d1df53afe23ae9b007a6a08b6e1ebe0) Thanks [@libahipi](https://github.com/libahipi)! - Bump kalep-react version to 1.1.0. No changes from previous version.

## 1.0.28

### Patch Changes

- [#818](https://github.com/bolteu/kalep/pull/818) [`e14bec22`](https://github.com/bolteu/kalep/commit/e14bec228cba75819f778d12765388b0e6f3ff09) Thanks [@libahipi](https://github.com/libahipi)! - chore: Export TypographyStack & more Typography TS types from root

* [#772](https://github.com/bolteu/kalep/pull/772) [`beb08736`](https://github.com/bolteu/kalep/commit/beb0873616d5c346f0cb709b5287f7904eb16169) Thanks [@grasscut](https://github.com/grasscut)! - KALEP-341

  #### IconView component
  - Created the IconView component for rendering icons with customizable size, color, and background image.
  - Supported rendering of either an SVG icon or an image as the icon content.
  - - Added optional spinner for showing loading state.
      Handled click events with an optional onClick prop.

  #### Examples:

  ##### Basic:

  ```tsx
  import * as React from "react";
  import {IconView} from "@bolteu/kalep-react/IconView";
  import {Heart} from "@bolteu/kalep-react-icons";

  export const ExampleComponent = () => {
    return <IconView icon={<Heart />} backgroundColor="bg-neutral-secondary" color="text-primary" />;
  };
  ```

  ##### Image

  ```tsx
  import * as React from "react";
  import {IconView} from "@bolteu/kalep-react/IconView";

  export const ExampleComponent = () => {
    return <IconView imageUrl="https://example.com/image.png" />;
  };
  ```

## 1.0.27

### Patch Changes

- [#804](https://github.com/bolteu/kalep/pull/804) [`69b5b7be`](https://github.com/bolteu/kalep/commit/69b5b7be164bff4f1a50e018f6ec657a4f5505c8) Thanks [@usetheplatform](https://github.com/usetheplatform)! - KALEP-442 - Implement ListItemLayout

  ### How to use:

  Basic view. Use wherever possible! Should be used in Lists

  ### How it work:

  Has 2 variants: base and sm. base should be used for default interfaces; sm for dense interfaces and for Menu of small Input.
  Consists of [leading] slot, TypographyStack and [trailing] slot.

  ### Basic example:

  > See more in Storybook

  #### ListItemLayout

  ```tsx
  import {ListItemLayout} from "@bolteu/kalep-react";

  export function App() {
    return (
      <ul className="flex flex-col gap-y-3 list-none px-0 m-0 empty:py-0">
        {items.map((item, index) => {
          return (
            <li key={index}>
              <ListItemLayout primary={item.label} secondary={item.description} />
            </li>
          );
        })}
      </ul>
    );
  }
  ```

  #### Skeleton

  ```tsx
  import {Skeleton} from "@bolteu/kalep-react";

  export function App() {
    return (
      <div className="p-4 flex flex-col gap-y-3 w-[400px] rounded border border-solid border-bg-neutral-secondary shadow">
        <div className="flex flex-1 gap-x-2 items-center">
          <div className="shrink-0">
            <Skeleton variant="circular" />
          </div>
          <div className="flex flex-1 flex-col gap-y-1">
            <Skeleton variant="text" textSize="text-sm" />
            <Skeleton variant="text" width="66%" textSize="text-sm" />
          </div>
        </div>
        <Skeleton variant="rounded" height="200px" />
        <div className="flex flex-1 flex-col gap-y-1">
          <Skeleton variant="text" textSize="text-sm" />
          <Skeleton variant="text" width="88%" textSize="text-sm" />
        </div>
      </div>
    );
  }
  ```

## 1.0.26

### Patch Changes

- [#757](https://github.com/bolteu/kalep/pull/757) [`2c90100b`](https://github.com/bolteu/kalep/commit/2c90100ba47f2788d3f0934426e21a1e841d653f) Thanks [@libahipi](https://github.com/libahipi)! - feature: custom color support in Chip and Badge - KALEP-306

  Implements support for using custom colors in Chip and Badge.

  For Chip the previous "color" prop is deprecated, use the new "appearance" instead, it accepts all the same values + new options.

  For usage examples refer to "Color Variations" stories under Chip and Badge in the kalep-react Storybook.

## 1.0.25

### Patch Changes

- [#787](https://github.com/bolteu/kalep/pull/787) [`5f4bd85e`](https://github.com/bolteu/kalep/commit/5f4bd85e087c329594a6e7cc4d818ced5ddafc1d) Thanks [@libahipi](https://github.com/libahipi)! - fix: wrap Menu in a div, previously appeared as 2 elements in DOM causing double gaps in flex context - KALEP-500

## 1.0.24

### Patch Changes

- [#784](https://github.com/bolteu/kalep/pull/784) [`31935798`](https://github.com/bolteu/kalep/commit/319357981c35d938069738ea51c865595d7737a3) Thanks [@burakozdemir32](https://github.com/burakozdemir32)! - Align LinkButton Style with Button

## 1.0.23

### Patch Changes

- [#771](https://github.com/bolteu/kalep/pull/771) [`d9e9f047`](https://github.com/bolteu/kalep/commit/d9e9f0477401d9ddf0ec930a62106b809a037586) Thanks [@usetheplatform](https://github.com/usetheplatform)! - Align LinkButton styles with Button for variant `sm`

* [#770](https://github.com/bolteu/kalep/pull/770) [`82a6ab47`](https://github.com/bolteu/kalep/commit/82a6ab47c89c4df169935b7eedbabdd26a5b06e4) Thanks [@usetheplatform](https://github.com/usetheplatform)! - Fixes for Tooltip:
  - Limited maximum with to `280px`
  - Allowed break words for too long words `break-all`
  - Made content occupy the max width available before breaking on another row
  - Added more stories for Tooltip
  - Allowed to pass a custom `boundaryElement` (the default is `targetRef.current?.closest("dialog") || document.body`). It should help position a tooltip in a dialog.

  ```tsx
  function App() {
    let boundaryRef = useRef<HTMLDivElement>(null);

    return (
      <div ref={boundaryRef}>
        <Tooltip content="Noop!" boundaryElement={boundaryRef.current as HTMLElement}>
          <Button onClick={() => {}}>Click me!</Button>
        </Tooltip>
      </div>
    );
  }
  ```

## 1.0.22

### Patch Changes

- [#728](https://github.com/bolteu/kalep/pull/728) [`1fec6d68`](https://github.com/bolteu/kalep/commit/1fec6d687228ad0bcc7e23fc0e3911d270c83f82) Thanks [@usetheplatform](https://github.com/usetheplatform)! - ### Implement Snackbar

  Snackbars provide brief messages about app processes at the bottom of the screen.

  [Figma link](https://www.figma.com/file/nU1QBYZxTAYsIZ4X0jW4tV/%F0%9F%8C%88-Kalep-Semantic-Components?node-id=4896%3A8782&t=HQpei4MaJWZbPbHm-1)

  #### Basic example:

  ```js
  import {Button, SnackbarProvider} from "@bolteu/kalep-react";

  function App() {
    return (
      <SnackbarProvider placement="bottom-left" maxVisibleSnackbars={1}>
        {(state) => (
          <Button
            onClick={() => {
              state.add({
                title: "☕️ Breakfast",
                description: "Your breakfast is ready!",
                dismissible: true,
              });
            }}
          >
            Show message!
          </Button>
        )}
      </SnackbarProvider>
    );
  }
  ```

  #### Basic example with hooks:

  ```js
  import {Button, SnackbarProvider, useSnackbar} from "@bolteu/kalep-react";

  function ShowToast() {
    let state = useSnackbar();

    return (
      <Button
        onClick={() => {
          state.add({
            title: "☕️ Breakfast",
            description: "Your breakfast is ready!",
            dismissible: true,
          });
        }}
      >
        Show message!
      </Button>
    );
  }

  function App() {
    return (
      <SnackbarProvider placement="bottom-left" maxVisibleSnackbars={1}>
        <ShowToast />
      </SnackbarProvider>
    );
  }
  ```

  #### Example with auto-close on timeout:

  > Please make sure to provide a reasonable amount of time for a user to spot and read the message

  ```js
  import {Button, SnackbarProvider} from "@bolteu/kalep-react";

  function App() {
    return (
      <SnackbarProvider placement="bottom-left" maxVisibleSnackbars={1}>
        {(state) => (
          <Button
            onClick={() => {
              state.add(
                {
                  title: "☕️ Breakfast",
                  description: "Your breakfast is ready!",
                  dismissible: false,
                },
                {
                  timeout: 5000, // undefined or 0 means no timeout (infinite until closed by user),
                },
              );
            }}
          >
            Show message!
          </Button>
        )}
      </SnackbarProvider>
    );
  }
  ```

  #### Example with custom onClose:

  ```js
  import {useState} from "react";
  import {Button, SnackbarProvider} from "@bolteu/kalep-react";

  function App() {
    let [snackbarKey, setSnackbarKey] = useState(null);

    return (
      <SnackbarProvider placement="bottom-left" maxVisibleSnackbars={1}>
        {(state) => (
          <Button
            onClick={() => {
              let key = state.add(
                {
                  title: "☕️ Breakfast",
                  description: "Your breakfast is ready!",
                  dismissible: true,
                },
                {
                  onClose: () => {
                    console.log("Closing!");
                    state.close(snackbarKey);
                  },
                },
              );

              setSnackbarKey(key);
            }}
          >
            Show message!
          </Button>
        )}
      </SnackbarProvider>
    );
  }
  ```

  #### Example with custom actions:

  > Please note, that actions onClick handler also closes the toast so you may hide the default close button.

  ```js
  import {Button, SnackbarProvider} from "@bolteu/kalep-react";

  function App() {
    return (
      <SnackbarProvider placement="bottom-left" maxVisibleSnackbars={1}>
        {(state) => (
          <Button
            onClick={() => {
              state.add({
                title: "☕️ Breakfast",
                description: "Your breakfast is ready!",
                dismissible: false,
                actions: [
                  {
                    label: "OK",
                    onClick: () => console.log("Clicked!"),
                  },
                ],
              });
            }}
          >
            Show message!
          </Button>
        )}
      </SnackbarProvider>
    );
  }
  ```

## 1.0.21

### Patch Changes

- [#736](https://github.com/bolteu/kalep/pull/736) [`b70bc085`](https://github.com/bolteu/kalep/commit/b70bc085a6c28912cfce1d929b35df3603512cbb) Thanks [@grasscut](https://github.com/grasscut)! - Allow custom content and href links in `Tabs.Tab` component
  - `children` prop allows using more complex tab labels
  - `href` prop allows navigation by clicking on the tabs
  - `render` prop allows rendering a custom element for a tab, useful for integrating with React Router's `Link` component

  Example usage:

  ```typescript
  import {Link} from "react-router-dom";

  export const CustomTabs = () => {
      const [selectedTab, setSelectedTab] = React.useState<number>(1);

      const handleChange = React.useCallback((newValue: number) => {
          setSelectedTab(newValue);
      }, []);

      return (
          <Tabs onChange={handleChange} selectedTab={selectedTab}>
              <Tabs.Tab id={1} href="/?tab=1">
                  Custom Tab Label
              </Tabs.Tab>
              <Tabs.Tab
                  id={2}
                  render={(props) => (
                      <Link to="/?tab=2" {...props}>
                          Custom Link Tab
                      </Link>
                  )}
              />
              <Tabs.Tab id={3} href="/?tab=3">
                  <HeartIcon />
              </Tabs.Tab>
          </Tabs>
      );
  };
  ```

## 1.0.20

### Patch Changes

- [#752](https://github.com/bolteu/kalep/pull/752) [`3bc395fe`](https://github.com/bolteu/kalep/commit/3bc395fe9be8e0b36440ffb35ef1af2b366384cc) Thanks [@grasscut](https://github.com/grasscut)! - Allow custom menu items in Menu component

  Support custom menu items, particularly for integration with react-router. To achieve this, the szhsin/react-menu library was used, and the implementation followed the official advice provided by the library's creator (link: https://github.com/szhsin/react-menu/issues/5).

  The following changes were made to the Menu component:
  - Added a render function to the MenuItem component, allowing users to provide a custom rendering logic for menu items.
  - The render function receives props, including modifiers such as hover and disabled, which are exposed from the react-menu FocusableItem render function.
  - Exposed our class names, making it convenient for users to apply the regular menu item appearance to their custom components.
  - Added a click function that closes the menu after a menu item is clicked.

  This enhancement enables users to use react-router's Link component as custom menu items within our Menu component. The custom menu items maintain the expected behavior, including styling consistency, closing the menu after a click, and support for keyboard navigation.

## 1.0.19

### Patch Changes

- [#751](https://github.com/bolteu/kalep/pull/751) [`5cebb8f8`](https://github.com/bolteu/kalep/commit/5cebb8f89a9eb38edd9a5bfdadbfc576d9fef247) Thanks [@usetheplatform](https://github.com/usetheplatform)! - (bugfix): KALEP-494 IconButton label text color is not defined

## 1.0.18

### Patch Changes

- [#734](https://github.com/bolteu/kalep/pull/734) [`f453d8f2`](https://github.com/bolteu/kalep/commit/f453d8f224b846350304cd6653d608498044acbb) Thanks [@grasscut](https://github.com/grasscut)! - Added documentation for Link component

  Explaining the difference between Link and LinkButton, examples of Link usage, including with react-router

* [#737](https://github.com/bolteu/kalep/pull/737) [`1fbd6d73`](https://github.com/bolteu/kalep/commit/1fbd6d734ea99150f1cf54148ca5f7689cea1355) Thanks [@libahipi](https://github.com/libahipi)! - fix: Do not show clear button in Combobox if filter equals value

## 1.0.17

### Patch Changes

- [#729](https://github.com/bolteu/kalep/pull/729) [`836130d`](https://github.com/bolteu/kalep/commit/836130df6d8e79eeeadfe77934bd5e8a8cdb45a4) Thanks [@grasscut](https://github.com/grasscut)! - Support for numeric ids in tabs by allowing the `selectedTab` prop to accept either a string or a number.

  The changes were made by updating the `TabsProps` interface to accept a type parameter that extends `string | number`. This type parameter is used for both the `selectedTab` prop and the `TabProps` interface, ensuring that the id types are always consistent.

  Additionally, the `InnerTabProps` interface was updated to accept both string and number ids for the `id` prop.

* [#724](https://github.com/bolteu/kalep/pull/724) [`3972f85`](https://github.com/bolteu/kalep/commit/3972f85f9b465483f4029b1f2beb662afebe8423) Thanks [@libahipi](https://github.com/libahipi)! - feature: Implement Typography component - KALEP-444

- [#722](https://github.com/bolteu/kalep/pull/722) [`95aeb54`](https://github.com/bolteu/kalep/commit/95aeb54329c961fefbda0103c09f23cdb0d1d8ff) Thanks [@grasscut](https://github.com/grasscut)! - This adds new components to the `kalep-react` package for creating simple tables, styled to look like a DataTable. These components include:
  - `Table`: a simple table component with default tailwind classes applied
  - `Table.Header`: a passthrough component for `thead` elements
  - `Table.HeaderRow`: a passthrough component for header `tr` elements
  - `Table.HeaderCell`: a passthrough component for `th` elements
  - `Table.Body`: a passthrough component for `tbody` elements
  - `Table.Row`: a passthrough component for `tr` elements
  - `Table.Cell`: a passthrough component for `td` elements

  Usage example:

  ```
  <Table>
      <Table.Header>
          <Table.HeaderRow>
              <Table.HeaderCell>Product</Table.HeaderCell>
              <Table.HeaderCell>Amount</Table.HeaderCell>
          </Table.HeaderRow>
      </Table.Header>
      <Table.Body>
          <Table.Row>
              <Table.Cell>Potato</Table.Cell>
              <Table.Cell align="right">50</Table.Cell>
          </Table.Row>
      </Table.Body>
  </Table>
  ```

* [#730](https://github.com/bolteu/kalep/pull/730) [`5c2a5eb`](https://github.com/bolteu/kalep/commit/5c2a5eb28e3c3dd0318ee7c30156f847138f90eb) Thanks [@libahipi](https://github.com/libahipi)! - fix: Opening a Select for the first time on a scrolling page scrolled to the end of the page - KALEP-492

  Context:
  On a scrolling page when a Select is opened for the first time the page scrolls to the end.
  This happens because the dropdown part is portalled to the end of the body and gets focused -> scrolls into view.
  We need it to be at the end to avoid all kinds of overflow problems (e.g in dialogs). But we don't want it to scroll.

  In theory we should be fine, but the precise positioning of the overlay happens after focusing.
  Focusing is triggered inside Downshift and we can't affect it.
  So observing the renders we can see that it renders once in open state without having been positioned yet.
  Then useOverlayPosition corrects the position and renders again. Page already scrolled though.

  The fix:
  Guesstimate the top offset of the dropdown based on the field position.
  Do this only if the dropdown is open but we don't have an actual library measured position yet.
  Likely we are a bit off, or a lot off in edge cases, but it's better than always scrolling to the end.
  Next render with actual measurements will correct the position.

## 1.0.16

### Patch Changes

- [#706](https://github.com/bolteu/kalep/pull/706) [`18410fe`](https://github.com/bolteu/kalep/commit/18410feb15d7d39d366a8f6ec15fc114bf857824) Thanks [@libahipi](https://github.com/libahipi)! - refactor: Change TextField types to not extend HTMLInputElement, explicitly lists allowed props - KALEP-411

## 1.0.15

### Patch Changes

- [#705](https://github.com/bolteu/kalep/pull/705) [`68eed86`](https://github.com/bolteu/kalep/commit/68eed86c29ec97b8239f21eb74d42c24297b510c) Thanks [@libahipi](https://github.com/libahipi)! - fix: dropdown at the right edge of Drawer could overflow page - KALEP-447
  - Select & Combobox dropdown placement is now "bottom" instead of "bottom start", this allows them to avoid overflowing the edge of the page. As a side effect, wide trigger element and narrow dropdown (short names) might look strange with the dropdown placed in the middle.
  - BaseModal's experimentalOverflowVisible prop is deprecated as the behavior (overflow: visible) becomes default.

* [#721](https://github.com/bolteu/kalep/pull/721) [`4d068b6`](https://github.com/bolteu/kalep/commit/4d068b666a283318dcf0bf3913dab8449e0938db) Thanks [@burakozdemir32](https://github.com/burakozdemir32)! - Add Misc Improvements for Input Components

## 1.0.14

### Patch Changes

- [#708](https://github.com/bolteu/kalep/pull/708) [`e5c55b2`](https://github.com/bolteu/kalep/commit/e5c55b238d7d23d7d5c500e343a85ff512e290e4) Thanks [@libahipi](https://github.com/libahipi)! - fix: MultipleOption checkbox breaks because of forced display:block - KALEP-448

## 1.0.13

### Patch Changes

- [#703](https://github.com/bolteu/kalep/pull/703) [`1ef7821`](https://github.com/bolteu/kalep/commit/1ef782164b9717f4aef5391c1dc89c6781536811) Thanks [@burakozdemir32](https://github.com/burakozdemir32)! - Standardize asterisk styling for required inputs.

* [#697](https://github.com/bolteu/kalep/pull/697) [`8c31f34`](https://github.com/bolteu/kalep/commit/8c31f342ff6e73abc8c28f1054fb9ad60d7ab000) Thanks [@grasscut](https://github.com/grasscut)! - Button, LinkButton, Chip & IconButton shouldn't have animations in disabled state

## 1.0.12

### Patch Changes

- [#702](https://github.com/bolteu/kalep/pull/702) [`e42c943`](https://github.com/bolteu/kalep/commit/e42c943e22a4e02f9c88b00a0b01969cac5602e2) Thanks [@libahipi](https://github.com/libahipi)! - fix: export upload components from root

* [#694](https://github.com/bolteu/kalep/pull/694) [`15d5a49`](https://github.com/bolteu/kalep/commit/15d5a4978553510923f5897d241aac2e64a61dcc) Thanks [@libahipi](https://github.com/libahipi)! - Fixes problems reported in KALEP-297

  Changes made according to this ADR: https://taxify.atlassian.net/wiki/spaces/DS/pages/4392583222/ADR+Controlled+uncontrolled+form+inputs+in+kalep-react

  This affects:

  BaseTextField (and specialised fields built on top of it)
  Checkbox, Switch
  Radio, RadioGroup
  TextArea

## 1.0.11

### Patch Changes

- [#688](https://github.com/bolteu/kalep/pull/688) [`8a414f8`](https://github.com/bolteu/kalep/commit/8a414f8971696408cce4fa5dac8d04cff7431e5e) Thanks [@grasscut](https://github.com/grasscut)! - Implemented input clearing in Combobox. Clear button appears in the input field when input value is not empty. Custom button tooltip can be set using `clearTextLabel` prop.

## 1.0.10

### Patch Changes

- [#638](https://github.com/bolteu/kalep/pull/638) [`ae18d66`](https://github.com/bolteu/kalep/commit/ae18d66a32777dfd5e6b558195fd2572472031fe) Thanks [@grasscut](https://github.com/grasscut)! - Select and ComboBox dropdown positioning improvements: make dropdown open to the left side when the field is near the right edge of the screeen

  Dropdown positioning is now handled by react-aria's `useOverlayPosition`. Dropdown is wrapped in `OverlayContainer` that creates a portal and places dropdown in the end of the body or dialog if Select/ComboBox is used inside a dialog.

## 1.0.9

### Patch Changes

- [#676](https://github.com/bolteu/kalep/pull/676) [`8ff3de9`](https://github.com/bolteu/kalep/commit/8ff3de9447bdab32d0e4941f98f503ab7c21e413) Thanks [@libahipi](https://github.com/libahipi)! - UploadArea, UploadAttachments components.

  These are meant to be used in constructing upload fields. It is the first iteration and the component APIs can change considerably.

## 1.0.8

### Patch Changes

- [#657](https://github.com/bolteu/kalep/pull/657) [`b6b2978`](https://github.com/bolteu/kalep/commit/b6b29787540f616d54ea3d185122a25a268a4fc3) Thanks [@dentuzhik](https://github.com/dentuzhik)! - Implement Spinner component - KALEP-405
  _ size and color properties are available to be picked from preset values
  _ it can also 'inherit' the size of enclosing container if pre-defined sizes don't match the design

* [#677](https://github.com/bolteu/kalep/pull/677) [`f16d757`](https://github.com/bolteu/kalep/commit/f16d7575c949c4fcb0d31b42698043faafc25c3b) Thanks [@libahipi](https://github.com/libahipi)! - Fix issue with fullWidth property not working on DatePicker component

## 1.0.7

### Patch Changes

- [#669](https://github.com/bolteu/kalep/pull/669) [`eb873f5`](https://github.com/bolteu/kalep/commit/eb873f587414b9d83119fb62c490b3dbfeb07a6d) Thanks [@kristerlooga-bolt](https://github.com/kristerlooga-bolt)! - Add closeOnActivation prop to Tooltip

## 1.0.6

### Patch Changes

- [#646](https://github.com/bolteu/kalep/pull/646) [`468465e`](https://github.com/bolteu/kalep/commit/468465e4bba7218bebebacb2b9002533dda7058b) Thanks [@libahipi](https://github.com/libahipi)! - fixes fullWidth mode for Datepicker after adding a flex wrapper.
  adds a Time icon when Datepicker is in hasTimeSelectOnly mode.

## 1.0.5

### Patch Changes

- [#601](https://github.com/bolteu/kalep/pull/601) [`cad5ef2`](https://github.com/bolteu/kalep/commit/cad5ef20a2f6430ce887292a2030023e2dea24d2) Thanks [@lelumees](https://github.com/lelumees)! - Update TextField, TextArea, Select and Combobox disabled state visuals.

* [#643](https://github.com/bolteu/kalep/pull/643) [`9df32f3`](https://github.com/bolteu/kalep/commit/9df32f3a3bc4643b53094f9c430a2033e83d4288) Thanks [@libahipi](https://github.com/libahipi)! - Add popper placement props to Datepicker, allowing calendar popper to open to a different side

## 1.0.4

### Patch Changes

- [#625](https://github.com/bolteu/kalep/pull/625) [`789a847`](https://github.com/bolteu/kalep/commit/789a84772c9dd7d7babd04a7dac934e6e0fed5b7) Thanks [@libahipi](https://github.com/libahipi)! - Wrap Datepicker component in a div.

  Datepicker component is 2 elements in practice. This can behave strange in a grid, where Datepicker is not wrapped with a Grid.Item. In that case Datepicker takes over the next Grid slot as well, despite visually placings the calendar correctly. Other Grid items will be pushed forward though.

* [#624](https://github.com/bolteu/kalep/pull/624) [`1d4c042`](https://github.com/bolteu/kalep/commit/1d4c04238bec428c26c83a2baee8ad0affea4c04) Thanks [@libahipi](https://github.com/libahipi)! - Adds support for "injectTimes" prop of react-datepicker.

  It works exactly as in react-datepicker taking an array of Date objects with the desired times.
  The injected times are added to the list of available times in their natural time order.
  A sample usecase is adding 23:59 as an option for campaign end times.

  https://reactdatepicker.com/#example-inject-specific-times

- [#634](https://github.com/bolteu/kalep/pull/634) [`27f1359`](https://github.com/bolteu/kalep/commit/27f1359eac6cf3162dcabd395d1922ae9ff33b57) Thanks [@burakozdemir32](https://github.com/burakozdemir32)! - Accept ID Property on GhostButton

* [#629](https://github.com/bolteu/kalep/pull/629) [`34e55d3`](https://github.com/bolteu/kalep/commit/34e55d3db257849e82c160e0e24f6a9744cd1a57) Thanks [@libahipi](https://github.com/libahipi)! - Add support for showing only time selection in Datepicker

  This is required by form-react which exposes a field called TimePicker.
  Implementation is delegated to react-datepicker.

## 1.0.3

### Patch Changes

- [#623](https://github.com/bolteu/kalep/pull/623) [`5ba1429`](https://github.com/bolteu/kalep/commit/5ba1429546bc93d45a7a074ccf4d123338a4d68a) Thanks [@burakozdemir32](https://github.com/burakozdemir32)! - Add Missing React Key for Chip Component Content

## 1.0.2

### Patch Changes

- [#610](https://github.com/bolteu/kalep/pull/610) [`45773d6`](https://github.com/bolteu/kalep/commit/45773d6a2f591df7b0a3aec8c4f313d58ac433d4) Thanks [@libahipi](https://github.com/libahipi)! - chore: fix missing versioned css build command

## 1.0.1

### Patch Changes

- [#590](https://github.com/bolteu/kalep/pull/590) [`4e2bd25`](https://github.com/bolteu/kalep/commit/4e2bd25738c4d5eb507e1994dd9d2efffb7092b0) Thanks [@libahipi](https://github.com/libahipi)! - feature: Add time picker support for Datepicker

* [#592](https://github.com/bolteu/kalep/pull/592) [`f1281c0`](https://github.com/bolteu/kalep/commit/f1281c0d4f671ef969b86a7d68799119b138cb19) Thanks [@libahipi](https://github.com/libahipi)! - feature: initial implementation of versioned scoping class.

## 1.0.0

### Major Changes

- [#597](https://github.com/bolteu/kalep/pull/597) [`738dd45`](https://github.com/bolteu/kalep/commit/738dd45c20fb19e5634bfeb0ad67fe9481fd8a9f) Thanks [@libahipi](https://github.com/libahipi)! - 1.0.0 release of Kalep React components

  This version does not include any features, just bumping version to 1.

## 0.0.87

### Patch Changes

- [#582](https://github.com/bolteu/kalep/pull/582) [`30d28f6`](https://github.com/bolteu/kalep/commit/30d28f62294e1d71dc20beb73b2f871e52435d6a) Thanks [@lelumees](https://github.com/lelumees)! - Fix dropdown positioning in Select and Combobox

## 0.0.86

### Patch Changes

- [#572](https://github.com/bolteu/kalep/pull/572) [`10ad2be`](https://github.com/bolteu/kalep/commit/10ad2be3c10c2ee50a19de69154320a5e130e7a1) Thanks [@lelumees](https://github.com/lelumees)! - Fix Dialog and BaseModal overflow issue using an experimentalOverflowVisible flag.

## 0.0.85

### Patch Changes

- [#549](https://github.com/bolteu/kalep/pull/549) [`7126f2a`](https://github.com/bolteu/kalep/commit/7126f2ac45ea33b440540a73473f97a310c16086) Thanks [@lelumees](https://github.com/lelumees)! - Virtualisation of List, Select and Combobox

* [#573](https://github.com/bolteu/kalep/pull/573) [`956c072`](https://github.com/bolteu/kalep/commit/956c072df68bb6bf1f8d968f945ca16d598435b9) Thanks [@grasscut](https://github.com/grasscut)! - define position relative for button so that absolutely positioned loading spinner always has a parent with position

- [#569](https://github.com/bolteu/kalep/pull/569) [`ffcdff9`](https://github.com/bolteu/kalep/commit/ffcdff99a108fb79fa2f4162f51508003fb00a32) Thanks [@grasscut](https://github.com/grasscut)! - add size prop for Datepicker

## 0.0.84

### Patch Changes

- [#568](https://github.com/bolteu/kalep/pull/568) [`d6b4243`](https://github.com/bolteu/kalep/commit/d6b4243ef1caf82abd9c11f65727baca9b831665) Thanks [@grasscut](https://github.com/grasscut)! - Truncate chip label if it's too long

* [#565](https://github.com/bolteu/kalep/pull/565) [`6f755ba`](https://github.com/bolteu/kalep/commit/6f755baabe4f4d6a8a62dbdebdc818295d457c65) Thanks [@libahipi](https://github.com/libahipi)! - fix: disabled TextField color is dimmed

## 0.0.83

### Patch Changes

- Updated dependencies [[`6a52a40`](https://github.com/bolteu/kalep/commit/6a52a40dc0af57f4162c426bbc3fde412632f94f)]:
  - @bolteu/kalep-react-icons@1.0.2

## 0.0.82

### Patch Changes

- [#545](https://github.com/bolteu/kalep/pull/545) [`4559950`](https://github.com/bolteu/kalep/commit/45599504e830a827b8ff65d877e73b7725fe5d9f) Thanks [@libahipi](https://github.com/libahipi)! - Refactor: removes components' reliance on preflight/reset styles

## 0.0.81

### Patch Changes

- [#541](https://github.com/bolteu/kalep/pull/541) [`67f9811`](https://github.com/bolteu/kalep/commit/67f9811e8523d3fa0e661e02db3db8855fd0ee5e) Thanks [@lelumees](https://github.com/lelumees)! - Rename prop renderSelectedOption to renderMultipleValue in Select and Combobox

* [#552](https://github.com/bolteu/kalep/pull/552) [`1ccf1e1`](https://github.com/bolteu/kalep/commit/1ccf1e19bb3b1a10e19ad9c9aceaa020b9673bd5) Thanks [@libahipi](https://github.com/libahipi)! - fix: Multiple{Select,Combobox} selected Chips allowed bypassing disabled prop

- [#550](https://github.com/bolteu/kalep/pull/550) [`8c48c53`](https://github.com/bolteu/kalep/commit/8c48c530f5f361e6fe09e712c93e2aaacd7bbdfa) Thanks [@grasscut](https://github.com/grasscut)! - set pointer cursor in Select and ComboBox dropdown options to indicate that they are clickable

## 0.0.80

### Patch Changes

- [#537](https://github.com/bolteu/kalep/pull/537) [`5c83af1`](https://github.com/bolteu/kalep/commit/5c83af14901b453b49061c6afa7a633a52628eb4) Thanks [@libahipi](https://github.com/libahipi)! - Refactor: changes the way prebuilt CSS files are created.

## 0.0.79

### Patch Changes

- [#522](https://github.com/bolteu/kalep/pull/522) [`f606082`](https://github.com/bolteu/kalep/commit/f606082fb87617014a23c248936fb8b39b02c54c) Thanks [@grasscut](https://github.com/grasscut)! - Do not close modal on Escape pressed if a modal element other than close button is in focus (e.g. input field)

* [#536](https://github.com/bolteu/kalep/pull/536) [`7a6d9a6`](https://github.com/bolteu/kalep/commit/7a6d9a683e77c696948c05b02f6275007560ff70) Thanks [@grasscut](https://github.com/grasscut)! - Do not animate Chip if no onClick handler is passed

- [#528](https://github.com/bolteu/kalep/pull/528) [`eb6770c`](https://github.com/bolteu/kalep/commit/eb6770cf4cf369b68e3416ffeed79253b2607567) Thanks [@grasscut](https://github.com/grasscut)! - fixed a type in class name in Chip component

* [#526](https://github.com/bolteu/kalep/pull/526) [`c7df4f5`](https://github.com/bolteu/kalep/commit/c7df4f5cfa991e81a6e7e432bee94e4ebfc2c055) Thanks [@grasscut](https://github.com/grasscut)! - use kalep-react-icons in PaymentCardField component

- [#532](https://github.com/bolteu/kalep/pull/532) [`3d89a3f`](https://github.com/bolteu/kalep/commit/3d89a3ff0291a6e014ac117784cc545b346da457) Thanks [@grasscut](https://github.com/grasscut)! - call onChange handler when uncontrolled TextField cleared

- Updated dependencies [[`5b9686e`](https://github.com/bolteu/kalep/commit/5b9686e75aadffc4a55369ea29755b0d16492927)]:
  - @bolteu/kalep-react-icons@1.0.1

## 0.0.78

### Patch Changes

- [#502](https://github.com/bolteu/kalep/pull/502) [`29a92e2`](https://github.com/bolteu/kalep/commit/29a92e2156b8ae0817dc174371e0d54d9809bbb4) Thanks [@lelumees](https://github.com/lelumees)! - Major icons update - migration to UI foundation icons

- Updated dependencies [[`29a92e2`](https://github.com/bolteu/kalep/commit/29a92e2156b8ae0817dc174371e0d54d9809bbb4)]:
  - @bolteu/kalep-react-icons@1.0.0

## 0.0.77

### Patch Changes

- [#501](https://github.com/bolteu/kalep/pull/501) [`2b3a1ae`](https://github.com/bolteu/kalep/commit/2b3a1ae02d06706cd8896ababbd8e766fdcadb14) Thanks [@grasscut](https://github.com/grasscut)! - Radio should be treated as controlled component ("checked" attribute used) if onChange is passed, and uncontrolled ("defaultChecked") if onChange prop is missing

## 0.0.76

### Patch Changes

- [#495](https://github.com/bolteu/kalep/pull/495) [`72ffd45`](https://github.com/bolteu/kalep/commit/72ffd4545a08a677399599f5acb2a58d5e6e9b57) Thanks [@grasscut](https://github.com/grasscut)! - bugfix: do not pass overrideClassName to InnerMenu in Menu component, otherwise it ends up in DOM

* [#476](https://github.com/bolteu/kalep/pull/476) [`61fd656`](https://github.com/bolteu/kalep/commit/61fd6563250e6fb385222260aacc5b5af910a396) Thanks [@grasscut](https://github.com/grasscut)! - KALEP-12: PaymentCardField component

  Figma: https://www.figma.com/file/nU1QBYZxTAYsIZ4X0jW4tV/🌈-Kalep-Semantic-Components?node-id=1%3A18&t=2dLpeBb9JrhLeR7y-0

  Usage: mostly similar to TextField. Consumers aren't allowed to pass custom renderStartSlot function because start slot should always display either card icon or payment type svg.

- [#503](https://github.com/bolteu/kalep/pull/503) [`993f7eb`](https://github.com/bolteu/kalep/commit/993f7ebaf340cbbc88748636adc811366a874e80) Thanks [@libahipi](https://github.com/libahipi)! - fix: ComboBox rendering will not break anymore when label is not provided

* [#496](https://github.com/bolteu/kalep/pull/496) [`970958a`](https://github.com/bolteu/kalep/commit/970958a3a47d8360b38555a17455b88f8a07a4e2) Thanks [@grasscut](https://github.com/grasscut)! - bugfix: do not shrink Button in flex container

## 0.0.75

### Patch Changes

- [#493](https://github.com/bolteu/kalep/pull/493) [`5a2fb72`](https://github.com/bolteu/kalep/commit/5a2fb72aceccdfaab156efa3869f52a0f7db064e) Thanks [@lelumees](https://github.com/lelumees)! - Breadcrumbs custom item renderer - [KALEP-274](https://taxify.atlassian.net/browse/KALEP-274)

  **Example:**

  ```tsx
  import {Breadcrumb, BreadcrumbItem} from "@bolteu/kalep-react";

  const MyBreadCrumbs = (items: BreadcrumbItem[]) => {
    const renderItem = (item: BreadcrumbItem) => {
      return (
        <li>
          <a className="text-promo-primary" href={item.href}>
            {item.title}
          </a>
        </li>
      );
    };

    return <Breadcrumb items={items} renderItem={renderItem} />;
  };
  ```

* [#489](https://github.com/bolteu/kalep/pull/489) [`eb96024`](https://github.com/bolteu/kalep/commit/eb96024e241170b38ca15cf64fd5d02404ab5f70) Thanks [@libahipi](https://github.com/libahipi)! - fix: BaseModal (and Dialog, Drawer) no longer trigger closing when you are selecting text inside, but end the selection outside of modal content

- [#490](https://github.com/bolteu/kalep/pull/490) [`5f836eb`](https://github.com/bolteu/kalep/commit/5f836ebab004bead555eb7299a3b81cfdb746101) Thanks [@libahipi](https://github.com/libahipi)! - fix: close Modals when animation is missing - KALEP-280

  To allow for closing modals with animation the actual closing was delayed on animationend event. (except in prefers-reduced-motion).
  In cases where animation for whatever reason was missing, it was impossible to close Modal as no animationend ever gets triggered.
  Such cases could arise when CSS fails to load.

  This change cheks that element has a value for either animation-duration or transition-duration at the moment of closing request.
  And only then follows the animated path, otherwise close modal immediately.

* [#485](https://github.com/bolteu/kalep/pull/485) [`6152bd1`](https://github.com/bolteu/kalep/commit/6152bd12f57c3f65b097f7619d3e291759295408) Thanks [@libahipi](https://github.com/libahipi)! - fix: Button no longer changes width when it goes to loading state

- [#486](https://github.com/bolteu/kalep/pull/486) [`7033533`](https://github.com/bolteu/kalep/commit/70335333089994cd42d625710e9a0907d9eda6f3) Thanks [@grasscut](https://github.com/grasscut)! - Button shouldn't fill grid item by default

## 0.0.74

### Patch Changes

- [#454](https://github.com/bolteu/kalep/pull/454) [`4d44e0c`](https://github.com/bolteu/kalep/commit/4d44e0c3224f926472966d37eef33d58b8059a78) Thanks [@grasscut](https://github.com/grasscut)! - remove label element from TextField & Select if label value isn't provided

## 0.0.73

### Patch Changes

- [#472](https://github.com/bolteu/kalep/pull/472) [`43723f3`](https://github.com/bolteu/kalep/commit/43723f3eeb97719e1ab513ccbca6d2ac69ddebd9) Thanks [@lelumees](https://github.com/lelumees)! - Support for text wrapping in menu items

## 0.0.72

### Patch Changes

- [#467](https://github.com/bolteu/kalep/pull/467) [`7be7ec2`](https://github.com/bolteu/kalep/commit/7be7ec272489bcb40f55150ebd6c4d7c0c3126b1) Thanks [@lelumees](https://github.com/lelumees)! - Menu allows more customisation through the overrideClassName prop

* [#456](https://github.com/bolteu/kalep/pull/456) [`86fc662`](https://github.com/bolteu/kalep/commit/86fc662167a01720473a55ffc956270b07e513de) Thanks [@grasscut](https://github.com/grasscut)! - remove border from idle/disabled state TextArea

## 0.0.71

### Patch Changes

- [#450](https://github.com/bolteu/kalep/pull/450) [`5d395c2`](https://github.com/bolteu/kalep/commit/5d395c2ed1d4c2f66102beefb4c6c474ce8bebd8) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Correctly remove options when isOptionEqualToValue is passed to multiple ComboBox and Select.

## 0.0.70

### Patch Changes

- [#447](https://github.com/bolteu/kalep/pull/447) [`371e386`](https://github.com/bolteu/kalep/commit/371e386a1d18def6a9e5eacc24039a0e0ab8355f) Thanks [@hekan](https://github.com/hekan)! - PAW-377: `UnixTimestampField` can't be closed while used with Kalep

## 0.0.69

### Patch Changes

- [#441](https://github.com/bolteu/kalep/pull/441) [`5f5bb08`](https://github.com/bolteu/kalep/commit/5f5bb08b7f0279c898df3f007ab5a54261fbb115) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Export SelectedOption and SelectedOptionProps from kalep-react.

* [#440](https://github.com/bolteu/kalep/pull/440) [`fb0a763`](https://github.com/bolteu/kalep/commit/fb0a763fdef4bd8c6ca327a9fd18d526e38785d0) Thanks [@aleksandrashulman](https://github.com/aleksandrashulman)! - Button: added 'background-image' for primary buttons to allow gradient for background

- [#442](https://github.com/bolteu/kalep/pull/442) [`97a9d5e`](https://github.com/bolteu/kalep/commit/97a9d5e3507f23dcae5668dbbe22d8868d921013) Thanks [@lelumees](https://github.com/lelumees)! - Fix Datepicker problems

* [#439](https://github.com/bolteu/kalep/pull/439) [`9ccb0c3`](https://github.com/bolteu/kalep/commit/9ccb0c32263d988a086cfe657a8fadd657f56a23) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Call onInputChange in multiple ComboBox.

* Updated dependencies [[`fb0a763`](https://github.com/bolteu/kalep/commit/fb0a763fdef4bd8c6ca327a9fd18d526e38785d0)]:
  - @bolteu/kalep-tailwind@0.0.23

## 0.0.68

### Patch Changes

- [#425](https://github.com/bolteu/kalep/pull/425) [`541d4c0`](https://github.com/bolteu/kalep/commit/541d4c08dd3f0ee4a28e3daadacb0d6e7c59dd25) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Use a div to render helperText instead of a p tag.

* [#416](https://github.com/bolteu/kalep/pull/416) [`9362b58`](https://github.com/bolteu/kalep/commit/9362b58a2b9bf534e40405106c639c4ef2358ccd) Thanks [@grasscut](https://github.com/grasscut)! - bugfix: uncontrolled Slider didn't behave as expected

- [#415](https://github.com/bolteu/kalep/pull/415) [`8053c82`](https://github.com/bolteu/kalep/commit/8053c82523041ddda355075ce3f1f32aa4d696d9) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Refactor in Select and ComboBox to improve code and the API for the renderSelectedOption prop.

  Before

  ```tsx
  export const CustomSelectedOption = React.forwardRef<HTMLSpanElement, SelectedOptionProps>(
      ({getOptionLabel, selectedOption, onRemove, getSelectedItemProps, index, ...rest}, refProp): JSX.Element => {
          const label = getOptionLabel(selectedOption);
          const {tabIndex, ref, onKeyDown, onClick} = getSelectedItemProps({
              selectedItem: selectedOption,
              index,
              ref: refProp,
          });

          return ...
  ```

  Now

  ```tsx
  export const CustomSelectedOption = React.forwardRef<HTMLSpanElement, SelectedOptionProps>(
      ({option, onRemove, label, tabIndex, onKeyDown, onClick, ...rest}, refProp): JSX.Element => {

          return ...
  ```

## 0.0.67

### Patch Changes

- [#397](https://github.com/bolteu/kalep/pull/397) [`fc8104a`](https://github.com/bolteu/kalep/commit/fc8104a7d22beffd19e59e002b52c2c3a233f1ff) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Implement error state for the Kalep Checkbox component.

* [#420](https://github.com/bolteu/kalep/pull/420) [`bb29760`](https://github.com/bolteu/kalep/commit/bb29760af39096e9934165b8ab8551ee103594cb) Thanks [@marekpagel](https://github.com/marekpagel)! - Pagination component now supports "disabled" state

* Updated dependencies [[`2e3e3fd`](https://github.com/bolteu/kalep/commit/2e3e3fd9429be279543e7070682dc4c7cc140d0a)]:
  - @bolteu/kalep-tailwind@0.0.22

## 0.0.66

### Patch Changes

- [#384](https://github.com/bolteu/kalep/pull/384) [`f68e030`](https://github.com/bolteu/kalep/commit/f68e030d245fe1d9c9a82dc0698f5dcd78187088) Thanks [@lelumees](https://github.com/lelumees)! - Tabs component

## 0.0.65

### Patch Changes

- [#402](https://github.com/bolteu/kalep/pull/402) [`13bd9a4`](https://github.com/bolteu/kalep/commit/13bd9a4d4705de848cfa39993a4e249a462910f3) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Support isOptionEqualToValue for Kalep ComboBox and Select in multiple selection.

* [#412](https://github.com/bolteu/kalep/pull/412) [`1f552f1`](https://github.com/bolteu/kalep/commit/1f552f1280b996eb585447eef175f124afd03da8) Thanks [@grasscut](https://github.com/grasscut)! - bugfix: Select idle state had visible border

- [#408](https://github.com/bolteu/kalep/pull/408) [`3bfaad7`](https://github.com/bolteu/kalep/commit/3bfaad70ce1d4d8a9860b2d090b5eebbec7abdec) Thanks [@grasscut](https://github.com/grasscut)! - add min-width to Select and ComboBox dropdown

- Updated dependencies [[`bc2006c`](https://github.com/bolteu/kalep/commit/bc2006c6e322b9b25afd506d8e554b4aa7a6f2b5)]:
  - @bolteu/kalep-react-icons@0.0.11

## 0.0.64

### Patch Changes

- [#409](https://github.com/bolteu/kalep/pull/409) [`9ab9a13`](https://github.com/bolteu/kalep/commit/9ab9a13ebf00023af6a037029c71a669085af4dc) Thanks [@HenryStevens](https://github.com/HenryStevens)! - Add BaseModal and ListItem to default exports

* [#411](https://github.com/bolteu/kalep/pull/411) [`9a63c22`](https://github.com/bolteu/kalep/commit/9a63c22bc9608fcc338505f6ecbf7298587db842) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Call onInputChange in freeSolo multiple ComboBox.

## 0.0.63

### Patch Changes

- [#399](https://github.com/bolteu/kalep/pull/399) [`8f20925`](https://github.com/bolteu/kalep/commit/8f20925da9455c7e50166c7157ee0ba0cd0362bb) Thanks [@grasscut](https://github.com/grasscut)! - set checked prop only for controlled Radio buttons, use defaultChecked for uncontrolled ones instead to avoid "chaning an uncontrolled input to be controlled" warning

* [#394](https://github.com/bolteu/kalep/pull/394) [`103a073`](https://github.com/bolteu/kalep/commit/103a0733cea22973878bfbc42481fcc0be15c613) Thanks [@aleksandrashulman](https://github.com/aleksandrashulman)! - text + graphic colors => content; update color classes in kalep-react

- [#387](https://github.com/bolteu/kalep/pull/387) [`08bbad7`](https://github.com/bolteu/kalep/commit/08bbad750c34c18fd3e900bb317ebd803896ee2b) Thanks [@libahipi](https://github.com/libahipi)! - Removed deprecated components (DialogLegacy, DrawerLegacy, Modal, Overlay)
  These are replaced by Dialog, Drawer and BaseModal

* [#378](https://github.com/bolteu/kalep/pull/378) [`a2cda8c`](https://github.com/bolteu/kalep/commit/a2cda8cad2b78b59e5abf4c26bb1e2720ffd194f) Thanks [@grasscut](https://github.com/grasscut)! - change colors to functional in Alert, Breadcrumb, Datepicker, Link, LinkButton, ProgressBar, Slider, Stepper, TextArea components

- [#349](https://github.com/bolteu/kalep/pull/349) [`be00f7a`](https://github.com/bolteu/kalep/commit/be00f7ab06d92c1d827b4e5d4bfe50a2ddaad293) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Support renderSelectedOption in multiple selection.

* [#367](https://github.com/bolteu/kalep/pull/367) [`91c1411`](https://github.com/bolteu/kalep/commit/91c1411e1e8df907cdb5f58b20cf1229e4546da3) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Make the right padding for ComboBox smaller, to account for the padding of the Toggle element.

- [#403](https://github.com/bolteu/kalep/pull/403) [`5863c2e`](https://github.com/bolteu/kalep/commit/5863c2ed16bc2172f8898a4a640598cec0ee1f4b) Thanks [@grasscut](https://github.com/grasscut)! - bugfix: use "content" instead of "graphic" in color classes

- Updated dependencies [[`103a073`](https://github.com/bolteu/kalep/commit/103a0733cea22973878bfbc42481fcc0be15c613), [`92eec02`](https://github.com/bolteu/kalep/commit/92eec024e5503768267384fd584e6156d90a64f1), [`96ef2fb`](https://github.com/bolteu/kalep/commit/96ef2fbe68f905d66697d791842bc7d40cce5168), [`9701551`](https://github.com/bolteu/kalep/commit/97015511b3077866ad38406239dcbfee83b31b92)]:
  - @bolteu/kalep-tailwind@0.0.21

## 0.0.62

### Patch Changes

- [#363](https://github.com/bolteu/kalep/pull/363) [`c089d0d`](https://github.com/bolteu/kalep/commit/c089d0d3ba83306ed18afda55098d9b097e52627) Thanks [@grasscut](https://github.com/grasscut)! - use functional colors in Dialog, Drawer & BaseModal components

* [#366](https://github.com/bolteu/kalep/pull/366) [`16c27e9`](https://github.com/bolteu/kalep/commit/16c27e90de288fb0a369db0c303d77698980e678) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Update Chip color names according to the new specs.

- [#381](https://github.com/bolteu/kalep/pull/381) [`2e4c52c`](https://github.com/bolteu/kalep/commit/2e4c52c97e0e35807ba32236e34d50dfdf71827f) Thanks [@lelumees](https://github.com/lelumees)! - Island component

* [#386](https://github.com/bolteu/kalep/pull/386) [`c47e3a7`](https://github.com/bolteu/kalep/commit/c47e3a7d52c1eaa868ac687b2d45ef9dade78649) Thanks [@libahipi](https://github.com/libahipi)! - Add Grid layout component

## 0.0.61

### Patch Changes

- [#368](https://github.com/bolteu/kalep/pull/368) [`c39a50a`](https://github.com/bolteu/kalep/commit/c39a50a37f496a1d344bfd83d2873417278d6ace) Thanks [@libahipi](https://github.com/libahipi)! - Apply scoping class to Datepicker and its styles

* [#353](https://github.com/bolteu/kalep/pull/353) [`40a34a4`](https://github.com/bolteu/kalep/commit/40a34a492baf930db13c1c3eafc21c801be21d6a) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Call onChange in all scenarion for ComboBox and Select.

* Updated dependencies [[`07c1084`](https://github.com/bolteu/kalep/commit/07c1084f4abadb703186bd75ddb82e0f31277fd9), [`2cf2e4e`](https://github.com/bolteu/kalep/commit/2cf2e4e1e25a707c5802f81da176e101187ab8fe)]:
  - @bolteu/kalep-tailwind@0.0.20

## 0.0.60

### Patch Changes

- [#359](https://github.com/bolteu/kalep/pull/359) [`2c9d227`](https://github.com/bolteu/kalep/commit/2c9d2272205e2e1660b4d14ad8e2fe1069777299) Thanks [@grasscut](https://github.com/grasscut)! - Applies default text color (text-primary) to `html` and sets text color explicitly on labels.

  Required for dark mode to behave as expected. Example of broken text colors: https://taxify.slack.com/archives/C030WAFUZBQ/p1666699896659829 (internal ds devs chat).

* [#351](https://github.com/bolteu/kalep/pull/351) [`1c8b55a`](https://github.com/bolteu/kalep/commit/1c8b55a139ba944311d0287baca10c276e863857) Thanks [@grasscut](https://github.com/grasscut)! - use functional colors in ComboBox, List, Menu & Pagination

- [#348](https://github.com/bolteu/kalep/pull/348) [`294026c`](https://github.com/bolteu/kalep/commit/294026cc8e1c59c78d8f2c6715e3a645682565bb) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Adapt size for Chips to the multiple selection Select / ComboBox.

* [#356](https://github.com/bolteu/kalep/pull/356) [`95cb5c1`](https://github.com/bolteu/kalep/commit/95cb5c181045821914ec4607a83fc88bea1ff077) Thanks [@grasscut](https://github.com/grasscut)! - use functional colors in Badge, Chip & Tooltip components

- [#354](https://github.com/bolteu/kalep/pull/354) [`9bcf501`](https://github.com/bolteu/kalep/commit/9bcf501ef2439ad4ec253cb6d82bd2ad0c1b46b2) Thanks [@grasscut](https://github.com/grasscut)! - bugfix: uncontrolled checkbox missing checkmark when checked

- Updated dependencies [[`d0d6348`](https://github.com/bolteu/kalep/commit/d0d63486c3398ba090330f19f7e54356fc5ce2f7), [`bf008ae`](https://github.com/bolteu/kalep/commit/bf008ae0a3d2effdbcdb0e087459ed2ffe48299e)]:
  - @bolteu/kalep-tailwind@0.0.19

## 0.0.59

### Patch Changes

- [#335](https://github.com/bolteu/kalep/pull/335) [`88938e3`](https://github.com/bolteu/kalep/commit/88938e3a60b5bf15229974b7498a1ec559f4482d) Thanks [@grasscut](https://github.com/grasscut)! - extend background, border and text colors with functional colors, avoid duplicates in class names, replace color class names in switch, checkbox and radio

* [#331](https://github.com/bolteu/kalep/pull/331) [`a171c2e`](https://github.com/bolteu/kalep/commit/a171c2edd473776b9f1d9bb29dcac85dbb345832) Thanks [@grasscut](https://github.com/grasscut)! - use functional colors for Icon Button

- [#346](https://github.com/bolteu/kalep/pull/346) [`624e2ae`](https://github.com/bolteu/kalep/commit/624e2aea7a15104d0d4342a0e770f6e2e6a5ca45) Thanks [@grasscut](https://github.com/grasscut)! - use functional colors in TextField component

* [#330](https://github.com/bolteu/kalep/pull/330) [`81502f1`](https://github.com/bolteu/kalep/commit/81502f184f62ba9c083c8de990d0dd57bc0cc867) Thanks [@grasscut](https://github.com/grasscut)! - change button colors to functional ones

* Updated dependencies [[`88938e3`](https://github.com/bolteu/kalep/commit/88938e3a60b5bf15229974b7498a1ec559f4482d)]:
  - @bolteu/kalep-tailwind@0.0.18

## 0.0.58

### Patch Changes

- [#341](https://github.com/bolteu/kalep/pull/341) [`01128ae`](https://github.com/bolteu/kalep/commit/01128aeb39e2d2551896afc21235e703ad88a0fd) Thanks [@lelumees](https://github.com/lelumees)! - Inputs now consider existing value property as indication of being controlled irregardless of the value

## 0.0.57

### Patch Changes

- [#327](https://github.com/bolteu/kalep/pull/327) [`e91df58`](https://github.com/bolteu/kalep/commit/e91df586397abb8d612f208fec06520611b91564) Thanks [@lelumees](https://github.com/lelumees)! - Fix Dialog problems

* [#321](https://github.com/bolteu/kalep/pull/321) [`df58f84`](https://github.com/bolteu/kalep/commit/df58f84d42273a956d9b6a016895513257ac0ce8) Thanks [@lelumees](https://github.com/lelumees)! - Update documentation and preflight css to fix overrides problem

## 0.0.56

### Patch Changes

- [#300](https://github.com/bolteu/kalep/pull/300) [`67e46a0`](https://github.com/bolteu/kalep/commit/67e46a0bcaf6a3a618f16facae3a83880dd72971) Thanks [@grasscut](https://github.com/grasscut)! - change colors to functional ones in Checkbox, Radio and Switch components

- Updated dependencies [[`6265f8d`](https://github.com/bolteu/kalep/commit/6265f8db19bdf31364f61772a70e24cf55ac7f92)]:
  - @bolteu/kalep-tailwind@0.0.17

## 0.0.55

### Patch Changes

- [#313](https://github.com/bolteu/kalep/pull/313) [`0822e1a`](https://github.com/bolteu/kalep/commit/0822e1abe7b8aaffe94d1e9d16d78643b2f563eb) Thanks [@libahipi](https://github.com/libahipi)! - Applied uniform CSS Cascade Layers structure across packages

- Updated dependencies [[`0822e1a`](https://github.com/bolteu/kalep/commit/0822e1abe7b8aaffe94d1e9d16d78643b2f563eb)]:
  - @bolteu/kalep-tailwind@0.0.16

## 0.0.54

### Patch Changes

- [#315](https://github.com/bolteu/kalep/pull/315) [`18d7bda`](https://github.com/bolteu/kalep/commit/18d7bda63129e3f7e489e29a65b570f4b4e49176) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Support error prop in RadioGroup. Fix checked prop in Radio. Add more unit tests and a11y support.

## 0.0.53

### Patch Changes

- [#308](https://github.com/bolteu/kalep/pull/308) [`65beee5`](https://github.com/bolteu/kalep/commit/65beee5aa2b19d0f804b6e763b4a6b61acb24f49) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Fix Breadcrumb aria label value. More unit tests for coverage.

* [#301](https://github.com/bolteu/kalep/pull/301) [`542809b`](https://github.com/bolteu/kalep/commit/542809b8d03f0de27ae6dd99728247203f1276e4) Thanks [@lelumees](https://github.com/lelumees)! - Datepicker component

- [#309](https://github.com/bolteu/kalep/pull/309) [`5c95ed2`](https://github.com/bolteu/kalep/commit/5c95ed26040af1b45e25c6f5f25396dc650e494a) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Support required prop in RadioGroup and some refactoring.

* [#302](https://github.com/bolteu/kalep/pull/302) [`5d904ea`](https://github.com/bolteu/kalep/commit/5d904eafa491c11b5e14c76e50e4dbc50a819956) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Add English defaults to aria label values.

- [#316](https://github.com/bolteu/kalep/pull/316) [`fba41f9`](https://github.com/bolteu/kalep/commit/fba41f907f19496c3bfc4f242080a27e6c62122f) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Fix Radio export.

## 0.0.52

### Patch Changes

- Updated dependencies [[`e5cb86f`](https://github.com/bolteu/kalep/commit/e5cb86fe31bb316ab5b78e9f2bee92afcf0c2719)]:
  - @bolteu/kalep-tailwind@0.0.15

## 0.0.51

### Patch Changes

- Updated dependencies [[`f843f0f`](https://github.com/bolteu/kalep/commit/f843f0f7d0915bbaafc2ab98ab64b3f519273a13)]:
  - @bolteu/kalep-tailwind@0.0.14

## 0.0.50

### Patch Changes

- Updated dependencies [[`17282fa`](https://github.com/bolteu/kalep/commit/17282faed4af3fd87ced271597af43a6b1d6478e), [`37b46d1`](https://github.com/bolteu/kalep/commit/37b46d12da06d353526ad269b8de86c560f53f46)]:
  - @bolteu/kalep-tailwind@0.0.13

## 0.0.49

### Patch Changes

- [#273](https://github.com/bolteu/kalep/pull/273) [`17303b9`](https://github.com/bolteu/kalep/commit/17303b90f082cda94f547e17ab3e0a871f7e1300) Thanks [@grasscut](https://github.com/grasscut)! - freeSolo mode in ComboBox

* [#294](https://github.com/bolteu/kalep/pull/294) [`c33766e`](https://github.com/bolteu/kalep/commit/c33766ebc12fe9276e513452617d02319399fe3e) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Update downshift for ComboBox Escape keydown fix.

## 0.0.48

### Patch Changes

- Updated dependencies [[`2933c3b`](https://github.com/bolteu/kalep/commit/2933c3bcb573132af474f9b87cec8facf280d494)]:
  - @bolteu/kalep-tailwind@0.0.12

## 0.0.47

### Patch Changes

- [#286](https://github.com/bolteu/kalep/pull/286) [`d71fdb4`](https://github.com/bolteu/kalep/commit/d71fdb4f013922046d887069ae80d1c701c77a04) Thanks [@lelumees](https://github.com/lelumees)! - Link component

## 0.0.46

### Patch Changes

- [#272](https://github.com/bolteu/kalep/pull/272) [`c7ce7e4`](https://github.com/bolteu/kalep/commit/c7ce7e4bec4807efc8270366f767e50f629def8b) Thanks [@libahipi](https://github.com/libahipi)! - Major refactor of Dialog & Drawer components, new BaseModal component to build modals on top of

- Updated dependencies [[`c7ce7e4`](https://github.com/bolteu/kalep/commit/c7ce7e4bec4807efc8270366f767e50f629def8b)]:
  - @bolteu/kalep-tailwind@0.0.11

## 0.0.45

### Patch Changes

- [#288](https://github.com/bolteu/kalep/pull/288) [`9b9741e`](https://github.com/bolteu/kalep/commit/9b9741e4832d099c65579954608a8321c428bf67) Thanks [@lelumees](https://github.com/lelumees)! - Fix kalep-react TS aliases in the built package

## 0.0.44

### Patch Changes

- [#278](https://github.com/bolteu/kalep/pull/278) [`f6474cf`](https://github.com/bolteu/kalep/commit/f6474cf6a1109375d76b688b9b7a93152f14ea43) Thanks [@arturluik](https://github.com/arturluik)! - Enable side effects for CSS files - so webpack based projects will not "tree-shake" them.

* [#287](https://github.com/bolteu/kalep/pull/287) [`08380bf`](https://github.com/bolteu/kalep/commit/08380bfee215959c9334fd5ae3beafe4dca55385) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Export SelectProps.

## 0.0.43

### Patch Changes

- [#276](https://github.com/bolteu/kalep/pull/276) [`a01e538`](https://github.com/bolteu/kalep/commit/a01e538fc1d9bfb4d9fe1fb913d45e7cc71c202d) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Wrap Alert in forwardRef and expose overrideClassName prop

## 0.0.42

### Patch Changes

- [#269](https://github.com/bolteu/kalep/pull/269) [`8cb038e`](https://github.com/bolteu/kalep/commit/8cb038e3c52b5b78226315df34cade9c3b22c998) Thanks [@lelumees](https://github.com/lelumees)! - Update root exports, export Modal

* [#271](https://github.com/bolteu/kalep/pull/271) [`30aafbe`](https://github.com/bolteu/kalep/commit/30aafbe5e8c938dc2117d64d9496a721db1dbd4c) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Export Props from all components.

## 0.0.41

### Patch Changes

- [#259](https://github.com/bolteu/kalep/pull/259) [`4ef41de`](https://github.com/bolteu/kalep/commit/4ef41deebf3970485151586a19cb40f6b351a13a) Thanks [@grasscut](https://github.com/grasscut)! - focus on ComboBox when input wrapper clicked + storybook interaction tests for the case

* [#251](https://github.com/bolteu/kalep/pull/251) [`94b4a25`](https://github.com/bolteu/kalep/commit/94b4a2534b9a5dfc9f164406c0e0775553950d90) Thanks [@grasscut](https://github.com/grasscut)! - added a version of main.css with preflight reset stylesheet applied only to kalep components

- [#257](https://github.com/bolteu/kalep/pull/257) [`071fd8d`](https://github.com/bolteu/kalep/commit/071fd8d480aad3fff60d8ea7c88ce74a3dd267ee) Thanks [@grasscut](https://github.com/grasscut)! - fix Textfield/ComboBox positioning

- Updated dependencies [[`37093ac`](https://github.com/bolteu/kalep/commit/37093ac76de9ada52f5c6ad7f742d0bd3a184e80)]:
  - @bolteu/kalep-react-icons@0.0.10

## 0.0.40

### Patch Changes

- [#256](https://github.com/bolteu/kalep/pull/256) [`d466600`](https://github.com/bolteu/kalep/commit/d466600f355b91fa6130acee0d14d7fe9a2e79fe) Thanks [@grasscut](https://github.com/grasscut)! - change icon import in Drawer

* [#247](https://github.com/bolteu/kalep/pull/247) [`ad6a2d3`](https://github.com/bolteu/kalep/commit/ad6a2d3c33758d43c3aab71bb0efa8e2a7b9b618) Thanks [@libahipi](https://github.com/libahipi)! - Upgrade tailwindcss to ^3.1.8

  Tailwind 3.1 Release notes: https://tailwindcss.com/blog/tailwindcss-v3-1

- [#246](https://github.com/bolteu/kalep/pull/246) [`d0418fe`](https://github.com/bolteu/kalep/commit/d0418fe30caca2d394cc59e4f8e4b6a043fc5813) Thanks [@grasscut](https://github.com/grasscut)! - Export tailwind config

* [#253](https://github.com/bolteu/kalep/pull/253) [`2e0ebcc`](https://github.com/bolteu/kalep/commit/2e0ebcca480333c44a9d6495238950c5a9257cc4) Thanks [@lelumees](https://github.com/lelumees)! - Update imports to use aliases

- [#237](https://github.com/bolteu/kalep/pull/237) [`818bc68`](https://github.com/bolteu/kalep/commit/818bc68a15e0e30b90d7149998db22b6a3d01cda) Thanks [@lelumees](https://github.com/lelumees)! - Update build tooling (use Babel for transpiling, introduce aliases, allow tree-shaking)

- Updated dependencies [[`ad6a2d3`](https://github.com/bolteu/kalep/commit/ad6a2d3c33758d43c3aab71bb0efa8e2a7b9b618)]:
  - @bolteu/kalep-tailwind@0.0.10

## 0.0.39

### Patch Changes

- [#236](https://github.com/bolteu/kalep/pull/236) [`b2cf08b`](https://github.com/bolteu/kalep/commit/b2cf08b7b2384659cac8945621bcfb158f8f7ff3) Thanks [@lelumees](https://github.com/lelumees)! - Fix SearchTextField controlled clearing

* [#249](https://github.com/bolteu/kalep/pull/249) [`d473c96`](https://github.com/bolteu/kalep/commit/d473c96628ae77bba4010850e7b0a4bb521349ff) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Refresh the filtered options when ComboBox options array change.

## 0.0.38

### Patch Changes

- [#239](https://github.com/bolteu/kalep/pull/239) [`126e95b`](https://github.com/bolteu/kalep/commit/126e95b8878e47d0f4c217e0c4c18af8c2e2f3c8) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Fix ComboBox No results element positioning and aria labelling. Fix controlled inputValue filtering.

* [#240](https://github.com/bolteu/kalep/pull/240) [`f23b9ac`](https://github.com/bolteu/kalep/commit/f23b9ac4360a79195bb384c4a74fc25d3cae0424) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Update Alert variations.

- [#229](https://github.com/bolteu/kalep/pull/229) [`68c9eef`](https://github.com/bolteu/kalep/commit/68c9eef2a672ae6e4d5f35b3b64dc6328dd6dec5) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Control inputValue in ComboBox.

## 0.0.37

### Patch Changes

- [#227](https://github.com/bolteu/kalep/pull/227) [`1bffca5`](https://github.com/bolteu/kalep/commit/1bffca57dd6b4177d4e48e8b29a73330f3344c88) Thanks [@grasscut](https://github.com/grasscut)! - add green border to Select field when menu is open

* [#226](https://github.com/bolteu/kalep/pull/226) [`7793dcf`](https://github.com/bolteu/kalep/commit/7793dcf963f8c6e8e2e5f199f0ce8a6663a0e253) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Support onInputChange in ComboBox.

## 0.0.36

### Patch Changes

- [#224](https://github.com/bolteu/kalep/pull/224) [`b9aeb5a`](https://github.com/bolteu/kalep/commit/b9aeb5a3797d08648973adac6b4d9f0db93b017e) Thanks [@grasscut](https://github.com/grasscut)! - support name and required in ComboBox

* [#216](https://github.com/bolteu/kalep/pull/216) [`3ce7ee0`](https://github.com/bolteu/kalep/commit/3ce7ee0efbd276bf725db74c6e968d4c01a8fbc8) Thanks [@eugenekovaljov](https://github.com/eugenekovaljov)! - Support Badge placement.

- [#223](https://github.com/bolteu/kalep/pull/223) [`037c23b`](https://github.com/bolteu/kalep/commit/037c23b416b8572de3d7ef5980f6662bcb98067c) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Support getOptionLabel in Select and ComboBox. Support filterOptions in ComboBox.

* [#225](https://github.com/bolteu/kalep/pull/225) [`7adf37f`](https://github.com/bolteu/kalep/commit/7adf37f1ec2ebd86468ba9be13e2b562f5d6c9a6) Thanks [@lelumees](https://github.com/lelumees)! - Fix TextInput height without a label

- [#220](https://github.com/bolteu/kalep/pull/220) [`8b8677b`](https://github.com/bolteu/kalep/commit/8b8677bf9a61f20bfa191ab807bffed8628c32a1) Thanks [@grasscut](https://github.com/grasscut)! - Improvements for useControlledValue to support more components.

## 0.0.35

### Patch Changes

- [#215](https://github.com/bolteu/kalep/pull/215) [`c5e3c9a`](https://github.com/bolteu/kalep/commit/c5e3c9a59fd1a4e60574a48ee901bea28dd2a43f) Thanks [@grasscut](https://github.com/grasscut)! - show close button in Dialog when onClose prop is passed

* [#208](https://github.com/bolteu/kalep/pull/208) [`b3c8540`](https://github.com/bolteu/kalep/commit/b3c85405bf78d72fb1a033d50c07a1ad84318501) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Loading state for Select and ComboBox.

- [#218](https://github.com/bolteu/kalep/pull/218) [`bf020b2`](https://github.com/bolteu/kalep/commit/bf020b25dcc14f3db52e337c0131cd51527b4624) Thanks [@grasscut](https://github.com/grasscut)! - useId from react-aria in Drawer component

* [#214](https://github.com/bolteu/kalep/pull/214) [`c507e11`](https://github.com/bolteu/kalep/commit/c507e111c201df0813dc1727ca1baa96c1bddfdf) Thanks [@libahipi](https://github.com/libahipi)! - - Remove custom CSS from kalep-react tailwind config, prefer keeping all styles in classnames
  - Add new special selectors to kalep-tailwind config

  Affects: Tooltip, TextField (search variant) & Slider

* Updated dependencies [[`c507e11`](https://github.com/bolteu/kalep/commit/c507e111c201df0813dc1727ca1baa96c1bddfdf)]:
  - @bolteu/kalep-tailwind@0.0.9

## 0.0.34

### Patch Changes

- [#210](https://github.com/bolteu/kalep/pull/210) [`7b8ce71`](https://github.com/bolteu/kalep/commit/7b8ce71e4dcdd1c6a16493bd6d4920a3154335d2) Thanks [@lelumees](https://github.com/lelumees)! - Fix Slider importing non-existent CSS, use Tailwing arbitrary variants instead

## 0.0.33

### Patch Changes

- [#198](https://github.com/bolteu/kalep/pull/198) [`0866e33`](https://github.com/bolteu/kalep/commit/0866e33d947148ddac59336639d6a351c380dcd2) Thanks [@lelumees](https://github.com/lelumees)! - Slider component

* [#203](https://github.com/bolteu/kalep/pull/203) [`0eb55d6`](https://github.com/bolteu/kalep/commit/0eb55d6af23ab425947bd76929eeda80cd2bb91d) Thanks [@eugenekovaljov](https://github.com/eugenekovaljov)! - Fix hover disabled state color of Switch

- [#202](https://github.com/bolteu/kalep/pull/202) [`8ba7af8`](https://github.com/bolteu/kalep/commit/8ba7af86a7f3b47356465c343847a39f85798bfd) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Add disableCloseOnSelect prop to ComboBox.

* [#206](https://github.com/bolteu/kalep/pull/206) [`61ac778`](https://github.com/bolteu/kalep/commit/61ac778b2c96e02253813ab9afb8af6abd6ba4c0) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Fix label text content for Select and ComboBox ListItems.

- [#194](https://github.com/bolteu/kalep/pull/194) [`9ffe693`](https://github.com/bolteu/kalep/commit/9ffe693cb6b5802cb8a3bf9f45d340ca1988bfa4) Thanks [@grasscut](https://github.com/grasscut)! - open select/combobox upwards when field is in the bottom of the screen

* [#184](https://github.com/bolteu/kalep/pull/184) [`a00f041`](https://github.com/bolteu/kalep/commit/a00f041ff607ec2e47d2eb2447a4563beee3f32a) Thanks [@grasscut](https://github.com/grasscut)! - alert component changes

## 0.0.32

### Patch Changes

- [#192](https://github.com/bolteu/kalep/pull/192) [`97565e4`](https://github.com/bolteu/kalep/commit/97565e4c13c0ff2d341898b14fb0cea2630a321d) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Export SelectOption type.

* [#199](https://github.com/bolteu/kalep/pull/199) [`047b88b`](https://github.com/bolteu/kalep/commit/047b88b1eecd04eecc0c66c42558c8875e794ab5) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Export Checkbox.

## 0.0.31

### Patch Changes

- [#189](https://github.com/bolteu/kalep/pull/189) [`a7895dc`](https://github.com/bolteu/kalep/commit/a7895dc667d2c7c0bde6d4ec1f7e28b884d75e78) Thanks [@libahipi](https://github.com/libahipi)! - fix: change input field error state border color to red-500

* [#188](https://github.com/bolteu/kalep/pull/188) [`7a67e9f`](https://github.com/bolteu/kalep/commit/7a67e9fa987486abbe5e66ad550d62fc481f90be) Thanks [@libahipi](https://github.com/libahipi)! - Update disabled&selected Switch color to neutral per design. Fix flex-shrinking issue.

* Updated dependencies [[`2e757ca`](https://github.com/bolteu/kalep/commit/2e757ca12039264ae97354e2d0e1ea122198b3b5), [`b10f1b6`](https://github.com/bolteu/kalep/commit/b10f1b67ff3a06d9551f4fda6361be9346dfb66a)]:
  - @bolteu/kalep-tailwind@0.0.8

## 0.0.30

### Patch Changes

- [#187](https://github.com/bolteu/kalep/pull/187) [`f6e49bc`](https://github.com/bolteu/kalep/commit/f6e49bca81d8885796e348ce94a08b2ab3c0639f) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Export TextFieldRenderProps and use it in all render functions. Similar changes in all components.

## 0.0.29

### Patch Changes

- [#186](https://github.com/bolteu/kalep/pull/186) [`c653082`](https://github.com/bolteu/kalep/commit/c653082fbaa1ae9fddc36daa0108729ee4080e67) Thanks [@libahipi](https://github.com/libahipi)! - Fix Radio button shape distorting when label is wide

* [#183](https://github.com/bolteu/kalep/pull/183) [`c656680`](https://github.com/bolteu/kalep/commit/c6566809ecfcea88a207d983f9b7bd720bd7631a) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Replace useId implementation from reach-ui to react-aria/utils.

- [#180](https://github.com/bolteu/kalep/pull/180) [`76748fb`](https://github.com/bolteu/kalep/commit/76748fb627b59245dde247dd9af744159eb8446c) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Test and improve itemToString.

* [#185](https://github.com/bolteu/kalep/pull/185) [`f7b0257`](https://github.com/bolteu/kalep/commit/f7b0257166564a39672e2b02de5560d449b13839) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Handle empty string in option.title and empty string label for ListItem.

- [#179](https://github.com/bolteu/kalep/pull/179) [`c81686a`](https://github.com/bolteu/kalep/commit/c81686aa446feaed0e4a18dd0d8bb42531981571) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Support name prop in Select.

* [#182](https://github.com/bolteu/kalep/pull/182) [`b812662`](https://github.com/bolteu/kalep/commit/b8126627eac921b0f3a5003ad8e600fdd56e95af) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Fixes for Select, ComboBox, List.

* Updated dependencies [[`49fff2b`](https://github.com/bolteu/kalep/commit/49fff2b94b76a52771f79d9fb898b0de98e4b752)]:
  - @bolteu/kalep-tailwind@0.0.7

## 0.0.28

### Patch Changes

- [#172](https://github.com/bolteu/kalep/pull/172) [`7af83c9`](https://github.com/bolteu/kalep/commit/7af83c9404922f7ab656acd02c9e14de04b07d35) Thanks [@lelumees](https://github.com/lelumees)! - Rename Tag to Chip

* [#170](https://github.com/bolteu/kalep/pull/170) [`97d34c9`](https://github.com/bolteu/kalep/commit/97d34c9c79ff796374cb3e907e435894342df32b) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Change type to support React Elements for helperText.

- [`00e947b`](https://github.com/bolteu/kalep/commit/00e947ba805e37e40281d5f9f44985ad76292d30) Thanks [@grasscut](https://github.com/grasscut)! - Pagination component

* [#169](https://github.com/bolteu/kalep/pull/169) [`e36a626`](https://github.com/bolteu/kalep/commit/e36a6266e66e5280354b38a467ff8536eef9baec) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Style fixes and API improvements for Select and TextField.

- [#171](https://github.com/bolteu/kalep/pull/171) [`0035c5b`](https://github.com/bolteu/kalep/commit/0035c5b1eeacc464a270167e5c69194ff237a163) Thanks [@lelumees](https://github.com/lelumees)! - ClassName merging

* [#175](https://github.com/bolteu/kalep/pull/175) [`6eb3f20`](https://github.com/bolteu/kalep/commit/6eb3f2009751962ded6d1afbb87b60178ab6cace) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Support disabled prop for ListItem.

- [#164](https://github.com/bolteu/kalep/pull/164) [`207943d`](https://github.com/bolteu/kalep/commit/207943d643ee10946ad277b0230ce95fee4e23bf) Thanks [@grasscut](https://github.com/grasscut)! - added useMultipleValues hook to enable multiple options selection in Select & ComboBox components

## 0.0.27

### Patch Changes

- [#165](https://github.com/bolteu/kalep/pull/165) [`a256a6c`](https://github.com/bolteu/kalep/commit/a256a6cbb7c93fa1c0b0d63b4840ce8d7183f71a) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Update React imports.

## 0.0.26

### Patch Changes

- [#132](https://github.com/bolteu/kalep/pull/132) [`0abb5c8`](https://github.com/bolteu/kalep/commit/0abb5c88f02bbf1677c867b1797d9d20cc4eb5c3) Thanks [@HenryStevens](https://github.com/HenryStevens)! - Dialog component

* [#150](https://github.com/bolteu/kalep/pull/150) [`3089114`](https://github.com/bolteu/kalep/commit/30891143d31e8efc93c89fdb06313b933438e43a) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Export TextArea and TextField props.

- [#138](https://github.com/bolteu/kalep/pull/138) [`8ade428`](https://github.com/bolteu/kalep/commit/8ade428f63cfdbc579047b3e002bd8875b7ac0f6) Thanks [@grasscut](https://github.com/grasscut)! - ProgressBar component & Stepper component, variant 'progress'

- Updated dependencies [[`8ade428`](https://github.com/bolteu/kalep/commit/8ade428f63cfdbc579047b3e002bd8875b7ac0f6), [`ea1de2d`](https://github.com/bolteu/kalep/commit/ea1de2d26c41d2c42380bfbb604609177aa22227)]:
  - @bolteu/kalep-tailwind@0.0.6

## 0.0.25

### Patch Changes

- [#146](https://github.com/bolteu/kalep/pull/146) [`5671f05`](https://github.com/bolteu/kalep/commit/5671f05145ea30d320963b9dc9521049a9f00c81) Thanks [@meikoudras](https://github.com/meikoudras)! - Add ref support for TextField component

## 0.0.24

### Patch Changes

- [#136](https://github.com/bolteu/kalep/pull/136) [`5014c06`](https://github.com/bolteu/kalep/commit/5014c069318cf7fee121ed244ff95daef9a45851) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Prevent custom icon resize on Alert.

* [#133](https://github.com/bolteu/kalep/pull/133) [`6683cb9`](https://github.com/bolteu/kalep/commit/6683cb9ea3af5fbe7e75ad592b300519977c7c46) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Make Clear button focusable in SearchTextField.

- [#129](https://github.com/bolteu/kalep/pull/129) [`2233c7f`](https://github.com/bolteu/kalep/commit/2233c7f798bc5ea9997f9a92f08b4bc1dfda5222) Thanks [@lelumees](https://github.com/lelumees)! - Breadcrumbs component

* [#130](https://github.com/bolteu/kalep/pull/130) [`af55fcc`](https://github.com/bolteu/kalep/commit/af55fcc41d1350ca0b0ffe4f8a8fabfeff157fae) Thanks [@grasscut](https://github.com/grasscut)! - define normal font weight for tooltip to prevent it from inheriting it from parent element

- [#141](https://github.com/bolteu/kalep/pull/141) [`32341c5`](https://github.com/bolteu/kalep/commit/32341c5265a9810d037b6ef768125cb9d2489af0) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Control open state for a Select.

* [#127](https://github.com/bolteu/kalep/pull/127) [`069cc00`](https://github.com/bolteu/kalep/commit/069cc00637ee4891a4af1c21e060e3b982f5ba71) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Multiple Select.

* Updated dependencies [[`f76a857`](https://github.com/bolteu/kalep/commit/f76a85793e1d351852288f1cba4ef060d06a4fe2)]:
  - @bolteu/kalep-react-icons@0.0.9

## 0.0.23

### Patch Changes

- [#119](https://github.com/bolteu/kalep/pull/119) [`0203df6`](https://github.com/bolteu/kalep/commit/0203df6ecbfe6e7a727fa1527ebfaa90fd6834e8) Thanks [@lelumees](https://github.com/lelumees)! - Added Menu component

* [#126](https://github.com/bolteu/kalep/pull/126) [`61109ee`](https://github.com/bolteu/kalep/commit/61109ee4880c06a526d5a2c8952fa042c5f2a9de) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Badge Component.

* Updated dependencies [[`18dee6a`](https://github.com/bolteu/kalep/commit/18dee6a04f5ac0fe2eeb3bf062c54866a6503ce9)]:
  - @bolteu/kalep-tailwind@0.0.5

## 0.0.22

### Patch Changes

- [#123](https://github.com/bolteu/kalep/pull/123) [`1173deb`](https://github.com/bolteu/kalep/commit/1173deb8647d16de4169a39256933d09d0bca58a) Thanks [@libahipi](https://github.com/libahipi)! - Add GhostButton component

## 0.0.21

### Patch Changes

- [#117](https://github.com/bolteu/kalep/pull/117) [`2e04975`](https://github.com/bolteu/kalep/commit/2e04975fddf1378d13b2fb1e5c92aeeb4fcb6927) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Fixes and code improvements for TextField, ComboBox and Select.

- Updated dependencies [[`6c04a3b`](https://github.com/bolteu/kalep/commit/6c04a3b46d4b00370d77fbbdc024162e08d12c88)]:
  - @bolteu/kalep-react-icons@0.0.8

## 0.0.20

### Patch Changes

- [#105](https://github.com/bolteu/kalep/pull/105) [`4339354`](https://github.com/bolteu/kalep/commit/4339354b586cccf8cbc48b086d89948509c0f5df) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Remove TextField hover styles.

## 0.0.19

### Patch Changes

- [#103](https://github.com/bolteu/kalep/pull/103) [`57b7279`](https://github.com/bolteu/kalep/commit/57b72793c17c162b7bee9bd087e6fddd24c719e5) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Alert component.

## 0.0.18

### Patch Changes

- [#101](https://github.com/bolteu/kalep/pull/101) [`32bf613`](https://github.com/bolteu/kalep/commit/32bf613c5dd3835f1719193785e167d740169d27) Thanks [@lelumees](https://github.com/lelumees)! - Implement Switch component

## 0.0.17

### Patch Changes

- [#92](https://github.com/bolteu/kalep/pull/92) [`8d6af1a`](https://github.com/bolteu/kalep/commit/8d6af1a06f0c95fa9818194c4041b64f1eab68e1) Thanks [@libahipi](https://github.com/libahipi)! - Apply negative margin to outer side of icons in Button

- Updated dependencies [[`9efb3a1`](https://github.com/bolteu/kalep/commit/9efb3a18c0192da4595373f94b6365e9066bb26f)]:
  - @bolteu/kalep-react-icons@0.0.7

## 0.0.16

### Patch Changes

- [#90](https://github.com/bolteu/kalep/pull/90) [`84fadce`](https://github.com/bolteu/kalep/commit/84fadce6201f162cfb5b4cb2951266a62a598fcf) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Fix TextField icon sizes.

## 0.0.15

### Patch Changes

- [#88](https://github.com/bolteu/kalep/pull/88) [`edcf8ef`](https://github.com/bolteu/kalep/commit/edcf8ef9e4014c1fa892b57471e7c8e112a5c2a4) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Visual and functional improvements for TextField.

* [#84](https://github.com/bolteu/kalep/pull/84) [`b7f4249`](https://github.com/bolteu/kalep/commit/b7f42499efadad303bada86980608e89929170a7) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Implement List component and use it in ComboBox and Select.

- [#87](https://github.com/bolteu/kalep/pull/87) [`9f6d9bf`](https://github.com/bolteu/kalep/commit/9f6d9bf2b0161bd9335272a7bd343b5ffdf9b663) Thanks [@silviuaavram](https://github.com/silviuaavram)! - TextArea component implementation.

## 0.0.14

### Patch Changes

- [#81](https://github.com/bolteu/kalep/pull/81) [`24f9cf8`](https://github.com/bolteu/kalep/commit/24f9cf8be462496b25351fa1dc846e4bb00cd7e3) Thanks [@silviuaavram](https://github.com/silviuaavram)! - ComboBox component implementation.

* [#80](https://github.com/bolteu/kalep/pull/80) [`a770eeb`](https://github.com/bolteu/kalep/commit/a770eeb30a241f41ec0eeb6698937dfdc32869e3) Thanks [@libahipi](https://github.com/libahipi)! - Add RadioGroup & Radio components

## 0.0.13

### Patch Changes

- [#79](https://github.com/bolteu/kalep/pull/79) [`abf0ff9`](https://github.com/bolteu/kalep/commit/abf0ff9c47b5e387f8b9a04cbf42906a9ad57330) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Export the Select component.

* [#72](https://github.com/bolteu/kalep/pull/72) [`60f343b`](https://github.com/bolteu/kalep/commit/60f343be5d804d0dc014e08fbd8c433164f9ec4e) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Kalep Select component and several TextField improvements

## 0.0.12

### Patch Changes

- [#74](https://github.com/bolteu/kalep/pull/74) [`3602b93`](https://github.com/bolteu/kalep/commit/3602b9325a6017edf1a7773b50066885a01790db) Thanks [@libahipi](https://github.com/libahipi)! - Add LinkButton component

* [#71](https://github.com/bolteu/kalep/pull/71) [`af5f54e`](https://github.com/bolteu/kalep/commit/af5f54e93aa6b767d931c30e3545e1edb207044f) Thanks [@libahipi](https://github.com/libahipi)! - Add Checkbox component

## 0.0.11

### Patch Changes

- [#66](https://github.com/bolteu/kalep/pull/66) [`8fff2d8`](https://github.com/bolteu/kalep/commit/8fff2d8e31453880a0213bb0967d2ba4d591c367) Thanks [@libahipi](https://github.com/libahipi)! - Fixes typescript issue with Button (required non-existent props)

## 0.0.10

### Patch Changes

- Updated dependencies [[`ed36e52`](https://github.com/bolteu/kalep/commit/ed36e52f300148b9f5a923808379272c5145a016)]:
  - @bolteu/kalep-tailwind@0.0.4

## 0.0.9

### Patch Changes

- [#61](https://github.com/bolteu/kalep/pull/61) [`a5fdf50`](https://github.com/bolteu/kalep/commit/a5fdf50479df0e471774387187be126ad4670781) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Support for the renderHelperText prop in TextField.

* [#60](https://github.com/bolteu/kalep/pull/60) [`91d39fa`](https://github.com/bolteu/kalep/commit/91d39fa489ca0e4536229bcb2e3c9d017f2aea29) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Fix Tooltip override of trigger keydown handlers.

* Updated dependencies [[`04968d6`](https://github.com/bolteu/kalep/commit/04968d643ae89613ecc7dacf8254360d1b8e86be)]:
  - @bolteu/kalep-react-icons@0.0.6

## 0.0.8

### Patch Changes

- [#57](https://github.com/bolteu/kalep/pull/57) [`aec20f9`](https://github.com/bolteu/kalep/commit/aec20f929a248e9df9522cf06eafdf487bc0c827) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Tooltip Base component.

* [#59](https://github.com/bolteu/kalep/pull/59) [`541f637`](https://github.com/bolteu/kalep/commit/541f637cc82c00609e1c7c0a60b2e1992c263af5) Thanks [@libahipi](https://github.com/libahipi)! - Add Tag component

## 0.0.7

### Patch Changes

- [#54](https://github.com/bolteu/kalep/pull/54) [`69bc4dd`](https://github.com/bolteu/kalep/commit/69bc4dd2bd5475fdc57ebd5c8076b5ca9be4b816) Thanks [@libahipi](https://github.com/libahipi)! - add KalepReactElement type alias

* [#55](https://github.com/bolteu/kalep/pull/55) [`e1fd47f`](https://github.com/bolteu/kalep/commit/e1fd47fe5e374f5e101b038214ab2d4b58f6b970) Thanks [@libahipi](https://github.com/libahipi)! - Add SpinnerIcon as a reusable component in the progress group

- [#53](https://github.com/bolteu/kalep/pull/53) [`942291a`](https://github.com/bolteu/kalep/commit/942291aa2b8dcfcbcae4968c3bac406c7afd2f12) Thanks [@libahipi](https://github.com/libahipi)! - Remove "xs" size option from Buttons and IconButtons

- Updated dependencies [[`69bc4dd`](https://github.com/bolteu/kalep/commit/69bc4dd2bd5475fdc57ebd5c8076b5ca9be4b816)]:
  - @bolteu/kalep-react-icons@0.0.5

## 0.0.6

### Patch Changes

- [#48](https://github.com/bolteu/kalep/pull/48) [`1db7778`](https://github.com/bolteu/kalep/commit/1db77780070f1af27bb4af8d3b167585e7703d99) Thanks [@libahipi](https://github.com/libahipi)! - Add built CSS to package

* [#47](https://github.com/bolteu/kalep/pull/47) [`d884699`](https://github.com/bolteu/kalep/commit/d884699582f8a7c2d6d86b34ef608c939895b429) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Add input element props to TextField

## 0.0.5

### Patch Changes

- [#38](https://github.com/bolteu/kalep/pull/38) [`90347e6`](https://github.com/bolteu/kalep/commit/90347e66e803e3e67b6a32c71c54466e8b1f1f78) Thanks [@silviuaavram](https://github.com/silviuaavram)! - TextField Search type.

* [#39](https://github.com/bolteu/kalep/pull/39) [`90a404b`](https://github.com/bolteu/kalep/commit/90a404b4ba8c4a9b7d80b3c028a72f11a855c3e0) Thanks [@libahipi](https://github.com/libahipi)! - Add IconButton component

- [#25](https://github.com/bolteu/kalep/pull/25) [`a1ba0ce`](https://github.com/bolteu/kalep/commit/a1ba0ce322a48f0a893de2042b501381293b9940) Thanks [@libahipi](https://github.com/libahipi)! - Add Button component

- Updated dependencies [[`609d2e6`](https://github.com/bolteu/kalep/commit/609d2e610d69e5b5f6d51376c4b5eef3c6191da0), [`4c72f19`](https://github.com/bolteu/kalep/commit/4c72f19033b804b04b82dee6fd038acec2c776a7)]:
  - @bolteu/kalep-react-icons@0.0.4

## 0.0.4

### Patch Changes

- Updated dependencies [[`eb67e5b`](https://github.com/bolteu/kalep/commit/eb67e5bb93d825cc51619e1ee380bef5f1ff70ca)]:
  - @bolteu/kalep-react-icons@0.0.3

## 0.0.3

### Patch Changes

- [#23](https://github.com/bolteu/kalep/pull/23) [`f97984b`](https://github.com/bolteu/kalep/commit/f97984b7a97d0e3f38223eb4d41eee8c1612adb0) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Additional TextField props: disabled, placeholder, id, helperText, label.

* [#18](https://github.com/bolteu/kalep/pull/18) [`7e8eae4`](https://github.com/bolteu/kalep/commit/7e8eae42a585c720c9f5f4f7878fa54499adcb17) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Textfield component styled according to the size prop.

* Updated dependencies [[`6e0d4fa`](https://github.com/bolteu/kalep/commit/6e0d4fa18f81911cf70723a22075a1f1edd9f0a6)]:
  - @bolteu/kalep-tailwind@0.0.3

## 0.0.2

### Patch Changes

- Updated dependencies [[`f7f5933`](https://github.com/bolteu/kalep/commit/f7f5933717c3a5e6fa5f40c988ee6c6522765915)]:
  - @bolteu/kalep-tailwind@0.0.2

## 0.0.1

### Patch Changes

- Updated dependencies [[`56eca97`](https://github.com/bolteu/kalep/commit/56eca972c3a534aafdfc23a4d307546ba173ea72), [`38dff80`](https://github.com/bolteu/kalep/commit/38dff808142e5905b5435be4c25cb4e716ed324b), [`22c490c`](https://github.com/bolteu/kalep/commit/22c490cc7529cffb090460915efa0ed9c23ff0a5)]:
  - @bolteu/kalep-tailwind@0.0.1
